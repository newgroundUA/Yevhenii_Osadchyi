import { downloadBlob } from 'download.js';

const withAuth = ({ api, method, url, fieldName, data }) =>
  api({
    method,
    url,
    data,
    fieldName,
  });

/**
 * Create request for downloading file.
 */
export const withAuthDownload = ({ api, method, url, fieldName, data, fileName = 'export.xls' }) =>
  api({
    method,
    url,
    data,
    fieldName,
    responseType: 'blob',
  }).then((resp) => {
    try {
      downloadBlob(fileName, resp.data);
    } catch (ex) {
      // console.log('Download file error:', ex);
    }

    return resp;
  });

export default withAuth;
