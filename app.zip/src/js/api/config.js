const env = process.env.NODE_ENV === 'production' ? 'prod' : 'dev';

const config = {
  dev: {
    // baseURL: 'http://localhost:8080/' // special for Pasha
    baseURL: 'devUrl/api/',
  },
  prod: {
    baseURL: '/api/',
  },
};

module.exports = config[env];
