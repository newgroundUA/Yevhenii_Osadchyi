import * as types from '../constants/actionTypes/AppConstants';

export const setValueAppSettings = (key, value) => ({
  type: types.SET_VALUE_APP_SETTINGS,
  key,
  value,
});

export const test = (key, value) => ({
  type: 'TEST',
  key,
  value,
});

export const getAppConfig = () => ({
  types: [
    types.LOAD_APP_CONFIG_REQUEST,
    types.LOAD_APP_CONFIG_SUCCESS,
    types.LOAD_APP_CONFIG_FAILURE,
  ],
  promise: (api) => api.get('properties'),
});
