import * as types from '../constants/actionTypes/ClassifiersConstants';
import * as config from '../api/config';
import withAuth from '../api/withAuth';
import mockClassifiers from '../models/classifiers/classifiers';

import { getUrlCreator, getClassifiersTypesByContainer } from '../helpers/classifiers';

const createUrl = getUrlCreator(config.baseUrl);

export const loadClassifiers = (classifiersNames, paramsMap, containerName = undefined) => ({
  classifiersNames,
  containerName,
  types: [
    types.LOAD_CLASSIFIERS_REQUEST,
    types.LOAD_CLASSIFIERS_SUCCESS,
    types.LOAD_CLASSIFIERS_FAILURE,
  ],
  promise: (api, apiAll) =>
    apiAll.all(
      classifiersNames.map((classifierName) => {
        const requestData = createUrl(classifierName, (paramsMap || {})[classifierName]);

        if (!requestData) {
          return new Promise((r) =>
            setTimeout(
              () =>
                r({
                  config: {
                    fieldName: classifierName,
                  },
                  data: mockClassifiers[classifierName] || [],
                }),
              1000,
            ),
          );
        }

        const request = {
          api,
          method: requestData.method || 'get',
          url: requestData.url || requestData,
          fieldName: classifierName,
        };

        if (requestData.body) {
          request.data = requestData.body;
        }

        return withAuth(request);
      }),
    ),
});
export function loadClassifiersForContainer(containerName, paramsMap) {
  const classifiersNames = getClassifiersTypesByContainer(containerName).filter(
    (el, i, arr) => arr.indexOf(el) === i,
  );
  return loadClassifiers(classifiersNames, paramsMap, containerName);
}

export function loadSpecifiedClassifiers(classifiersNames, paramsMap) {
  return {
    types: [
      types.LOAD_CLASSIFIERS_REQUEST,
      types.LOAD_CLASSIFIERS_SUCCESS,
      types.LOAD_CLASSIFIERS_FAILURE,
    ],
    promise: (api, apiAll) =>
      apiAll.all(
        classifiersNames.map((classifierName) => {
          const url = createUrl(classifierName, (paramsMap || {})[classifierName]);

          if (!url) {
            return new Promise((r) =>
              setTimeout(
                () =>
                  r({
                    data: {
                      [classifierName]: mockClassifiers[classifierName],
                    },
                  }),
                1000,
              ),
            );
          }

          return withAuth({
            api,
            method: 'get',
            url,
            fieldName: classifierName,
          });
        }),
      ),
  };
}

export function loadSingleClassifier(name, params) {
  return loadSpecifiedClassifiers([name], { [name]: params });
}

/*
  Очистить классификаторы
*/
export const clearClassifiers = (classifiers) => ({
  type: types.CLEAR_CLASSIFIERS,
  data: classifiers,
});

export const loadLiveSearchKvedClassifier = (params) => ({
  types: [
    types.LOAD_KVED_LIVE_SEARCH_CLASSIFIER_REQUEST,
    types.LOAD_KVED_LIVE_SEARCH_CLASSIFIER_SUCCESS,
    types.LOAD_KVED_LIVE_SEARCH_CLASSIFIER_FAILURE,
  ],
  promise: (api) =>
    withAuth({
      api,
      method: 'get',
      url: `CLASSIFIER/KVED/liveSearch/${params.search}`,
    }),
});
