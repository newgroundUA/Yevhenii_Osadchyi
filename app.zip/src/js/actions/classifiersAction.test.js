import * as api from '../api/config';
import request from '../helpers/utils/request';

describe('Testing classifiers:', () => {
  beforeAll(async () => {
    const ls = require('../helpers/utils/localStorage.js');
    ls.setLocalStorage();
    const login = 'systemUser__1';
    const password = 'systemUser__1';
    await request(`${api.baseUrl}/login?login=${login}&password=${password}`).then((res) => {
      localStorage.setItem('token', res);
      return res;
    });
  });

  it('Should localStorage have token', () => {
    expect(localStorage.getItem('token').length).toBeGreaterThan(0);
  });

  // it('Should be tested EMAIL_TYPE on expected object on FE', async () => {
  //   const config = {
  //     url: `${api.baseUrl}/CLASSIFIER/EMAIL_TYPE`,
  //     headers: { 'X-AUTH-TOKEN': localStorage.getItem('token') }
  //   };

  //   const expected = {
  //     dateFrom: null,
  //     dateTo: null,
  //     description: expect.any(String),
  //     guid: expect.any(String),
  //     name: expect.any(String),
  //     shortName: expect.any(String)
  //   };

  //   const req = await request(config);
  //   expect(req.result.statusCode).toEqual(200);
  //   expect(req.data.length).toBeGreaterThan(0);
  //   expect(req.data[0]).toEqual(expect.objectContaining(expected));
  // });

  // it('Should be tested PHONE_TYPE on expected object on FE', async () => {
  //   const config = {
  //     url: `${api.baseUrl}/CLASSIFIER/PHONE_TYPE`,
  //     headers: { 'X-AUTH-TOKEN': localStorage.getItem('token') }
  //   };

  //   const expected = {
  //     dateFrom: null,
  //     dateTo: null,
  //     description: expect.any(String),
  //     guid: expect.any(String),
  //     name: expect.any(String),
  //     shortName: expect.any(String)
  //   };

  //   const req = await request(config);
  //   expect(req.result.statusCode).toEqual(200);
  //   expect(req.data.length).toBeGreaterThan(0);
  //   expect(req.data[0]).toEqual(expect.objectContaining(expected));
  // });

  // it('Should be tested KVED_ACTIVITY_TYPE on expected object on FE', async () => {
  //   const config = {
  //     url: `${api.baseUrl}/CLASSIFIER/KVED_ACTIVITY_TYPE`,
  //     headers: { 'X-AUTH-TOKEN': localStorage.getItem('token') }
  //   };

  //   const expected = {
  //     dateFrom: expect.any(String),
  //     dateTo: null,
  //     description: null,
  //     guid: expect.any(String),
  //     name: expect.any(String),
  //     shortName: null
  //   };

  //   const req = await request(config);
  //   expect(req.result.statusCode).toEqual(200);
  //   expect(req.data.length).toBeGreaterThan(0);
  //   expect(req.data[0]).toEqual(expect.objectContaining(expected));
  // });

  // it('Should be tested SKODU_BODY_TYPE on expected object on FE', async () => {
  //   const config = {
  //     url: `${api.baseUrl}/CLASSIFIER/SKODU_BODY_TYPE`,
  //     headers: { 'X-AUTH-TOKEN': localStorage.getItem('token') }
  //   };

  //   const expected = {
  //     dateFrom: null,
  //     dateTo: null,
  //     description: null,
  //     guid: expect.any(String),
  //     name: expect.any(String),
  //     shortName: expect.any(String)
  //   };

  //   const req = await request(config);
  //   expect(req.result.statusCode).toEqual(200);
  //   expect(req.data.length).toBeGreaterThan(0);
  //   expect(req.data[0]).toEqual(expect.objectContaining(expected));
  // });

  // it('Should be tested KOPFG_FORM_TYPE on expected object on FE', async () => {
  //   const config = {
  //     url: `${api.baseUrl}/CLASSIFIER/KOPFG_FORM_TYPE`,
  //     headers: {
  //       'X-AUTH-TOKEN': localStorage.getItem('token')
  //     }
  //   };

  //   const expected = {
  //     dateFrom: expect.any(String),
  //     dateTo: null,
  //     description: expect.any(String),
  //     guid: expect.any(String),
  //     name: expect.any(String),
  //     shortName: null
  //   };

  //   const req = await request(config);
  //   expect(req.result.statusCode).toEqual(200);
  //   expect(req.data.length).toBeGreaterThan(0);
  //   expect(req.data[0]).toEqual(expect.objectContaining(expected));
  // });
});
