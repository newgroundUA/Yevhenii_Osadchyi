import * as types from '../constants/actionTypes/UserConstants';
import withAuth from '../api/withAuth';
import { createStringReqParams } from '../helpers/createReqParams';
import { getClientID, getRefreshToken } from '../helpers/OAuth2Service';

export const postLogin = (data) => ({
  types: [types.POST_LOGIN_REQUEST, types.POST_LOGIN_SUCCESS, types.POST_LOGIN_FAILURE],
  promise: (api) => api.post('login', data),
  isAuthRequest: true, // should be for midleware
});

export const getSelfCounterparty = (token) => ({
  types: [
    types.GET_SELF_COUNTERPARTY_REQUEST,
    types.GET_SELF_COUNTERPARTY_SUCCESS,
    types.GET_SELF_COUNTERPARTY_FAILURE,
  ],
  promise: (api) =>
    api.get('self-couterparty', {
      headers: {
        Authorization: token,
      },
    }),
  isAuthRequest: true, // should be for midleware
});

export const postLoginStep2 = (data, token) => ({
  types: [
    types.POST_LOGIN_STEP_2_REQUEST,
    types.POST_LOGIN_STEP_2_SUCCESS,
    types.POST_LOGIN_STEP_2_FAILURE,
  ],
  promise: (api) =>
    api.post(
      `authorize/second-step${createStringReqParams(data)}`,
      {},
      {
        headers: {
          Authorization: token,
        },
      },
    ),
  clientId: data.clientId,
  isAuthRequest: true, // should be for midleware
});

export const postRefreshToken = (
  data = {
    clientId: getClientID(),
    refresh: getRefreshToken(),
  },
) => ({
  types: [
    types.POST_REFRRESH_TOKEN_REQUEST,
    types.POST_REFRRESH_TOKEN_SUCCESS,
    types.POST_REFRRESH_TOKEN_FAILURE,
  ],
  promise: (api) => api.post(`refresh${createStringReqParams(data)}`),
  isAuthRequest: true, // should be for midleware
});

export const doLogOut = () => ({
  types: [types.GET_LOG_OUT_REQUEST, types.GET_LOG_OUT_SUCCESS, types.GET_LOG_OUT_FAILURE],
  promise: (api) => withAuth({ api, method: 'get', url: 'user-logout' }),
});

export const postUserAppSettings = (data) => ({
  types: [
    types.POST_USER_APP_SETTINGS_REQUEST,
    types.POST_USER_APP_SETTINGS_SUCCESS,
    types.POST_USER_APP_SETTINGS_FAILURE,
  ],
  promise: (api) => withAuth({ api, method: 'post', url: 'uisettings/', data }),
});

export const putUserAppSettings = (data) => ({
  types: [
    types.PUT_USER_APP_SETTINGS_REQUEST,
    types.PUT_USER_APP_SETTINGS_SUCCESS,
    types.PUT_USER_APP_SETTINGS_FAILURE,
  ],
  promise: (api) => withAuth({ api, method: 'put', url: 'uisettings/', data }),
});

export const getUserAppSettings = (userAccountGuid, key) => ({
  types: [
    types.GET_USER_APP_SETTINGS_REQUEST,
    types.GET_USER_APP_SETTINGS_SUCCESS,
    types.GET_USER_APP_SETTINGS_FAILURE,
  ],
  promise: (api) =>
    withAuth({ api, method: 'get', url: `uisettings/${userAccountGuid}/${key.join('')}` }),
  userAccountGuid,
  key,
});

export const setUserIsAuth = (status) => ({
  type: types.SET_USER_IS_AUTH,
  status,
});

export const resetUserInfo = () => ({
  type: types.RESET_USER_INFO,
});
