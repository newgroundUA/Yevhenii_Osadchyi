import * as types from '../../../constants/actionTypes/documents/DocumentsConstants';
import withAuth from '../../../api/withAuth';

export const getContests = (guid, storeKey) => ({
  types: [types.GET_CONTESTS_REQUEST, types.GET_CONTESTS_SUCCESS, types.GET_CONTESTS_FAILURE],
  promise: (api) => withAuth({ api, method: 'get', url: `competitionProtocol/get/${guid}` }),
  storeKey,
});

export const postContests = (data, storeKey, ignoreStatus) => ({
  types: [types.POST_CONTESTS_REQUEST, types.POST_CONTESTS_SUCCESS, types.POST_CONTESTS_FAILURE],
  promise: (api) => withAuth({ api, method: 'post', url: 'competitionProtocol/', data }),
  storeKey,
  ignoreStatus,
});

export const putContests = (data, storeKey, ignoreStatus) => ({
  types: [types.PUT_CONTESTS_REQUEST, types.PUT_CONTESTS_SUCCESS, types.PUT_CONTESTS_FAILURE],
  promise: (api) => withAuth({ api, method: 'put', url: 'competitionProtocol/', data }),
  storeKey,
  ignoreStatus,
});

export const resetContestsForm = (storeKey) => ({
  type: types.RESET_CONTESTS_FORM,
  storeKey,
});

export const resetContestsDoneStatus = (storeKey) => ({
  type: types.RESET_CONTESTS_DONE_STATUS,
  storeKey,
});

export const getContestMember = (guid, storeKey) => ({
  types: [
    types.GET_CONTEST_MEMBER_REQUEST,
    types.GET_CONTEST_MEMBER_SUCCESS,
    types.GET_CONTEST_MEMBER_FAILURE,
  ],
  promise: (api) => withAuth({ api, method: 'get', url: `compMemberList/get/${guid}` }),
  storeKey,
});

export const postContestMember = (data, storeKey) => ({
  types: [
    types.POST_CONTEST_MEMBER_REQUEST,
    types.POST_CONTEST_MEMBER_SUCCESS,
    types.POST_CONTEST_MEMBER_FAILURE,
  ],
  promise: (api) => withAuth({ api, method: 'post', url: 'compMemberList/', data }),
  storeKey,
});

export const putContestMember = (data, storeKey) => ({
  types: [
    types.PUT_CONTEST_MEMBER_REQUEST,
    types.PUT_CONTEST_MEMBER_SUCCESS,
    types.PUT_CONTEST_MEMBER_FAILURE,
  ],
  promise: (api) => withAuth({ api, method: 'put', url: 'compMemberList/', data }),
  storeKey,
});

export const bindDocToContestsDocument = (fieldName, data) => ({
  type: types.BIND_DOC_TO_CONTESTS_DOCUMENT,
  fieldName,
  data,
});

export const lockDocToContestsDocument = (data) => ({
  type: types.LOCK_DOC_TO_CONTESTS_DOCUMENT,
  data,
});
