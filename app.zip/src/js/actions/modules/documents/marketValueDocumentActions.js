import * as types from '../../../constants/actionTypes/documents/DocumentsConstants';

export const postMarketValueDocument = (data, storeKey) => ({
  storeKey,
  types: [
    types.POST_MARKET_VALUE_DOCUMENT_REQUEST,
    types.POST_MARKET_VALUE_DOCUMENT_SUCCESS,
    types.POST_MARKET_VALUE_DOCUMENT_FAILURE,
  ],
  promise: (api) => api.post('document/market_price_detect/', data),
});

export const putMarketValueDocument = (data, storeKey, ignoreStatus) => ({
  ignoreStatus,
  storeKey,
  types: [
    types.PUT_MARKET_VALUE_DOCUMENT_REQUEST,
    types.PUT_MARKET_VALUE_DOCUMENT_SUCCESS,
    types.PUT_MARKET_VALUE_DOCUMENT_FAILURE,
  ],
  promise: (api) => api.put('document/market_price_detect/', data),
});

export const getMarketValueDocument = (guid, storeKey) => ({
  storeKey,
  types: [
    types.GET_MARKET_VALUE_DOCUMENT_REQUEST,
    types.GET_MARKET_VALUE_DOCUMENT_SUCCESS,
    types.GET_MARKET_VALUE_DOCUMENT_FAILURE,
  ],
  promise: (api) => api.get(`document/market_price_detect/get/${guid}`),
});

export const resetMarketValueDocumentForm = (storeKey) => ({
  storeKey,
  type: types.RESET_MARKET_VALUE_DOCUMENT_FORM,
});

export const resetMarketValueDocumentDoneStatus = (storeKey) => ({
  storeKey,
  type: types.RESET_MARKET_VALUE_DOCUMENT_DONE_STATUS,
});

export const postAccountingItemWithMarketPrice = (data, storeKey) => ({
  storeKey,
  types: [
    types.POST_ACCOUNTING_ITEM_WITH_MARKET_PRICE_REQUEST,
    types.POST_ACCOUNTING_ITEM_WITH_MARKET_PRICE_SUCCESS,
    types.POST_ACCOUNTING_ITEM_WITH_MARKET_PRICE_FAILURE,
  ],
  promise: (api) => api.post('document/account_item_with_market_price/', data),
});

export const putAccountingItemWithMarketPrice = (data, storeKey) => ({
  storeKey,
  types: [
    types.PUT_ACCOUNTING_ITEM_WITH_MARKET_PRICE_REQUEST,
    types.PUT_ACCOUNTING_ITEM_WITH_MARKET_PRICE_SUCCESS,
    types.PUT_ACCOUNTING_ITEM_WITH_MARKET_PRICE_FAILURE,
  ],
  promise: (api) => api.put('document/account_item_with_market_price/', data),
});

export const deleteAccountingItemWithMarketPrice = (guid, storeKey) => ({
  storeKey,
  types: [
    types.DELETE_ACCOUNTING_ITEM_WITH_MARKET_PRICE_REQUEST,
    types.DELETE_ACCOUNTING_ITEM_WITH_MARKET_PRICE_SUCCESS,
    types.DELETE_ACCOUNTING_ITEM_WITH_MARKET_PRICE_FAILURE,
  ],
  promise: (api) => api.delete(`document/account_item_with_market_price/${guid}`),
});

export const bindDocToMarketValueDocument = (fieldName, data) => ({
  type: types.BIND_DOC_TO_MARKET_VALUE_DOCUMENT,
  fieldName,
  data,
});

export const lockDocToMarketValueDocument = (data) => ({
  type: types.LOCK_DOC_TO_MARKET_VALUE_DOCUMENT,
  data,
});
