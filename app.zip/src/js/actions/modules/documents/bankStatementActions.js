import * as types from '../../../constants/actionTypes/documents/BankStatementConstants';

export const getBankStatement = (guid, storeKey) => ({
  storeKey,
  types: [
    types.GET_BANK_STATEMENT_REQUEST,
    types.GET_BANK_STATEMENT_SUCCESS,
    types.GET_BANK_STATEMENT_FAILURE,
  ],
  promise: (api) => api.get(`document/bankStatement/get/${guid}`),
});

export const putCalculatePenalty = (guid, storeKey) => ({
  storeKey,
  types: [
    types.PUT_CALCULATE_PENALTY_REQUEST,
    types.PUT_CALCULATE_PENALTY_SUCCESS,
    types.PUT_CALCULATE_PENALTY_FAILURE,
  ],
  promise: (api) => api.put(`lease/leasecontract/calculate/${guid}`),
});

export const postBankStatement = (data, storeKey) => ({
  storeKey,
  types: [
    types.POST_BANK_STATEMENT_REQUEST,
    types.POST_BANK_STATEMENT_SUCCESS,
    types.POST_BANK_STATEMENT_FAILURE,
  ],
  promise: (api) => api.post('document/bankStatement/', data),
});

export const putBankStatement = (data, storeKey, ignoreStatus) => ({
  storeKey,
  ignoreStatus,
  types: [
    types.PUT_BANK_STATEMENT_REQUEST,
    types.PUT_BANK_STATEMENT_SUCCESS,
    types.PUT_BANK_STATEMENT_FAILURE,
  ],
  promise: (api) => api.put('document/bankStatement/', data),
});

export const resetBankStatementForm = () => ({
  type: types.RESET_BANK_STATEMENT_FORM,
});

export const setReceivedMoneyList = (data) => ({
  type: types.SET_RECEIVED_MONEY_LIST,
  data,
});

export const resetBankStatementDoneStatus = () => ({
  type: types.RESET_BANK_STATEMENT_DONE_STATUS,
});

// SentMoney

export const postSentMoney = (data, storeKey) => ({
  storeKey,
  types: [
    types.POST_SENT_MONEY_REQUEST,
    types.POST_SENT_MONEY_SUCCESS,
    types.POST_SENT_MONEY_FAILURE,
  ],
  promise: (api) => api.post('document/sentMoneyList/', data),
});

export const putSentMoney = (data, storeKey) => ({
  storeKey,
  types: [types.PUT_SENT_MONEY_REQUEST, types.PUT_SENT_MONEY_SUCCESS, types.PUT_SENT_MONEY_FAILURE],
  promise: (api) => api.put('document/sentMoneyList/', data),
});

// ReceivedMoney

export const postReceivedMoney = (data, storeKey) => ({
  storeKey,
  types: [
    types.POST_RECEIVED_MONEY_REQUEST,
    types.POST_RECEIVED_MONEY_SUCCESS,
    types.POST_RECEIVED_MONEY_FAILURE,
  ],
  promise: (api) => api.post('document/receivedMoneyList/', data),
});

export const putReceivedMoney = (data, storeKey) => ({
  storeKey,
  types: [
    types.PUT_RECEIVED_MONEY_REQUEST,
    types.PUT_RECEIVED_MONEY_SUCCESS,
    types.PUT_RECEIVED_MONEY_FAILURE,
  ],
  promise: (api) => api.put('document/receivedMoneyList/', data),
});

export const deleteReceivedMoney = (guid, storeKey) => ({
  storeKey,
  types: [
    types.DELETE_RECEIVED_MONEY_REQUEST,
    types.DELETE_RECEIVED_MONEY_SUCCESS,
    types.DELETE_RECEIVED_MONEY_FAILURE,
  ],
  promise: (api) => api.delete(`document/receivedMoneyList/${guid}`),
});

// SentPayment

export const postSentPayment = (data, storeKey) => ({
  storeKey,
  types: [
    types.POST_SENT_PAYMENT_REQUEST,
    types.POST_SENT_PAYMENT_SUCCESS,
    types.POST_SENT_PAYMENT_FAILURE,
  ],
  promise: (api) => api.post('document/sentPaymentToPurposeList/', data),
});

export const putSentPayment = (data, storeKey) => ({
  types: [
    types.PUT_SENT_PAYMENT_REQUEST,
    types.PUT_SENT_PAYMENT_SUCCESS,
    types.PUT_SENT_PAYMENT_FAILURE,
  ],
  storeKey,
  promise: (api) => api.put('document/sentPaymentToPurposeList/', data),
});

// ReceivedPayment

export const postReceivedPayment = (data, storeKey) => ({
  types: [
    types.POST_RECEIVED_PAYMENT_REQUEST,
    types.POST_RECEIVED_PAYMENT_SUCCESS,
    types.POST_RECEIVED_PAYMENT_FAILURE,
  ],
  storeKey,
  promise: (api) => api.post('document/receivedPaymentToPurposeList/', data),
});

export const putReceivedPayment = (data, storeKey) => ({
  types: [
    types.PUT_RECEIVED_PAYMENT_REQUEST,
    types.PUT_RECEIVED_PAYMENT_SUCCESS,
    types.PUT_RECEIVED_PAYMENT_FAILURE,
  ],
  storeKey,
  promise: (api) => api.put('document/receivedPaymentToPurposeList/', data),
});

export const deleteReceivedPayment = (data, storeKey) => ({
  types: [
    types.DELETE_RECEIVED_PAYMENT_REQUEST,
    types.DELETE_RECEIVED_PAYMENT_SUCCESS,
    types.DELETE_RECEIVED_PAYMENT_FAILURE,
  ],
  storeKey,
  promise: (api) => api.delete(`document/receivedPaymentToPurposeList/${data.guid}`),
});

export const bindDocToBankStatementDocument = (fieldName, data) => ({
  type: types.BIND_DOC_TO_BANK_STATEMENT_DOCUMENT,
  fieldName,
  data,
});

export const lockDocToBankStatementDocument = (data) => ({
  type: types.LOCK_DOC_TO_BANK_STATEMENT_DOCUMENT,
  data,
});
