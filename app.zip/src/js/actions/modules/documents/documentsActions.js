import * as types from '../../../constants/actionTypes/documents/DocumentsConstants';
import withAuth, { withAuthDownload } from '../../../api/withAuth';
import { createParams, createStringReqParams } from '../../../helpers/createReqParams';

export const mountDocumentModal = (key) => ({
  type: types.MOUNT_DOCUMENTS_DROPDOWN,
  key,
});

export const unmountDocumentModal = (key) => ({
  type: types.UNMOUNT_DOCUMENTS_DROPDOWN,
  key,
});

export const liveLoadDocuments = (key, searchTerm, documentType = null) => ({
  key,
  types: [
    types.LIVE_LOAD_DOCUMENTS_REQUEST,
    types.LIVE_LOAD_DOCUMENTS_SUCCESS,
    types.LIVE_LOAD_DOCUMENTS_FAILURE,
  ],
  promise: (api) =>
    api.get(
      `document/live_search/${searchTerm}/${createStringReqParams({
        limit: '30',
        offset: '0',
        documentType,
      })}`,
    ),
});

export const loadDocuments = (data) => ({
  types: [
    types.LOAD_GET_DOCUMENTS_REQUEST,
    types.LOAD_GET_DOCUMENTS_SUCCESS,
    types.LOAD_GET_DOCUMENTS_FAILURE,
  ],
  promise: (api) => api.post('document/registry/get', createParams(data)),
});

export const loadDocumentsTypeEnum = () => ({
  types: [
    types.LOAD_DOCUMENTS_TYPE_ENUM_REQUEST,
    types.LOAD_DOCUMENTS_TYPE_ENUM_SUCCESS,
    types.LOAD_DOCUMENTS_TYPE_ENUM_FAILURE,
  ],
  promise: (api) => api.get('CLASSIFIER/CATALOG/DOCUMENT_TYPE_ENUM'),
});

export const setValueRequestBody = (key, value) => ({
  type: types.SET_DOCUMENTS_VALUE_REQUEST_BODY,
  key,
  value,
});

export const setValuePages = (key, value) => ({
  type: types.SET_DOCUMENTS_VALUE_PAGES,
  key,
  value,
});

export const resetDocumentsForm = () => ({
  type: types.RESET_DOCUMENTS_FORM,
});

// html editor

export const resetHtmlDocument = () => ({
  type: types.RESET_HTML_DOCUMENT,
});

export const loadFileLinks = (/* documentGUID */) => ({
  // use it next time
  types: [
    types.LOAD_FILE_LINKS_REQUEST,
    types.LOAD_FILE_LINKS_SUCCESS,
    types.LOAD_FILE_LINKS_FAILURE,
  ],
  promise: (api, apiAll) =>
    apiAll.all([
      withAuth({
        api,
        method: 'get',
        url: 'lease/leasecontract/editor/get/primaryOriginals',
        fieldName: 'originals',
      }),
      withAuth({
        api,
        method: 'get',
        url: 'lease/leasecontract/editor/get/derivativeOriginals',
        fieldName: 'copies',
      }),
    ]),
});

export const loadTemplateLinks = (/* documentTypeGUID */) => ({
  // one of the classifiers
  types: [
    types.LOAD_TEMPLATE_LINKS_REQUEST,
    types.LOAD_TEMPLATE_LINKS_SUCCESS,
    types.LOAD_TEMPLATE_LINKS_FAILURE,
  ],
  promise: (api) => api.get('lease/leasecontract/editor/get/patternLinks'),
});

export const loadEditorDocumentFile = (documentFileLink, version) => ({
  types: [
    types.LOAD_EDITOR_DOCUMENT_FILE_REQUEST,
    types.LOAD_EDITOR_DOCUMENT_FILE_SUCCESS,
    types.LOAD_EDITOR_DOCUMENT_FILE_FAILURE,
  ],
  promise: (api) =>
    withAuth({
      api,
      method: 'post',
      url: 'lease/leasecontract/editor/download',
      responseType: 'blob',
      data: {
        fileExtension: 'htm',
        fileLink: documentFileLink,
        version,
      },
    }),
});

export const postEditorDocumentFile = ({ fileLink, version }, fileName, leaseContractGuid) => ({
  types: [
    types.POST_EDITOR_DOCUMENT_FILE_REQUEST,
    types.POST_EDITOR_DOCUMENT_FILE_SUCCESS,
    types.POST_EDITOR_DOCUMENT_FILE_FAILURE,
  ],
  promise: (api) =>
    withAuth({
      api,
      method: 'post',
      url: `lease/leasecontract/editor/generateOriginal/${leaseContractGuid}`,
      data: {
        fileLink,
        version,
        fileExtension: 'vm',
        fileName,
      },
    }),
});

export const putEditorDocumentFile = (fullDocumentLink, html) => {
  const data = new FormData();

  const fileData = {
    fileParam: 'file',
    primaryFileStorageGuid: fullDocumentLink.primaryFileStorageGuid,
  };

  if (fullDocumentLink.version) {
    fileData.fileId = fullDocumentLink.fileLink;
    fileData.version = fullDocumentLink.version;
  }

  data.append(
    'file',
    new File([new Blob([html], { type: 'text/plain' })], fullDocumentLink.fileName),
  ); // put here correct name in future
  data.append('saveDocument', JSON.stringify(fileData));

  return {
    types: [
      types.PUT_EDITOR_DOCUMENT_FILE_REQUEST,
      types.PUT_EDITOR_DOCUMENT_FILE_SUCCESS,
      types.PUT_EDITOR_DOCUMENT_FILE_FAILURE,
    ],
    promise: (api) =>
      withAuth({
        api,
        method: 'post',
        url: 'lease/leasecontract/editor/save',
        data,
        headers: { 'Content-Type': '' },
      }),
  };
};

export const exportPDF = (data) => ({
  types: [
    types.EXPORT_PDF_EDITOR_DOCUMENT_FILE_REQUEST,
    types.EXPORT_PDF_EDITOR_DOCUMENT_FILE_SUCCESS,
    types.EXPORT_PDF_EDITOR_DOCUMENT_FILE_FAILURE,
  ],
  promise: (api) =>
    withAuthDownload({
      api,
      method: 'post',
      url: 'lease/leasecontract/editor/export',
      data,
      fileName: /(htm)$/i.test(data.fileName)
        ? data.fileName.replace(/(htm)$/i, 'pdf')
        : `${data.fileName}.pdf`,
    }),
});

export const loadDocumentsByArrayGuids = (data) => ({
  types: [
    types.LOAD_GET_DOCUMENTS_BY_ARRAY_GUIDS_REQUEST,
    types.LOAD_GET_DOCUMENTS_BY_ARRAY_GUIDS_SUCCESS,
    types.LOAD_GET_DOCUMENTS_BY_ARRAY_GUIDS_FAILURE,
  ],
  promise: (api) => api.post('document/ids', data),
});
