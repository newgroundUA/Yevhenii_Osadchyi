import * as types from '../../../constants/actionTypes/documents/DocumentsConstants';

export const createFileTag = (data) => ({
  types: [types.POST_FILE_TAG_REQUEST, types.POST_FILE_TAG_SUCCESS, types.POST_FILE_TAG_FAILURE],
  promise: (api) => api.post('file-tag/', data),
});

export const liveSearchFileTags = (value) => ({
  types: [
    types.LOAD_LIVE_SEARCH_FILE_TAGS_REQUEST,
    types.LOAD_LIVE_SEARCH_FILE_TAGS_SUCCESS,
    types.LOAD_LIVE_SEARCH_FILE_TAGS_FAILURE,
  ],
  promise: (api) => api.get(`file-tag/live_search/${value}?offset=0&limit=30`),
});
