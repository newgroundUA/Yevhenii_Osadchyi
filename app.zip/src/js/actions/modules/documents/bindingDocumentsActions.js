import * as types from '../../../constants/actionTypes/documents/DocumentsConstants';

export const bindDocument = (data) => ({
  types: [
    types.POST_BIND_DOCUMENT_REQUEST,
    types.POST_BIND_DOCUMENT_SUCCESS,
    types.POST_BIND_DOCUMENT_FAILURE,
  ],
  promise: (api) => api.post('/document/bind_docs', data),
});

export const liveSearchDocuments = (data) => ({
  types: [
    types.LOAD_LIVE_SEARCH_DOCUMENTS_REQUEST,
    types.LOAD_LIVE_SEARCH_DOCUMENTS_SUCCESS,
    types.LOAD_LIVE_SEARCH_DOCUMENTS_FAILURE,
  ],
  promise: (api) => api.post('document/live_search/get', data),
});
