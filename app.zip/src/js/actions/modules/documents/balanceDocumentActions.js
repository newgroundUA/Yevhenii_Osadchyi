import * as types from '../../../constants/actionTypes/documents/DocumentsConstants';

export const resetBalanceDocumentForm = (storeKey) => ({
  type: types.RESET_DOCUMENT_BALANCE_FORM,
  storeKey,
});

export const getBalance = (guid, storeKey) => ({
  types: [
    types.GET_DOCUMENT_BALANCE_REQUEST,
    types.GET_DOCUMENT_BALANCE_SUCCESS,
    types.GET_DOCUMENT_BALANCE_FAILURE,
  ],
  promise: (api) => api.get(`document/account_item_receipt_act/get/${guid}`),
  storeKey,
});

export const postBalance = (data, storeKey, ignoreStatus) => ({
  types: [
    types.POST_DOCUMENT_BALANCE_REQUEST,
    types.POST_DOCUMENT_BALANCE_SUCCESS,
    types.POST_DOCUMENT_BALANCE_FAILURE,
  ],
  promise: (api) => api.post('document/account_item_receipt_act/', data),
  storeKey,
  ignoreStatus,
});

export const putBalance = (data, storeKey, ignoreStatus) => ({
  types: [
    types.PUT_DOCUMENT_BALANCE_REQUEST,
    types.PUT_DOCUMENT_BALANCE_SUCCESS,
    types.PUT_DOCUMENT_BALANCE_FAILURE,
  ],
  promise: (api) => api.put('document/account_item_receipt_act/', data),
  storeKey,
  ignoreStatus,
});

export const getBalanceDetail = (guid, storeKey) => ({
  types: [
    types.GET_DOCUMENT_BALANCE_DETAIL_REQUEST,
    types.GET_DOCUMENT_BALANCE_DETAIL_SUCCESS,
    types.GET_DOCUMENT_BALANCE_DETAIL_FAILURE,
  ],
  promise: (api) => api.get(`document/account_item_list/findLastActive/${guid}`),
  storeKey,
});

export const postBalanceDetail = (data, storeKey) => ({
  types: [
    types.POST_DOCUMENT_BALANCE_DETAIL_REQUEST,
    types.POST_DOCUMENT_BALANCE_DETAIL_SUCCESS,
    types.POST_DOCUMENT_BALANCE_DETAIL_FAILURE,
  ],
  promise: (api) => api.post('document/account_item_list/', data),
  storeKey,
});

export const putBalanceDetail = (data, storeKey) => ({
  types: [
    types.PUT_DOCUMENT_BALANCE_DETAIL_REQUEST,
    types.PUT_DOCUMENT_BALANCE_DETAIL_SUCCESS,
    types.PUT_DOCUMENT_BALANCE_DETAIL_FAILURE,
  ],
  promise: (api) => api.put('document/account_item_list/', data),
  storeKey,
});

export const deleteBalanceDetail = (guid, storeKey) => ({
  types: [
    types.DELETE_DOCUMENT_BALANCE_DETAIL_REQUEST,
    types.DELETE_DOCUMENT_BALANCE_DETAIL_SUCCESS,
    types.DELETE_DOCUMENT_BALANCE_DETAIL_FAILURE,
  ],
  promise: (api) => api.delete(`document/account_item_list/${guid}`),
  storeKey,
});

export const resetBalanceDocumentDoneStatus = (storeKey) => ({
  type: types.RESET_BALANCE_FORM_DONE_STATUS,
  storeKey,
});

export const bindDocToBalanceDocument = (fieldName, data) => ({
  type: types.BIND_DOC_TO_DOCUMENT_BALANCE,
  fieldName,
  data,
});

export const lockDocToBalanceDocument = (data) => ({
  type: types.LOCK_DOC_TO_DOCUMENT_BALANCE,
  data,
});
