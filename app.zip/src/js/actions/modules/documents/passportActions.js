import * as types from '../../../constants/actionTypes/documents/DocumentsConstants';

export const postPassportDocument = (data, storeKey) => ({
  types: [
    types.POST_PASSPORT_DOCUMENT_REQUEST,
    types.POST_PASSPORT_DOCUMENT_SUCCESS,
    types.POST_PASSPORT_DOCUMENT_FAILURE,
  ],
  storeKey,
  promise: (api) => api.post('document/personPassport/', data),
});

export const putPassportDocument = (data, storeKey, ignoreStatus) => ({
  types: [
    types.PUT_PASSPORT_DOCUMENT_REQUEST,
    types.PUT_PASSPORT_DOCUMENT_SUCCESS,
    types.PUT_PASSPORT_DOCUMENT_FAILURE,
  ],
  storeKey,
  ignoreStatus,
  promise: (api) => api.put('document/personPassport/', data),
});

export const getPassportDocument = (guid, storeKey) => ({
  types: [
    types.GET_PASSPORT_DOCUMENT_REQUEST,
    types.GET_PASSPORT_DOCUMENT_SUCCESS,
    types.GET_PASSPORT_DOCUMENT_FAILURE,
  ],
  storeKey,
  promise: (api) => api.get(`document/personPassport/get/${guid}`),
});

export const resetPassportDocumentForm = (storeKey) => ({
  type: types.RESET_PASSPORT_DOCUMENT_FORM,
  storeKey,
});

export const resetPassportDocumentDoneStatus = (storeKey) => ({
  type: types.RESET_PASSPORT_DOCUMENT_DONE_STATUS,
  storeKey,
});

export const bindDocToPassportDocument = (fieldName, data) => ({
  type: types.BIND_DOC_TO_PASSPORT_DOCUMENT,
  fieldName,
  data,
});

export const lockDocToPassportDocument = (data) => ({
  type: types.LOCK_DOC_TO_PASSPORT_DOCUMENT,
  data,
});
