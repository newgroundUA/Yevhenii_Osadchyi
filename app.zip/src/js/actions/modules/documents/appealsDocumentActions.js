import * as types from '../../../constants/actionTypes/documents/DocumentsConstants';

export const postAppealsDocument = (data) => ({
  types: [
    types.POST_DOCUMENT_APPEALS_REQUEST,
    types.POST_DOCUMENT_APPEALS_SUCCESS,
    types.POST_DOCUMENT_APPEALS_FAILURE,
  ],
  promise: (api) => api.post('appeals/', data),
});

export const putAppealsDocument = (data) => ({
  types: [
    types.PUT_DOCUMENT_APPEALS_REQUEST,
    types.PUT_DOCUMENT_APPEALS_SUCCESS,
    types.PUT_DOCUMENT_APPEALS_FAILURE,
  ],
  promise: (api) => api.put('appeals/', data),
});

export const getAppealsDocument = (guid) => ({
  types: [
    types.GET_DOCUMENT_APPEALS_REQUEST,
    types.GET_DOCUMENT_APPEALS_SUCCESS,
    types.GET_DOCUMENT_APPEALS_FAILURE,
  ],
  promise: (api) => api.get(`appeals/get/${guid}`),
});

export const resetAppealsForm = () => ({
  type: types.RESET_APPEALS_FORM,
});

export const bindDocToAppealsDocument = (fieldName, data) => ({
  type: types.BIND_DOC_TO_APPEALS_DOCUMENT,
  fieldName,
  data,
});

export const lockDocToAppealsDocument = (data) => ({
  type: types.LOCK_DOC_TO_APPEALS_DOCUMENT,
  data,
});
