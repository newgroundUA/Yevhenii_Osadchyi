import * as types from '../../../constants/actionTypes/documents/DocumentsConstants';

export const postLeaseContractDocument = (data, storeKey) => ({
  storeKey,
  types: [
    types.POST_DOCUMENT_LEASE_CONTRACT_REQUEST,
    types.POST_DOCUMENT_LEASE_CONTRACT_SUCCESS,
    types.POST_DOCUMENT_LEASE_CONTRACT_FAILURE,
  ],
  promise: (api) => api.post('lease/leasecontract/', data),
});

export const putLeaseContractDocument = (data, storeKey, ignoreStatus) => ({
  storeKey,
  ignoreStatus,
  types: [
    types.PUT_DOCUMENT_LEASE_CONTRACT_REQUEST,
    types.PUT_DOCUMENT_LEASE_CONTRACT_SUCCESS,
    types.PUT_DOCUMENT_LEASE_CONTRACT_FAILURE,
  ],
  promise: (api) => api.put('lease/leasecontract/', data),
});

export const putUpdateLeaseContractPaymentSchedule = (guid, storeKey) => ({
  storeKey,
  types: [
    types.PUT_UPDATE_LEASE_CONTRACT_PAYMENT_SCHEDULE_REQUEST,
    types.PUT_UPDATE_LEASE_CONTRACT_PAYMENT_SCHEDULE_SUCCESS,
    types.PUT_UPDATE_LEASE_CONTRACT_PAYMENT_SCHEDULE_FAILURE,
  ],
  promise: (api) =>
    api.put(`lease/leaseContractPaymentSchedule/updateLeaseContractPaymentSchedule/${guid}`),
});

export const getLeaseContractDocument = (guid, storeKey) => ({
  storeKey,
  types: [
    types.GET_DOCUMENT_LEASE_CONTRACT_REQUEST,
    types.GET_DOCUMENT_LEASE_CONTRACT_SUCCESS,
    types.GET_DOCUMENT_LEASE_CONTRACT_FAILURE,
  ],
  promise: (api) => api.get(`lease/leasecontract/get/${guid}`),
});

export const resetLeaseContractDocumentForm = (storeKey) => ({
  storeKey,
  type: types.RESET_LEASE_CONTRACT_FORM,
});

export const resetLeaseContractDocumentDoneStatus = (storeKey) => ({
  storeKey,
  type: types.RESET_LEASE_CONTRACT_DONE_STATUS,
});

export const postObjectInLeaseContract = (data, storeKey) => ({
  storeKey,
  types: [
    types.POST_OBJECT_IN_LEASE_CONTRACT_REQUEST,
    types.POST_OBJECT_IN_LEASE_CONTRACT_SUCCESS,
    types.POST_OBJECT_IN_LEASE_CONTRACT_FAILURE,
  ],
  promise: (api) => api.post('lease/objectOfLeasecontract/', data),
});

export const putObjectInLeaseContract = (data, storeKey) => ({
  storeKey,
  types: [
    types.PUT_OBJECT_IN_LEASE_CONTRACT_REQUEST,
    types.PUT_OBJECT_IN_LEASE_CONTRACT_SUCCESS,
    types.PUT_OBJECT_IN_LEASE_CONTRACT_FAILURE,
  ],
  promise: (api) => api.put('lease/objectOfLeasecontract/', data),
});

export const deleteObjectInLeaseContract = (guid, storeKey) => ({
  storeKey,
  types: [
    types.DELETE_OBJECT_IN_LEASE_CONTRACT_REQUEST,
    types.DELETE_OBJECT_IN_LEASE_CONTRACT_SUCCESS,
    types.DELETE_OBJECT_IN_LEASE_CONTRACT_FAILURE,
  ],
  promise: (api) => api.delete(`lease/objectOfLeasecontract/${guid}`),
});

export const postLeaseBasePeriod = (data, storeKey) => ({
  storeKey,
  types: [
    types.POST_LEASE_BASE_PERIOD_REQUEST,
    types.POST_LEASE_BASE_PERIOD_SUCCESS,
    types.POST_LEASE_BASE_PERIOD_FAILURE,
  ],
  promise: (api) => api.post('lease/mltQuantityByPeriod/', data),
});

export const putLeaseBasePeriod = (data, storeKey) => ({
  storeKey,
  types: [
    types.PUT_LEASE_BASE_PERIOD_REQUEST,
    types.PUT_LEASE_BASE_PERIOD_SUCCESS,
    types.PUT_LEASE_BASE_PERIOD_FAILURE,
  ],
  promise: (api) => api.put('lease/mltQuantityByPeriod/', data),
});

export const deleteLeaseBasePeriod = (guid, storeKey) => ({
  storeKey,
  types: [
    types.DELETE_LEASE_BASE_PERIOD_REQUEST,
    types.DELETE_LEASE_BASE_PERIOD_SUCCESS,
    types.DELETE_LEASE_BASE_PERIOD_FAILURE,
  ],
  promise: (api) => api.delete(`lease/mltQuantityByPeriod/${guid}`),
});

export const getLeaseObjectOfLeaseContract = (guid, storeKey) => ({
  storeKey,
  types: [
    types.GET_LEASE_OBJECT_OF_LEASE_CONTRACT_REQUEST,
    types.GET_LEASE_OBJECT_OF_LEASE_CONTRACT_SUCCESS,
    types.GET_LEASE_OBJECT_OF_LEASE_CONTRACT_FAILURE,
  ],
  promise: (api) => api.get(`/lease/mltQuantityByPeriod/get/objectOfLeaseContract/${guid}`),
});

export const bindDocToLeaseContractDocument = (fieldName, data) => ({
  type: types.BIND_DOC_TO_LEASE_CONTRACT_DOCUMENT,
  fieldName,
  data,
});

export const lockDocToLeaseContractDocument = (data) => ({
  type: types.LOCK_DOC_TO_LEASE_CONTRACT_DOCUMENT,
  data,
});
