import * as types from '../../../constants/actionTypes/documents/DocumentsConstants';

export const loadScopeOfApp = () => ({
  types: [
    types.LOAD_SCOPE_OF_DOCUMENTS_REQUEST,
    types.LOAD_SCOPE_OF_DOCUMENTS_SUCCESS,
    types.LOAD_SCOPE_OF_DOCUMENTS_FAILURE,
  ],
  promise: (api) => api.get('CLASSIFIER/REF_DOCUMENT_TYPE/scopeOfApplication'),
});

export const loadDocCategory = (scopeOfApp) => ({
  types: [
    types.LOAD_CATEGORY_OF_DOCUMENTS_REQUEST,
    types.LOAD_CATEGORY_OF_DOCUMENTS_SUCCESS,
    types.LOAD_CATEGORY_OF_DOCUMENTS_FAILURE,
  ],
  scopeOfApp,
  promise: (api) =>
    api.get(`CLASSIFIER/REF_DOCUMENT_TYPE/scopeOfApplication/${scopeOfApp}/docCategory`),
});

export const loadDocView = (scopeOfApp, category) => ({
  types: [
    types.LOAD_NAME_OF_DOCUMENTS_REQUEST,
    types.LOAD_NAME_OF_DOCUMENTS_SUCCESS,
    types.LOAD_NAME_OF_DOCUMENTS_FAILURE,
  ],
  scopeOfApp,
  category,
  promise: (api) =>
    api.get(
      `CLASSIFIER/REF_DOCUMENT_TYPE/scopeOfApplication/${scopeOfApp}/docCategory/${category}/docView`,
    ),
});

export const selectCascaderValue = (value, storeKey) => ({
  type: types.DOCUMENT_TYPES_SELECT_CASCADER_VALUE,
  value,
  storeKey,
});
