import * as types from '../../../constants/actionTypes/documents/DocumentsConstants';

export const postJudicialDecision = (data) => ({
  types: [
    types.POST_DOCUMENT_JUDICIAL_DECISION_REQUEST,
    types.POST_DOCUMENT_JUDICIAL_DECISION_SUCCESS,
    types.POST_DOCUMENT_JUDICIAL_DECISION_FAILURE,
  ],
  promise: (api) => api.post('judicialDecision/', data),
});

export const putJudicialDecision = (data) => ({
  types: [
    types.PUT_DOCUMENT_JUDICIAL_DECISION_REQUEST,
    types.PUT_DOCUMENT_JUDICIAL_DECISION_SUCCESS,
    types.PUT_DOCUMENT_JUDICIAL_DECISION_FAILURE,
  ],
  promise: (api) => api.put('judicialDecision/', data),
});

export const getJudicialDecision = (guid) => ({
  types: [
    types.GET_DOCUMENT_JUDICIAL_DECISION_REQUEST,
    types.GET_DOCUMENT_JUDICIAL_DECISION_SUCCESS,
    types.GET_DOCUMENT_JUDICIAL_DECISION_FAILURE,
  ],
  promise: (api) => api.get(`judicialDecision/get/${guid}`),
});

export const deleteJudicialDecision = (guid) => ({
  types: [
    types.DELETE_DOCUMENT_JUDICIAL_DECISION_REQUEST,
    types.DELETE_DOCUMENT_JUDICIAL_DECISION_SUCCESS,
    types.DELETE_DOCUMENT_JUDICIAL_DECISION_FAILURE,
  ],
  promise: (api) => api.delete(`judicialDecision/get/${guid}`),
});

export const resetJudicialDecisionForm = () => ({
  type: types.RESET_JUDICIAL_DECISION_FORM,
});

export const resetJudicialDecisionDoneStatus = () => ({
  type: types.RESET_JUDICIAL_DECISION_DONE_STATUS,
});

export const bindDocToJudicialDecisionDocument = (fieldName, data) => ({
  type: types.BIND_DOC_TO_JUDICIAL_DECISION_DOCUMENT,
  fieldName,
  data,
});

export const lockDocToJudicialDecisionDocument = (data) => ({
  type: types.LOCK_DOC_TO_JUDICIAL_DECISION_DOCUMENT,
  data,
});
