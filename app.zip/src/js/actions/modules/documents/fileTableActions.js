import * as types from '../../../constants/actionTypes/documents/DocumentsConstants';
import { createStringReqParams } from '../../../helpers/createReqParams';

export const setFileTable = (files) => ({
  type: types.LOAD_DOCUMENT_FILE_SUCCESS,
  data: files,
});

export const resetFileTable = () => setFileTable([]);

export const loadFileTable = () => ({
  types: [
    types.LOAD_DOCUMENT_FILE_REQUEST,
    types.LOAD_DOCUMENT_FILE_SUCCESS,
    types.LOAD_DOCUMENT_FILE_FAILURE,
  ],
  promise: (api) =>
    api.get(
      `filestorage/get${createStringReqParams({
        limit: '20',
        offset: '0',
      })}`,
    ),
});

export const postFile = (fileData) => {
  const data = new FormData();

  data.append('file', fileData.file);
  data.append(
    'fileData',
    JSON.stringify([
      {
        fileParam: 'file',
        notice: fileData.notice,
        types: fileData.types,
      },
    ]),
  );

  return {
    types: [
      types.POST_DOCUMENT_FILE_REQUEST,
      types.POST_DOCUMENT_FILE_SUCCESS,
      types.POST_DOCUMENT_FILE_FAILURE,
    ],
    promise: (api) => api.post('filestorage/', data, { headers: { 'Content-Type': '' } }),
  };
};

export const deleteFile = (guid) => ({
  types: [
    types.DELETE_DOCUMENT_FILE_REQUEST,
    types.DELETE_DOCUMENT_FILE_SUCCESS,
    types.DELETE_DOCUMENT_FILE_FAILURE,
  ],
  promise: (api) => api.delete(`filestorage/${guid}`),
});
