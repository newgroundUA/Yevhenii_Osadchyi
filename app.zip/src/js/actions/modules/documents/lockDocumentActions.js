import * as types from '../../../constants/actionTypes/documents/DocumentsConstants';

export const lockDocument = (data) => ({
  types: [
    types.PUT_LOCK_DOCUMENT_REQUEST,
    types.PUT_LOCK_DOCUMENT_SUCCESS,
    types.PUT_LOCK_DOCUMENT_FAILURE,
  ],
  promise: (api) => api.put('document/lock_document', data),
});

export default lockDocument;
