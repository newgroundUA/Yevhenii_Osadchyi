import * as types from '../../../constants/actionTypes/documents/DocumentsConstants';
import { withAuthDownload } from '../../../api/withAuth';

export const uploadFile = (file, metaData) => {
  const data = new FormData();

  data.append('file', file);
  data.append(
    'metaData',
    JSON.stringify({
      fileTags: (metaData.fileTags || []).map((el) => ({
        ...JSON.parse(el.key),
        tag: el.label,
      })),
      fileAlias: metaData.fileAlias,
      fileNotes: metaData.fileNotes,
    }),
  );

  return {
    types: [
      types.POST_FILE_UPLOAD_REQUEST,
      types.POST_FILE_UPLOAD_SUCCESS,
      types.POST_FILE_UPLOAD_FAILURE,
    ],
    promise: (api) => api.post('filestorage/file', data, { headers: { 'Content-Type': '' } }),
  };
};

export const downloadFile = (link, fileName) => ({
  types: [
    types.GET_DOWNLOAD_FILE_REQUEST,
    types.GET_DOWNLOAD_FILE_SUCCESS,
    types.GET_DOWNLOAD_FILE_FAILURE,
  ],
  promise: (api) =>
    withAuthDownload({
      api,
      method: 'get',
      url: `filestorage/file/${link}`,
      fileName,
    }),
});

export const liveSearchFilestorage = (data) => ({
  types: [
    types.LOAD_LIVE_SEARCH_FILE_STORAGE_REQUEST,
    types.LOAD_LIVE_SEARCH_FILE_STORAGE_SUCCESS,
    types.LOAD_LIVE_SEARCH_FILE_STORAGE_FAILURE,
  ],
  promise: (api) => api.post('filestorage/live_search', data),
});
