import * as types from '../../../constants/actionTypes/documents/DocumentsConstants';

export const postGeneralDocument = (data, storeKey) => ({
  types: [
    types.POST_DOCUMENT_GENERAL_DOCUMENT_REQUEST,
    types.POST_DOCUMENT_GENERAL_DOCUMENT_SUCCESS,
    types.POST_DOCUMENT_GENERAL_DOCUMENT_FAILURE,
  ],
  storeKey,
  promise: (api) => api.post('document/', data),
});

export const putGeneralDocument = (data, storeKey, ignoreStatus) => ({
  types: [
    types.PUT_DOCUMENT_GENERAL_DOCUMENT_REQUEST,
    types.PUT_DOCUMENT_GENERAL_DOCUMENT_SUCCESS,
    types.PUT_DOCUMENT_GENERAL_DOCUMENT_FAILURE,
  ],
  storeKey,
  ignoreStatus,
  promise: (api) => api.put('document/', data),
});

export const getGeneralDocument = (guid, storeKey) => ({
  types: [
    types.GET_DOCUMENT_GENERAL_DOCUMENT_REQUEST,
    types.GET_DOCUMENT_GENERAL_DOCUMENT_SUCCESS,
    types.GET_DOCUMENT_GENERAL_DOCUMENT_FAILURE,
  ],
  storeKey,
  promise: (api) => api.get(`document/get/${guid}`),
});

export const resetGeneralDocumentForm = (storeKey) => ({
  type: types.RESET_GENERAL_DOCUMENT_FORM,
  storeKey,
});

export const resetGeneralDocumentDoneStatus = (storeKey) => ({
  type: types.RESET_GENERAL_DOCUMENT_DONE_STATUS,
  storeKey,
});

export const bindDocToGeneralDocument = (fieldName, data) => ({
  type: types.BIND_DOC_TO_GENERAL_DOCUMENT,
  fieldName,
  data,
});

export const lockDocToGeneralDocument = (data) => ({
  type: types.LOCK_DOC_TO_GENERAL_DOCUMENT,
  data,
});
