import * as types from '../../../constants/actionTypes/documents/DocumentsConstants';
import { createParams } from '../../../helpers/createReqParams';

export const postRentStatement = (data, storeKey) => ({
  storeKey,
  types: [
    types.POST_DOCUMENT_RENT_STATEMENT_REQUEST,
    types.POST_DOCUMENT_RENT_STATEMENT_SUCCESS,
    types.POST_DOCUMENT_RENT_STATEMENT_FAILURE,
  ],
  promise: (api) => api.post('applicationLease/', data),
});

export const putRentStatement = (data, storeKey, ignoreStatus) => ({
  ignoreStatus,
  storeKey,
  types: [
    types.PUT_DOCUMENT_RENT_STATEMENT_REQUEST,
    types.PUT_DOCUMENT_RENT_STATEMENT_SUCCESS,
    types.PUT_DOCUMENT_RENT_STATEMENT_FAILURE,
  ],
  promise: (api) => api.put('applicationLease/', data),
});

export const getRentStatement = (guid, storeKey) => ({
  storeKey,
  types: [
    types.GET_DOCUMENT_RENT_STATEMENT_REQUEST,
    types.GET_DOCUMENT_RENT_STATEMENT_SUCCESS,
    types.GET_DOCUMENT_RENT_STATEMENT_FAILURE,
  ],
  promise: (api) => api.get(`applicationLease/get/${guid}`),
});

export const loadDocumentRentStatementPropertyObjects = (list, storeKey) => ({
  fieldNames: list.map((el) => el.guid),
  storeKey,
  types: [
    types.LOAD_DOCUMENT_RENT_STATEMENT_PROPERTY_OBJECTS_REQUEST,
    types.LOAD_DOCUMENT_RENT_STATEMENT_PROPERTY_OBJECTS_SUCCESS,
    types.LOAD_DOCUMENT_RENT_STATEMENT_PROPERTY_OBJECTS_FAILURE,
  ],
  promise: (api, apiAll) =>
    apiAll.all(
      list.map((el) =>
        api({
          method: 'GET',
          url: `objectsLeaseList/get/${el.guid}`,
          fieldName: el.guid,
        }),
      ),
    ),
});

export const loadDocumentRentStatementLeaseObjects = (list, storeKey) => ({
  fieldNames: list.map((el) => el.guid),
  storeKey,
  types: [
    types.LOAD_DOCUMENT_RENT_STATEMENT_LEASE_OBJECTS_REQUEST,
    types.LOAD_DOCUMENT_RENT_STATEMENT_LEASE_OBJECTS_SUCCESS,
    types.LOAD_DOCUMENT_RENT_STATEMENT_LEASE_OBJECTS_FAILURE,
  ],
  promise: (api, apiAll) =>
    apiAll.all(
      list.map((el) =>
        api({
          method: 'GET',
          url: `lease/leaseObjectsLeaseList/get/${el.guid}`,
          fieldName: el.guid,
        }),
      ),
    ),
});

export const loadLandlordsToLeaseObjects = (storeKey) => ({
  storeKey,
  types: [
    types.LOAD_LANDLORDS_TO_LEASE_OBJECTS_REQUEST,
    types.LOAD_LANDLORDS_TO_LEASE_OBJECTS_SUCCESS,
    types.LOAD_LANDLORDS_TO_LEASE_OBJECTS_FAILURE,
  ],
  promise: (api) =>
    api.post(
      'lease/registry/landlordsAndLeaseObjects/get',
      createParams({
        limit: 999,
        offset: 0,
      }),
    ),
});

export const resetRentStatementForm = (storeKey) => ({
  storeKey,
  type: types.RESET_RENT_STATEMENT_FORM,
});

export const resetRentStatementDoneStatus = (storeKey) => ({
  storeKey,
  type: types.RESET_RENT_STATEMENT_DONE_STATUS,
});

// property objects table

export const postPropertyObject = (data, storeKey) => ({
  storeKey,
  types: [
    types.POST_DOCUMENT_RENT_STATEMENT_PROPERTY_OBJECT_REQUEST,
    types.POST_DOCUMENT_RENT_STATEMENT_PROPERTY_OBJECT_SUCCESS,
    types.POST_DOCUMENT_RENT_STATEMENT_PROPERTY_OBJECT_FAILURE,
  ],
  promise: (api) => api.post('objectsLeaseList/', data),
});

export const putPropertyObject = (data, storeKey) => ({
  storeKey,
  types: [
    types.PUT_DOCUMENT_RENT_STATEMENT_PROPERTY_OBJECT_REQUEST,
    types.PUT_DOCUMENT_RENT_STATEMENT_PROPERTY_OBJECT_SUCCESS,
    types.PUT_DOCUMENT_RENT_STATEMENT_PROPERTY_OBJECT_FAILURE,
  ],
  promise: (api) => api.put('objectsLeaseList/', data),
});

export const deletePropertyObject = (guid, storeKey) => ({
  storeKey,
  types: [
    types.DELETE_DOCUMENT_RENT_STATEMENT_PROPERTY_OBJECT_REQUEST,
    types.DELETE_DOCUMENT_RENT_STATEMENT_PROPERTY_OBJECT_SUCCESS,
    types.DELETE_DOCUMENT_RENT_STATEMENT_PROPERTY_OBJECT_FAILURE,
  ],
  promise: (api) => api.delete(`objectsLeaseList/${guid}`),
});

// lease objects table

export const postLeaseObject = (data, storeKey) => ({
  storeKey,
  leaseObjectGUID: data.leaseObjects.guid,
  types: [
    types.POST_DOCUMENT_RENT_STATEMENT_LEASE_OBJECT_REQUEST,
    types.POST_DOCUMENT_RENT_STATEMENT_LEASE_OBJECT_SUCCESS,
    types.POST_DOCUMENT_RENT_STATEMENT_LEASE_OBJECT_FAILURE,
  ],
  promise: (api) => api.post('lease/leaseObjectsLeaseList/', data),
});

export const putLeaseObject = (data, storeKey) => ({
  storeKey,
  leaseObjectGUID: data.leaseObjects.guid,
  types: [
    types.PUT_DOCUMENT_RENT_STATEMENT_LEASE_OBJECT_REQUEST,
    types.PUT_DOCUMENT_RENT_STATEMENT_LEASE_OBJECT_SUCCESS,
    types.PUT_DOCUMENT_RENT_STATEMENT_LEASE_OBJECT_FAILURE,
  ],
  promise: (api) => api.put('lease/leaseObjectsLeaseList/', data),
});

export const deleteLeaseObject = (guid, storeKey) => ({
  storeKey,
  types: [
    types.DELETE_DOCUMENT_RENT_STATEMENT_LEASE_OBJECT_REQUEST,
    types.DELETE_DOCUMENT_RENT_STATEMENT_LEASE_OBJECT_SUCCESS,
    types.DELETE_DOCUMENT_RENT_STATEMENT_LEASE_OBJECT_FAILURE,
  ],
  promise: (api) => api.delete(`lease/leaseObjectsLeaseList/${guid}`),
});

export const bindDocToRentStatementDocument = (fieldName, data) => ({
  type: types.BIND_DOC_TO_RENT_STATEMENT_DOCUMENT,
  fieldName,
  data,
});

export const lockDocToRentStatementDocument = (data) => ({
  type: types.LOCK_DOC_TO_RENT_STATEMENT_DOCUMENT,
  data,
});
