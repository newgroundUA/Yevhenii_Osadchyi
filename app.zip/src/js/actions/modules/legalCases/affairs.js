import * as types from '../../../constants/actionTypes/legalCases/LegalCasesConstants';
import { createParams } from '../../../helpers/createReqParams';

export const getLegalCasesAffairsRegister = (data) => ({
  types: [
    types.GET_LEGAL_CASES_AFFAIRS_REGISTER_REQUEST,
    types.GET_LEGAL_CASES_AFFAIRS_REGISTER_SUCCESS,
    types.GET_LEGAL_CASES_AFFAIRS_REGISTER_FAILURE,
  ],
  promise: (api) =>
    api.post('request_for_legal_processing/registry/legalAffairs/get', createParams(data)),
});

export const getLegalCasesAffairsByGuid = (guid) => ({
  types: [
    types.LOAD_GET_LEGAL_CASES_AFFAIRS_BY_GUID_REQUEST,
    types.LOAD_GET_LEGAL_CASES_AFFAIRS_BY_GUID_SUCCESS,
    types.LOAD_GET_LEGAL_CASES_AFFAIRS_BY_GUID_FAILURE,
  ],
  promise: (api) => api.get(`legal_affairs/get/${guid}`),
});

export const postLegalCasesAffairs = (data) => ({
  types: [
    types.LOAD_POST_LEGAL_CASES_AFFAIRS_REQUEST,
    types.LOAD_POST_LEGAL_CASES_AFFAIRS_SUCCESS,
    types.LOAD_POST_LEGAL_CASES_AFFAIRS_FAILURE,
  ],
  promise: (api) => api.post('legal_affairs/', data),
});

export const putLegalCasesAffairs = (data) => ({
  types: [
    types.LOAD_PUT_LEGAL_CASES_AFFAIRS_REQUEST,
    types.LOAD_PUT_LEGAL_CASES_AFFAIRS_SUCCESS,
    types.LOAD_PUT_LEGAL_CASES_AFFAIRS_FAILURE,
  ],
  promise: (api) => api.put('legal_affairs/', data),
});

export const setValueRequestBody = (key, value) => ({
  type: types.SET_LEGAL_CASES_AFFAIRS_VALUE_REQUEST_BODY,
  key,
  value,
});

export const setValuePages = (key, value) => ({
  type: types.SET_LEGAL_CASES_AFFAIRS_VALUE_PAGES,
  key,
  value,
});

export const setValueFastFilters = (key, value) => ({
  type: types.SET_LEGAL_CASES_AFFAIRS_VALUE_FAST_FILTERS,
  key,
  value,
});

export const resetFilters = () => ({
  type: types.RESET_LEGAL_CASES_AFFAIRS_FILTERS,
});

export const resetLegalCasesAffairsForm = () => ({
  type: types.RESET_LEGAL_CASES_AFFAIRS_FORM,
});

export const postLegalAffairsStages = (data) => ({
  types: [
    types.LOAD_POST_LEGAL_AFFAIRS_STAGES_REQUEST,
    types.LOAD_POST_LEGAL_AFFAIRS_STAGES_SUCCESS,
    types.LOAD_POST_LEGAL_AFFAIRS_STAGES_FAILURE,
  ],
  promise: (api) => api.post('legalAffairsStages/', data),
});

export const putLegalAffairsStages = (data) => ({
  types: [
    types.LOAD_PUT_LEGAL_AFFAIRS_STAGES_REQUEST,
    types.LOAD_PUT_LEGAL_AFFAIRS_STAGES_SUCCESS,
    types.LOAD_PUT_LEGAL_AFFAIRS_STAGES_FAILURE,
  ],
  promise: (api) => api.put('legalAffairsStages/', data),
});

export const deleteLegalAffairsStages = (guid) => ({
  types: [
    types.LOAD_DELETE_LEGAL_AFFAIRS_STAGES_REQUEST,
    types.LOAD_DELETE_LEGAL_AFFAIRS_STAGES_SUCCESS,
    types.LOAD_DELETE_LEGAL_AFFAIRS_STAGES_FAILURE,
  ],
  promise: (api) => api.delete(`legalAffairsStages/${guid}`),
});

export const postProceedingCourt = (data) => ({
  types: [
    types.LOAD_POST_PROCEEDING_COURT_REQUEST,
    types.LOAD_POST_PROCEEDING_COURT_SUCCESS,
    types.LOAD_POST_PROCEEDING_COURT_FAILURE,
  ],
  promise: (api) => api.post('proceedingCourt/', data),
});

export const putProceedingCourt = (data) => ({
  types: [
    types.LOAD_PUT_PROCEEDING_COURT_REQUEST,
    types.LOAD_PUT_PROCEEDING_COURT_SUCCESS,
    types.LOAD_PUT_PROCEEDING_COURT_FAILURE,
  ],
  promise: (api) => api.put('proceedingCourt/', data),
});

export const deleteProceedingCourt = (guid) => ({
  types: [
    types.LOAD_DELETE_PROCEEDING_COURT_REQUEST,
    types.LOAD_DELETE_PROCEEDING_COURT_SUCCESS,
    types.LOAD_DELETE_PROCEEDING_COURT_FAILURE,
  ],
  promise: (api) => api.delete(`proceedingCourt/${guid}`),
});

export const postСourtSessionPlanning = (data) => ({
  types: [
    types.LOAD_POST_COURT_SESSION_PLANNING_REQUEST,
    types.LOAD_POST_COURT_SESSION_PLANNING_SUCCESS,
    types.LOAD_POST_COURT_SESSION_PLANNING_FAILURE,
  ],
  promise: (api) => api.post('courtSessionPlanning/', data),
});

export const putСourtSessionPlanning = (data) => ({
  types: [
    types.LOAD_PUT_COURT_SESSION_PLANNING_REQUEST,
    types.LOAD_PUT_COURT_SESSION_PLANNING_SUCCESS,
    types.LOAD_PUT_COURT_SESSION_PLANNING_FAILURE,
  ],
  promise: (api) => api.put('courtSessionPlanning/', data),
});

export const deleteСourtSessionPlanning = (guid, deleteKey) => ({
  types: [
    types.LOAD_DELETE_COURT_SESSION_PLANNING_REQUEST,
    types.LOAD_DELETE_COURT_SESSION_PLANNING_SUCCESS,
    types.LOAD_DELETE_COURT_SESSION_PLANNING_FAILURE,
  ],
  promise: (api) => api.delete(`courtSessionPlanning/${guid}`),
  deleteKey,
});
