import * as types from '../../../constants/actionTypes/legalCases/LegalCasesConstants';

export const getLegalCasesInitiativeRegister = () => ({
  types: [
    types.GET_LEGAL_CASES_INITIATIVE_REGISTER_REQUEST,
    types.GET_LEGAL_CASES_INITIATIVE_REGISTER_SUCCESS,
    types.GET_LEGAL_CASES_INITIATIVE_REGISTER_FAILURE,
  ],
  promise: () =>
    new Promise((res) =>
      res({
        data: Array(30)
          .fill(0)
          .map((el, id) => ({ guid: `${id}` })),
        result: {
          total: 30,
        },
      }),
    ),
});

export const setValueRequestBody = (key, value) => ({
  type: types.SET_LEGAL_CASES_INITIATIVE_VALUE_REQUEST_BODY,
  key,
  value,
});

export const setValuePages = (key, value) => ({
  type: types.SET_LEGAL_CASES_INITIATIVE_VALUE_PAGES,
  key,
  value,
});

export const setValueFastFilters = (key, value) => ({
  type: types.SET_LEGAL_CASES_INITIATIVE_VALUE_FAST_FILTERS,
  key,
  value,
});

export const resetFilters = () => ({
  type: types.RESET_LEGAL_CASES_INITIATIVE_FILTERS,
});
