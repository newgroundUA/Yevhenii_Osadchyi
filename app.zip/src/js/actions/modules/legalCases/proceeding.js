import * as types from '../../../constants/actionTypes/legalCases/LegalCasesConstants';
// import { createStringReqParams } from '../../../helpers/createReqParams';

export const resetProceeding = () => ({
  type: types.RESET_PROCEEDING_CARDS,
});

export const getProceeding = (guid) => ({
  types: [
    types.GET_PROCEEDING_CARD_REQUEST,
    types.GET_PROCEEDING_CARD_SUCCESS,
    types.GET_PROCEEDING_CARD_FAILURE,
  ],
  promise: (api) => api.get(`request_for_legal_processing/get/${guid}`),
});

export const postProceeding = (data) => ({
  types: [
    types.POST_PROCEEDING_CARD_REQUEST,
    types.POST_PROCEEDING_CARD_SUCCESS,
    types.POST_PROCEEDING_CARD_FAILURE,
  ],
  promise: (api) => api.post('request_for_legal_processing/', data),
});

export const putProceeding = (data) => ({
  types: [
    types.PUT_PROCEEDING_CARD_REQUEST,
    types.PUT_PROCEEDING_CARD_SUCCESS,
    types.PUT_PROCEEDING_CARD_FAILURE,
  ],
  promise: (api) => api.put('request_for_legal_processing/', data),
});

export const liveLoadRequestsForLegalProcessing = ({
  storeKey,
  processingStatuses,
  reqNumber,
}) => ({
  storeKey,
  types: [
    types.LIVE_LOAD_REQUESTS_FOR_LEGAL_PROCESSING_REQUEST,
    types.LIVE_LOAD_REQUESTS_FOR_LEGAL_PROCESSING_SUCCESS,
    types.LIVE_LOAD_REQUESTS_FOR_LEGAL_PROCESSING_FAILURE,
  ],
  promise: (api) =>
    api.post('request_for_legal_processing/liveSearch/requestForLegalProcessing', {
      processingStatuses,
      reqNumber,
      limit: 1000,
      page: 0,
    }),
});

export const mountRequestsForLegalProcessingDropDown = (storeKey) => ({
  type: types.MOUNT_REQUESTS_FOR_LEGAL_PROCESSING_DROP_DOWN,
  storeKey,
});

export const unMountRequestsForLegalProcessingDropDown = (storeKey) => ({
  type: types.UNMOUNT_REQUESTS_FOR_LEGAL_PROCESSING_DROP_DOWN,
  storeKey,
});
