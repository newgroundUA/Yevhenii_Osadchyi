import * as types from '../../../constants/actionTypes/legalCases/LegalCasesConstants';
import { createParams } from '../../../helpers/createReqParams';

export const getLegalCasesCourtSessionsPlanningsRegister = (data) => ({
  types: [
    types.GET_LEGAL_CASES_COURT_SESSIONS_PLANNINGS_REGISTER_REQUEST,
    types.GET_LEGAL_CASES_COURT_SESSIONS_PLANNINGS_REGISTER_SUCCESS,
    types.GET_LEGAL_CASES_COURT_SESSIONS_PLANNINGS_REGISTER_FAILURE,
  ],
  promise: (api) =>
    api.post('request_for_legal_processing/registry/courtSessionPlanning/get', createParams(data)),
});

export const setValueRequestBody = (key, value) => ({
  type: types.SET_LEGAL_CASES_COURT_SESSIONS_PLANNINGS_REGISTER_VALUE_REQUEST_BODY,
  key,
  value,
});

export const setValuePages = (key, value) => ({
  type: types.SET_LEGAL_CASES_COURT_SESSIONS_PLANNINGS_REGISTER_VALUE_PAGES,
  key,
  value,
});

export const setValueFastFilters = (key, value) => ({
  type: types.SET_LEGAL_CASES_COURT_SESSIONS_PLANNINGS_REGISTER_VALUE_FAST_FILTERS,
  key,
  value,
});

export const resetFilters = () => ({
  type: types.RESET_LEGAL_CASES_COURT_SESSIONS_PLANNINGS_REGISTER_FILTERS,
});
