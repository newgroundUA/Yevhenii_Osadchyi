import * as types from '../../constants/actionTypes/AddressConstants';

export const createAddress = (data) => ({
  types: [types.POST_ADDRESS_REQUEST, types.POST_ADDRESS_SUCCESS, types.POST_ADDRESS_FAILURE],
  promise: (api) => api.post('registry/ADDRESS_REGISTRY/', data),
});

export const updateAddress = (data) => ({
  types: [types.PUT_ADDRESS_REQUEST, types.PUT_ADDRESS_SUCCESS, types.PUT_ADDRESS_FAILURE],
  promise: (api) => api.put('registry/ADDRESS_REGISTRY/', data),
});

export const deleteAddress = (guid) => ({
  types: [types.DELETE_ADDRESS_REQUEST, types.DELETE_ADDRESS_SUCCESS, types.DELETE_ADDRESS_FAILURE],
  promise: (api) => api.delete(`registry/ADDRESS_REGISTRY/${guid}`),
});

// Получение списка стран
export const loadCountries = (str) => ({
  types: [types.LOAD_COUNTRIES_REQUEST, types.LOAD_COUNTRIES_SUCCESS, types.LOAD_COUNTRIES_FAILURE],
  promise: (api) => api.get(`addressunit/countries${str ? `?prefix=${str}` : ''}`),
});

// Получение списка регионов
export const loadRegions = (countryGuid, str) => ({
  types: [types.LOAD_REGIONS_REQUEST, types.LOAD_REGIONS_SUCCESS, types.LOAD_REGIONS_FAILURE],
  promise: (api) =>
    api.get(`addressunit/countries/${countryGuid}/regions${str ? `?prefix=${str}` : ''}`),
});

// Получение списка районов
export const loadDistricts = (regionGuid, str) => ({
  types: [types.LOAD_DISTRICTS_REQUEST, types.LOAD_DISTRICTS_SUCCESS, types.LOAD_DISTRICTS_FAILURE],
  promise: (api) =>
    api.get(`addressunit/regions/${regionGuid}/districts${str ? `?prefix=${str}` : ''}`),
});

// Получение списка населенных пунктов
export const loadLocalities = (districtGuid, str) => ({
  types: [
    types.LOAD_LOCALITIES_REQUEST,
    types.LOAD_LOCALITIES_SUCCESS,
    types.LOAD_LOCALITIES_FAILURE,
  ],
  promise: (api) =>
    api.get(`addressunit/districts/${districtGuid}/localities${str ? `?prefix=${str}` : ''}`),
});

// Получение списка улиц по гуайди города
export const loadLocalityStreets = (localityGuid, str) => ({
  types: [types.LOAD_STREETS_REQUEST, types.LOAD_STREETS_SUCCESS, types.LOAD_STREETS_FAILURE],
  promise: (api) =>
    api.get(`addressunit/localities/${localityGuid}/streets${str ? `?prefix=${str}` : ''}`),
});

// получение списка улиц по гуайди района
export const loadLocalityAreaStreets = (cityDistrictGuid, str) => ({
  types: [types.LOAD_STREETS_REQUEST, types.LOAD_STREETS_SUCCESS, types.LOAD_STREETS_FAILURE],
  promise: (api) =>
    api.get(`addressunit/locality_areas/${cityDistrictGuid}/streets${str ? `?prefix=${str}` : ''}`),
});

export const loadLocalityAreas = (cityGuid, str) => ({
  types: [
    types.LOAD_LOCALITY_AREAS_REQUEST,
    types.LOAD_LOCALITY_AREAS_SUCCESS,
    types.LOAD_LOCALITY_AREAS_FAILURE,
  ],
  promise: (api) =>
    api.get(`addressunit/localities/${cityGuid}/locality_areas${str ? `?prefix=${str}` : ''}`),
});

// Получение списка объектов (зданий, учреждений...) улицы
export const loadStreetBuildings = (streetGuid, str) => ({
  types: [
    types.LOAD_STREET_BUILDINGS_REQUEST,
    types.LOAD_STREET_BUILDINGS_SUCCESS,
    types.LOAD_STREET_BUILDINGS_FAILURE,
  ],
  promise: (api) => api.get(`addressunit/steets/${streetGuid}/ao${str ? `?prefix=${str}` : ''}`),
});

export const loadInheritAddressObjects = (buildingGuid, str) => ({
  types: [
    types.LOAD_INHERIT_ADDRESS_OBJECTS_REQUEST,
    types.LOAD_INHERIT_ADDRESS_OBJECTS_SUCCESS,
    types.LOAD_INHERIT_ADDRESS_OBJECTS_FAILURE,
  ],
  promise: (api) => api.get(`addressunit/ao/${buildingGuid}/iao${str ? `?prefix=${str}` : ''}`),
});

export const loadBuildingPremices = (buildingGuid, str) => ({
  types: [
    types.LOAD_BUILDING_PREMICES_REQUEST,
    types.LOAD_BUILDING_PREMICES_SUCCESS,
    types.LOAD_BUILDING_PREMICES_FAILURE,
  ],
  promise: (api) =>
    api.get(`addressunit/ao/${buildingGuid}/premises${str ? `?prefix=${str}` : ''}`),
});

export const loadAddressTypes = () => ({
  types: [
    types.LOAD_ADDRESS_TYPE_CLISSIFIER_REQUEST,
    types.LOAD_ADDRESS_TYPE_CLISSIFIER_SUCCESS,
    types.LOAD_ADDRESS_TYPE_CLISSIFIER_FAILURE,
  ],
  promise: (api) => api.get('CLASSIFIER/ADDRESS_TYPE'),
});

export const loadAddressTypesByHierarchy = () => ({
  types: [
    types.LOAD_ADDRESS_TYPE_BY_HIERARCHY_CLISSIFIER_REQUEST,
    types.LOAD_ADDRESS_TYPE_BY_HIERARCHY_CLISSIFIER_SUCCESS,
    types.LOAD_ADDRESS_TYPE_BY_HIERARCHY_CLISSIFIER_FAILURE,
  ],
  promise: (api) => api.get('CLASSIFIER/ADDRESS_TYPE'),
});

// loading address parts entities
export const loadCountry = (guid) => ({
  types: [types.LOAD_COUNTRY_REQUEST, types.LOAD_COUNTRY_SUCCESS, types.LOAD_COUNTRY_FAILURE],
  promise: (api) => api.get(`addressunit/countries/${guid}`),
});

export const loadRegion = (guid) => ({
  types: [types.LOAD_REGION_REQUEST, types.LOAD_REGION_SUCCESS, types.LOAD_REGION_FAILURE],
  promise: (api) => api.get(`addressunit/regions/${guid}`),
});

export const loadDistrict = (guid) => ({
  types: [types.LOAD_DISTRICT_REQUEST, types.LOAD_DISTRICT_SUCCESS, types.LOAD_DISTRICT_FAILURE],
  promise: (api) => api.get(`addressunit/districts/${guid}`),
});

export const loadLocality = (guid) => ({
  types: [types.LOAD_LOCALITY_REQUEST, types.LOAD_LOCALITY_SUCCESS, types.LOAD_LOCALITY_FAILURE],
  promise: (api) => api.get(`addressunit/localities/${guid}`),
});

export const loadlocalityArea = (guid) => ({
  types: [
    types.LOAD_LOCALITY_AREA_REQUEST,
    types.LOAD_LOCALITY_AREA_SUCCESS,
    types.LOAD_LOCALITY_AREA_FAILURE,
  ],
  promise: (api) => api.get(`addressunit/locality_areas/${guid}`),
});

export const loadStreet = (guid) => ({
  types: [types.LOAD_STREET_REQUEST, types.LOAD_STREET_SUCCESS, types.LOAD_STREET_FAILURE],
  promise: (api) => api.get(`addressunit/streets/${guid}`),
});

export const loadBuilding = (guid) => ({
  types: [types.LOAD_BUILDING_REQUEST, types.LOAD_BUILDING_SUCCESS, types.LOAD_BUILDING_FAILURE],
  promise: (api) => api.get(`addressunit/ao/${guid}`),
});

export const loadInheritAddressObject = (guid) => ({
  types: [
    types.LOAD_INHERIT_ADDRESS_OBJECT_REQUEST,
    types.LOAD_INHERIT_ADDRESS_OBJECT_SUCCESS,
    types.LOAD_INHERIT_ADDRESS_OBJECT_FAILURE,
  ],
  promise: (api) => api.get(`addressunit/iao/${guid}`),
});

export const loadBuildingPremice = (guid) => ({
  types: [
    types.LOAD_BUILDING_PREMICE_REQUEST,
    types.LOAD_BUILDING_PREMICE_SUCCESS,
    types.LOAD_BUILDING_PREMICE_FAILURE,
  ],
  promise: (api) => api.get(`addressunit/premises/${guid}`),
});
