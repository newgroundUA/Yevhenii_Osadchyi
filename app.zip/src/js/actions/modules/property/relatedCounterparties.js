import * as types from '../../../constants/actionTypes/property/PropertyConstants';

export const loadPropertyOwnershipData = (objectGUID) => ({
  types: [
    types.LOAD_PROPERTY_RELATED_COUNTERPARTIES_REQUEST,
    types.LOAD_PROPERTY_RELATED_COUNTERPARTIES_SUCCESS,
    types.LOAD_PROPERTY_RELATED_COUNTERPARTIES_FAILURE,
  ],
  promise: (api) =>
    api.get(`accountingItem/registry/ownersRegistry/get/accountingItem/${objectGUID}`),
});

export const postPropertyOwnershipData = (data) => ({
  types: [
    types.POST_PROPERTY_RELATED_COUNTERPARTIES_REQUEST,
    types.POST_PROPERTY_RELATED_COUNTERPARTIES_SUCCESS,
    types.POST_PROPERTY_RELATED_COUNTERPARTIES_FAILURE,
  ],
  promise: (api) => api.post('accountingItem/registry/ownersRegistry/', data),
});

export const setPropertyOwners = (data) => ({
  type: types.LOAD_PROPERTY_RELATED_COUNTERPARTIES_SUCCESS,
  data,
});

export const resetPropertyOwners = () =>
  setPropertyOwners({
    ownersOfPrimaryPRs: [],
    ownersOfDerivativePRs: [],
    propertyOwnershipType: { guid: null },
    guid: null,
    isDone: false,
  });

export const postPrimaryOwner = (data) => ({
  localData: data,
  types: [
    types.POST_PROPERTY_PRIMARY_OWNERS_REQUEST,
    types.POST_PROPERTY_PRIMARY_OWNERS_SUCCESS,
    types.POST_PROPERTY_PRIMARY_OWNERS_FAILURE,
  ],
  promise: (api) => api.post('accountingItem/registry/ownersOfPrimary/', data),
});

export const putPrimaryOwner = (data) => ({
  localData: data,
  types: [
    types.PUT_PROPERTY_PRIMARY_OWNERS_REQUEST,
    types.PUT_PROPERTY_PRIMARY_OWNERS_SUCCESS,
    types.PUT_PROPERTY_PRIMARY_OWNERS_FAILURE,
  ],
  promise: (api) => api.put('accountingItem/registry/ownersOfPrimary/', data),
});

export const deletePrimaryOwner = (guid) => ({
  types: [
    types.DELETE_PROPERTY_PRIMARY_OWNERS_REQUEST,
    types.DELETE_PROPERTY_PRIMARY_OWNERS_SUCCESS,
    types.DELETE_PROPERTY_PRIMARY_OWNERS_FAILURE,
  ],
  promise: (api) => api.delete(`accountingItem/registry/ownersOfPrimary/${guid}`),
});

export const postPrimaryOwnerLocal = (data) => ({
  type: types.POST_PROPERTY_PRIMARY_OWNERS_SUCCESS,
  data: {
    guid: `${Math.random()}`.substring(2),
    ...data,
  },
});

export const putPrimaryOwnerLocal = (data) => ({
  type: types.PUT_PROPERTY_PRIMARY_OWNERS_SUCCESS,
  data,
});

export const deletePrimaryOwnerLocal = (guid) => ({
  type: types.DELETE_PROPERTY_PRIMARY_OWNERS_SUCCESS,
  data: { guid },
});

export const postDerivativeOwner = (data) => ({
  localData: data,
  types: [
    types.POST_PROPERTY_DERIVATIVE_OWNERS_REQUEST,
    types.POST_PROPERTY_DERIVATIVE_OWNERS_SUCCESS,
    types.POST_PROPERTY_DERIVATIVE_OWNERS_FAILURE,
  ],
  promise: (api) => api.post('accountingItem/registry/ownersOfDerivative/', data),
});

export const putDerivativeOwner = (data) => ({
  localData: data,
  types: [
    types.PUT_PROPERTY_DERIVATIVE_OWNERS_REQUEST,
    types.PUT_PROPERTY_DERIVATIVE_OWNERS_SUCCESS,
    types.PUT_PROPERTY_DERIVATIVE_OWNERS_FAILURE,
  ],
  promise: (api) => api.put('accountingItem/registry/ownersOfDerivative/', data),
});

export const deleteDerivativeOwner = (guid) => ({
  types: [
    types.DELETE_PROPERTY_DERIVATIVE_OWNERS_REQUEST,
    types.DELETE_PROPERTY_DERIVATIVE_OWNERS_SUCCESS,
    types.DELETE_PROPERTY_DERIVATIVE_OWNERS_FAILURE,
  ],
  promise: (api) => api.delete(`accountingItem/registry/ownersOfDerivative/${guid}`),
});

export const postDerivativeOwnerLocal = (data) => ({
  type: types.POST_PROPERTY_DERIVATIVE_OWNERS_SUCCESS,
  data: {
    guid: `${Math.random()}`.substring(2),
    ...data,
  },
});

export const putDerivativeOwnerLocal = (data) => ({
  type: types.PUT_PROPERTY_DERIVATIVE_OWNERS_SUCCESS,
  data,
});

export const deleteDerivativeOwnerLocal = (guid) => ({
  type: types.DELETE_PROPERTY_DERIVATIVE_OWNERS_SUCCESS,
  data: { guid },
});
