import * as types from '../../../constants/actionTypes/property/PropertyConstants';
import withAuth, { withAuthDownload } from '../../../api/withAuth';
import { createParams, createStringReqParams } from '../../../helpers/createReqParams';

const setTypeOfRegister = (type) => (type ? `${type}_` : '');

export const getPropertyRegister = (data, type) => ({
  types: [
    types[`GET_PROPERTY_${setTypeOfRegister(type)}REGISTER_REQUEST`],
    types[`GET_PROPERTY_${setTypeOfRegister(type)}REGISTER_SUCCESS`],
    types[`GET_PROPERTY_${setTypeOfRegister(type)}REGISTER_FAILURE`],
  ],
  promise: (api) => api.post('accountingItem/registry/get', createParams(data)),
  savedData: data,
});

export const setValueRequestBody = ({ key, value, type }) => ({
  type: types[`SET_PROPERTY_${setTypeOfRegister(type)}REGISTER_VALUE_REQUEST_BODY`],
  key,
  value,
});

export const setValuePages = ({ key, value, type }) => ({
  type: types[`SET_PROPERTY_${setTypeOfRegister(type)}REGISTER_VALUE_PAGES`],
  key,
  value,
});

export const resetFilters = (type) => ({
  type: types[`RESET_PROPERTY_${setTypeOfRegister(type)}REGISTER_FILTERS`],
});

export const mountObjectModal = (key) => ({
  type: types.MOUNT_OBJECTS_DROPDOWN,
  key,
});

export const unmountObjectModal = (key) => ({
  type: types.UNMOUNT_OBJECTS_DROPDOWN,
  key,
});

export const liveLoadObjects = (key, searchTerm, objectType) => ({
  key,
  objectType,
  types: [
    types.LIVE_LOAD_OBJECTS_REQUEST,
    types.LIVE_LOAD_OBJECTS_SUCCESS,
    types.LIVE_LOAD_OBJECTS_FAILURE,
  ],
  promise: (api) =>
    withAuth({
      api,
      method: 'get',
      url: `accountingItem/live_search/${searchTerm}/${createStringReqParams({
        limit: '30',
        offset: '0',
      })}`,
    }),
});

/**
 * Data for exporting to XLS
 * @type {{limit: number, offset: number, propertyTypes: Array,
 * exportType: string, exportColumns: Array}}
 */
const propertyExportData = {
  limit: 1000,
  offset: 0,
  propertyTypes: [],
  exportType: 'XLS',
  exportColumns: [],
};

/**
 * Request to export to XLS
 */
export const requestPropertyXLS = () => ({
  types: [types.PRINT_TO_XLS_REQUEST, types.PRINT_TO_XLS_SUCCESS, types.PRINT_TO_XLS_FAILURE],
  promise: (api) =>
    withAuthDownload({
      api,
      method: 'post',
      url: 'property/export',
      data: propertyExportData,
    }),
});
