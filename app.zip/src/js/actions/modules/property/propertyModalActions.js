import * as types from '../../../constants/actionTypes/property/PropertyConstants';

export const setStatePropertyType = (value, name, guid) => ({
  type: types.SET_STATE_PROPERTY_TYPE,
  value,
  name,
  guid,
});

export const changeCurAccountingType = (data) => ({
  type: types.UPDATE_ACCOUNTING_TYPE,
  data,
});
