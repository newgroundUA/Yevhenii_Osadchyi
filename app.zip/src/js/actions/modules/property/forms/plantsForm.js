import * as types from '../../../../constants/actionTypes/property/PropertyConstants';
// import { createParams } from '../../../../helpers/createReqParams';

export const postPlant = (data) => ({
  types: [
    types.POST_PROPERTY_PLANT_REQUEST,
    types.POST_PROPERTY_PLANT_SUCCESS,
    types.POST_PROPERTY_PLANT_FAILURE,
  ],
  promise: (api) => api.post('accountingItem/plants/', data),
});

export const putPlant = (data) => ({
  types: [
    types.PUT_PROPERTY_PLANT_REQUEST,
    types.PUT_PROPERTY_PLANT_SUCCESS,
    types.PUT_PROPERTY_PLANT_FAILURE,
  ],
  promise: (api) => api.put('accountingItem/plants/', data),
});

export const getPlant = (guid) => ({
  types: [
    types.GET_PROPERTY_PLANT_REQUEST,
    types.GET_PROPERTY_PLANT_SUCCESS,
    types.GET_PROPERTY_PLANT_FAILURE,
  ],
  promise: (api) => api.get(`accountingItem/plants/get/${guid}`),
});

export const resetPlantForm = () => ({
  type: types.RESET_PLANT_FORM,
});
