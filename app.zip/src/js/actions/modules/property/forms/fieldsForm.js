import * as types from '../../../../constants/actionTypes/property/PropertyConstants';
// import { createParams } from '../../../../helpers/createReqParams';

export const postField = (data) => ({
  types: [
    types.POST_PROPERTY_FIELD_REQUEST,
    types.POST_PROPERTY_FIELD_SUCCESS,
    types.POST_PROPERTY_FIELD_FAILURE,
  ],
  promise: (api) => api.post('accountingItem/fields/', data),
});

export const putField = (data) => ({
  types: [
    types.PUT_PROPERTY_FIELD_REQUEST,
    types.PUT_PROPERTY_FIELD_SUCCESS,
    types.PUT_PROPERTY_FIELD_FAILURE,
  ],
  promise: (api) => api.put('accountingItem/fields/', data),
});

export const getField = (guid) => ({
  types: [
    types.GET_PROPERTY_FIELD_REQUEST,
    types.GET_PROPERTY_FIELD_SUCCESS,
    types.GET_PROPERTY_FIELD_FAILURE,
  ],
  promise: (api) => api.get(`accountingItem/fields/get/${guid}`),
});

export const resetFieldForm = () => ({
  type: types.RESET_FIELD_FORM,
});

export const resetFieldDoneStatus = () => ({
  type: types.RESET_FIELD_DONE_STATUS,
});
