import * as types from '../../../../constants/actionTypes/property/PropertyConstants';

export const postFloor = (data) => ({
  types: [
    types.POST_PROPERTY_FLOOR_REQUEST,
    types.POST_PROPERTY_FLOOR_SUCCESS,
    types.POST_PROPERTY_FLOOR_FAILURE,
  ],
  promise: (api) => api.post('accountingItem/floors/', data),
});

export const putFloor = (data) => ({
  types: [
    types.PUT_PROPERTY_FLOOR_REQUEST,
    types.PUT_PROPERTY_FLOOR_SUCCESS,
    types.PUT_PROPERTY_FLOOR_FAILURE,
  ],
  promise: (api) => api.put('accountingItem/floors/', data),
});

export const getFloor = (guid) => ({
  types: [
    types.GET_PROPERTY_FLOOR_REQUEST,
    types.GET_PROPERTY_FLOOR_SUCCESS,
    types.GET_PROPERTY_FLOOR_FAILURE,
  ],
  promise: (api) => api.get(`accountingItem/floors/get/${guid}`),
});

export const resetFloorForm = () => ({
  type: types.RESET_FLOOR_FORM,
});

export const resetFloorDoneStatus = () => ({
  type: types.RESET_FLOOR_DONE_STATUS,
});
