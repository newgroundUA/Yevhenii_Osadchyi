import * as types from '../../../../constants/actionTypes/property/PropertyConstants';
// import { createParams } from '../../../../helpers/createReqParams';

export const postAnimal = (data) => ({
  types: [
    types.POST_PROPERTY_ANIMAL_REQUEST,
    types.POST_PROPERTY_ANIMAL_SUCCESS,
    types.POST_PROPERTY_ANIMAL_FAILURE,
  ],
  promise: (api) => api.post('accountingItem/anumals/', data),
});

export const putAnimal = (data) => ({
  types: [
    types.PUT_PROPERTY_ANIMAL_REQUEST,
    types.PUT_PROPERTY_ANIMAL_SUCCESS,
    types.PUT_PROPERTY_ANIMAL_FAILURE,
  ],
  promise: (api) => api.put('accountingItem/anumals/', data),
});

export const getAnimal = (guid) => ({
  types: [
    types.GET_PROPERTY_ANIMAL_REQUEST,
    types.GET_PROPERTY_ANIMAL_SUCCESS,
    types.GET_PROPERTY_ANIMAL_FAILURE,
  ],
  promise: (api) => api.get(`accountingItem/anumals/get/${guid}`),
});

export const resetAnimalForm = () => ({
  type: types.RESET_ANIMAL_FORM,
});
