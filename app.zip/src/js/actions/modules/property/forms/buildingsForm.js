import * as types from '../../../../constants/actionTypes/property/PropertyConstants';
// import { createParams } from '../../../../helpers/createReqParams';

export const postBuilding = (data) => ({
  types: [
    types.POST_PROPERTY_BUILDING_REQUEST,
    types.POST_PROPERTY_BUILDING_SUCCESS,
    types.POST_PROPERTY_BUILDING_FAILURE,
  ],
  promise: (api) => api.post('accountingItem/buildings/', data),
});

export const putBuilding = (data) => ({
  types: [
    types.PUT_PROPERTY_BUILDING_REQUEST,
    types.PUT_PROPERTY_BUILDING_SUCCESS,
    types.PUT_PROPERTY_BUILDING_FAILURE,
  ],
  promise: (api) => api.put('accountingItem/buildings/', data),
});

export const getBuilding = (guid) => ({
  types: [
    types.GET_PROPERTY_BUILDING_REQUEST,
    types.GET_PROPERTY_BUILDING_SUCCESS,
    types.GET_PROPERTY_BUILDING_FAILURE,
  ],
  promise: (api) => api.get(`accountingItem/buildings/get/${guid}`),
});

export const resetBuildingForm = () => ({
  type: types.RESET_BUILDING_FORM,
});

export const resetBuildingDoneStatus = () => ({
  type: types.RESET_BUILDING_DONE_STATUS,
});
