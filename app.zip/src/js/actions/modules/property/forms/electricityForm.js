import * as types from '../../../../constants/actionTypes/property/PropertyConstants';
// import { createParams } from '../../../../helpers/createReqParams';

export const postElectricity = (data) => ({
  types: [
    types.POST_PROPERTY_ELECTRICITY_REQUEST,
    types.POST_PROPERTY_ELECTRICITY_SUCCESS,
    types.POST_PROPERTY_ELECTRICITY_FAILURE,
  ],
  promise: (api) => api.post('accountingItem/electricities/', data),
});

export const putElectricity = (data) => ({
  types: [
    types.PUT_PROPERTY_ELECTRICITY_REQUEST,
    types.PUT_PROPERTY_ELECTRICITY_SUCCESS,
    types.PUT_PROPERTY_ELECTRICITY_FAILURE,
  ],
  promise: (api) => api.put('accountingItem/electricities/', data),
});

export const getElectricity = (guid) => ({
  types: [
    types.GET_PROPERTY_ELECTRICITY_REQUEST,
    types.GET_PROPERTY_ELECTRICITY_SUCCESS,
    types.GET_PROPERTY_ELECTRICITY_FAILURE,
  ],
  promise: (api) => api.get(`accountingItem/electricities/get/${guid}`),
});

export const resetElectricityForm = () => ({
  type: types.RESET_ELECTRICITY_FORM,
});
