import * as types from '../../../../constants/actionTypes/property/PropertyConstants';
// import { createParams } from '../../../../helpers/createReqParams';

export const postWhTransport = (data) => ({
  types: [
    types.POST_PROPERTY_WH_TRANSPORT_REQUEST,
    types.POST_PROPERTY_WH_TRANSPORT_SUCCESS,
    types.POST_PROPERTY_WH_TRANSPORT_FAILURE,
  ],
  promise: (api) => api.post('accountingItem/whTransports/', data),
});

export const putWhTransport = (data) => ({
  types: [
    types.PUT_PROPERTY_WH_TRANSPORT_REQUEST,
    types.PUT_PROPERTY_WH_TRANSPORT_SUCCESS,
    types.PUT_PROPERTY_WH_TRANSPORT_FAILURE,
  ],
  promise: (api) => api.put('accountingItem/whTransports/', data),
});

export const getWhTransport = (guid) => ({
  types: [
    types.GET_PROPERTY_WH_TRANSPORT_REQUEST,
    types.GET_PROPERTY_WH_TRANSPORT_SUCCESS,
    types.GET_PROPERTY_WH_TRANSPORT_FAILURE,
  ],
  promise: (api) => api.get(`accountingItem/whTransports/get/${guid}`),
});

export const resetWhTransportForm = () => ({
  type: types.RESET_WH_TRANSPORT_FORM,
});
