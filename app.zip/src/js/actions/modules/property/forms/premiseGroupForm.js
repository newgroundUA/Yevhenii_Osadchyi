import * as types from '../../../../constants/actionTypes/property/PropertyConstants';

export const postPremiseGroup = (data) => ({
  types: [
    types.POST_PROPERTY_PREMISE_GROUP_REQUEST,
    types.POST_PROPERTY_PREMISE_GROUP_SUCCESS,
    types.POST_PROPERTY_PREMISE_GROUP_FAILURE,
  ],
  promise: (api) => api.post('accountingItem/groupOfPremise/', data),
});

export const putPremiseGroup = (data) => ({
  types: [
    types.PUT_PROPERTY_PREMISE_GROUP_REQUEST,
    types.PUT_PROPERTY_PREMISE_GROUP_SUCCESS,
    types.PUT_PROPERTY_PREMISE_GROUP_FAILURE,
  ],
  promise: (api) => api.put('accountingItem/groupOfPremise/', data),
});

export const getPremiseGroup = (guid) => ({
  types: [
    types.GET_PROPERTY_PREMISE_GROUP_REQUEST,
    types.GET_PROPERTY_PREMISE_GROUP_SUCCESS,
    types.GET_PROPERTY_PREMISE_GROUP_FAILURE,
  ],
  promise: (api) => api.get(`accountingItem/groupOfPremise/get/${guid}`),
});

export const resetPremiseGroupForm = () => ({
  type: types.RESET_PREMISE_GROUP_FORM,
});

export const resetResetPremiseGroupDoneStatus = () => ({
  type: types.RESET_PREMISE_GROUP_DONE_STATUS,
});
