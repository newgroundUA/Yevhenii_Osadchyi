import * as types from '../../../../constants/actionTypes/property/PropertyConstants';
// import { createParams } from '../../../../helpers/createReqParams';

export const postEquipment = (data) => ({
  types: [
    types.POST_PROPERTY_EQUIPMENT_REQUEST,
    types.POST_PROPERTY_EQUIPMENT_SUCCESS,
    types.POST_PROPERTY_EQUIPMENT_FAILURE,
  ],
  promise: (api) => api.post('accountingItem/equipments/', data),
});

export const putEquipment = (data) => ({
  types: [
    types.PUT_PROPERTY_EQUIPMENT_REQUEST,
    types.PUT_PROPERTY_EQUIPMENT_SUCCESS,
    types.PUT_PROPERTY_EQUIPMENT_FAILURE,
  ],
  promise: (api) => api.put('accountingItem/equipments/', data),
});

export const getEquipment = (guid) => ({
  types: [
    types.GET_PROPERTY_EQUIPMENT_REQUEST,
    types.GET_PROPERTY_EQUIPMENT_SUCCESS,
    types.GET_PROPERTY_EQUIPMENT_FAILURE,
  ],
  promise: (api) => api.get(`accountingItem/equipments/get/${guid}`),
});

export const resetEquipmentForm = () => ({
  type: types.RESET_EQUIPMENT_FORM,
});
