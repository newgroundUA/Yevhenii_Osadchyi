import * as types from '../../../../constants/actionTypes/property/PropertyConstants';
// import { createParams } from '../../../../helpers/createReqParams';

export const postIntellRight = (data) => ({
  types: [
    types.POST_PROPERTY_INTELL_RIGHT_REQUEST,
    types.POST_PROPERTY_INTELL_RIGHT_SUCCESS,
    types.POST_PROPERTY_INTELL_RIGHT_FAILURE,
  ],
  promise: (api) => api.post('accountingItem/intellRights/', data),
});

export const putIntellRight = (data) => ({
  types: [
    types.PUT_PROPERTY_INTELL_RIGHT_REQUEST,
    types.PUT_PROPERTY_INTELL_RIGHT_SUCCESS,
    types.PUT_PROPERTY_INTELL_RIGHT_FAILURE,
  ],
  promise: (api) => api.put('accountingItem/intellRights/', data),
});

export const getIntellRight = (guid) => ({
  types: [
    types.GET_PROPERTY_INTELL_RIGHT_REQUEST,
    types.GET_PROPERTY_INTELL_RIGHT_SUCCESS,
    types.GET_PROPERTY_INTELL_RIGHT_FAILURE,
  ],
  promise: (api) => api.get(`accountingItem/intellRights/get/${guid}`),
});

export const resetIntellRightForm = () => ({
  type: types.RESET_INTELL_RIGHT_FORM,
});
