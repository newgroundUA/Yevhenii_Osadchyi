import * as types from '../../../../constants/actionTypes/property/PropertyConstants';
// import { createParams } from '../../../../helpers/createReqParams';

export const postPremise = (data) => ({
  types: [
    types.POST_PROPERTY_PREMISE_REQUEST,
    types.POST_PROPERTY_PREMISE_SUCCESS,
    types.POST_PROPERTY_PREMISE_FAILURE,
  ],
  promise: (api) => api.post('accountingItem/premises/', data),
});

export const putPremise = (data) => ({
  types: [
    types.PUT_PROPERTY_PREMISE_REQUEST,
    types.PUT_PROPERTY_PREMISE_SUCCESS,
    types.PUT_PROPERTY_PREMISE_FAILURE,
  ],
  promise: (api) => api.put('accountingItem/premises/', data),
});

export const getPremise = (guid) => ({
  types: [
    types.GET_PROPERTY_PREMISE_REQUEST,
    types.GET_PROPERTY_PREMISE_SUCCESS,
    types.GET_PROPERTY_PREMISE_FAILURE,
  ],
  promise: (api) => api.get(`accountingItem/premises/get/${guid}`),
});

export const resetPremiseForm = () => ({
  type: types.RESET_PREMISE_FORM,
});

export const resetPremiseDoneStatus = () => ({
  type: types.RESET_PREMISE_DONE_STATUS,
});
