import * as types from '../../../../constants/actionTypes/property/PropertyConstants';

export const loadPropertyConstructions = (guid) => ({
  types: [
    types.LOAD_GET_CONSTRUCTIONS_REQUEST,
    types.LOAD_GET_CONSTRUCTIONS_SUCCESS,
    types.LOAD_GET_CONSTRUCTIONS_FAILURE,
  ],
  promise: (api) => api.get(`accountingItem/constructions/get/${guid}`),
});

export const postConstructions = (data) => ({
  types: [
    types.LOAD_POST_CONSTRUCTIONS_REQUEST,
    types.LOAD_POST_CONSTRUCTIONS_SUCCESS,
    types.LOAD_POST_CONSTRUCTIONS_FAILURE,
  ],
  promise: (api) => api.post('accountingItem/constructions/', data),
});

export const putConstructions = (data) => ({
  types: [
    types.LOAD_PUT_CONSTRUCTIONS_REQUEST,
    types.LOAD_PUT_CONSTRUCTIONS_SUCCESS,
    types.LOAD_PUT_CONSTRUCTIONS_FAILURE,
  ],
  promise: (api) => api.put('accountingItem/constructions/', data),
});

export const resetConstructionsForm = () => ({
  type: types.RESET_CONSTRUCTIONS_FORM,
});
