import * as types from '../../../../constants/actionTypes/property/PropertyConstants';
// import { createParams } from '../../../../helpers/createReqParams';

export const postStead = (data) => ({
  types: [
    types.POST_PROPERTY_STEAD_REQUEST,
    types.POST_PROPERTY_STEAD_SUCCESS,
    types.POST_PROPERTY_STEAD_FAILURE,
  ],
  promise: (api) => api.post('accountingItem/steads/', data),
});

export const putStead = (data) => ({
  types: [
    types.PUT_PROPERTY_STEAD_REQUEST,
    types.PUT_PROPERTY_STEAD_SUCCESS,
    types.PUT_PROPERTY_STEAD_FAILURE,
  ],
  promise: (api) => api.put('accountingItem/steads/', data),
});

export const getStead = (guid) => ({
  types: [
    types.GET_PROPERTY_STEAD_REQUEST,
    types.GET_PROPERTY_STEAD_SUCCESS,
    types.GET_PROPERTY_STEAD_FAILURE,
  ],
  promise: (api) => api.get(`accountingItem/steads/get/${guid}`),
});

export const resetSteadForm = () => ({
  type: types.RESET_STEAD_FORM,
});

export const resetSteadFormIsDone = () => ({
  type: types.RESET_STEAD_FORM_IS_DONE,
});
