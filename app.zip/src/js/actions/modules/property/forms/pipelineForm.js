import * as types from '../../../../constants/actionTypes/property/PropertyConstants';
// import { createParams } from '../../../../helpers/createReqParams';

export const postPipeline = (data) => ({
  types: [
    types.POST_PROPERTY_PIPELINE_REQUEST,
    types.POST_PROPERTY_PIPELINE_SUCCESS,
    types.POST_PROPERTY_PIPELINE_FAILURE,
  ],
  promise: (api) => api.post('accountingItem/pipelines/', data),
});

export const putPipeline = (data) => ({
  types: [
    types.PUT_PROPERTY_PIPELINE_REQUEST,
    types.PUT_PROPERTY_PIPELINE_SUCCESS,
    types.PUT_PROPERTY_PIPELINE_FAILURE,
  ],
  promise: (api) => api.put('accountingItem/pipelines/', data),
});

export const getPipeline = (guid) => ({
  types: [
    types.GET_PROPERTY_PIPELINE_REQUEST,
    types.GET_PROPERTY_PIPELINE_SUCCESS,
    types.GET_PROPERTY_PIPELINE_FAILURE,
  ],
  promise: (api) => api.get(`accountingItem/pipelines/get/${guid}`),
});

export const resetPipelineForm = () => ({
  type: types.RESET_PIPELINE_FORM,
});
