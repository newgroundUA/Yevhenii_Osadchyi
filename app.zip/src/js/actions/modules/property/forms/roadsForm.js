import * as types from '../../../../constants/actionTypes/property/PropertyConstants';
// import { createParams } from '../../../../helpers/createReqParams';

export const postRoad = (data) => ({
  types: [
    types.POST_PROPERTY_ROAD_REQUEST,
    types.POST_PROPERTY_ROAD_SUCCESS,
    types.POST_PROPERTY_ROAD_FAILURE,
  ],
  promise: (api) => api.post('accountingItem/roads/', data),
});

export const putRoad = (data) => ({
  types: [
    types.PUT_PROPERTY_ROAD_REQUEST,
    types.PUT_PROPERTY_ROAD_SUCCESS,
    types.PUT_PROPERTY_ROAD_FAILURE,
  ],
  promise: (api) => api.put('accountingItem/roads/', data),
});

export const getRoad = (guid) => ({
  types: [
    types.GET_PROPERTY_ROAD_REQUEST,
    types.GET_PROPERTY_ROAD_SUCCESS,
    types.GET_PROPERTY_ROAD_FAILURE,
  ],
  promise: (api) => api.get(`accountingItem/roads/get/${guid}`),
});

export const resetRoadForm = () => ({
  type: types.RESET_ROAD_FORM,
});
