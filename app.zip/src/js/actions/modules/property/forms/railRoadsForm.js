import * as types from '../../../../constants/actionTypes/property/PropertyConstants';
// import { createParams } from '../../../../helpers/createReqParams';

export const postRailRoad = (data) => ({
  types: [
    types.POST_PROPERTY_RAIL_ROAD_REQUEST,
    types.POST_PROPERTY_RAIL_ROAD_SUCCESS,
    types.POST_PROPERTY_RAIL_ROAD_FAILURE,
  ],
  promise: (api) => api.post('accountingItem/railRoads/', data),
});

export const putRailRoad = (data) => ({
  types: [
    types.PUT_PROPERTY_RAIL_ROAD_REQUEST,
    types.PUT_PROPERTY_RAIL_ROAD_SUCCESS,
    types.PUT_PROPERTY_RAIL_ROAD_FAILURE,
  ],
  promise: (api) => api.put('accountingItem/railRoads/', data),
});

export const getRailRoad = (guid) => ({
  types: [
    types.GET_PROPERTY_RAIL_ROAD_REQUEST,
    types.GET_PROPERTY_RAIL_ROAD_SUCCESS,
    types.GET_PROPERTY_RAIL_ROAD_FAILURE,
  ],
  promise: (api) => api.get(`accountingItem/railRoads/get/${guid}`),
});

export const resetRailRoadForm = () => ({
  type: types.RESET_RAIL_ROAD_FORM,
});
