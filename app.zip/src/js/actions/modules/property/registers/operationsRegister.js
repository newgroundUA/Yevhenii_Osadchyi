import * as types from '../../../../constants/actionTypes/property/PropertyConstants';

export const mountOperationsRegister = (key) => ({
  key,
  type: types.MOUNT_OPERATIONS_REGISTER,
});

export const unmountOperationsRegister = (key) => ({
  key,
  type: types.UNMOUNT_OPERATIONS_REGISTER,
});

export const setOperationsRegister = (key, files) => ({
  type: types.LOAD_PROPERTY_OPERATIONS_REGISTER_SUCCESS,
  data: files,
  key,
});

export const resetOperationsRegister = (key) => setOperationsRegister(key, []);

export const loadPropertyOperationsRegister = (key, objectGUID) => ({
  key,
  types: [
    types.LOAD_PROPERTY_OPERATIONS_REGISTER_REQUEST,
    types.LOAD_PROPERTY_OPERATIONS_REGISTER_SUCCESS,
    types.LOAD_PROPERTY_OPERATIONS_REGISTER_FAILURE,
  ],
  promise: (api) =>
    api.get(`accountingItem/objectsOperationStatus/get/accountingItem/${objectGUID}`),
});

export const postOperation = (key, data) => ({
  key,
  types: [
    types.POST_PROPERTY_OPERATIONS_REGISTER_REQUEST,
    types.POST_PROPERTY_OPERATIONS_REGISTER_SUCCESS,
    types.POST_PROPERTY_OPERATIONS_REGISTER_FAILURE,
  ],
  promise: (api) => api.post('accountingItem/objectsOperationStatus/', data),
});

export const putOperation = (key, data) => ({
  key,
  types: [
    types.PUT_PROPERTY_OPERATIONS_REGISTER_REQUEST,
    types.PUT_PROPERTY_OPERATIONS_REGISTER_SUCCESS,
    types.PUT_PROPERTY_OPERATIONS_REGISTER_FAILURE,
  ],
  promise: (api) => api.put('accountingItem/objectsOperationStatus/', data),
});

export const deleteOperation = (key, guid) => ({
  key,
  types: [
    types.DELETE_PROPERTY_OPERATIONS_REGISTER_REQUEST,
    types.DELETE_PROPERTY_OPERATIONS_REGISTER_SUCCESS,
    types.DELETE_PROPERTY_OPERATIONS_REGISTER_FAILURE,
  ],
  promise: (api) => api.delete(`accountingItem/objectsOperationStatus/${guid}`),
});
