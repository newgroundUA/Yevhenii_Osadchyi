import * as types from '../../../../constants/actionTypes/property/PropertyConstants';
import { createParams } from '../../../../helpers/createReqParams';

export const getAnimalsRegister = (data) => ({
  types: [
    types.GET_PROPERTY_ANIMALS_REGISTER_REQUEST,
    types.GET_PROPERTY_ANIMALS_REGISTER_SUCCESS,
    types.GET_PROPERTY_ANIMALS_REGISTER_FAILURE,
  ],
  promise: (api) => api.post('accountingItem/get', createParams(data)),
});

export const setValueRequestBody = (key, value) => ({
  type: types.SET_PROPERTY_ANIMALS_REGISTER_VALUE_REQUEST_BODY,
  key,
  value,
});

export const setValuePages = (key, value) => ({
  type: types.SET_PROPERTY_ANIMALS_REGISTER_VALUE_PAGES,
  key,
  value,
});

export const setValueFastFilters = (key, value) => ({
  type: types.SET_PROPERTY_ANIMALS_REGISTER_VALUE_FAST_FILTERS,
  key,
  value,
});

export const resetFilters = () => ({
  type: types.RESET_PROPERTY_ANIMALS_REGISTER_FILTERS,
});
