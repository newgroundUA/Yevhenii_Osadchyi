import * as types from '../../../constants/actionTypes/accountingItem/groupOfPremise';

export const getGroupOfPremise = (data) => ({
  types: [
    types.GET_GROUP_OF_PREMISE_REQUEST,
    types.GET_GROUP_OF_PREMISE_SUCCESS,
    types.GET_GROUP_OF_PREMISE_FAILURE,
  ],
  promise: (api) =>
    api.get(`accountingItem/groupOfPremise/get?offset=${data.offset}&limit=${data.limit}`),
});
