import * as types from '../../../constants/actionTypes/accountingItem/bindingDocuments';

export const bindDocumentToAccountingItem = (data) => ({
  types: [
    types.BIND_DOCUMENT_TO_ACCOUNTING_ITEM_REQUEST,
    types.BIND_DOCUMENT_TO_ACCOUNTING_ITEM_SUCCESS,
    types.BIND_DOCUMENT_TO_ACCOUNTING_ITEM_FAILURE,
  ],
  promise: (api) =>
    api.get(
      `accountingItem/documents/get/accountingItem/${data.accountingItem}/bind/document/${
        data.documentGuid
      }`,
    ),
});

export const unBindDocumentToAccountingItem = (data) => ({
  types: [
    types.UNBIND_DOCUMENT_TO_ACCOUNTING_ITEM_REQUEST,
    types.UNBIND_DOCUMENT_TO_ACCOUNTING_ITEM_SUCCESS,
    types.UNBIND_DOCUMENT_TO_ACCOUNTING_ITEM_FAILURE,
  ],
  promise: (api) =>
    api.get(
      `accountingItem/documents/get/accountingItem/${data.accountingItem}/unBind/document/${
        data.documentGuid
      }`,
    ),
});

export const getAccountingItemBoundDocuments = (data) => ({
  types: [
    types.GET_ACCOUNTING_ITEM_BOUND_DOCUMENTS_REQUEST,
    types.GET_ACCOUNTING_ITEM_BOUND_DOCUMENTS_SUCCESS,
    types.GET_ACCOUNTING_ITEM_BOUND_DOCUMENTS_FAILURE,
  ],
  promise: (api) => api.get(`accountingItem/documents/get/accountingItem/${data.guid}`),
});
