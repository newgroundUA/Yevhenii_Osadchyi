import * as types from '../../../constants/actionTypes/lease/LeaseConstants';

export const getLeaseAffairsRegister = () => ({
  types: [
    types.GET_LEASE_AFFAIRS_REGISTER_REQUEST,
    types.GET_LEASE_AFFAIRS_REGISTER_SUCCESS,
    types.GET_LEASE_AFFAIRS_REGISTER_FAILURE,
  ],
  promise: () =>
    new Promise((res) =>
      res({
        data: Array(30)
          .fill(0)
          .map((el, id) => ({ guid: `${id}` })),
        result: {
          total: 30,
        },
      }),
    ),
});

export const setValueRequestBody = (key, value) => ({
  type: types.SET_LEASE_AFFAIRS_REGISTER_VALUE_REQUEST_BODY,
  key,
  value,
});

export const setValuePages = (key, value) => ({
  type: types.SET_LEASE_AFFAIRS_REGISTER_VALUE_PAGES,
  key,
  value,
});

export const setValueFastFilters = (key, value) => ({
  type: types.SET_LEASE_AFFAIRS_REGISTER_VALUE_FAST_FILTERS,
  key,
  value,
});

export const resetFilters = () => ({
  type: types.RESET_LEASE_AFFAIRS_REGISTER_FILTERS,
});
