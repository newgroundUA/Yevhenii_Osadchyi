import * as types from '../../../constants/actionTypes/lease/LeaseContractPaymentScheduleRegisterConstants';
import {
  createParams,
  // createStringReqParams
} from '../../../helpers/createReqParams';

export const getLeaseContractPaymentSchedule = (data) => ({
  types: [
    types.GET_LEASE_CONTRACT_PAYMENT_SCHEDULE_REGISTER_REQUEST,
    types.GET_LEASE_CONTRACT_PAYMENT_SCHEDULE_REGISTER_SUCCESS,
    types.GET_LEASE_CONTRACT_PAYMENT_SCHEDULE_REGISTER_FAILURE,
  ],
  promise: (api) => api.post('lease/registry/leaseContractPaymentSchedule/get', createParams(data)),
});

export const setValueRequestBody = (key, value) => ({
  type: types.SET_LEASE_CONTRACT_PAYMENT_SCHEDULE_REGISTER_VALUE_REQUEST_BODY,
  key,
  value,
});

export const setValuePages = (key, value) => ({
  type: types.SET_LEASE_CONTRACT_PAYMENT_SCHEDULE_REGISTER_VALUE_PAGES,
  key,
  value,
});

export const setValueFastFilters = (key, value) => ({
  type: types.SET_LEASE_CONTRACT_PAYMENT_SCHEDULE_REGISTER_VALUE_FAST_FILTERS,
  key,
  value,
});

export const resetFilters = () => ({
  type: types.RESET_LEASE_CONTRACT_PAYMENT_SCHEDULE_REGISTER_FILTERS,
});
