import * as types from '../../../constants/actionTypes/lease/LeasePeriodicalByBalanceholderlReportConstants';

export const getLeacePeriodocialByBalanceHolderReport = (guid) => ({
  types: [
    types.GET_LEASE_PERIODICAL_BY_BALANCE_HOLDER_REPORT_REQUEST,
    types.GET_LEASE_PERIODICAL_BY_BALANCE_HOLDER_REPORT_SUCCESS,
    types.GET_LEASE_PERIODICAL_BY_BALANCE_HOLDER_REPORT_FAILURE,
  ],
  promise: (api) => api.get(`leasePeriodicalByBalanceholderReport/get/${guid}`),
});

export const postLeacePeriodocialByBalanceHolderReport = (data) => ({
  types: [
    types.POST_LEASE_PERIODICAL_BY_BALANCE_HOLDER_REPORT_REQUEST,
    types.POST_LEASE_PERIODICAL_BY_BALANCE_HOLDER_REPORT_SUCCESS,
    types.POST_LEASE_PERIODICAL_BY_BALANCE_HOLDER_REPORT_FAILURE,
  ],
  promise: (api) => api.post('leasePeriodicalByBalanceholderReport/', data),
});

export const putLeacePeriodocialByBalanceHolderReport = (data) => ({
  types: [
    types.PUT_LEASE_PERIODICAL_BY_BALANCE_HOLDER_REPORT_REQUEST,
    types.PUT_LEASE_PERIODICAL_BY_BALANCE_HOLDER_REPORT_SUCCESS,
    types.PUT_LEASE_PERIODICAL_BY_BALANCE_HOLDER_REPORT_FAILURE,
  ],
  promise: (api) => api.put('leasePeriodicalByBalanceholderReport/', data),
});

export const resetLeacePeriodocialByBalanceHolderReportForm = () => ({
  type: types.RESET_LEASE_PERIODICAL_BY_BALANCE_HOLDER_REPORT_FORM,
});

export const resetLeacePeriodocialByBalanceHolderReportDoneStatus = () => ({
  type: types.RESET_LEASE_PERIODICAL_BY_BALANCE_HOLDER_REPORT_DONE_STATUS,
});
