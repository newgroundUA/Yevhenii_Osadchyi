import * as types from '../../../constants/actionTypes/lease/CompetitionsConstants';

export const getCompetitions = (guid) => ({
  types: [
    types.GET_COMPETITIONS_REQUEST,
    types.GET_COMPETITIONS_SUCCESS,
    types.GET_COMPETITIONS_FAILURE,
  ],
  promise: (api) => api.get(`leaseCompetition/get/${guid}`),
});

export const postCompetitions = (data) => ({
  types: [
    types.POST_COMPETITIONS_REQUEST,
    types.POST_COMPETITIONS_SUCCESS,
    types.POST_COMPETITIONS_FAILURE,
  ],
  promise: (api) => api.post('leaseCompetition/', data),
});

export const putCompetitions = (data) => ({
  types: [
    types.PUT_COMPETITIONS_REQUEST,
    types.PUT_COMPETITIONS_SUCCESS,
    types.PUT_COMPETITIONS_FAILURE,
  ],
  promise: (api) => api.put('leaseCompetition/', data),
});

export const resetCompetitionsForm = () => ({
  type: types.RESET_COMPETITIONS_FORM,
});

export const resetCompetitionsDoneStatus = () => ({
  type: types.RESET_COMPETITIONS_DONE_STATUS,
});

export const postSubmitDocList = (data) => ({
  types: [
    types.POST_SUBMIT_DOC_LIST_REQUEST,
    types.POST_SUBMIT_DOC_LIST_SUCCESS,
    types.POST_SUBMIT_DOC_LIST_FAILURE,
  ],
  promise: (api) => api.post('submitDocList/', data),
});

export const putSubmitDocList = (data) => ({
  types: [
    types.PUT_SUBMIT_DOC_LIST_REQUEST,
    types.PUT_SUBMIT_DOC_LIST_SUCCESS,
    types.PUT_SUBMIT_DOC_LIST_FAILURE,
  ],
  promise: (api) => api.put('submitDocList/', data),
});

export const postAdvertLists = (data) => ({
  types: [
    types.POST_ADVERT_LISTS_REQUEST,
    types.POST_ADVERT_LISTS_SUCCESS,
    types.POST_ADVERT_LISTS_FAILURE,
  ],
  promise: (api) => api.post('advertList/', data),
});

export const putAdvertLists = (data) => ({
  types: [
    types.PUT_ADVERT_LISTS_REQUEST,
    types.PUT_ADVERT_LISTS_SUCCESS,
    types.PUT_ADVERT_LISTS_FAILURE,
  ],
  promise: (api) => api.put('advertList/', data),
});

// CompReqList

export const postCompReqList = (data) => ({
  types: [
    types.POST_COMP_REQ_LIST_REQUEST,
    types.POST_COMP_REQ_LIST_SUCCESS,
    types.POST_COMP_REQ_LIST_FAILURE,
  ],
  promise: (api) => api.post('compReqList/', data),
});

export const putCompReqList = (data) => ({
  types: [
    types.PUT_COMP_REQ_LIST_REQUEST,
    types.PUT_COMP_REQ_LIST_SUCCESS,
    types.PUT_COMP_REQ_LIST_FAILURE,
  ],
  promise: (api) => api.put('compReqList/', data),
});

// MemberOfCompCommission

export const postMemberOfCompCommission = (data) => ({
  types: [
    types.POST_MEMBER_OF_COMP_COMMISSION_REQUEST,
    types.POST_MEMBER_OF_COMP_COMMISSION_SUCCESS,
    types.POST_MEMBER_OF_COMP_COMMISSION_FAILURE,
  ],
  promise: (api) => api.post('memberOfCompCommission/', data),
});

export const putMemberOfCompCommission = (data) => ({
  types: [
    types.PUT_MEMBER_OF_COMP_COMMISSION_REQUEST,
    types.PUT_MEMBER_OF_COMP_COMMISSION_SUCCESS,
    types.PUT_MEMBER_OF_COMP_COMMISSION_FAILURE,
  ],
  promise: (api) => api.put('memberOfCompCommission/', data),
});
