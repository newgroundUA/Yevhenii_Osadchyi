import * as types from '../../../constants/actionTypes/lease/LeasePaymentToPurposeConstants';
import { createParams } from '../../../helpers/createReqParams';

// paymentToPurposeRegister

export const getPaymentToPurposeRegister = (data) => ({
  types: [
    types.GET_PAYMENT_TO_PURPOSE_REGISTER_REQUEST,
    types.GET_PAYMENT_TO_PURPOSE_REGISTER_SUCCESS,
    types.GET_PAYMENT_TO_PURPOSE_REGISTER_FAILURE,
  ],
  promise: (api) =>
    api.post(
      'receivedPaymentToPurposeList/registry/receivedPaymentToPurposeList/get',
      createParams(data),
    ),
});

export const setValueRequestBody = (key, value) => ({
  type: types.SET_PAYMENT_TO_PURPOSE_REGISTER_VALUE_REQUEST_BODY,
  key,
  value,
});

export const setValuePages = (key, value) => ({
  type: types.SET_PAYMENT_TO_PURPOSE_REGISTER_VALUE_PAGES,
  key,
  value,
});

export const setValueFastFilters = (key, value) => ({
  type: types.SET_PAYMENT_TO_PURPOSE_REGISTER_VALUE_FAST_FILTERS,
  key,
  value,
});

export const resetFilters = () => ({
  type: types.RESET_PAYMENT_TO_PURPOSE_REGISTER_FILTERS,
});
