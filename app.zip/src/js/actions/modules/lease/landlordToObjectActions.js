import * as types from '../../../constants/actionTypes/lease/LandlordToObjectConstants';

// /lease/landlordToObjects/

export const getLandlordToObjects = (guid) => ({
  types: [
    types.GET_LANDLORD_TO_OBJECT_REQUEST,
    types.GET_LANDLORD_TO_OBJECT_SUCCESS,
    types.GET_LANDLORD_TO_OBJECT_FAILURE,
  ],
  promise: (api) => api.get(`lease/landlordToObjects/get/${guid}`),
});

export const postLandlordToObjects = (data) => ({
  types: [
    types.POST_LANDLORD_TO_OBJECT_REQUEST,
    types.POST_LANDLORD_TO_OBJECT_SUCCESS,
    types.POST_LANDLORD_TO_OBJECT_FAILURE,
  ],
  promise: (api) => api.post('lease/landlordToObjects/', data),
});

export const putLandlordToObjects = (data) => ({
  types: [
    types.PUT_LANDLORD_TO_OBJECT_REQUEST,
    types.PUT_LANDLORD_TO_OBJECT_SUCCESS,
    types.PUT_LANDLORD_TO_OBJECT_FAILURE,
  ],
  promise: (api) => api.put('lease/landlordToObjects/', data),
});

export const resetLandlordToObjectsForm = () => ({
  type: types.RESET_LANDLORD_TO_OBJECT_FORM,
});

export const resetLandlordToObjectsDoneStatus = () => ({
  type: types.RESET_LANDLORD_TO_OBJECT_DONE_STATUS,
});

// /lease/leaseObjects/

export const getLeaseObjectsList = (params) => ({
  types: [
    types.GET_LEASE_OBJECTS_LIST_REQUEST,
    types.GET_LEASE_OBJECTS_LIST_SUCCESS,
    types.GET_LEASE_OBJECTS_LIST_FAILURE,
  ],
  promise: (api) => api.get(`lease/leaseObjects/get?limit=${params.limit}&offset=${params.offset}`),
});

export const getLeaseObjects = (guid) => ({
  types: [
    types.GET_LEASE_OBJECTS_REQUEST,
    types.GET_LEASE_OBJECTS_SUCCESS,
    types.GET_LEASE_OBJECTS_FAILURE,
  ],
  promise: (api) => api.get(`lease/leaseObjects/get/${guid}`),
});

export const postLeaseObjects = (data) => ({
  types: [
    types.POST_LEASE_OBJECTS_REQUEST,
    types.POST_LEASE_OBJECTS_SUCCESS,
    types.POST_LEASE_OBJECTS_FAILURE,
  ],
  promise: (api) => api.post('lease/leaseObjects/', data),
});

export const putLeaseObjects = (data) => ({
  types: [
    types.PUT_LEASE_OBJECTS_REQUEST,
    types.PUT_LEASE_OBJECTS_SUCCESS,
    types.PUT_LEASE_OBJECTS_FAILURE,
  ],
  promise: (api) => api.put('lease/leaseObjects/', data),
});

export const getLeaseObjectsLiveSearch = ({ predicate }) => ({
  types: [
    types.GET_LEASE_OBJECTS_LIVE_SEARCH_REQUEST,
    types.GET_LEASE_OBJECTS_LIVE_SEARCH_SUCCESS,
    types.GET_LEASE_OBJECTS_LIVE_SEARCH_FAILURE,
  ],
  promise: (api) => api.get(`lease/leaseObjects/liveSearch?predicate=${predicate}&page=0&size=50`),
});
