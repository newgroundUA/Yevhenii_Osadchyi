import * as types from '../../../constants/actionTypes/lease/LeaseCasesConstants';
import {
  createParams,
  // createStringReqParams
} from '../../../helpers/createReqParams';

export const getLeaseCasesRegister = (data) => ({
  types: [
    types.GET_LEASE_CASES_REGISTER_REQUEST,
    types.GET_LEASE_CASES_REGISTER_SUCCESS,
    types.GET_LEASE_CASES_REGISTER_FAILURE,
  ],
  promise: (api) => api.post('lease/registry/leaseCasesRegistry/get', createParams(data)),
});

export const setValueRequestBody = (key, value) => ({
  type: types.SET_LEASE_CASES_REGISTER_VALUE_REQUEST_BODY,
  key,
  value,
});

export const setValuePages = (key, value) => ({
  type: types.SET_LEASE_CASES_REGISTER_VALUE_PAGES,
  key,
  value,
});

export const setValueFastFilters = (key, value) => ({
  type: types.SET_LEASE_CASES_REGISTER_VALUE_FAST_FILTERS,
  key,
  value,
});

export const resetFilters = () => ({
  type: types.RESET_LEASE_CASES_REGISTER_FILTERS,
});

export const getLeaseCases = (guid) => ({
  types: [
    types.GET_LEASE_CASES_REQUEST,
    types.GET_LEASE_CASES_SUCCESS,
    types.GET_LEASE_CASES_FAILURE,
  ],
  promise: (api) => api.get(`lease/leaseCases/get/${guid}`),
});

export const postLeaseCases = (data) => ({
  types: [
    types.POST_LEASE_CASES_REQUEST,
    types.POST_LEASE_CASES_SUCCESS,
    types.POST_LEASE_CASES_FAILURE,
  ],
  promise: (api) => api.post('lease/leaseCases/', data),
});

export const putLeaseCases = (data) => ({
  types: [
    types.PUT_LEASE_CASES_REQUEST,
    types.PUT_LEASE_CASES_SUCCESS,
    types.PUT_LEASE_CASES_FAILURE,
  ],
  promise: (api) => api.put('lease/leaseCases/', data),
});

export const resetLeaseCasesForm = () => ({
  type: types.RESET_LEASE_CASES_FORM,
});

export const resetLeaseCasesDoneStatus = () => ({
  type: types.RESET_LEASE_CASES_DONE_STATUS,
});
