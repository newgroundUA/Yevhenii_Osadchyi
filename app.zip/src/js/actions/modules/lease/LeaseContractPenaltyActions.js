import * as types from '../../../constants/actionTypes/lease/LeaseContractPenaltyConstants';
import {
  createParams,
  // createStringReqParams
} from '../../../helpers/createReqParams';

export const getLeaseContractPenalty = (data) => ({
  types: [
    types.GET_LEASE_CONTRACT_PENALTY_REQUEST,
    types.GET_LEASE_CONTRACT_PENALTY_SUCCESS,
    types.GET_LEASE_CONTRACT_PENALTY_FAILURE,
  ],
  promise: (api) => api.post('lease/leasecontract/penalty/registry', createParams(data)),
});

export const setValueRequestBody = (key, value) => ({
  type: types.SET_LEASE_CONTRACT_PENALTY_VALUE_REQUEST_BODY,
  key,
  value,
});

export const setValuePages = (key, value) => ({
  type: types.SET_LEASE_CONTRACT_PENALTY_VALUE_PAGES,
  key,
  value,
});

export const setValueFastFilters = (key, value) => ({
  type: types.SET_LEASE_CONTRACT_PENALTY_VALUE_FAST_FILTERS,
  key,
  value,
});

export const resetFilters = () => ({
  type: types.RESET_LEASE_CONTRACT_PENALTY_FILTERS,
});
