import * as types from '../../../constants/actionTypes/lease/LeaseConstants';

export const getLeaseClaimActionActivityCard = (guid) => ({
  types: [
    types.GET_LEASE_CLAIM_ACTION_ACTIVITY_CARD_REQUEST,
    types.GET_LEASE_CLAIM_ACTION_ACTIVITY_CARD_SUCCESS,
    types.GET_LEASE_CLAIM_ACTION_ACTIVITY_CARD_FAILURE,
  ],
  promise: (api) => api.get(`lease/ppd/claimActionActivity/${guid}`),
});

export const resetLeaseClaimActionActivityCard = (storeKey) => ({
  type: types.RESET_LEASE_CLAIM_ACTION_ACTIVITY_CARD_SUCCESS,
  storeKey,
});

export const getLeaseClaimActionActivityStep = (guid) => ({
  types: [
    types.GET_LEASE_CLAIM_ACTION_ACTIVITY_STEP_REQUEST,
    types.GET_LEASE_CLAIM_ACTION_ACTIVITY_STEP_SUCCESS,
    types.GET_LEASE_CLAIM_ACTION_ACTIVITY_STEP_FAILURE,
  ],
  promise: (api) => api.post(`lease/ppd/step/get/claimActionActivity/${guid}`),
  // storeKey: guid,
});

export const postLeaseClaimActionActivityStep = (data, storeKey) => ({
  types: [
    types.POST_LEASE_CLAIM_ACTION_ACTIVITY_STEP_REQUEST,
    types.POST_LEASE_CLAIM_ACTION_ACTIVITY_STEP_SUCCESS,
    types.POST_LEASE_CLAIM_ACTION_ACTIVITY_STEP_FAILURE,
  ],
  promise: (api) => api.post('lease/ppd/step/', data),
  storeKey,
});

export const putLeaseClaimActionActivityStep = (data, storeKey) => ({
  types: [
    types.PUT_LEASE_CLAIM_ACTION_ACTIVITY_STEP_REQUEST,
    types.PUT_LEASE_CLAIM_ACTION_ACTIVITY_STEP_SUCCESS,
    types.PUT_LEASE_CLAIM_ACTION_ACTIVITY_STEP_FAILURE,
  ],
  promise: (api) => api.put('lease/ppd/step/', data),
  storeKey,
});

export const putDeactivateLeaseClaimActionActivityStep = (data, storeKey) => ({
  types: [
    types.PUT_DEACTIVATE_LEASE_CLAIM_ACTION_ACTIVITY_STEP_REQUEST,
    types.PUT_DEACTIVATE_LEASE_CLAIM_ACTION_ACTIVITY_STEP_SUCCESS,
    types.PUT_DEACTIVATE_LEASE_CLAIM_ACTION_ACTIVITY_STEP_FAILURE,
  ],
  promise: (api) => api.put('lease/ppd/step/deactivate/', data),
  storeKey,
});

export const getLeaseClaimActionActivityStepStage = (guid) => ({
  types: [
    types.GET_LEASE_CLAIM_ACTION_ACTIVITY_STEP_STAGE_REQUEST,
    types.GET_LEASE_CLAIM_ACTION_ACTIVITY_STEP_STAGE_SUCCESS,
    types.GET_LEASE_CLAIM_ACTION_ACTIVITY_STEP_STAGE_FAILURE,
  ],
  promise: (api) => api.get(`lease/ppd/stepStage/byStepGuid/get/${guid}`),
  storeKey: guid,
});

export const postLeaseClaimActionActivityStepStage = (data, storeKey) => ({
  types: [
    types.POST_LEASE_CLAIM_ACTION_ACTIVITY_STEP_STAGE_REQUEST,
    types.POST_LEASE_CLAIM_ACTION_ACTIVITY_STEP_STAGE_SUCCESS,
    types.POST_LEASE_CLAIM_ACTION_ACTIVITY_STEP_STAGE_FAILURE,
  ],
  promise: (api) => api.post('lease/ppd/stepStage/', data),
  storeKey,
});

export const putLeaseClaimActionActivityStepStage = (data, storeKey) => ({
  types: [
    types.PUT_LEASE_CLAIM_ACTION_ACTIVITY_STEP_STAGE_REQUEST,
    types.PUT_LEASE_CLAIM_ACTION_ACTIVITY_STEP_STAGE_SUCCESS,
    types.PUT_LEASE_CLAIM_ACTION_ACTIVITY_STEP_STAGE_FAILURE,
  ],
  promise: (api) => api.put('lease/ppd/stepStage/', data),
  storeKey,
});

export const bindDocToLeaseCAA = (data, storeKey, stepStageGuid) => ({
  type: types.BIND_DOC_TO_LEASE_CAA,
  data,
  storeKey,
  stepStageGuid,
});

export const resetLeaseClaimActionActivityStep = (storeKey) => ({
  type: types.RESET_LEASE_CLAIM_ACTION_ACTIVITY_STEP,
  storeKey,
});

export const resetLeaseClaimActionActivityStepStages = (storeKey) => ({
  type: types.RESET_LEASE_CLAIM_ACTION_ACTIVITY_STEP_STAGE,
  storeKey,
});
