import * as types from '../../../constants/actionTypes/lease/LeaseClaimActionActivityConstants';
import { createParams } from '../../../helpers/createReqParams';
import { withAuthDownload } from '../../../api/withAuth';

export const loadClaimActivities = (data) => ({
  types: [
    types.LOAD_GET_CLAIM_ACTION_ACTIVITIES_REQUEST,
    types.LOAD_GET_CLAIM_ACTION_ACTIVITIES_SUCCESS,
    types.LOAD_GET_CLAIM_ACTION_ACTIVITIES_FAILURE,
  ],
  promise: (api) => api.post('lease/ppd/registry/get', createParams(data)),
});

export const postGenerateClaimActivityCards = () => ({
  types: [
    types.LOAD_POST_GENERATE_CLAIM_ACTIVITY_CARDS_REQUEST,
    types.LOAD_POST_GENERATE_CLAIM_ACTIVITY_CARDS_SUCCESS,
    types.LOAD_POST_GENERATE_CLAIM_ACTIVITY_CARDS_FAILURE,
  ],
  promise: (api) => api.post('lease/ppd/claimActionActivity/'),
});

export const setValueRequestBody = (key, value) => ({
  type: types.SET_CLAIM_ACTION_ACTIVITIES_VALUE_REQUEST_BODY,
  key,
  value,
});

export const setValuePages = (key, value) => ({
  type: types.SET_CLAIM_ACTION_ACTIVITIES_VALUE_PAGES,
  key,
  value,
});

export const setValueFastFilters = (key, value) => ({
  type: types.SET_CLAIM_ACTION_ACTIVITIES_VALUE_FAST_FILTERS,
  key,
  value,
});

export const resetFilters = () => ({
  type: types.RESET_CLAIM_ACTION_ACTIVITIES_FILTERS,
});

export const exportToXls = (exportColumns, requestBody) => ({
  types: [
    types.EXPORT_CLAIM_ACTION_ACTIVITIES_TO_XLS_REQUEST,
    types.EXPORT_CLAIM_ACTION_ACTIVITIES_TO_XLS_SUCCESS,
    types.EXPORT_CLAIM_ACTION_ACTIVITIES_TO_XLS_FAILURE,
  ],
  promise: (api) => {
    // TODO: хочу передать привет бреду от бэка
    const params = createParams(requestBody);
    return withAuthDownload({
      api,
      method: 'post',
      url: 'lease/ppd/registry/export',
      data: {
        exportColumns,
        filter: {
          ...params,
          countAll: true,
        },
      },
    });
  },
});
