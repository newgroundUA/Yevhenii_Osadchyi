import * as types from '../../../constants/actionTypes/lease/LeaseConsolidatedPaymentScheduleContractPeriod';
import {
  createParams,
  // createStringReqParams
} from '../../../helpers/createReqParams';

export const getLeaseConsolidatedPaymentScheduleContractPeriod = (data) => ({
  types: [
    types.GET_LEASE_CONSOLIDATED_PAYMENT_SCHEDULE_CONTRACT_PERIOD_REQUEST,
    types.GET_LEASE_CONSOLIDATED_PAYMENT_SCHEDULE_CONTRACT_PERIOD_SUCCESS,
    types.GET_LEASE_CONSOLIDATED_PAYMENT_SCHEDULE_CONTRACT_PERIOD_FAILURE,
  ],
  promise: (api) =>
    api.post('lease/registry/LeaseConsolidatedPaymentSchedule/get', {
      ...createParams(data),
      leaseContractPaymentScheduleType: 'ContractPeriod',
    }),
});

export const setValueRequestBody = (key, value) => ({
  type: types.SET_LEASE_CONSOLIDATED_PAYMENT_SCHEDULE_CONTRACT_PERIOD_VALUE_REQUEST_BODY,
  key,
  value,
});

export const setValuePages = (key, value) => ({
  type: types.SET_LEASE_CONSOLIDATED_PAYMENT_SCHEDULE_CONTRACT_PERIOD_VALUE_PAGES,
  key,
  value,
});

export const setValueFastFilters = (key, value) => ({
  type: types.SET_LEASE_CONSOLIDATED_PAYMENT_SCHEDULE_CONTRACT_PERIOD_VALUE_FAST_FILTERS,
  key,
  value,
});

export const resetFilters = () => ({
  type: types.RESET_LEASE_CONSOLIDATED_PAYMENT_SCHEDULE_CONTRACT_PERIOD_FILTERS,
});
