import * as types from '../../../constants/actionTypes/lease/LeaseContractPaymentScheduleFormConstants';

export const getLeaseContractPaymentSchedule = (guid) => ({
  types: [
    types.GET_LEASE_CONTRACT_PAYMENT_SCHEDULE_REQUEST,
    types.GET_LEASE_CONTRACT_PAYMENT_SCHEDULE_SUCCESS,
    types.GET_LEASE_CONTRACT_PAYMENT_SCHEDULE_FAILURE,
  ],
  promise: (api) => api.get(`lease/leaseContractPaymentSchedule/get/${guid}`),
});

export const postLeaseContractPaymentSchedule = (data) => ({
  types: [
    types.POST_LEASE_CONTRACT_PAYMENT_SCHEDULE_REQUEST,
    types.POST_LEASE_CONTRACT_PAYMENT_SCHEDULE_SUCCESS,
    types.POST_LEASE_CONTRACT_PAYMENT_SCHEDULE_FAILURE,
  ],
  promise: (api) => api.post('lease/leaseContractPaymentSchedule/', data),
});

export const putLeaseContractPaymentSchedule = (data) => ({
  types: [
    types.PUT_LEASE_CONTRACT_PAYMENT_SCHEDULE_REQUEST,
    types.PUT_LEASE_CONTRACT_PAYMENT_SCHEDULE_SUCCESS,
    types.PUT_LEASE_CONTRACT_PAYMENT_SCHEDULE_FAILURE,
  ],
  promise: (api) => api.put('lease/leaseContractPaymentSchedule/', data),
});

export const resetLeaseContractPaymentScheduleForm = () => ({
  type: types.RESET_LEASE_CONTRACT_PAYMENT_SCHEDULE_FORM,
});

export const resetLeaseContractPaymentScheduleDoneStatus = () => ({
  type: types.RESET_LEASE_CONTRACT_PAYMENT_SCHEDULE_DONE_STATUS,
});
