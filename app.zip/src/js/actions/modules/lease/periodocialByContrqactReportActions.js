import * as types from '../../../constants/actionTypes/lease/LeasePeriodocialByContrqactReportConstants';

export const getLeacePeriodocialByContrqactReport = (guid) => ({
  types: [
    types.GET_LEASE_PERIODICAL_BY_CONTRACT_REPORT_REQUEST,
    types.GET_LEASE_PERIODICAL_BY_CONTRACT_REPORT_SUCCESS,
    types.GET_LEASE_PERIODICAL_BY_CONTRACT_REPORT_FAILURE,
  ],
  promise: (api) => api.get(`leasePeriodicalByContractReport/get/${guid}`),
});

export const postLeacePeriodocialByContrqactReport = (data) => ({
  types: [
    types.POST_LEASE_PERIODICAL_BY_CONTRACT_REPORT_REQUEST,
    types.POST_LEASE_PERIODICAL_BY_CONTRACT_REPORT_SUCCESS,
    types.POST_LEASE_PERIODICAL_BY_CONTRACT_REPORT_FAILURE,
  ],
  promise: (api) => api.post('leasePeriodicalByContractReport/', data),
});

export const putLeacePeriodocialByContrqactReport = (data) => ({
  types: [
    types.PUT_LEASE_PERIODICAL_BY_CONTRACT_REPORT_REQUEST,
    types.PUT_LEASE_PERIODICAL_BY_CONTRACT_REPORT_SUCCESS,
    types.PUT_LEASE_PERIODICAL_BY_CONTRACT_REPORT_FAILURE,
  ],
  promise: (api) => api.put('leasePeriodicalByContractReport/', data),
});

export const resetLeacePeriodocialByContrqactReportForm = () => ({
  type: types.RESET_LEASE_PERIODICAL_BY_CONTRACT_REPORT_FORM,
});

export const resetLeacePeriodocialByContrqactReportDoneStatus = () => ({
  type: types.RESET_LEASE_PERIODICAL_BY_CONTRACT_REPORT_DONE_STATUS,
});
