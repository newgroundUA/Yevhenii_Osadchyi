import * as types from '../../../constants/actionTypes/administration/RegistryConstants';
import { createStringReqParams } from '../../../helpers/createReqParams';

export const resetPhones = () => ({
  type: types.RESET_PHONES_FORM,
});

export const resetPhonesDoneStatus = () => ({
  type: types.RESET_PHONES_DONE_STATUS,
});

export const getPhone = (params) => ({
  types: [types.GET_PHONES_REQUEST, types.GET_PHONES_SUCCESS, types.GET_PHONES_FAILURE],
  promise: (api) => api.get(`registry/PHONE_REGISTRY${createStringReqParams(params)}`),
});

export const postPhone = (data) => ({
  types: [types.POST_PHONES_REQUEST, types.POST_PHONES_SUCCESS, types.POST_PHONES_FAILURE],
  promise: (api) => api.post('registry/PHONE_REGISTRY/', data),
});

export const putPhone = (data) => ({
  types: [types.PUT_PHONES_REQUEST, types.PUT_PHONES_SUCCESS, types.PUT_PHONES_FAILURE],
  promise: (api) => api.put('registry/PHONE_REGISTRY/', data),
});

// emails

export const resetEmails = () => ({
  type: types.RESET_EMAILS_FORM,
});

export const resetEmailsDoneStatus = () => ({
  type: types.RESET_EMAILS_DONE_STATUS,
});

export const getEmail = (params) => ({
  types: [types.GET_EMAILS_REQUEST, types.GET_EMAILS_SUCCESS, types.GET_EMAILS_FAILURE],
  promise: (api) => api.get(`registry/EMAIL_REGISTRY${createStringReqParams(params)}`),
});

export const postEmail = (data) => ({
  types: [types.POST_EMAILS_REQUEST, types.POST_EMAILS_SUCCESS, types.POST_EMAILS_FAILURE],
  promise: (api) => api.post('registry/EMAIL_REGISTRY/', data),
});

export const putEmail = (data) => ({
  types: [types.PUT_EMAILS_REQUEST, types.PUT_EMAILS_SUCCESS, types.PUT_EMAILS_FAILURE],
  promise: (api) => api.put('registry/EMAIL_REGISTRY/', data),
});

// web sites

export const resetSites = () => ({
  type: types.RESET_SITES_FORM,
});

export const resetSitesDoneStatus = () => ({
  type: types.RESET_SITES_DONE_STATUS,
});

export const getSite = (params) => ({
  types: [types.GET_SITES_REQUEST, types.GET_SITES_SUCCESS, types.GET_SITES_FAILURE],
  promise: (api) => api.get(`registry/WEB_SITE_REGISTRY${createStringReqParams(params)}`),
});

export const postSite = (data) => ({
  types: [types.POST_SITES_REQUEST, types.POST_SITES_SUCCESS, types.POST_SITES_FAILURE],
  promise: (api) => api.post('registry/WEB_SITE_REGISTRY/', data),
});

export const putSite = (data) => ({
  types: [types.PUT_SITES_REQUEST, types.PUT_SITES_SUCCESS, types.PUT_SITES_FAILURE],
  promise: (api) => api.put('registry/WEB_SITE_REGISTRY/', data),
});
