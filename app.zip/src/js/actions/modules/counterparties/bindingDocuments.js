import * as types from '../../../constants/actionTypes/counterparty/bindingDocuments';

export const bindDocumentToCounterparty = ({ counterpartyGuid, documentGuid }) => ({
  types: [
    types.BIND_DOCUMENT_TO_COUNTERPARTY_REQUEST,
    types.BIND_DOCUMENT_TO_COUNTERPARTY_SUCCESS,
    types.BIND_DOCUMENT_TO_COUNTERPARTY_FAILURE,
  ],
  promise: (api) =>
    api.get(
      `counterparty/documents/get/counterparty/${counterpartyGuid}/bind/document/${documentGuid}`,
    ),
});

export const unBindDocumentToCounterparty = ({ counterpartyGuid, documentGuid }) => ({
  types: [
    types.UNBIND_DOCUMENT_TO_COUNTERPARTY_REQUEST,
    types.UNBIND_DOCUMENT_TO_COUNTERPARTY_SUCCESS,
    types.UNBIND_DOCUMENT_TO_COUNTERPARTY_FAILURE,
  ],
  promise: (api) =>
    api.get(
      `counterparty/documents/get/counterparty/${counterpartyGuid}/unBind/document/${documentGuid}`,
    ),
});

export const getCounterpartyBoundDocuments = ({ counterpartyGuid }) => ({
  types: [
    types.GET_COUNTERPARTY_BOUND_DOCUMENTS_REQUEST,
    types.GET_COUNTERPARTY_BOUND_DOCUMENTS_SUCCESS,
    types.GET_COUNTERPARTY_BOUND_DOCUMENTS_FAILURE,
  ],
  promise: (api) => api.get(`counterparty/documents/get/counterparty/${counterpartyGuid}`),
});
