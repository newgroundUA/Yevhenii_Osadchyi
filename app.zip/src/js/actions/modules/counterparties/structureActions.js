import * as types from '../../../constants/actionTypes/counterparty/CounterpartiesConstants';
import { createStringReqParams } from '../../../helpers/createReqParams';

export const getDepartment = (guid) => ({
  key: 'rootCounterpartyContainer',
  types: [types.GET_DEPARTMENT_REQUEST, types.GET_DEPARTMENT_SUCCESS, types.GET_DEPARTMENT_FAILURE],
  promise: (api) => api.get(`departments/all/${guid}`),
});

export const putDepartment = (data) => ({
  key: 'rootCounterpartyContainer',
  types: [types.PUT_DEPARTMENT_REQUEST, types.PUT_DEPARTMENT_SUCCESS, types.PUT_DEPARTMENT_FAILURE],
  promise: (api) => api.put('departments/', data),
});

export const postDepartment = (data) => ({
  key: 'rootCounterpartyContainer',
  types: [
    types.POST_DEPARTMENT_REQUEST,
    types.POST_DEPARTMENT_SUCCESS,
    types.POST_DEPARTMENT_FAILURE,
  ],
  promise: (api) => api.post('departments/', data),
});

export const resetDepartments = () => ({
  key: 'rootCounterpartyContainer',
  type: types.RESET_DEPARTMENTS_FORM,
});

export const resetDepartmentsDoneStatus = () => ({
  key: 'rootCounterpartyContainer',
  type: types.RESET_DEPARTMENTS_DONE_STATUS,
});

export const getPosition = (guid) => ({
  key: 'rootCounterpartyContainer',
  types: [types.GET_POSITION_REQUEST, types.GET_POSITION_SUCCESS, types.GET_POSITION_FAILURE],
  promise: (api) => api.get(`positions/get/${guid}`),
});

export const putPosition = (data) => ({
  key: 'rootCounterpartyContainer',
  types: [types.PUT_POSITION_REQUEST, types.PUT_POSITION_SUCCESS, types.PUT_POSITION_FAILURE],
  promise: (api) => api.put('positions/', data),
});

export const postPosition = (data) => ({
  key: 'rootCounterpartyContainer',
  types: [types.POST_POSITION_REQUEST, types.POST_POSITION_SUCCESS, types.POST_POSITION_FAILURE],
  promise: (api) => api.post('positions/', data),
});

export const resetPositions = () => ({
  key: 'rootCounterpartyContainer',
  type: types.RESET_POSITIONS_FORM,
});

export const resetPositionsDoneStatus = () => ({
  key: 'rootCounterpartyContainer',
  type: types.RESET_POSITIONS_DONE_STATUS,
});

export const getEmployee = (guid) => ({
  key: 'rootCounterpartyContainer',
  types: [types.GET_EMPLOYEE_REQUEST, types.GET_EMPLOYEE_SUCCESS, types.GET_EMPLOYEE_FAILURE],
  promise: (api) => api.get(`employees/get/${guid}`),
});

export const putEmployee = (data) => ({
  key: 'rootCounterpartyContainer',
  types: [types.PUT_EMPLOYEE_REQUEST, types.PUT_EMPLOYEE_SUCCESS, types.PUT_EMPLOYEE_FAILURE],
  promise: (api) => api.put('employees/', data),
});

export const postEmployee = (data) => ({
  key: 'rootCounterpartyContainer',
  types: [types.POST_EMPLOYEE_REQUEST, types.POST_EMPLOYEE_SUCCESS, types.POST_EMPLOYEE_FAILURE],
  promise: (api) => api.post('employees/', data),
});

export const resetEmployees = () => ({
  key: 'rootCounterpartyContainer',
  type: types.RESET_EMPLOYEES_FORM,
});

export const resetEmployeesDoneStatus = () => ({
  key: 'rootCounterpartyContainer',
  type: types.RESET_EMPLOYEES_DONE_STATUS,
});

export const getDepartmentsView = (departmentGuid, counterpartyOwner) => ({
  types: [
    types.GET_DEPARTMENTS_VIEW_REQUEST,
    types.GET_DEPARTMENTS_VIEW_SUCCESS,
    types.GET_DEPARTMENTS_VIEW_FAILURE,
  ],
  promise: (api) =>
    api.get(
      `departments/get/${departmentGuid}${
        counterpartyOwner ? createStringReqParams({ counterpartyOwner }) : ''
      }`,
    ),
});

export const resetDepartmentsView = () => ({
  type: types.CLEAR_DEPARTMENTS_VIEW,
});

export const getPositionsView = (departmentGuid, positionGuid) => ({
  types: [
    types.GET_POSITIONS_VIEW_REQUEST,
    types.GET_POSITIONS_VIEW_SUCCESS,
    types.GET_POSITIONS_VIEW_FAILURE,
  ],
  promise: (api) => api.get(`departments/get/${departmentGuid}/positions/${positionGuid}`),
});

export const resetPositionsView = () => ({
  type: types.CLEAR_POSITIONS_VIEW,
});

export const getEmployeesView = (departmentGuid, positionGuid, personGuid) => ({
  types: [
    types.GET_EMPLOYEES_VIEW_REQUEST,
    types.GET_EMPLOYEES_VIEW_SUCCESS,
    types.GET_EMPLOYEES_VIEW_FAILURE,
  ],
  promise: (api) =>
    api.get(`departments/get/${departmentGuid}/positions/${positionGuid}/persons/${personGuid}`),
});

export const resetEmployeesView = () => ({
  type: types.CLEAR_EMPLOYEES_VIEW,
});
