import * as types from '../../../constants/actionTypes/counterparty/CounterpartiesConstants';
import { createParams } from '../../../helpers/createReqParams';
import { withAuthDownload } from '../../../api/withAuth';

export const loadCounterparties = (data) => ({
  types: [
    types.LOAD_GET_COUNTERPARTIES_REQUEST,
    types.LOAD_GET_COUNTERPARTIES_SUCCESS,
    types.LOAD_GET_COUNTERPARTIES_FAILURE,
  ],
  promise: (api) => api.post('counterparty/registry/get', createParams(data)),
});
/**
 * Send request for printing to XLSX file.
 * @param data parameters for printing.
 */
export const requestCounterpartyXLS = ({ exportColumns, requestBody, counterpartyTypes }) => ({
  types: [types.PRINT_TO_XLS_REQUEST, types.PRINT_TO_XLS_SUCCESS, types.PRINT_TO_XLS_FAILURE],
  promise: (api) => {
    // TODO: хочу передать привет бреду от бэка
    const params = createParams(requestBody);
    return withAuthDownload({
      api,
      method: 'post',
      url: 'counterparty/registry/export',
      data: {
        exportColumns,
        filter: {
          ...params,
          counterpartyTypes,
          countAll: true,
        },
      },
    });
  },
});

export const setValueRequestBody = (key, value) => ({
  type: types.SET_COUNTERPARTIES_VALUE_REQUEST_BODY,
  key,
  value,
});

export const setValuePages = (key, value) => ({
  type: types.SET_COUNTERPARTIES_VALUE_PAGES,
  key,
  value,
});

export const setValueFastFilters = (key, value) => ({
  type: types.SET_COUNTERPARTIES_VALUE_FAST_FILTERS,
  key,
  value,
});

export const resetFilters = () => ({
  type: types.RESET_COUNTERPARTIES_FILTERS,
});
