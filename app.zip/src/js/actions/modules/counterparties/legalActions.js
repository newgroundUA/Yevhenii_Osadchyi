import * as types from '../../../constants/actionTypes/counterparty/CounterpartiesConstants';

export const postNewLegal = (key, data) => ({
  key,
  types: [
    types.LOAD_POST_NEW_LEGAL_REQUEST,
    types.LOAD_POST_NEW_LEGAL_SUCCESS,
    types.LOAD_POST_NEW_LEGAL_FAILURE,
  ],
  promise: (api) => api.post('legalentities/', data),
});

export const putLegalByGuid = (key, data) => ({
  key,
  types: [
    types.LOAD_PUT_LEGAL_BY_GUID_REQUEST,
    types.LOAD_PUT_LEGAL_BY_GUID_SUCCESS,
    types.LOAD_PUT_LEGAL_BY_GUID_FAILURE,
  ],
  promise: (api) => api.put('legalentities/', data),
});

export const getLegalByGuid = (key, guid) => ({
  key,
  types: [
    types.LOAD_GET_LEGAL_BY_GUID_REQUEST,
    types.LOAD_GET_LEGAL_BY_GUID_SUCCESS,
    types.LOAD_GET_LEGAL_BY_GUID_FAILURE,
  ],
  promise: (api) => api.get(`legalentities/full/${guid}`),
});

export const resetLegalIsDoneStatus = (key) => ({
  key,
  type: types.RESET_LEGAL_DONE_STATUS,
});
