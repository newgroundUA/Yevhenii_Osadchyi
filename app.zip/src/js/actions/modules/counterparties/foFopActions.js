import * as types from '../../../constants/actionTypes/counterparty/CounterpartiesConstants';

export const postNewPerson = (key, data, status = {}) => ({
  key,
  types: [
    types.LOAD_POST_NEW_PERSON_REQUEST,
    types.LOAD_POST_NEW_PERSON_SUCCESS,
    types.LOAD_POST_NEW_PERSON_FAILURE,
  ],
  promise: (api) => api.post('persons/', data),
  status,
});

export const getPersonByGuid = (key, guid) => ({
  key,
  types: [
    types.LOAD_GET_PERSON_BY_GUID_REQUEST,
    types.LOAD_GET_PERSON_BY_GUID_SUCCESS,
    types.LOAD_GET_PERSON_BY_GUID_FAILURE,
  ],
  promise: (api) => api.get(`persons/full/${guid}`),
});

export const delPersonByGuid = (guid) => ({
  types: [
    types.LOAD_DEL_PERSON_BY_GUID_REQUEST,
    types.LOAD_DEL_PERSON_BY_GUID_SUCCESS,
    types.LOAD_DEL_PERSON_BY_GUID_FAILURE,
  ],
  promise: (api) => api.delete(`persons/${guid}`),
});

export const putPersonByGuid = (key, data, status = {}) => ({
  key,
  types: [
    types.LOAD_PUT_PERSON_BY_GUID_REQUEST,
    types.LOAD_PUT_PERSON_BY_GUID_SUCCESS,
    types.LOAD_PUT_PERSON_BY_GUID_FAILURE,
  ],
  promise: (api) => api.put('persons/', data),
  status,
});

export const postNewSelfemployed = (key, data) => ({
  key,
  types: [
    types.LOAD_POST_NEW_SELFEMPLOYED_REQUEST,
    types.LOAD_POST_NEW_SELFEMPLOYED_SUCCESS,
    types.LOAD_POST_NEW_SELFEMPLOYED_FAILURE,
  ],
  promise: (api) => api.post('selfemployed/', data),
});

export const getSelfemployedByGuid = (key, guid) => ({
  key,
  types: [
    types.LOAD_GET_SELFEMPLOYED_BY_GUID_REQUEST,
    types.LOAD_GET_SELFEMPLOYED_BY_GUID_SUCCESS,
    types.LOAD_GET_SELFEMPLOYED_BY_GUID_FAILURE,
  ],
  promise: (api) => api.get(`selfemployed/full/${guid}`),
});

export const delSelfemployedByGuid = (guid) => ({
  types: [
    types.LOAD_DEL_SELFEMPLOYED_BY_GUID_REQUEST,
    types.LOAD_DEL_SELFEMPLOYED_BY_GUID_SUCCESS,
    types.LOAD_DEL_SELFEMPLOYED_BY_GUID_FAILURE,
  ],
  promise: (api) => api.delete(`selfemployed/${guid}`),
});

export const putSelfemployedByGuid = (key, data) => ({
  key,
  types: [
    types.LOAD_PUT_SELFEMPLOYED_BY_GUID_REQUEST,
    types.LOAD_PUT_SELFEMPLOYED_BY_GUID_SUCCESS,
    types.LOAD_PUT_SELFEMPLOYED_BY_GUID_FAILURE,
  ],
  promise: (api) => api.put('selfemployed/', data),
});

export const loadLastNames = (predicate) => ({
  types: [
    types.LOAD_GET_LAST_NAMES_REQUEST,
    types.LOAD_GET_LAST_NAMES_SUCCESS,
    types.LOAD_GET_LAST_NAMES_FAILURE,
  ],
  promise: (api) => api.get(`persons/lastname?predicate=${predicate}&offset=0&limit=15`),
});

export const loadFirstNames = (predicate) => ({
  types: [
    types.LOAD_GET_FIRST_NAMES_REQUEST,
    types.LOAD_GET_FIRST_NAMES_SUCCESS,
    types.LOAD_GET_FIRST_NAMES_FAILURE,
  ],
  promise: (api) => api.get(`persons/firstname?predicate=${predicate}&offset=0&limit=15`),
});

export const loadMiddleNames = (predicate) => ({
  types: [
    types.LOAD_GET_MIDDLE_NAMES_REQUEST,
    types.LOAD_GET_MIDDLE_NAMES_SUCCESS,
    types.LOAD_GET_MIDDLE_NAMES_FAILURE,
  ],
  promise: (api) => api.get(`persons/middlename?predicate=${predicate}&offset=0&limit=15`),
});
