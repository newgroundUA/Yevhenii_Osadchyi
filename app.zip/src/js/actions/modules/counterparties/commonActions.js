import * as types from '../../../constants/actionTypes/counterparty/CounterpartiesConstants';
import { createStringReqParams } from '../../../helpers/createReqParams';

export const mountCounterpartyModal = (key) => ({
  type: types.MOUNT_COUNTERPARTY_MODAL,
  key,
});

export const unmountCounterpartyModal = (key) => ({
  type: types.UNMOUNT_COUNTERPARTY_MODAL,
  key,
});

export const setOptionsForEntity = (key, options) => ({
  type: types.SET_OPTIONS_FOR_ENTITY,
  options,
  key,
});

export const getLegalEntityByEdrpou = (edrpou) => ({
  types: [
    types.LOAD_LEGAL_ENTITY_BY_EDRPOU_REQUEST,
    types.LOAD_LEGAL_ENTITY_BY_EDRPOU_SUCCESS,
    types.LOAD_LEGAL_ENTITY_BY_EDRPOU_FAILURE,
  ],
  promise: (api) =>
    api.get(
      `counterparty/live_search/${edrpou}/${createStringReqParams({
        limit: '1',
        offset: '0',
      })}`,
    ),
});

export const getFoByIpn = (ipn) => ({
  types: [types.LOAD_FO_BY_IPN_REQUEST, types.LOAD_FO_BY_IPN_SUCCESS, types.LOAD_FO_BY_IPN_FAILURE],
  promise: (api) =>
    api.get(
      `counterparty/live_search/${ipn}/${createStringReqParams({
        limit: '1',
        offset: '0',
      })}`,
    ),
});

export const liveLoadCounterparties = (key, searchTerm, counterpartyType) => ({
  key,
  counterpartyType,
  types: [
    types.LIVE_LOAD_COUNTERPARTIES_REQUEST,
    types.LIVE_LOAD_COUNTERPARTIES_SUCCESS,
    types.LIVE_LOAD_COUNTERPARTIES_FAILURE,
  ],
  promise: (api) =>
    api.get(
      `counterparty/live_search/${searchTerm}/${createStringReqParams({
        limit: '30',
        offset: '0',
      })}`,
    ),
});

export const loadCounterpartiesByArrayGuids = (data) => ({
  types: [
    types.LOAD_GET_COUNTERPARTIES_BY_ARRAY_GUIDS_REQUEST,
    types.LOAD_GET_COUNTERPARTIES_BY_ARRAY_GUIDS_SUCCESS,
    types.LOAD_GET_COUNTERPARTIES_BY_ARRAY_GUIDS_FAILURE,
  ],
  promise: (api) => api.post('counterparty/ids', data),
});

export const resetCounterpartiesForm = (key) => ({
  key,
  type: types.RESET_COUNTERPARTIES_FORM,
});

export const getPersonsByPersonData = (data) => ({
  types: [
    types.LOAD_GET_PERSONS_BY_PERSON_DATA_REQUEST,
    types.LOAD_GET_PERSONS_BY_PERSON_DATA_SUCCESS,
    types.LOAD_GET_PERSONS_BY_PERSON_DATA_FAILURE,
  ],
  promise: (api) => api.post('/persons/check', data),
});

export const getBankDetails = (guid) => ({
  types: [
    types.LOAD_GET_BANK_DETAILS_REQUEST,
    types.LOAD_GET_BANK_DETAILS_SUCCESS,
    types.LOAD_GET_BANK_DETAILS_FAILURE,
  ],
  promise: (api) => api.get(`/bankDetails/get/accountOwner/${guid}`),
});

export const postBankDetails = (data) => ({
  types: [
    types.LOAD_POST_BANK_DETAILS_REQUEST,
    types.LOAD_POST_BANK_DETAILS_SUCCESS,
    types.LOAD_POST_BANK_DETAILS_FAILURE,
  ],
  promise: (api) => api.post('/bankDetails/', data),
});

export const putBankDetails = (data) => ({
  types: [
    types.LOAD_PUT_BANK_DETAILS_REQUEST,
    types.LOAD_PUT_BANK_DETAILS_SUCCESS,
    types.LOAD_PUT_BANK_DETAILS_FAILURE,
  ],
  promise: (api) => api.put('/bankDetails/', data),
});
