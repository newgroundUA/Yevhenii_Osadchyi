import * as NotifyTypes from '../constants/actionTypes/NotifyConstants';
import * as AppTypes from '../constants/actionTypes/AppConstants';

const types = {
  ...NotifyTypes,
  ...AppTypes,
};

export const setIsLoadStatus = (status) => ({
  type: types.SET_IS_LOAD_STATUS,
  status,
});

// ====================== Notification start ======================
export const showSuccessMessage = (data) => ({
  type: types.SCHOW_SUCCESS_MESSAGE,
  data,
});

export const showErrorMessage = (data) => ({
  type: types.SCHOW_ERROR_MESSAGE,
  data,
});

export const showInfoMessage = (data) => ({
  type: types.SCHOW_INFO_MESSAGE,
  data,
});

export const closeMessage = () => ({
  type: types.CLOSE_MESSAGE,
});
// ====================== Notification end ======================
