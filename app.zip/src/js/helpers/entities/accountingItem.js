import { getStr } from '../geters';
import {
  PROPERTY,
  ROAD_FORM,
  PIPELINE_FORM,
  RAILROAD_FORM,
  ELECTRICITY_FORM,
  CONSTRUCTION_FORM,
  EQUIPMENT_FORM,
  WHTRANSPORT_FORM,
  PLANT_FORM,
  ANIMAL_FORM,
  INTELLRIGHT_FORM,
  BUILDINGS_FORM,
  PREMISE_FORM,
  FIELD_FORM,
} from '../../constants/RouteNames';
import {
  CONSTRUCTION,
  RAILROAD,
  EQUIPMENT,
  ANIMAL,
  INTELLRIGHT,
  WHTRANSPORT,
  ELECTRICITYCABLE,
  PLANT,
  PIPELINE,
  ROAD,
  BUILDING,
  PREMISE,
  FIELD,
} from '../../constants/property';

const createLinkToAccountingItemForm = ({ form, mode, id }) => `/${PROPERTY}/${form}/${mode}/${id}`;

// real estate
export const getLinkToBuildingForm = (id, mode) => `/${PROPERTY}/${BUILDINGS_FORM}/${mode}/${id}`;

export const getLinkToPremiseForm = (id, mode) => `/${PROPERTY}/${PREMISE_FORM}/${mode}/${id}`;

export const getLinkToFieldForm = (id, mode) => `/${PROPERTY}/${FIELD_FORM}/${mode}/${id}`;
// real estate

export const getLinkToRoadForm = (id, mode) =>
  createLinkToAccountingItemForm({ id, mode, form: ROAD_FORM });

export const getLinkToPipelineForm = (id, mode) =>
  createLinkToAccountingItemForm({ id, mode, form: PIPELINE_FORM });

export const getLinkToRailRoadForm = (id, mode) =>
  createLinkToAccountingItemForm({ id, mode, form: RAILROAD_FORM });

export const getLinkToElectricityForm = (id, mode) =>
  createLinkToAccountingItemForm({ id, mode, form: ELECTRICITY_FORM });

export const getLinkToConstructionForm = (id, mode) =>
  createLinkToAccountingItemForm({ id, mode, form: CONSTRUCTION_FORM });

export const getLinkToEquipmentForm = (id, mode) =>
  createLinkToAccountingItemForm({ id, mode, form: EQUIPMENT_FORM });

export const getLinkToWhTransportForm = (id, mode) =>
  createLinkToAccountingItemForm({ id, mode, form: WHTRANSPORT_FORM });

export const getLinkToPlantForm = (id, mode) =>
  createLinkToAccountingItemForm({ id, mode, form: PLANT_FORM });

export const getLinkToAnimalForm = (id, mode) =>
  createLinkToAccountingItemForm({ id, mode, form: ANIMAL_FORM });

export const getLinkToIntellrightForm = (id, mode) =>
  createLinkToAccountingItemForm({ id, mode, form: INTELLRIGHT_FORM });

export const getAccountingItemLink = ({ id, type, mode }) => {
  const accountingItemsToLinkGettersMap = {
    [BUILDING]: getLinkToBuildingForm,
    [PREMISE]: getLinkToPremiseForm,
    [FIELD]: getLinkToFieldForm,
    [CONSTRUCTION]: getLinkToConstructionForm,
    [RAILROAD]: getLinkToRailRoadForm,
    [EQUIPMENT]: getLinkToEquipmentForm,
    [ANIMAL]: getLinkToAnimalForm,
    [INTELLRIGHT]: getLinkToIntellrightForm,
    [WHTRANSPORT]: getLinkToWhTransportForm,
    [ELECTRICITYCABLE]: getLinkToElectricityForm,
    [PLANT]: getLinkToPlantForm,
    [PIPELINE]: getLinkToPipelineForm,
    [ROAD]: getLinkToRoadForm,
  };

  const linkGetter = accountingItemsToLinkGettersMap[type];

  return linkGetter ? linkGetter(id, mode) : null;
};

const getAccountingItemFullName = (accItem) => getStr(accItem.fullname || accItem.fullName);

const getAccountingItemAddress = (accItem) =>
  accItem.address ? getStr(accItem.address.addressAsString) : '';
const getAccountingItemSquare = (accItem) => accItem.accountingItemSpace;

export const getAccountingItemLabel = ({
  accountingItem,
  withoutAddress = false,
  withoutSquare = false,
}) => {
  let label;
  if (accountingItem.label) label = accountingItem.label;
  label = getAccountingItemFullName(accountingItem);

  return `${getStr(label)}
    ${!withoutAddress ? getAccountingItemAddress(accountingItem) : ''}
    ${!withoutSquare ? getAccountingItemSquare(accountingItem) : ''} м.кв.`;
};
