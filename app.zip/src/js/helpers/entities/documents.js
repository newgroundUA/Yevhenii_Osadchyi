import { DOCUMENT_TYPE_MAP } from '../../constants/VocabularyForBE';
import { DOCUMENTS, DOCUMENT_GENERAL } from '../../constants/RouteNames';
import EnumToLabelsMap from '../../constants/EnumToLabelsMap';
import { getStr } from '../geters';

export const getDocumentLink = ({ guid, type, mode }) =>
  `/${DOCUMENTS}/${DOCUMENT_TYPE_MAP[type] || DOCUMENT_GENERAL}/${mode}/${guid}`;

export const getDocumentLabel = ({ documentData }) => {
  if (documentData.label) return documentData.label;

  return `${getStr(documentData.docSerialNumber)} ${getStr(documentData.docNumber)} ${getStr(
    EnumToLabelsMap[documentData.documentType], // TODO: change docType to correct value
  )}`;
};
