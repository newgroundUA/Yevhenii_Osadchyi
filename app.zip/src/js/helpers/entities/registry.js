import * as RouteNames from '../../constants/RouteNames';

export const goToRegistry = ({ history, name }) => {
  const registersToRoutesMap = {
    documents: RouteNames.DOCUMENTS,
    // TODO: add other registers names as needed
  };

  history.push(`/${registersToRoutesMap[name]}/${RouteNames.REGISTER}`);
};
