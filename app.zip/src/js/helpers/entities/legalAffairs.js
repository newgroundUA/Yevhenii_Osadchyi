import { getStr } from '../geters';
import EnumToLabelsMap from '../../constants/EnumToLabelsMap';
import { LEGAL_PROCESSING_STATUS_ENUM } from '../../constants/ClassifiersNames';

export const getRequestForLegalProcessingLabel = (request) =>
  `${EnumToLabelsMap[LEGAL_PROCESSING_STATUS_ENUM][request.requestStatus]} № ${getStr(
    request.requestNumber,
  )}`;

export const createRequestForLegalProsessingDropDownValue = (requestForLegProsObj) => ({
  ...requestForLegProsObj,
  key: requestForLegProsObj.guid,
  label: getRequestForLegalProcessingLabel(requestForLegProsObj),
});
