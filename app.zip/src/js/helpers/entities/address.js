import { getStr } from '../geters';

export const getCountryLabel = (obj) => getStr(obj.countryName);

export const getRegionLabel = (obj) => getStr(obj.regionName);

export const getDistrictLabel = (obj) => getStr(obj.districtName);

export const getLocalityDstrict = (obj) => getStr(obj.localityAreaName);

export const getLocalityLabel = (obj) => getStr(obj.localityName);

export const getLocalityAreaLabel = (obj) => getStr(obj.localityAreaName);

export const getStreetLabel = (obj) => `${getStr(obj.streetTypeShort)} ${getStr(obj.streetName)}`;

export const getBuildingLabel = (obj) => `${getStr(obj.addressObjectType)}`; // in this case addressObjectType === addressObjectLabel

export const getInheritAddressObjectLabel = (obj) =>
  `${getStr(obj.inheritAddressObjectTypeShortName)} ${getStr(obj.inheritAddressObjectName)}`;

export const getPremiseLabel = (obj) =>
  `${getStr(obj.premiseTypeShortName)} ${getStr(obj.premiseName)}`;
