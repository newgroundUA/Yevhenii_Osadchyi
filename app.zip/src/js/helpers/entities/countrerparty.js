import { COUNTERPARTIES, LEGALPAGE, FOP, FO } from '../../constants/RouteNames';
import { COUNTERPARTY_TYPE_SHORT_NAMES_MAP } from '../../constants/VocabularyForBE';
import { getStr } from '../geters';

export const getLinkToLegalForm = (id, mode) => `/${COUNTERPARTIES}/${LEGALPAGE}/${mode}/${id}`;

export const getLinkToFOForm = (id, mode) => `/${COUNTERPARTIES}/${FO}/${mode}/${id}`;

export const getLinkToFOPForm = (id, mode) => `/${COUNTERPARTIES}/${FOP}/${mode}/${id}`;

export const getLinkToCounterpartyForm = ({ guid, type, mode }) => {
  switch (type) {
    case 'LegalEntity':
      return getLinkToLegalForm(guid, mode);
    case 'SelfEmployed':
      return getLinkToFOPForm(guid, mode);
    case 'Person':
      return getLinkToFOForm(guid, mode);
    default:
      return '';
  }
};

export const getKopfgName = (counterparty) =>
  `${counterparty.kopfgDto ? getStr(counterparty.kopfgDto.name) : ''}`;

export const getPersonString = (person) => {
  const { lastName, firstName, middleName, fistName, fullName, shortName } = person;

  if (fullName) {
    return fullName;
  }
  if (shortName) {
    return shortName;
  }
  return `${getStr(lastName)} ${getStr(firstName || fistName)} ${getStr(middleName)}`;
};

export const getLegalString = (legal, kopfg) =>
  `${kopfg ? getKopfgName(legal) : ''} ${getStr(legal.fullName)}`;

export const getSelfEmployedString = (selfEmployed, kopfg) =>
  `${kopfg ? getKopfgName(selfEmployed) : ''} ${getPersonString(selfEmployed)}`;

export const getCounterpartyLabel = ({ counterparty, withoutType = false, kopfg = true }) => {
  let counterpartyLabel = '';
  if (!counterparty) return '';
  if (counterparty.label) counterpartyLabel = counterparty.label;
  if (counterparty.shortName) counterpartyLabel = counterparty.shortName;
  switch (counterparty.counterpartyType) {
    case 'Person':
      counterpartyLabel = getPersonString(counterparty);
      break;
    case 'LegalEntity':
      counterpartyLabel = getLegalString(counterparty, kopfg);
      break;
    case 'SelfEmployed':
      counterpartyLabel = getSelfEmployedString(counterparty, kopfg);
      break;
    default:
      return '';
  }

  return counterparty.counterpartyType && !withoutType
    ? `${COUNTERPARTY_TYPE_SHORT_NAMES_MAP[counterparty.counterpartyType]} ${counterpartyLabel}`
    : counterpartyLabel;
};

export const getCounterpartyITN = ({ counterparty }) => {
  if (!counterparty) return '';
  switch (counterparty.counterpartyType) {
    case 'Person':
    case 'SelfEmployed':
      return counterparty.itn;
    case 'LegalEntity':
      return counterparty.edrpou;
    default:
      return '';
  }
};
