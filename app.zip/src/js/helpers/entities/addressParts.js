import { getStr } from '../geters';

export const getLocalityAreaLabel = (localityArea) => `${getStr(localityArea.localityAreaName)}`;
