import moment from 'moment';
import _get from 'lodash/_baseGet';

const DATE_FORMAT_FE = 'DD.MM.YYYY';
const DATE_FORMAT_BE = 'YYYY-MM-DD HH:mm:ss.SSS Z';

/**
 * Convert ISO ZONE DATE TIME 8601 to string format DD.MM.YYYY
 * @param {String} date The date in string format
 * @returns {String}
 */
export const getFeDate = (date) =>
  date ? moment(date, DATE_FORMAT_BE).format(DATE_FORMAT_FE) : '';

/**
 * Displaying only string
 * @param {String} prop Only string
 */
export const getStr = (prop) => prop || '';

/**
 * Displaying number or 0 if undefined
 * @param {String} prop Only string
 */
export const getNumber = (number) => number || 0;

const getKopfgName = (counterparty) =>
  `${counterparty.kopfgDto ? getStr(counterparty.kopfgDto.name) : ''}`;
const getPersonString = (person) =>
  `${getStr(person.lastName)} ${getStr(person.firstName)} ${getStr(person.middleName)}`;
const getLegalEntitytString = (legal) => `${getKopfgName(legal)} ${getStr(legal.fullName)}`;
const getSelfEmployedString = (selfEmployed) =>
  `${getKopfgName(selfEmployed)} ${getPersonString(selfEmployed)}`;

/**
 * Make name of counterparty by his type
 * @param {Object} counterparty The object of counterparty
 * @returns {String} Name of counterparty
 */
export const getCounterpartyString = (counterparty) => {
  if (!counterparty) return '';
  switch (counterparty.counterpartyType) {
    case 'Person':
      return getPersonString(counterparty);
    case 'LegalEntity':
      return getLegalEntitytString(counterparty);
    case 'SelfEmployed':
      return getSelfEmployedString(counterparty);
    default:
      return 'Error';
  }
};

const generateOptionForDropDown = (value, title) => ({ value, title });

/**
 * Generate dropdown options in table row in register
 *
 * @param {Object} obj The object to query.
 * @param {String} str The path of the property to get.
 * @param {String} value The key in object to put it in <option value={value}></option>
 * @param {String} label The key in object to display it in <option>{label}</option>
 * @returns {Array|null} Returns the array of objects for displaying in drop-down.
 */
export const getOptions = (obj, str, value, label) => {
  const arr = _get(obj, str);
  if (arr) {
    return arr.map((item) => generateOptionForDropDown(item[value], item[label]));
  }

  return null;
};
