import mapContainersToForms from './mapContainersToForms';
import mapClassifiersToUrls from './mapClassifiersToUrls';
import { COUNTERPARTY, OBJECTS, DOCUMENTS } from '../../constants/ClassifiersNames';

export function getClassifiersNamesArr(formFields) {
  return formFields.reduce(
    (arr, fields) => [
      ...arr,
      ...Object.values(fields)
        .map((val) => val.classifier)
        .filter(
          (classifier) =>
            !!classifier &&
            classifier !== COUNTERPARTY &&
            classifier !== DOCUMENTS &&
            classifier !== OBJECTS,
        ),
    ],
    [],
  );
}

export function getClassifiersTypesByContainer(containerName) {
  const formFields = mapContainersToForms[containerName] || [];
  return getClassifiersNamesArr(formFields);
}

export function getUrlCreator(baseUrl) {
  return (classifierName, params) => mapClassifiersToUrls[classifierName](baseUrl, params);
}
