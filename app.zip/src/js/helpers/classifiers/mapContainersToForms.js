import * as containerNames from '../../constants/ContainerNames';

import { fields as departmentFields } from '../../models/formFields/counterparty/departmentFields';

import { fields as positionFields } from '../../models/formFields/counterparty/positionFields';

import {
  SubjectsEvaluationFields,
  SubjectsEvaluationTableFields,
  DocumentsFields,
} from '../../models/formFields/commonFields';

import { foMainFields, foContactFields } from '../../models/formFields/counterparty/foFields';

import {
  fopDataFOPFields,
  fopRegistrationDataFields,
} from '../../models/formFields/counterparty/fopFields';

import {
  typicalContractFields,
  objectOfLeaseContractListFields,
  leaseBasePeriodinReportingPeriodFields,
} from '../../models/formFields/documents/typicalContractFields';

import {
  contestsFields,
  contestsTableFields,
} from '../../models/formFields/documents/contestsFields';

import {
  receivedMoneyFields,
  receivedPaymentFields,
  sentMoneyFields,
  sentPaymentFields,
} from '../../models/formFields/documents/bankStatementFields';

import {
  writeOffOOMTableFields,
  writeOffInformationFields,
} from '../../models/formFields/documents/writeOffFields';

import { balanceFields, balanceTableFields } from '../../models/formFields/documents/balanceFields';

import {
  marketValueInformationFields,
  marketValueOOMTableFields,
} from '../../models/formFields/documents/marketValueFields';

import {
  generalFields as documentGeneralFields,
  generalFieldsForComponentDocuments,
} from '../../models/formFields/documents/generalFields';

import { appealsFields } from '../../models/formFields/documents/appealsFields';

import { passportFields } from '../../models/formFields/documents/passportFields';

import {
  rentStatementFields,
  rentStatementFieldsTableProperty,
  rentStatementFieldsTableRent,
} from '../../models/formFields/documents/rentStatementFields';

import { judicialDecisionFields } from '../../models/formFields/documents/judicialDecisionFields';

import {
  ApplicationForEvaluationFields,
  ObjectEvaluationFields,
  EvaluationProcessFields,
} from '../../models/formFields/evaluationFields';

import {
  reviewCaseOptionsFields as evLeaseCeviewCaseOptionsFields,
  caseIncomingDocumentsFields as evLeaseCaseIncomingDocumentsFields,
  caseReviewingResultrsFields as evLeaseCaseReviewingResultrsFields,
  caseCounterpartiesFields as evLeaseCaseCounterpartiesFields,
} from '../../models/formFields/evaluation/evaluationFoLeaseFields';

import {
  reviewCaseOptionsFields as evPrivatizationCeviewCaseOptionsFields,
  caseIncomingDocumentsFields as evPrivatizationCaseIncomingDocumentsFields,
  caseReviewingResultrsFields as evPrivatizationCaseReviewingResultrsFields,
  caseCounterpartiesFields as evPrivatizationCaseCounterpartiesFields,
} from '../../models/formFields/evaluation/evaluationFoPrivatizationFields';

import { fileFields } from '../../models/formFields/fileFields';

import {
  legalFastFields,
  legalDataFields,
  legalRegistrationFields,
} from '../../models/formFields/counterparty/legalFields';

import {
  structureFields,
  ownersFields,
  movementsFields,
} from '../../models/formFields/counterparty/corporateRightsFields';

import {
  privatisationProgramFields,
  privatisationObjectsFields,
} from '../../models/formFields/privatisationFields';

import {
  generalInfoFields as affairs,
  processesTableFields,
  // stagesFields,
  // documentsFields
  caseParameters,
  caseParties,
  caseCourt,
  courtHearing,
  objectsOfTheRequest,
  stagesAndDocuments,
} from '../../models/formFields/legalCases/caseCardFields';
import {
  tableFields as proceedingTable,
  formsFields as proceedingForm,
} from '../../models/formFields/legalCases/proceedingFields';

import { generalInfoFields as initiative } from '../../models/formFields/legalCases/initiativeCard';

import { constructionsFields } from '../../models/formFields/property/constructionsFields';

// property
import { generalInfoFields, operationFields } from '../../models/formFields/property/generalFields';

import {
  specificationFields1,
  specificationFields2,
} from '../../models/formFields/property/buildingFields';
import { premiseFields } from '../../models/formFields/property/premisesFields';
import { electricityFields } from '../../models/formFields/property/electricityFields';
import { steadFields } from '../../models/formFields/property/steadFields';
import { fieldFields } from '../../models/formFields/property/fieldFields';
import { equipmentFields } from '../../models/formFields/property/equipmentFields';
import { roadFields } from '../../models/formFields/property/roadFields';
import { whTransportFields } from '../../models/formFields/property/whTransportFields';
import { railRoadFields } from '../../models/formFields/property/railRoadFields';
import { plantFields } from '../../models/formFields/property/plantFields';
import { intellRightFields } from '../../models/formFields/property/intellRightFields';
import { animalFields } from '../../models/formFields/property/animalFields';
import { pipelineFields } from '../../models/formFields/property/pipelineFields';
import { floorFields } from '../../models/formFields/property/floorFields';

import { ownersOfPrimaryPRFields } from '../../models/formFields/property/common/ownersOfPrimaryPRFields';
import { ownersOfDerivativePRFields } from '../../models/formFields/property/common/ownersOfDerivativePRFields';

// administration
import { phonesFields } from '../../models/formFields/administration/phonesFields';
import { emailsFields } from '../../models/formFields/administration/emailsFields';
import { sitesFields } from '../../models/formFields/administration/sitesFields';

// lease
import { periodocialByContractReportFields } from '../../models/formFields/lease/periodicalByContractReport';

import { periodocialByBalanceHolderReportFields } from '../../models/formFields/lease/periodocialByBalanceHolderReportFields';

import {
  competitionsFields,
  competitionAdvertListsFields,
  compReqListFields,
  memberOfCompCommissionFields,
  submitDocListFields,
} from '../../models/formFields/lease/competitionsFields';

import {
  landlordToObjectsFields,
  leaseObjectsFields,
} from '../../models/formFields/lease/landlordToObjectsFields';

import { leaseCasesFields } from '../../models/formFields/lease/leaseCasesFields';
import {
  claimActionActivityClassifiersFields,
  leaseClaimActionActivityCardCurrentSumFields,
  leaseClaimActionActivityCardGeneralFields,
  leaseClaimActionActivityCardInitialSumFields,
} from '../../models/formFields/lease/leaseClaimActionActivityCardFields';
import { leaseClaimActionActivityStepFields } from '../../models/formFields/lease/leaseClaimActionActivityStepFields';
import { bindingByDocumentInfoFields } from '../../models/formFields/documents/bindingDocumentFields';
import { bankDetailsFields } from '../../models/formFields/counterparty/bankDetailsFields';

const propertyGeneralFieldsArr = [generalInfoFields];

export default {
  [containerNames.LEASE_PERIODICAL_BY_BALANCE_HOLDER_REPORT_FORM_CONTAINER]: [
    periodocialByBalanceHolderReportFields,
  ],
  [containerNames.LEASE_PERIODICAL_BY_CONTRACT_REPORT_FORM_CONTAINER]: [
    periodocialByContractReportFields,
  ],
  [containerNames.LEASE_COMPETITIONS_CONTAINER]: [
    competitionsFields,
    competitionAdvertListsFields,
    compReqListFields,
    memberOfCompCommissionFields,
    submitDocListFields,
  ],
  [containerNames.DIVISION_CONTAINER]: [departmentFields],
  [containerNames.POSITION_CONTAINER]: [positionFields],
  [containerNames.FO_FORM_CONTAINER]: [
    foMainFields,
    foContactFields,
    generalFieldsForComponentDocuments,
  ],
  [containerNames.BANK_DETAILS_FORM_CONTAINER]: [bankDetailsFields],
  [containerNames.FOP_FORM_CONTAINER]: [
    foMainFields,
    foContactFields,
    fopDataFOPFields,
    fopRegistrationDataFields,
    generalFieldsForComponentDocuments,
  ],
  [containerNames.LEGAL_PAGE_CONTAINER]: [
    legalFastFields,
    legalDataFields,
    legalRegistrationFields,
    foContactFields,
    generalFieldsForComponentDocuments,
  ],
  [containerNames.CORPORATE_RIGHTS_STRUCTURE_CONTAINER]: [
    structureFields,
    ownersFields,
    movementsFields,
  ],
  [containerNames.BALANCE_FORM_CONTAINER]: [
    documentGeneralFields,
    balanceFields,
    balanceTableFields,
  ],
  [containerNames.BIND_DOCUMENT_CONTAINER]: [bindingByDocumentInfoFields],
  [containerNames.BANK_STATEMENT_FORM_CONTAINER]: [
    documentGeneralFields,
    receivedMoneyFields,
    receivedPaymentFields,
    sentMoneyFields,
    sentPaymentFields,
  ],
  [containerNames.CONTESTS_FORM_CONTAINER]: [
    documentGeneralFields,
    contestsFields,
    contestsTableFields,
  ],
  [containerNames.FILE_TABLE]: [fileFields],
  [containerNames.MARKET_VALUE_FORM_CONTAINER]: [
    documentGeneralFields,
    marketValueOOMTableFields,
    marketValueInformationFields,
  ],
  [containerNames.PASSPORT_FORM_CONTAINER]: [documentGeneralFields, passportFields],
  [containerNames.GENERAL_DOCUMENT_FORM_CONTAINER]: [documentGeneralFields],
  [containerNames.APPEALS_FORM_CONTAINER]: [documentGeneralFields, appealsFields],
  [containerNames.RENT_STATEMENT_FORM_CONTAINER]: [
    documentGeneralFields,
    rentStatementFields,
    rentStatementFieldsTableProperty,
    rentStatementFieldsTableRent,
  ],
  [containerNames.TYPICAL_CONTRACT_FORM_CONTAINER]: [
    documentGeneralFields,
    typicalContractFields,
    objectOfLeaseContractListFields,
    leaseBasePeriodinReportingPeriodFields,
  ],
  [containerNames.WRITE_OFF_FORM_CONTAINER]: [
    documentGeneralFields,
    writeOffOOMTableFields,
    writeOffInformationFields,
  ],
  [containerNames.JUDICIAL_DECISION_FORM_CONTAINER]: [
    documentGeneralFields,
    judicialDecisionFields,
  ],
  [containerNames.CREATE_EVALUATION_CONTAINER]: [
    ApplicationForEvaluationFields,
    ObjectEvaluationFields,
    EvaluationProcessFields,
    SubjectsEvaluationFields,
    SubjectsEvaluationTableFields,
    DocumentsFields,
  ],
  [containerNames.LEASE_CASES_CONTAINER]: [leaseCasesFields],
  [containerNames.LANDLORD_TO_OBJECTS_CONTAINER]: [leaseObjectsFields, landlordToObjectsFields],

  // legalcases
  [containerNames.LEGAL_CASES_AFFAIRS_FORM_CONTAINER]: [
    caseParameters,
    caseParties,
    caseCourt,
    courtHearing,
    objectsOfTheRequest,
    stagesAndDocuments,
    DocumentsFields,
    affairs,
    processesTableFields,
  ],
  [containerNames.CREATE_LEGAL_CASES_INITIATIVE_CONTAINER]: [DocumentsFields, initiative],
  [containerNames.PROCEEDING_FORM_CONTAINER]: [proceedingTable, proceedingForm],

  // privatisation?
  [containerNames.CREATE_PRIVATIZATION_CONTAINER]: [
    privatisationProgramFields,
    privatisationObjectsFields,
  ],

  // property
  [containerNames.FLOOR_FORM_CONTAINER]: [floorFields],
  [containerNames.ANIMALS_FORM_CONTAINER]: [...propertyGeneralFieldsArr, animalFields],
  [containerNames.INTELL_RIGHTS_FORM_CONTAINER]: [...propertyGeneralFieldsArr, intellRightFields],
  [containerNames.PLANTS_FORM_CONTAINER]: [...propertyGeneralFieldsArr, plantFields],
  [containerNames.RAIL_ROADS_FORM_CONTAINER]: [...propertyGeneralFieldsArr, railRoadFields],
  [containerNames.WH_TRANSPORTS_FORM_CONTAINER]: [...propertyGeneralFieldsArr, whTransportFields],
  [containerNames.ROADS_FORM_CONTAINER]: [...propertyGeneralFieldsArr, roadFields],
  [containerNames.EQUIPMENTS_FORM_CONTAINER]: [...propertyGeneralFieldsArr, equipmentFields],
  [containerNames.FIELDS_FORM_CONTAINER]: [...propertyGeneralFieldsArr, fieldFields],
  [containerNames.STEADS_FORM_CONTAINER]: [...propertyGeneralFieldsArr, steadFields],
  [containerNames.BUILDING_FORM_CONTAINER]: [
    ...propertyGeneralFieldsArr,
    specificationFields1,
    specificationFields2,
  ],

  [containerNames.CONSTRUCTIONS_FORM_CONTAINER]: [...propertyGeneralFieldsArr, constructionsFields],

  [containerNames.PREMISE_FORM_CONTAINER]: [...propertyGeneralFieldsArr, premiseFields],

  [containerNames.ELECTRICITY_FORM_CONTAINER]: [...propertyGeneralFieldsArr, electricityFields],

  [containerNames.OPERATIONS_REGISTER]: [operationFields],

  [containerNames.EVALUATION_FO_LEASE_FORM_CONTAINER]: [
    evLeaseCeviewCaseOptionsFields,
    evLeaseCaseIncomingDocumentsFields,
    evLeaseCaseReviewingResultrsFields,
    evLeaseCaseCounterpartiesFields,
  ],

  [containerNames.EVALUATION_FO_PRIVATIZATION_FORM_CONTAINER]: [
    evPrivatizationCeviewCaseOptionsFields,
    evPrivatizationCaseIncomingDocumentsFields,
    evPrivatizationCaseReviewingResultrsFields,
    evPrivatizationCaseCounterpartiesFields,
  ],

  [containerNames.PIPELINE_FORM_CONTAINER]: [...propertyGeneralFieldsArr, pipelineFields],

  [containerNames.RELATED_COUNTERPARTIES]: [ownersOfPrimaryPRFields, ownersOfDerivativePRFields],

  // administration
  [containerNames.PHONES_CONTAINER]: [phonesFields],
  [containerNames.EMAILS_CONTAINER]: [emailsFields],
  [containerNames.SITES_CONTAINER]: [sitesFields],

  // LEASE CCA (PPD) LEASE_CLAIM_ACTION_ACTIVITY_CARD
  [containerNames.LEASE_CLAIM_ACTION_ACTIVITY]: [
    claimActionActivityClassifiersFields,
    leaseClaimActionActivityStepFields,
  ],
  [containerNames.LEASE_CLAIM_ACTION_ACTIVITY_CARD]: [
    leaseClaimActionActivityCardCurrentSumFields,
    leaseClaimActionActivityCardGeneralFields,
    leaseClaimActionActivityCardInitialSumFields,
  ],
};
