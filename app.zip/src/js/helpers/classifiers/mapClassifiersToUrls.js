import * as names from '../../constants/ClassifiersNames';

const res = {
  tempOptions: () => null,
  [names.GROUP_OF_PREMISE]: () => null,
  [names.PREMISE]: () => null,
  [names.PERSON_TYPE_ENUM]: () => 'CLASSIFIER/CATALOG/PERSON_TYPE_ENUM',
  [names.ASSESSMENT_REVIEWING_CATEGORY]: () => 'CLASSIFIER/CL_ASSESSMENT_REVIEWING_CATEGORY',
  [names.CL_CLAIM_ACTION_ACTIVITY_STEP_TYPE]: (
    baseUrl,
    { offset, limit } = {
      offset: 0,
      limit: 100,
    },
  ) => `CLASSIFIER/get/CL_CLAIM_ACTION_ACTIVITY_STEP_TYPE?offset=${offset}&limit=${limit}`,
  [names.GROUPED_OBJECTS_TYPE]: () => 'CLASSIFIER/CATALOG/GROUPED_OBJECTS_TYPE',
  [names.LEGAL_AFFAIRS]: () => '/legal_affairs/get?limit=100&offset=0', // Посилання на юридичну справу TODO: should be live search
  [names.ASSESSMENT_REASON_TYPE]: () => 'CLASSIFIER/CATALOG/ASSESSMENT_REASON_TYPE', // причини оцінки майна
  [names.LEASE_ASSESSMENT_TYPE]: () => 'CLASSIFIER/CATALOG/LEASE_ASSESSMENT_TYPE', // Тип оцінки майна
  [names.CL_ASSESSMENT_REVIEWING_STATE]: () => 'CLASSIFIER/CL_ASSESSMENT_REVIEWING_STATE', // Стан процесу рецензування оцінки майна
  [names.ASSESSMENT_REVIEWING_CONCLUSION]: () =>
    'CLASSIFIER/CATALOG/ASSESSMENT_REVIEWING_CONCLUSION', // Висновок рецензування оцінки майна
  [names.MARKET_PRICE_DETECT_METHOD]: () => 'CLASSIFIER/CL_MARKET_PRICE_DETECT_METHOD',
  [names.LANDLORD_TO_OBJECTS]: () => 'lease/landlordToObjects/get?offset=0&limit=1000', // TODO: life search
  [names.REF_PUBLICATION_RESOURCE]: () => 'CLASSIFIER/REF_PUBLICATION_RESOURCE',
  [names.COMPETITION_CANCEL_REASON_TYPE]: () => 'CLASSIFIER/COMPETITION_CANCEL_REASON_TYPE',
  [names.DOC_FILLING_FORM]: () => 'CLASSIFIER/CATALOG/DOC_FILLING_FORM',
  [names.PAYMENT_STATE]: () => 'CLASSIFIER/CATALOG/PAYMENT_STATE',
  [names.CL_LEASE_COMPETITION_STATUS]: () => 'CLASSIFIER/CL_LEASE_COMPETITION_STATUS',
  [names.CL_COMPETION_REQUREMENT_TYPE]: () => 'CLASSIFIER/CL_COMPETION_REQUREMENT_TYPE',
  [names.REQUEST_FOR_LEGAL_PROCESSING]: (
    baseUrl,
    { offset, limit } = { offset: 0, limit: 1000 },
  ) => ({
    url: 'request_for_legal_processing/registry/requestForLegalProcessings/get',
    method: 'post',
    body: { offset, limit },
  }),
  [names.DEPARTMENT_TYPE]: () => 'CLASSIFIER/DEPARTMENT_TYPE',
  [names.BANKS]: (
    baseUrl,
    { offset, limit } = {
      offset: 0,
      limit: 1000,
    },
  ) => `bank/get?limit=${limit}&offset=${offset}`,
  [names.YES_NO]: () => null,
  [names.PERSON_TYPE_ENUM_ON_FE]: () => null,
  [names.APPEAL]: () => null,
  [names.APPEAL_INIT_TYPE]: () => null,
  [names.BANKDETAILS]: () => null,
  [names.FILE_CONTENT_TYPE]: () => 'CLASSIFIER/FILE_CONTENT_TYPE',
  [names.PHONE_TYPE]: () => 'CLASSIFIER/PHONE_TYPE',
  [names.EMAIL_TYPE]: () => 'CLASSIFIER/EMAIL_TYPE',
  [names.SITE_TYPE]: () => 'CLASSIFIER/WEB_SITE_TYPE',
  [names.PROCESS]: () => null,
  [names.STATE]: () => null,
  [names.CASE_CLASIFICATION]: () => null,
  [names.ENUM_JUDICIAL_SHOT_RESULT]: () => null,
  [names.POST]: () => 'CLASSIFIER/POST',
  [names.PERSON_ADDRESSING]: () => 'CLASSIFIER/get/PERSON_ADDRESSING?offset=0&limit=100',
  [names.CL_MARKET_PRICE_DETECT_METHOD]: () => 'CLASSIFIER/CL_MARKET_PRICE_DETECT_METHOD',
  [names.CL_ASSET_SPECIALIZATION]: () => 'CLASSIFIER/CL_ASSET_SPECIALIZATION',
  [names.LANDLORD_LEGAL_TYPE]: () => 'CLASSIFIER/LANDLORD_LEGAL_TYPE',
  [names.LEASE_CASES]: () => 'lease/leaseCases/get?offset=0&limit=1000', // TODO: will change to live search
  [names.LEASE_CASES_STATUS]: () => 'CLASSIFIER/LEASE_CASES_STATUS',
  [names.LEASE_COMPETITIONS]: () => 'leaseCompetition/get?offset=0&limit=100', // TODO: will change to live search
  [names.LEASE_UNUSED_COMPETITIONS]: () => 'leaseCompetition/getNotUsed?offset=0&limit=100', // TODO: will change to live search
  [names.ADDITIONAL_REGISTRATION]: () => null,
  [names.LEASE_START_USING_TERM]: () => 'CLASSIFIER/CATALOG/LEASE_START_USING_TERM_ENUM',
  [names.PAYMENT_PURPOSE_TYPE]: () => 'CLASSIFIER/PAYMENT_PURPOSE_TYPE',
  [names.BASE_LEASE_RATE_DETECT_METHOD]: () => null,
  [names.LEASE_RATE_DISCOUNTBASE_TYPE]: () => 'CLASSIFIER/LEASE_RATE_DISCOUNT_BASE_TYPE',
  [names.SHARES_FORM_TYPE]: () => 'CLASSIFIER/CATALOG/SHARES_FORM_TYPE',
  [names.CORPORATE_RIGHTS_OPERATION_TYPE]: () =>
    'CLASSIFIER/CATALOG/CORPORATE_RIGHTS_OPERATION_TYPE',
  [names.OPERATION_METHOD_TYPE]: () => 'CLASSIFIER/CATALOG/OPERATION_METHOD_TYPE',
  [names.STOCKS_TYPE]: () => 'CLASSIFIER/CATALOG/STOCKS_TYPE',
  [names.EVALUATION_STAGE]: () => null,
  [names.CONCLUSION_EVALUATION_LEASE]: () => null,
  [names.REVIEW_CATEGORY]: () => null,
  [names.CLASSIFICATION_PROCESS]: () => null,
  [names.INVENTORY]: () => null,
  [names.INCOMING_DOCUMENT]: () => null,
  [names.OUTGOING_DOCUMENT]: () => null,
  [names.CONTRACT_SUBJECT_EVALUATION_ACTIVITY]: () => null,
  [names.SUBJECT_EVALUATION_ACTIVITY]: () => null,
  [names.STATEMENT]: () => null,
  [names.YEARS]: () => null,
  [names.MONTH]: () => 'CLASSIFIER/CATALOG/MONTH',
  [names.DOCUMENT_TYPE]: () => 'CLASSIFIER/DOCUMENT_TYPE',
  [names.DOCUMENT_TYPE_ENUM]: () => 'CLASSIFIER/CATALOG/DOCUMENT_TYPE_ENUM',
  [names.DOCTYPE_SCOPE_OF_APP]: () => 'CLASSIFIER/REF_DOCUMENT_TYPE/scopeOfApplication',
  [names.DOCTYPE_CATEGORY]: (baseUrl, { scopeOfApp }) =>
    `CLASSIFIER/REF_DOCUMENT_TYPE/scopeOfApplication/${scopeOfApp}/docCategory`,
  [names.DOCTYPE_NAME]: (baseUrl, { scopeOfApp, category }) =>
    `CLASSIFIER/REF_DOCUMENT_TYPE/scopeOfApplication/${scopeOfApp}/docCategory/${category}/docView`,
  [names.CL_DOC_VALIDITY_STATUS]: () => 'CLASSIFIER/CL_DOC_VALIDITY_STATUS',
  [names.DOCUMENT_VALIDITY_STATUS_ENUM]: () => 'CLASSIFIER/CATALOG/DOCUMENT_VALIDITY_STATUS_ENUM',
  [names.REF_DOCUMENT_TYPE_GENERAL_DOC_CLASSNAME]: (baseUrl, { generalDocClassName }) =>
    `CLASSIFIER/REF_DOCUMENT_TYPE/generalDocClassName/${generalDocClassName}`,
  [names.MEMBER_AUCTION_STATE]: () => 'CLASSIFIER/CATALOG/MEMBER_AUCTION_STATE',
  [names.STATE_PROPERTY_OF_ACCOUNTING_ITEM]: () =>
    'CLASSIFIER/QUICK_SEARCH/STATE_PROPERTY_OF_ACCOUNTING_ITEM',
  [names.STATE_PROPERTY_OF_ACCOUNTING_ITEM_TYPE]: () =>
    'CLASSIFIER/CATALOG/STATE_PROPERTY_OF_ACCOUNTING_ITEM_TYPE',
  [names.KDM_SECTIONS]: () => 'CLASSIFIER/KDM/sections',
  [names.KDM_PARTITIONS]: (baseUrl, { sectionName }) =>
    `CLASSIFIER/KDM/sections/${sectionName}/partitions`,
  [names.KDM_SUBSECTIONS]: (baseUrl, { sectionName, partitionName }) =>
    `CLASSIFIER/KDM/sections/${sectionName}/partitions/${partitionName}/subpartitions`,
  [names.KDM_GROUPS]: (baseUrl, { sectionName, partitionName, subPartitionName }) =>
    `CLASSIFIER/KDM/sections/${sectionName}/partitions/${partitionName}/subpartitions/${subPartitionName}/groups`,
  [names.KDM_CLASS]: (baseUrl, { sectionName, partitionName, subPartitionName, groupName }) =>
    `CLASSIFIER/KDM/sections/${sectionName}/partitions/${partitionName}/subpartitions/${subPartitionName}/groups/${groupName}/classes`,
  [names.KDM_SUBCLASS]: (
    baseUrl,
    { sectionName, partitionName, subPartitionName, groupName, className },
  ) =>
    `CLASSIFIER/KDM/sections/${sectionName}/partitions/${partitionName}/subpartitions/${subPartitionName}/groups/${groupName}/classes/${className}/subclasses`,
  [names.CL_PREMISE_PURPOSE]: () => 'CLASSIFIER/CL_PREMISE_PURPOSE',
  [names.CL_PREMISE_CONSTRUCTION]: () => 'CLASSIFIER/CL_PREMISE_CONSTRUCTION',
  [names.CL_PREMISE_EQUIP]: () => 'CLASSIFIER/CL_PREMISE_EQUIP',
  [names.CL_PROPERTY_STRUCT]: () => 'CLASSIFIER/CL_PROPERTY_STRUCT',
  [names.CL_WRITE_OFF]: () => 'CLASSIFIER/CL_WRITE_OFF',
  [names.CL_FLOOR]: () => 'CLASSIFIER/CL_FLOOR',
  [names.CL_BUILDING_MATERIAL]: () => 'CLASSIFIER/CL_BUILDING_MATERIAL',
  [names.CL_ELECTRO_SUPPLY]: () => 'CLASSIFIER/CL_ELECTRO_SUPPLY',
  [names.CL_COLD_WATER_SUPPLY]: () => 'CLASSIFIER/CL_COLD_WATER_SUPPLY',
  [names.CL_HOT_WATER_SUPPLY]: () => 'CLASSIFIER/CL_HOT_WATER_SUPPLY',
  [names.CL_SEWERAGE_SUPPLY]: () => 'CLASSIFIER/CL_SEWERAGE_SUPPLY',
  [names.CL_GAS_SUPPLY]: () => 'CLASSIFIER/CL_GAS_SUPPLY',
  [names.CL_LIFT]: () => 'CLASSIFIER/CL_LIFT',
  [names.CL_HEATING_SUPPLY]: () => 'CLASSIFIER/CL_HEATING_SUPPLY',
  [names.CL_RUBBISH_SUPPLY]: () => 'CLASSIFIER/CL_RUBBISH_SUPPLY',
  [names.CL_LAND_CATEGORY]: () => 'CLASSIFIER/CL_LAND_CATEGORY',
  [names.CL_LAND_PURPOSE]: () => 'CLASSIFIER/CL_LAND_PURPOSE',
  [names.CL_OBJECTS_OPERATION_STATUS_TYPE]: () => 'CLASSIFIER/CL_OBJECT_OPERATION_STATUS_TYPE',
  [names.CL_STATE_PROPERTY]: () => 'CLASSIFIER/STATE_PROPERTY_OF_ACCOUNTING_ITEM',
  [names.CL_LEGAL_AFFAIRS_TYPE]: () => 'CLASSIFIER/CL_LEGAL_AFFAIRS_TYPE',
  [names.CL_LEGAL_AFFAIRS_STAGES_TYPE]: () => 'CLASSIFIER/CL_LEGAL_AFFAIRS_STAGES_TYPE',
  [names.LEGAL_PROCESSING_STATUS_ENUM]: () =>
    'CLASSIFIER/CATALOG/REQUEST_FOR_LEGAL_PROCESSING_STATUS_ENUM',
  [names.COURT_INSTANCE_LEVEL_ENUM]: () => 'CLASSIFIER/CATALOG/COURT_INSTANCE_LEVEL_ENUM',
  [names.COURT_SESSION_STATUS_ENUM]: () => 'CLASSIFIER/CATALOG/COURT_SESSION_STATUS_ENUM',
  [names.PRIVAT_OBJECT_GROUP_TYPE]: () => 'CLASSIFIER/PRIVAT_OBJECT_GROUP_TYPE',
  [names.PRIVAT_ORGANISATION_TYPE]: () => 'CLASSIFIER/PRIVAT_ORGANISATION_TYPE',
  [names.PRIVAT_METHOD_TYPE]: () => 'CLASSIFIER/PRIVAT_METHOD_TYPE',
  [names.PRIVAT_STAGE_TYPE]: () => 'CLASSIFIER/PRIVAT_STAGE_TYPE',
  [names.PRIVAT_OBJECT_STATUS]: () => 'CLASSIFIER/CATALOG/PRIVAT_OBJECT_STATUS',
  [names.CL_MANUFACTURER]: () => null,
  [names.EQUIPMENT_TYPE]: () => null,
  [names.CL_ROAD_MOVE_LINE]: () => null,
  [names.CL_ROAD_TECHNOLOGY]: () => null,
  [names.REF_WH_TRANSPORT_TYPE]: () => null,
  [names.REF_WH_TRANSPORT_COLOR_TYPE]: () => null,
  [names.REF_RAIL_ROAD_MATERIAL]: () => null,
  [names.REF_RAIL_ROAD_BALAST_MATERIAL]: () => null,
  [names.REF_RAIL_ROAD_SLEEPERS_MATERIAL]: () => null,
  [names.REF_RAIL_ROAD_TECHNOLOGY]: () => null,
  [names.CL_PLANT]: () => null,
  [names.CL_PLANT_PURPOSE]: () => null,
  [names.CL_INTELL_CREATION_TYPE]: () => null,
  [names.CL_INTELL_LICENSE_TYPE]: () => null,
  [names.CL_INTELL_PATENT_DATA]: () => null,
  [names.REF_ANIMAL_CLASSIFIER]: () => null,
  [names.CL_ANIMAL_PURPOSE]: () => null,
  [names.BODIES]: () => null,
  [names.OBJECT_EVALUATION]: () => null,
  [names.OBJECT_ADDRESS]: () => null,
  [names.OBJECT_TYPE]: () => 'CLASSIFIER/LEASE_OBJECT_TYPE',
  [names.PROPERTY_PARENT_OBJECTS]: (baseUrl, { searchTerm }) =>
    `accountingItem/parents?predicate=${encodeURI(searchTerm)}`,
  [names.OBJECTS_TYPE_BY_ACCOUNTING]: () => 'CLASSIFIER/ACCOUNT_TYPE',
  [names.CL_PHYSICAL_STATE]: () => 'CLASSIFIER/CL_PHYSICAL_STATE',
  [names.CL_FUNK_ACCORDANCE]: () => 'CLASSIFIER/CL_FUNK_ACCORDANCE',
  [names.LEASE_RATE_DIRECTORY]: () => 'CLASSIFIER/LEASE_RATE_DIRECTORY',
  [names.LEASE_OPERATION_MODE]: () => 'CLASSIFIER/CATALOG/LEASE_OPERATION_MODE_ENUM',
  [names.CONTRACT_ADDITIONAL_REGISTRATION_ENUM]: () =>
    'CLASSIFIER/CATALOG/CONTRACT_ADDITIONAL_REGISTRATION_ENUM',
  [names.OBJECT_LIST_RECORD_STATUS_ENUM]: () => 'CLASSIFIER/CATALOG/OBJECT_LIST_RECORD_STATUS_ENUM',
  [names.BASE_LEASE_RATE_DETECT_METHOD_ENUM]: () =>
    'CLASSIFIER/CATALOG/BASE_LEASE_RATE_DETECT_METHOD_ENUM',
  [names.BASE_LEASE_PERIODS]: () => null,
  [names.CL_AMORTIZATION]: () => 'CLASSIFIER/CL_AMORTIZATION',
  [names.CL_ASSET_SPECIALISATION]: () => 'CLASSIFIER/CL_ASSET_SPECIALIZATION',
  [names.CL_PROPERTY_RIGHTS_TYPE]: () => 'CLASSIFIER/CL_DERIVATIVE_PROPERTY_RIGHTS_TYPE',
  [names.CL_PROPERTY_OWNERSHIP_TYPE]: () => 'CLASSIFIER/CL_PROPERTY_OWNERSHIP_TYPE',
  [names.KOPFG]: () => 'CLASSIFIER/KOPFG_FORM_TYPE',
  [names.KVED]: () => 'CLASSIFIER/KVED_ACTIVITY_TYPE',
  [names.KVED_LIVE_SEARCH]: (baseUrl, { search } = {}) =>
    search ? `CLASSIFIER/KVED/liveSearch/${search || ''}` : null,
  [names.SKOF]: () => 'CLASSIFIER/SKOF_FORM_TYPE',
  [names.SKODY]: () => 'CLASSIFIER/SKODU_BODY_TYPE',
  [names.KFV]: () => 'CLASSIFIER/KFV_PROPERTY_FORM',
  [names.FIN_SOURSE_TYPE]: () => 'CLASSIFIER/FIN_SOURCE_TYPE',
  [names.REGISTRATION_STATE]: () => 'CLASSIFIER/CATALOG/STATUS_OF_STATE_REGISTRATION_ENUM',
  [names.LEGAL_ENTITY_STATE]: () => 'CLASSIFIER/CATALOG/LEGAL_ENTITY_STATE',
  [names.IS_MODEL_STATUT]: () => null,
  [names.PHONELIST]: () => 'registry/PHONE_REGISTRY?offset=0&limit=1000', // TODO: will change to live search
  [names.EMAILLIST]: () => 'registry/EMAIL_REGISTRY?offset=0&limit=1000', // TODO: will change to live search
  [names.WEBSITELIST]: () => 'registry/WEB_SITE_REGISTRY?offset=0&limit=1000', // TODO: will change to live search
  [names.CL_CABLE_ELECTRICITY_PURPOSE]: () => null,
  [names.CL_CABLE_CLASSIFIER]: () => null,
  [names.CL_CABLE_PILLAR_MATERIAL]: () => null,
  [names.CL_CABLE_TECHNOLOGY]: () => null,
  // property pipelines
  [names.CL_PROPERTY_TUBE_CLASSIFIER]: () => null,
  [names.CL_PROPERTY_TUBE_TEHNOLOGY]: () => null,
  [names.CL_PROPERTY_TUBE_BASE_MATERIAL]: () => null,
  [names.LAND_LORDS_TO_LEASE_OBJECTS]: () => null,
  [names.COUNTRIES_LIST]: () => 'addressunit/countries',
  // LEASE CCA (PPD)
  [names.CLAIM_ACTION_ACTIVITY_STEP]: () => `CLASSIFIER/CATALOG/CLAIM_ACTION_ACTIVITY_STEP`,
  [names.CLAIM_ACTION_ACTIVITY_STEP_STAGE]: () =>
    `CLASSIFIER/CATALOG/CLAIM_ACTION_ACTIVITY_STEP_STAGE`,
  [names.CLAIM_ACTION_ACTIVITY_STEP_STAGE_SUM_OPERATION]: () =>
    `CLASSIFIER/CATALOG/CLAIM_ACTION_ACTIVITY_STEP_STAGE_SUM_OPERATION`,
  [names.CLAIM_ACTION_ACTIVITY_STATUS]: () => `CLASSIFIER/CATALOG/CLAIM_ACTION_ACTIVITY_STATUS`,
};

export default res;
