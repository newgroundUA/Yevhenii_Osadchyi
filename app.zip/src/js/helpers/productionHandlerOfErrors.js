/* eslint-disable */
import { message } from 'antd';

export const runHandlerOfErrors = () => {
  (function(console) {
    console.save = function(data, fileName) {
      if (!data) {
        console.error('Console.save: No data');
        return;
      }

      if (!fileName) fileName = 'console.json';

      if (typeof data === 'object') {
        data = JSON.stringify(data, undefined, 4);
      }

      const blob = new Blob([data], { type: 'text/json' }),
        e = document.createEvent('MouseEvents'),
        a = document.createElement('a');

      a.download = fileName;
      a.href = window.URL.createObjectURL(blob);
      a.dataset.downloadurl = ['text/json', a.download, a.href].join(':');
      e.initMouseEvent(
        'click',
        true,
        false,
        window,
        0,
        0,
        0,
        0,
        0,
        false,
        false,
        false,
        false,
        0,
        null,
      );
      a.dispatchEvent(e);
    };
  })(console);

  window.onerror = function(msg, url, lineNo, columnNo, error) {
    const errorDate = new Date();
    const seconds = errorDate.getSeconds();
    const minutes = errorDate.getMinutes();
    const hour = errorDate.getHours();
    const day = errorDate.getDate();
    const month = errorDate.getMonth() + 1;
    const year = errorDate.getFullYear();
    const fileName = `Errors Log ${year}-${month}-${day}_${hour}-${minutes}-${seconds}.json`;
    message.error('Виникла помилка системи.');
    console.save(
      {
        msg,
        url,
        lineNo,
        columnNo,
        error,
      },
      fileName,
    );
  };
};
