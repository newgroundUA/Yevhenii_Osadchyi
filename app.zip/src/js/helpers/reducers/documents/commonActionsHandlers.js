import update from 'immutability-helper';

export const defStoreKey = 'default';

export const bindDocument = (state, action) =>
  update(state, {
    [action.storeKey || defStoreKey]: {
      createdForm: {
        [action.fieldName]: {
          $set: action.data[action.fieldName],
        },
        versionId: {
          $set: action.data.ownerDocument.versionId,
        },
      },
    },
  });

export const lockDocument = (state, action) =>
  update(state, {
    [action.storeKey || defStoreKey]: {
      createdForm: {
        $merge: action.data,
      },
    },
  });
