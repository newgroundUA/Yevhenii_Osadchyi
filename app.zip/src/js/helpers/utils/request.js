import request from 'request';

export default (config) =>
  new Promise((resolve, reject) => {
    request.get(config, (err, res, body) => {
      if (err) return reject(err);
      return resolve(JSON.parse(body));
    });
  }).then((result) => result);
