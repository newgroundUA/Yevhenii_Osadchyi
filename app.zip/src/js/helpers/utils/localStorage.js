// custom localStorage for test env.
module.exports = {
  setLocalStorage: () => {
    global.localStorage = {
      getItem: function(key) {
        return this[key];
      },
      setItem: function(key, value) {
        return (this[key] = value);
      },
      removeItem: function(key) {
        return delete this[key];
      },
    };
  },
};
