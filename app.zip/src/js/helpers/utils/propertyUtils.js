import * as cellTypes from '../../constants/CellTypes';

export const changePropertySortTypeForModels = (list, sortList) => {
  sortList.forEach((key) => {
    const item = list[key];
    if (!item) {
      // eslint-disable-next-line
      return console.log(
        `--->>> DO NOT FORGET <<<---: ${key} check model for property (invalid sort)`,
      );
    }
    item.type = cellTypes.SORT;
  });
};

export default {
  changePropertySortTypeForModels,
};
