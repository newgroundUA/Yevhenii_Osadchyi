import EnumToLabelsMap from '../../constants/EnumToLabelsMap';

export const getEnumLabel = ({ enumValue, classifierName }) => {
  let label = null;
  if (
    classifierName &&
    EnumToLabelsMap[classifierName] &&
    EnumToLabelsMap[classifierName][enumValue]
  ) {
    label = EnumToLabelsMap[classifierName][enumValue];
  } else if (EnumToLabelsMap[enumValue]) label = EnumToLabelsMap[enumValue];

  return label;
};
