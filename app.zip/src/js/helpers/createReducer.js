import update from 'immutability-helper';
import { combineReducers } from 'redux';

import setValue from './setObjValue';

export const defaultStoreKey = 'default';

export const multipleCasesObj = (casesArr = [], func) =>
  casesArr.reduce(
    (curObj, key) => ({
      ...curObj,
      [key]: func,
    }),
    {},
  );

const initialFormData = (additionalFieldsParams) => ({
  createdForm: {
    guid: '',
    ...((additionalFieldsParams && additionalFieldsParams.initialState) || {}),
  },
  status: {
    isDone: false,
  },
  errors: [],
});

export const createDistributedReducer = (initialState, reducerMap, additionalFieldsParams) => (
  defaultState = initialState,
  action,
) => {
  const reducer = reducerMap[action.type];
  const storeKey = action.storeKey || defaultStoreKey;
  const state =
    !defaultState[storeKey] && reducer
      ? { ...defaultState, [storeKey]: initialFormData(additionalFieldsParams) }
      : defaultState;

  return reducer ? reducer(state, action) : state;
};

export const createReducer = (initialState, reducerMap) => (state = initialState, action) => {
  const reducer = reducerMap[action.type];
  return reducer ? reducer(state, action) : state;
};

const parseAdditionalFields = (fields) =>
  Object.keys(fields).reduce((prev, actionType) => {
    const actionHandler = fields[actionType];
    return {
      ...prev,
      [actionType]: actionHandler,
    };
  }, {});

const createPagesReducer = (
  { resets, set, load },
  initialState = {
    currentPage: 0,
    totalPages: 0,
    totalFinded: 0,
  },
) =>
  createReducer(initialState, {
    ...multipleCasesObj(resets, () => initialState),
    [set]: (state, action) => ({
      ...state,
      ...setValue(state, action.key, action.value),
    }),
    [load]: (state, action) =>
      update(state, {
        totalFinded: {
          $set: action.data.totalElements,
        },
      }),
  });

const createFastFiltersReducer = ({ reset, set }, initialState = {}) =>
  createReducer(initialState, {
    [reset]: () => initialState,
    [set]: (state, action) => ({
      ...state,
      ...setValue(state, action.key, action.value),
    }),
  });

const createRequestBodyReducer = (
  { reset, set },
  initialState = {
    limit: '25',
    page: 0,
    offset: '0',
    sortList: {},
    filter: [],
  },
) =>
  createReducer(initialState, {
    [reset]: () => initialState,
    [set]: (state, action) => ({
      ...state,
      ...setValue(state, action.key, action.value),
    }),
  });

const createRegistersReducer = ({ success, failure }, initialState = []) =>
  createReducer(initialState, {
    [success]: (state, { data }) => (data.content ? data.content : data),
    [failure]: () => [],
  });

export const createDefaultRegisterReducer = ({
  fastFilters,
  requestBody,
  registers,
  pages,
  additionalReducers,
}) =>
  combineReducers({
    fastFilters: createFastFiltersReducer(
      {
        reset: fastFilters.reset,
        set: fastFilters.set,
      },
      fastFilters.initialState,
    ),
    requestBody: createRequestBodyReducer(
      {
        reset: requestBody.reset,
        set: requestBody.set,
      },
      requestBody.initialState,
    ),
    registers: createRegistersReducer(
      {
        success: registers.success,
        failure: registers.failure,
      },
      registers.initialState,
    ),
    pages: createPagesReducer(
      {
        resets: pages.resets,
        set: pages.set,
        load: pages.load,
      },
      pages.initialState,
    ),
    ...additionalReducers,
  });

export const createFormReducer = (
  {
    reset,
    resetStatus,
    loads, // get
    reloads, // post, put
    errors,
    additionalFieldsParams,
  },
  initialState = {
    [defaultStoreKey]: initialFormData(additionalFieldsParams),
  },
) =>
  createDistributedReducer(
    initialState,
    {
      [reset]: (state, action) =>
        update(state, {
          [action.storeKey || defaultStoreKey]: {
            $set: initialFormData(additionalFieldsParams),
          },
        }),
      [resetStatus]: (state, action) =>
        update(state, {
          [action.storeKey || defaultStoreKey]: {
            status: {
              isDone: {
                $set: false,
              },
            },
          },
        }),
      ...multipleCasesObj(loads, (state, action) =>
        update(state, {
          [action.storeKey || defaultStoreKey]: {
            createdForm: {
              $set: {
                ...initialState[defaultStoreKey].createdForm,
                ...action.data,
              },
            },
          },
        }),
      ),
      ...multipleCasesObj(reloads, (state, action) =>
        update(state, {
          [action.storeKey || defaultStoreKey]: {
            createdForm: {
              $set: {
                ...initialState[defaultStoreKey].createdForm,
                ...action.data,
              },
            },
            status: {
              isDone: {
                $set: !action.ignoreStatus,
              },
            },
          },
        }),
      ),
      ...multipleCasesObj(errors, (state, action) =>
        update(state, {
          [action.storeKey || defaultStoreKey]: {
            errors: {
              $set: action.errors,
            },
          },
        }),
      ),
      ...((additionalFieldsParams && parseAdditionalFields(additionalFieldsParams.fields)) || {}),
    },
    additionalFieldsParams,
  );
