import moment from 'moment';

import { postRefreshToken } from '../actions/usersActions';

const getToken = () => localStorage.getItem('token');
const getTokenExpire = () => localStorage.getItem('tokenExpire');

const clearToken = () => localStorage.removeItem('token');
const clearTokenExpire = () => localStorage.removeItem('tokenExpire');

const setToken = (val) => localStorage.setItem('token', val);
const setTokenExpire = (val) => localStorage.setItem('tokenExpire', val);

const getClientID = () => localStorage.getItem('clientId');
const clearClientID = () => localStorage.removeItem('clientId');
const setClientID = (val) => localStorage.setItem('clientId', val);

const getRefreshToken = () => localStorage.getItem('refreshToken');
const clearRefreshToken = () => localStorage.removeItem('refreshToken');
const setRefreshToken = (val) => localStorage.setItem('refreshToken', val);

const isTokenExpired = () => moment(getTokenExpire()) < moment();

const isLoggedIn = () => !!getToken();
// const isLoggedIn = () => !!getToken() && !isTokenExpired();

const clearDkvStorage = () => {
  clearToken();
  clearTokenExpire();
  clearClientID();
  clearRefreshToken();
};

const refreshToken = ({ dispatch, cb }) => {
  const clientId = getClientID();
  const refresh = getRefreshToken();
  return dispatch(postRefreshToken({ clientId, refresh })).then(() => cb());
};

export {
  clearDkvStorage,
  isLoggedIn,
  isTokenExpired,
  setTokenExpire,
  clearTokenExpire,
  getToken,
  clearToken,
  setToken,
  getClientID,
  clearClientID,
  setClientID,
  getRefreshToken,
  clearRefreshToken,
  setRefreshToken,
  refreshToken,
};
