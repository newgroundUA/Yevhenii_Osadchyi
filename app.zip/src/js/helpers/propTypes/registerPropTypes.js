import PropTypes from 'prop-types';

export const registerPropTypes = {
  tableToolbar: PropTypes.objectOf(PropTypes.any).isRequired,
  sortedColumns: PropTypes.shape({
    fixed: PropTypes.object,
    fluid: PropTypes.object,
  }).isRequired,
  setValueRequestBody: PropTypes.func.isRequired,

  handleChangeColumns: PropTypes.func.isRequired,
  handleToggleToolbarItem: PropTypes.func.isRequired,
  handleSubmitFilters: PropTypes.func.isRequired,
  handleCancelFilters: PropTypes.func.isRequired,
};

export const someShit = {};
