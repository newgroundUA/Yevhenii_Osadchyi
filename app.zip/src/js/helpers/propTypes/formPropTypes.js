import PropTypes from 'prop-types';

export const formPropTypes = {
  curMode: PropTypes.string.isRequired,
  renderButtons: PropTypes.func.isRequired,

  putForm: PropTypes.func.isRequired,
  postForm: PropTypes.func.isRequired,

  classifiers: PropTypes.objectOf(PropTypes.array).isRequired,
  formParam: PropTypes.objectOf(PropTypes.any).isRequired,

  form: PropTypes.objectOf(PropTypes.any).isRequired,
};

export const fullFormPropTypes = {
  ...formPropTypes,
  curGuid: PropTypes.string.isRequired,
  getForm: PropTypes.func.isRequired,
};
