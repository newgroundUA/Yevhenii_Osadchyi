import React from 'react';
import PropTypes from 'prop-types';
import { Radio } from 'antd';
import * as cn from '../../constants/ClassifiersNames';
import { getEnumLabel } from '../enums';

const enumRadioGetter = ({ option, index, disabledValues = [], classifierName }) => {
  enumRadioGetter.defaultProps = {
    disabledValues: [],
    classifierName: undefined,
  };
  enumRadioGetter.propTypes = {
    option: PropTypes.string.isRequired,
    index: PropTypes.string.isRequired,
    disabledValues: PropTypes.string,
    classifierName: PropTypes.string,
  };

  return (
    <Radio value={option} key={`${option}-${index}`} disabled={disabledValues.includes(option)}>
      {getEnumLabel({
        enumValue: option,
        classifierName,
      }) || option}
    </Radio>
  );
};

export default {
  [cn.GROUPED_OBJECTS_TYPE]: enumRadioGetter,
};
