import React from 'react';
import PropTypes from 'prop-types';
import { Select } from 'antd';
import * as cn from '../../constants/ClassifiersNames';
import { getCounterpartyLabel } from '../entities/countrerparty';
import { getEnumLabel } from '../enums';

const Option = Select.Option;
const enumOptionGetter = ({ option, index, disabledValue, classifierName }) => {
  enumOptionGetter.defaultProps = {
    disabledValue: undefined,
    classifierName: undefined,
  };
  enumOptionGetter.propTypes = {
    option: PropTypes.string.isRequired,
    index: PropTypes.string.isRequired,
    disabledValue: PropTypes.string,
    classifierName: PropTypes.string,
  };
  return (
    <Option value={option} key={`${option}-${index}`} disabled={option === disabledValue || false}>
      {getEnumLabel({
        enumValue: option,
        classifierName,
      }) || option}
    </Option>
  );
};

export default {
  [cn.LEGAL_AFFAIRS]: (option) => (
    <Option value={`${option.guid}`} key={option.guid}>
      {option.courtNumber}
    </Option>
  ),
  [cn.GROUP_OF_PREMISE]: (option) => (
    <Option value={`${option.guid}`} key={option.guid}>
      {option.groupName}
    </Option>
  ),
  [cn.PREMISE]: (
    { option }, // eslint-disable-line
  ) => (
    <Option value={`${option.guid}`} key={option.guid}>
      {option.fullName}
    </Option>
  ),
  [cn.ASSESSMENT_REVIEWING_CATEGORY]: (
    { option }, // eslint-disable-line
  ) => (
    <Option value={`${option.guid}`} key={option.guid}>
      {option.name}
    </Option>
  ),
  [cn.ASSESSMENT_REVIEWING_CONCLUSION]: (option) => (
    <Option value={option} key={option}>
      {option}
    </Option>
  ),
  [cn.CL_ASSESSMENT_REVIEWING_STATE]: (
    { option }, // eslint-disable-line
  ) => (
    <Option value={`${option.guid}`} key={option.guid}>
      {option.name}
    </Option>
  ),
  [cn.LEASE_ASSESSMENT_TYPE]: (option) => (
    <Option value={option} key={option}>
      {option}
    </Option>
  ),
  [cn.ASSESSMENT_REASON_TYPE]: (option) => (
    <Option value={option} key={option}>
      {option}
    </Option>
  ),
  [cn.LEASE_COMPETITIONS]: (option) => (
    <Option value={`${option.guid}`} key={option.guid}>
      {option.leaseCompetitionsNumber}
    </Option>
  ),
  [cn.PHONELIST]: (option) => (
    <Option value={`${option.guid}`} key={option.guid}>
      {option.phoneNumber}
    </Option>
  ),
  [cn.EMAILLIST]: (option) => (
    <Option value={`${option.guid}`} key={option.guid}>
      {option.emailName}
    </Option>
  ),
  [cn.WEBSITELIST]: (option) => (
    <Option value={`${option.guid}`} key={option.guid}>
      {option.wwwPage}
    </Option>
  ),
  [cn.PROPERTY_PARENT_OBJECTS]: (option) => (
    <Option value={`${option.guid}`} key={option.guid}>
      {option.fullName}
    </Option>
  ),
  [cn.REGISTRATION_STATE]: enumOptionGetter,
  [cn.PERSON_TYPE_ENUM]: enumOptionGetter,
  [cn.DOCUMENTS]: (option) => (
    <Option value={`${option.guid}`} key={option.guid}>
      {option.docSerialNumber}
    </Option>
  ),
  [cn.REQUEST_FOR_LEGAL_PROCESSING]: (option) => (
    <Option value={`${option.guid}`} key={option.guid}>
      {`${option.requestStatus} № ${option.requestNumber}`}
    </Option>
  ),
  // TODO: change name to other param
  [cn.LANDLORD_TO_OBJECTS]: (option) => (
    <Option value={`${option.guid}`} key={option.guid}>
      {option.guid}
    </Option>
  ),
  [cn.LEASE_CASES]: (
    { option }, // eslint-disable-line
  ) => (
    <Option value={`${option.guid}`} key={option.guid}>
      {option.leaseCasesNumber}
    </Option>
  ),
  [cn.LEASE_UNUSED_COMPETITIONS]: (option) => (
    <Option value={`${option.guid}`} key={option.guid}>
      {option.leaseCompetitionsNumber}
    </Option>
  ),
  [cn.COUNTERPARTY]: (option) => (
    <Option value={`${option.guid}`} key={option.guid}>
      {option.legalFullName || option.personShortOfficeName}
    </Option>
  ),
  [cn.BANKS]: (
    { option }, // eslint-disable-line
  ) => (
    <Option value={`${option.guid}`} key={option.guid}>
      {`${option.mfo} ${getCounterpartyLabel({
        counterparty: option.legalEntity,
        withoutType: true,
        kopfg: false,
      })}`}
    </Option>
  ),
  [cn.MONTH]: enumOptionGetter,
  [cn.CLAIM_ACTION_ACTIVITY_STEP_STAGE]: enumOptionGetter,
  [cn.CLAIM_ACTION_ACTIVITY_STEP_STAGE_SUM_OPERATION]: enumOptionGetter,
  [cn.YEARS]: enumOptionGetter,
  [cn.DOCUMENT_VALIDITY_STATUS_ENUM]: enumOptionGetter,
  [cn.BASE_LEASE_PERIODS]: enumOptionGetter,
  [cn.CONTRACT_ADDITIONAL_REGISTRATION_ENUM]: enumOptionGetter,
  [cn.OBJECT_LIST_RECORD_STATUS_ENUM]: enumOptionGetter,
  [cn.BASE_LEASE_RATE_DETECT_METHOD_ENUM]: enumOptionGetter,
  [cn.SHARES_FORM_TYPE]: enumOptionGetter,
  [cn.CORPORATE_RIGHTS_OPERATION_TYPE]: enumOptionGetter,
  [cn.OPERATION_METHOD_TYPE]: enumOptionGetter,
  [cn.STOCKS_TYPE]: enumOptionGetter,
  [cn.LEGAL_PROCESSING_STATUS_ENUM]: enumOptionGetter,
  [cn.COURT_INSTANCE_LEVEL_ENUM]: enumOptionGetter,
  [cn.LEASE_OPERATION_MODE]: enumOptionGetter,
  [cn.PRIVAT_OBJECT_STATUS]: enumOptionGetter,
  [cn.COUNTRIES_LIST]: (
    { option }, // eslint-disable-line
  ) => (
    <Option value={option.countryGuid} key={option.countryGuid}>
      {option.countryName}
    </Option>
  ),
  [cn.DOC_FILLING_FORM]: enumOptionGetter,
  [cn.COURT_SESSION_STATUS_ENUM]: enumOptionGetter,
  [cn.LEASE_START_USING_TERM]: enumOptionGetter,
  [cn.MEMBER_AUCTION_STATE]: enumOptionGetter,
  [cn.OBJECTS]: (option) => (
    <Option value={`${option.guid}`} key={option.guid}>
      {option.fullname}
    </Option>
  ),
  [cn.APPEAL_INIT_TYPE]: enumOptionGetter,
  [cn.ENUM_JUDICIAL_SHOT_RESULT]: enumOptionGetter,
  // не класификаторы
  lastName: enumOptionGetter,
  firstName: enumOptionGetter,
  middleName: enumOptionGetter,
  [cn.FILTER_CRITERIA]: (
    { option }, // eslint-disable-line
  ) => (
    <Option value={`${option.value}`} key={option.value}>
      {option.label}
    </Option>
  ),
  [cn.FILTER_TYPE]: (
    { option }, // eslint-disable-line
  ) => (
    <Option value={`${option.type}`} key={option.type}>
      {option.label}
    </Option>
  ),
  [cn.LEGAL_ENTITY_STATE]: enumOptionGetter,
  [cn.CLAIM_ACTION_ACTIVITY_STATUS]: (option, index) => (
    <Option value={getEnumLabel(option) || option} key={`${option}-${index}`}>
      {getEnumLabel(option) || option}
    </Option>
  ),
  [cn.ASSESSMENT_REASON_TYPE]: enumOptionGetter,
  [cn.LEASE_ASSESSMENT_TYPE]: enumOptionGetter,
  [cn.ASSESSMENT_REVIEWING_CONCLUSION]: enumOptionGetter,
  [cn.PRIVAT_OBJECT_STATUS]: enumOptionGetter,
};
