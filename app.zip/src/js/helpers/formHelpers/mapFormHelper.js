import React from 'react';

import { Form, Select, Row, Col, Input, DatePicker, TimePicker, Radio, Switch } from 'antd';

import * as cn from '../../constants/ClassifiersNames';

import Uploader from '../../components/common/form/Uploader';
import CounterpartiesDropdownContainer from '../../containers/common/CounterpartiesDropdownContainer';
import DocumentsDropdownContainer from '../../containers/common/DocumentsDropdownContainer';
import ObjectsDropdownContainer from '../../containers/common/ObjectsDropdownContainer';
import PhoneModalContainer from '../../containers/modals/PhoneModalContainer';
import EmailModalContainer from '../../containers/modals/EmailModalContainer';
import SiteModalContainer from '../../containers/modals/SiteModalContainer';
import * as itemTypes from '../../constants/FormItemTypes';
import formsFieldsValuesNormilizers from '../validation/FormsFieldsValuesNormilizers';
import optionGetters from './optionGetters';
import radioGetters from './radioGetters';
import DocumentCascader from '../../containers/documents/common/DocumentCascader';
import KvedTreeLiveSearch from '../../containers/common/KvedTreeLiveSearch';
import RequestsForLegalProcessingDropDownContainer from '../../containers/common/RequestsForLegalProcessingDropDownContainer';
import LocalityAreasDropDownContainer from '../../containers/common/address/addressParts/LocalityAreasDropDownContainer';

const RadioGroup = Radio.Group;
const FormItem = Form.Item;
const Option = Select.Option;
const TextArea = Input.TextArea;

export const renderInput = (params) => {
  const { key, item, isViewMode = false, formItemLayout = {}, disabled, onChange, form } = params;

  return (
    <FormItem
      label={item.name || item.title || ''}
      key={key}
      {...formItemLayout}
      className={`labelOneRow ${item.className || ''}`}
    >
      {form.getFieldDecorator(item.field, {
        getValueFromEvent: (e) => e.target.value,
        rules: item.rules || [],
        initialValue: item.defaultValue,
      })(
        <Input
          id={item.field}
          onChange={item.onChange || onChange}
          onBlur={item.onBlur}
          onPressEnter={item.onPressEnter}
          disabled={isViewMode || item.readOnly || disabled}
          placeholder={item.placeholder}
        />,
      )}
    </FormItem>
  );
};

export const renderRequestsForLegalProcessingDropDown = (params) => {
  const {
    item,
    isViewMode = false,
    form,
    viewMode,
    formItemLayout = {},
    mode,
    disabled,
    formName,
  } = params;
  return (
    <span id={item.field}>
      <RequestsForLegalProcessingDropDownContainer
        isViewMode={isViewMode || disabled}
        formItemLayout={formItemLayout}
        mode={mode}
        fieldSpec={item}
        excludeLayout
        viewMode={viewMode}
        form={form}
        storeKey={`${formName}-${item.field}`}
      />
    </span>
  );
};

export const renderLocalityAreasDropDown = (params) => {
  const { item, isViewMode = false, form, viewMode, formItemLayout = {}, mode, disabled } = params;

  return (
    <span id={item.field}>
      <LocalityAreasDropDownContainer
        disabled={isViewMode || disabled}
        formItemLayout={formItemLayout}
        mode={mode}
        fieldSpec={item}
        viewMode={viewMode}
        form={form}
      />
    </span>
  );
};

export const renderStreetsDropDown = () => {};
export const renderBuildingsDropDown = () => {};
export const renderInheritAddressObjectsDropDown = () => {};
export const renderPremisesDropDown = () => {};

export const renderCounterpartyDropdown = (params) => {
  const { item, isViewMode = false, form, mode, disabled } = params;
  return (
    <span id={item.field}>
      <CounterpartiesDropdownContainer
        form={form}
        isViewMode={isViewMode || disabled}
        mode={mode}
        fieldSpec={item}
        updater={{}}
        counterpartyType={item.counterpartyType || null}
        excludeLayout
      />
    </span>
  );
};

export const renderDocumentsDropdown = (params) => {
  const { item, isViewMode = false, form, viewMode, formItemLayout, mode, disabled } = params;
  return (
    <span id={item.field}>
      <DocumentsDropdownContainer
        isViewMode={isViewMode || disabled}
        formItemLayout={formItemLayout}
        mode={mode}
        fieldSpec={item}
        updater={{}}
        excludeLayout
        viewMode={viewMode}
        form={form}
      />
    </span>
  );
};

export const renderPhonesDropdown = (params) => {
  const { item, classifiers, isViewMode = false, form, disabled } = params;
  return (
    <span id={item.field}>
      <PhoneModalContainer
        isViewMode={isViewMode || disabled}
        fieldSpec={item}
        classifiers={classifiers}
        form={form}
        updater={{}}
      />
    </span>
  );
};

export const renderEmailesDropdown = (params) => {
  const { item, classifiers, isViewMode = false, form, disabled } = params;
  return (
    <span id={item.field}>
      <EmailModalContainer
        isViewMode={isViewMode || disabled}
        fieldSpec={item}
        classifiers={classifiers}
        form={form}
        updater={{}}
      />
    </span>
  );
};

export const renderSitesDropdown = (params) => {
  const { item, classifiers, isViewMode = false, form, disabled } = params;
  return (
    <span id={item.field}>
      <SiteModalContainer
        isViewMode={isViewMode || disabled}
        fieldSpec={item}
        classifiers={classifiers}
        form={form}
        updater={{}}
      />
    </span>
  );
};

export const renderObjectsDropdown = (params) => {
  const { item, isViewMode = false, form, formItemLayout, viewMode, mode, disabled } = params;
  return (
    <span id={item.field}>
      <ObjectsDropdownContainer
        isViewMode={isViewMode || disabled}
        displayMode={item.displayMode}
        mode={mode}
        fieldSpec={item}
        objectType={item.objectType}
        formItemLayout={formItemLayout}
        updater={{}}
        excludeLayout
        form={form}
        viewMode={viewMode || item.viewMode}
        value={item.value}
      />
    </span>
  );
};

export const renderFile = (params) => {
  const { key, item, isViewMode = false, formItemLayout = {}, form } = params;
  return (
    <FormItem
      label={item.name || item.title || ''}
      key={key}
      {...formItemLayout}
      className={`labelOneRow ${item.className || ''}`}
    >
      {form.getFieldDecorator(item.field, {
        rules: item.rules || [],
      })(
        <Uploader
          className={item.field} // write for testing by className in TestRails
          disabled={isViewMode}
          name={item.field}
        />,
      )}
    </FormItem>
  );
};

export const renderSelect = (params) => {
  const {
    key,
    item,
    classifiers,
    isViewMode = false,
    formItemLayout = {},
    onChange,
    form,
    disabled,
  } = params;

  function getClassifierOptions() {
    return (item.classifierOptions || classifiers[item.classifier] || []).map(
      (el, index) =>
        optionGetters[item.classifier] ? (
          optionGetters[item.classifier]({
            option: el,
            index,
            disabledValue: item.disabledOptionValue,
            classifierName: item.classifier,
          })
        ) : (
          <Option title={el.name} value={el.guid} key={el.guid}>
            {el.name}
          </Option>
        ),
    );
  }

  function getCustomOptions() {
    return item.customOptions.map(({ guid, name }) => (
      <Option key={guid} value={guid}>
        {name}
      </Option>
    ));
  }

  const result = item.customOptions ? getCustomOptions() : getClassifierOptions();
  return (
    <FormItem
      label={item.name || item.title || ''}
      key={key}
      {...formItemLayout}
      className={`labelOneRow ${item.className || ''}`}
    >
      {form.getFieldDecorator(item.field, {
        rules: item.rules,
        initialValue: item.defaultValue,
      })(
        <Select
          className={item.field} // write for testing by className in TestRails
          dropdownClassName={`dropdown_${item.field}`} // write for testing by className in TestRails
          placeholder={item.placeholder}
          optionFilterProp="children"
          disabled={isViewMode || disabled || item.readOnly}
          onChange={item.onChange || onChange}
          showSearch={!!item.filter}
          filterOption={item.filter}
        >
          {result}
        </Select>,
      )}
    </FormItem>
  );
};

export const renderSearchBox = (params) => {
  const { key, item, isViewMode = false, formItemLayout = {}, form, formName } = params;
  const field = item.field;
  const normilizer =
    formsFieldsValuesNormilizers[formName] && formsFieldsValuesNormilizers[formName][field];
  return (
    <FormItem
      label={item.name || item.title || ''}
      key={key}
      {...formItemLayout}
      className={`labelOneRow ${item.className || ''}`}
    >
      {form.getFieldDecorator(field, {
        rules: item.rules || [],
        getValueFromEvent: normilizer,
        initialValue: item.defaultValue,
      })(
        <Select
          showSearch={item.showSearch || false}
          mode={item.mode}
          labelInValue={item.labelInValue || false}
          className={item.field} // write for testing by className in TestRails
          placeholder={item.placeholder}
          optionFilterProp={item.optionFilterProp}
          dropdownClassName={`dropdown_${item.field}`} // write for testing by className in TestRails
          disabled={isViewMode}
          defaultActiveFirstOption={false}
          filterOption={false}
          onSearch={item.search && item.search.handler}
        >
          {((item.search && item.search.result) || []).map(
            (el, index) =>
              optionGetters[field] ? (
                optionGetters[field]({
                  option: el,
                  index,
                })
              ) : (
                <Option value={el.guid} key={el.guid}>
                  {el.name}
                </Option>
              ),
          )}
        </Select>,
      )}
    </FormItem>
  );
};

export const renderMuliselect = (params) => {
  const { key, item, classifiers, isViewMode = false, formItemLayout = {}, form } = params;
  return (
    <FormItem
      label={item.name || item.title || ''}
      key={key}
      {...formItemLayout}
      className={`labelOneRow ${item.className || ''}`}
    >
      {form.getFieldDecorator(item.field, {
        rules: item.rules || [],
        initialValue: item.defaultValue,
      })(
        <Select
          mode="multiple"
          className={item.field} // write for testing by className in TestRails
          optionFilterProp="children"
          placeholder={item.placeholder}
          dropdownClassName={`dropdown_${item.field}`} // write for testing by className in TestRails
          disabled={isViewMode}
        >
          {(item.classifierOptions || classifiers[item.classifier] || []).map(
            (el, index) =>
              optionGetters[item.classifier] ? (
                optionGetters[item.classifier]({
                  option: el,
                  index,
                  classifierName: item.classifier,
                })
              ) : (
                <Option value={el.guid} key={el.guid}>
                  {el.name}
                </Option>
              ),
          )}
        </Select>,
      )}
    </FormItem>
  );
};

export const renderDatepicker = (params) => {
  const {
    key,
    item: {
      name,
      title,
      className,
      field,
      rules,
      defaultValue,
      placeholder,
      disabledDate,
      mode = 'date',
    },
    isViewMode = false,
    formItemLayout = {},
    disabled,
    onChange,
    form,
  } = params;
  return (
    <FormItem
      label={name || title || ''}
      key={key}
      {...formItemLayout}
      className={`labelOneRow ${className || ''}`}
    >
      {form.getFieldDecorator(field, {
        rules: rules || [],
        initialValue: defaultValue,
      })(
        <DatePicker
          mode={mode}
          className={field}
          onChange={onChange}
          // inputPrefixCls="osaInp"
          // prefixCls="osaPre"
          // popupStyle={{ 'background-color': 'red' }}
          placeholder={placeholder}
          dropdownClassName={`dropdown_${field}`} // write for testing by className in TestRails
          disabled={isViewMode || disabled}
          format={mode === 'year' ? 'YYYY' : 'DD.MM.YYYY'}
          disabledDate={disabledDate || (() => false)}
        />,
      )}
    </FormItem>
  );
};

export const renderDateTimePicker = (params) => {
  const { key, item, isViewMode = false, formItemLayout = {}, form } = params;
  return (
    <FormItem
      label={item.name || item.title || ''}
      key={key}
      {...formItemLayout}
      className={`labelOneRow ${item.className || ''}`}
    >
      {form.getFieldDecorator(item.field, {
        rules: item.rules || [],
        initialValue: item.defaultValue,
      })(
        <DatePicker
          showTime
          className={item.field} // write for testing by className in TestRails
          dropdownClassName={`dropdown_${item.field}`} // write for testing by className in TestRails
          format="DD.MM.YYYY HH:mm"
          disabled={isViewMode}
          disabledDate={item.disabledDate ? item.disabledDate : () => false}
        />,
      )}
    </FormItem>
  );
};

export const renderTimepicker = (params) => {
  const { key, item, isViewMode = false, formItemLayout = {}, form } = params;
  return (
    <FormItem
      label={item.name || item.title || ''}
      key={key}
      {...formItemLayout}
      className={`labelOneRow ${item.className || ''}`}
    >
      {form.getFieldDecorator(item.field, {
        rules: item.rules || [],
        initialValue: item.defaultValue,
      })(
        <TimePicker
          className={item.field} // write for testing by className in TestRails
          dropdownClassName={`dropdown_${item.field}`} // write for testing by className in TestRails
          disabled={isViewMode}
          format="HH:mm"
        />,
      )}
    </FormItem>
  );
};

export const renderTextarea = (params) => {
  const { key, item, isViewMode = false, formItemLayout = {}, form } = params;
  return (
    <FormItem
      label={item.name || item.title || ''}
      key={key}
      {...formItemLayout}
      className={`labelOneRow ${item.className || ''}`}
    >
      {form.getFieldDecorator(item.field, {
        getValueFromEvent: (e) => e.target.value,
        rules: item.rules || [],
        initialValue: item.defaultValue,
      })(<TextArea id={item.field} disabled={isViewMode} />)}
    </FormItem>
  );
};

export const renderRadio = (params) => {
  const { key, item, classifiers, isViewMode = false, formItemLayout = {}, form } = params;

  function getClassifierRadio() {
    return classifiers[item.classifier].map((el, index) => {
      const getter = radioGetters[item.classifier];
      return getter ? (
        getter({
          option: el,
          index,
          disabledValues: item.disabledRadioValues,
          classifierName: [item.classifier],
        })
      ) : (
        <Radio
          value={el.guid}
          key={el.guid}
          disabled={(item.disabledRadioValues || []).includes(el.guid)}
        >
          {el.name}
        </Radio>
      );
    });
  }

  return (
    <FormItem
      label={item.name || item.title || ''}
      key={key}
      {...formItemLayout}
      className={`labelOneRow ${item.className || ''}`}
    >
      {form.getFieldDecorator(item.field, {
        rules: item.rules || [],
        initialValue: item.defaultValue,
      })(
        <RadioGroup
          className={item.field} // write for testing by className in TestRails
          disabled={isViewMode}
          onChange={item.onChange}
        >
          {getClassifierRadio()}
        </RadioGroup>,
      )}
    </FormItem>
  );
};

export const renderSwitch = (params) => {
  const { key, item, isViewMode = false, formItemLayout = {}, form } = params;
  return (
    <FormItem
      label={item.name || item.title || ''}
      key={key}
      {...formItemLayout}
      className={`labelOneRow ${item.className || ''}`}
    >
      {form.getFieldDecorator(item.field, {
        rules: item.rules || [],
        initialValue: item.defaultValue,
        valuePropName: 'checked',
      })(
        <Switch
          className={item.field} // write for testing by className in TestRails
          disabled={isViewMode}
          onChange={item.onChange}
          checkedChildren={item.checkedChildren}
          unCheckedChildren={item.unCheckedChildren}
        />,
      )}
    </FormItem>
  );
};

export const renderDocumentTypeCascader = (params) => {
  const { isModal, storeKey, form, item } = params;

  return (
    <FormItem>
      {form.getFieldDecorator(item.field, {
        rules: item.rules || [],
      })(<DocumentCascader isModal={isModal} storeKey={`${storeKey}`} />)}
    </FormItem>
  );
};

export const renderKvedLiveSearchSelect = (params) => {
  const { key, item, isViewMode = false, formItemLayout = {}, form } = params;

  return (
    <KvedTreeLiveSearch
      key={key}
      item={item}
      isViewMode={isViewMode}
      formItemLayout={formItemLayout}
      form={form}
    />
  );
};

const selectStructure = {
  [cn.COUNTERPARTY]: renderCounterpartyDropdown,
  [cn.DOCUMENTS]: renderDocumentsDropdown,
  [cn.OBJECTS]: renderObjectsDropdown,
  [cn.PHONELIST]: renderPhonesDropdown,
  [cn.EMAILLIST]: renderEmailesDropdown,
  [cn.WEBSITELIST]: renderSitesDropdown,
  [cn.REQUEST_FOR_LEGAL_PROCESSING]: renderRequestsForLegalProcessingDropDown,
  // Address parts drop
  [cn.ADDRESS_LOCALITY_AREA]: renderLocalityAreasDropDown,
  [cn.ADDRESS_STREET]: renderStreetsDropDown,
  [cn.ADDRESS_BUILDIND]: renderBuildingsDropDown,
  [cn.ADDRESS_BUILDIND_SUB_OBJECT]: renderInheritAddressObjectsDropDown,
  [cn.ADDRESS_PREMISE]: renderPremisesDropDown,
};

const getDropdownRenderer = (params) => {
  const {
    item: { classifier = '', type },
  } = params;
  const isMultiselect = type === itemTypes.MULTISELECT;
  const mode = isMultiselect ? 'multiple' : 'single';
  const genericSelectRenderer = isMultiselect ? renderMuliselect : renderSelect;

  const customSelect = selectStructure[classifier];

  if (customSelect) {
    return customSelect({ ...params, mode });
  }

  return genericSelectRenderer(params);
};

const fieldsStructure = {
  [itemTypes.INPUT]: renderInput,
  [itemTypes.SEARCH_BOX]: renderSearchBox,
  [itemTypes.MULTISELECT]: getDropdownRenderer,
  [itemTypes.SELECT]: getDropdownRenderer,
  [itemTypes.DATEPICKER]: renderDatepicker,
  [itemTypes.DATE_TIME_PICKER]: renderDateTimePicker,
  [itemTypes.TIMEPICKER]: renderTimepicker,
  [itemTypes.TEXTAREA]: renderTextarea,
  [itemTypes.RADIO]: renderRadio,
  [itemTypes.FILE]: renderFile,
  [itemTypes.SWITCH]: renderSwitch,
  [itemTypes.DOCUMENT_TYPE_CASCADER]: renderDocumentTypeCascader,
  [itemTypes.KVED_LIVE_SEARCH_SELECT]: renderKvedLiveSearchSelect,
};

export const renderFormField = ({ item, key, formItemParams }) =>
  fieldsStructure[item.type] && fieldsStructure[item.type]({ ...formItemParams, item, key });

export const mapFormItems = (params) => {
  const {
    formName,
    viewMode = 'edit',
    fields,
    classifiers = {},
    isViewMode,
    customFields,
    col = 4,
    form,
    formItemLayout = {
      wrapperCol: { span: 24 },
      labelCol: { span: 24 },
    },
    onChange,
    disabled,
  } = params;

  const fieldsArr = Object.values(fields).filter((el) => !el.customRendered);

  const formItemParams = {
    formName,
    classifiers,
    isViewMode,
    formItemLayout,
    onChange,
    form,
    disabled,
    viewMode,
  };

  const mapFilelds = (item, key) =>
    fieldsStructure[item.type] && fieldsStructure[item.type]({ ...formItemParams, item, key });

  if (col === 4) {
    return (
      <Row type="flex" justify="start">
        {fieldsArr.map(
          (item, key) =>
            item.field && (
              <Col key={key} span={item.colSpan || 6}>
                <div style={{ padding: '0 1.5rem' }}>
                  {fieldsStructure[item.type] &&
                    fieldsStructure[item.type]({
                      ...formItemParams,
                      item,
                      key,
                      formItemLayout: item.formItemLayout || formItemLayout,
                    })}
                </div>
              </Col>
            ),
        )}
        {customFields &&
          customFields.map((item) => (
            <Col key={item.key} span={item.colSpan || 8} className="df aic">
              <div
                style={{ padding: '0 1.5rem' }}
                className={`labelOneRow ${item.className || ''}`}
              >
                {item.render()}
              </div>
            </Col>
          ))}
      </Row>
    );
  }

  if (col === 1) {
    return (
      <Row>
        <Col key="0" span={24}>
          {fieldsArr.map(mapFilelds)}
        </Col>
      </Row>
    );
  }

  const fieldsInCol = Math.ceil(fieldsArr.length / col);
  const leftFields = fieldsArr.slice(0, fieldsInCol);
  const rightfield = fieldsArr.slice(fieldsInCol);

  return (
    <Row>
      <Col key="0" span={11} style={{ marginRight: '3vw' }}>
        {leftFields.map(mapFilelds)}
      </Col>
      <Col key="1" span={11}>
        {rightfield.map(mapFilelds)}
      </Col>
    </Row>
  );
};
