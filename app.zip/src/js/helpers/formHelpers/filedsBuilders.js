import * as formItemTypes from '../../constants/FormItemTypes';
import { isRequired } from '../../services/validator/rules';
import { ADDRESS_LOCALITY_AREA } from '../../constants/ClassifiersNames';

export const getFormField = ({
  field,
  type,
  classifier = undefined,
  placeholder = undefined,
  rules = [],
  colSpan = undefined,
  readOnly = undefined,
  ...otherFieldParams
}) => ({
  field,
  type,
  classifier,
  placeholder,
  rules,
  colSpan,
  readOnly,
  ...otherFieldParams,
});

export const getStrInputFormField = ({
  rules = [isRequired()],
  colSpan = 24,
  ...fieldSpecification
}) =>
  getFormField({
    type: formItemTypes.INPUT,
    rules,
    colSpan,
    ...fieldSpecification,
  });

export const getSelectFormField = ({ ...fieldSpecification }) =>
  getFormField({
    type: formItemTypes.SELECT,
    ...fieldSpecification,
  });

export const getDateFormField = ({ ...fieldSpecification }) =>
  getFormField({
    type: formItemTypes.DATEPICKER,
    ...fieldSpecification,
  });

export const getDocTypeCascaderFormField = ({ rules, colSpan = 24, ...fieldSpecification }) =>
  getFormField({
    type: formItemTypes.DOCUMENT_TYPE_CASCADER,
    rules,
    colSpan,
    ...fieldSpecification,
  });

// ADDRESS_LOCALITY_AREA
export const getAddressLocalityAreaFormField = (fieldSpecification) =>
  getFormField({
    type: formItemTypes.SELECT,
    classifier: ADDRESS_LOCALITY_AREA,
    ...fieldSpecification,
  });
