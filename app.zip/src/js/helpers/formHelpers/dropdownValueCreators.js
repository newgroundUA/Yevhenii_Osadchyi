import { getStr } from '../geters';

export function getCounterpartyLabel(object) {
  const type = object.counterpartyType || object.type || '';
  switch (type) {
    case 'Person':
      return {
        label:
          'ФО, ' + // eslint-disable-line
            (object.personShortOfficeName ||
              object.shortName ||
              `${getStr(object.lastName)} 
                ${getStr(object.fistName)} 
                ${getStr(object.middleName)}
               `) +
            (object.itn ? ', ' + object.itn : '') || object.label, // eslint-disable-line
      };
    case 'SelfEmployed':
      return {
        label:
          'ФОП, ' + // eslint-disable-line
            (object.personShortOfficeName ||
              object.shortName ||
              `${object.lastName} ${object.fistName} ${object.middleName}`) +
            (object.personITN || object.itn ? (object.personITN || object.itn) + ', ' : '') || // eslint-disable-line
          object.label,
      };
    case 'LegalEntity':
      return {
        label:
          'ЮО, ' + // eslint-disable-line
            ((object.kopfg && (object.kopfg.shortName || object.kopfg.name)) ||
              (object.kopfgDto && (object.kopfgDto.shortName || object.kopfgDto.name)) ||
              object.kopfgShortName ||
              '') +
            ' ' +
            object.fullName +
            ', ' +
            object.edrpou || object.label,
      };
    default:
      return {
        label:
          object.fullName ||
          object.legalFullName ||
          object.personShortOfficeName ||
          object.shortOfficeName ||
          object.lastName ||
          object.firstName ||
          object.middleName ||
          object.shortName ||
          (object.personDto && object.personDto.lastName) ||
          object.label,
      };
  }
}

export function getDocumentLabel(object) {
  return {
    label: `${object.docSerialNumber || ''}, ${object.docNumber || ''}, ${object.docDate ||
      ''}, ${(object.refDocumentType && object.refDocumentType.shortName) || ''}`,
  };
}

export function getObjectLabel(object) {
  return {
    label: object.fullName || object.leaseObjectFullName || object.guid,
  };
}

const mapTypesToLabelCreators = {
  counterparty: getCounterpartyLabel,
  document: getDocumentLabel,
  object: getObjectLabel,
};

export function createObjectValue(backendDropdownValue, type) {
  if (typeof backendDropdownValue === 'string') {
    return { key: backendDropdownValue };
  }

  if (typeof backendDropdownValue === 'object') {
    return {
      key: backendDropdownValue.guid,
      ...mapTypesToLabelCreators[type](backendDropdownValue),
      ...backendDropdownValue,
      address: (backendDropdownValue.address && backendDropdownValue.address.addressAsString) || '',
      clStateProperty:
        (backendDropdownValue.clStateProperty && backendDropdownValue.clStateProperty.name) || '',
      accountingItemId: backendDropdownValue.accountingItemId || '',
    };
  }

  return undefined;
}

export function createValue(backendDropdownValue, type) {
  if (!backendDropdownValue) {
    return undefined;
  }

  if (Array.isArray(backendDropdownValue)) {
    return backendDropdownValue.map((el) => createObjectValue(el, type));
  }

  return createObjectValue(backendDropdownValue, type);
}

export function createValueCreator(type) {
  return (backendDropdownValue) => createValue(backendDropdownValue, type);
}

export const createAccountingItemValue = createValueCreator('object');
