import moment from 'moment';
import { message, notification } from 'antd';
import * as formItemTypes from '../../constants/FormItemTypes';

import {
  PHONELIST,
  EMAILLIST,
  WEBSITELIST,
  PERSON_TYPE_ENUM,
  PROPERTY_PARENT_OBJECTS,
  REGISTRATION_STATE,
  BASE_LEASE_PERIODS,
  COUNTRIES_LIST,
  APPEAL_INIT_TYPE,
  ENUM_JUDICIAL_SHOT_RESULT,
  LEGAL_PROCESSING_STATUS_ENUM,
  COURT_INSTANCE_LEVEL_ENUM,
  COURT_SESSION_STATUS_ENUM,
  SHARES_FORM_TYPE,
  CORPORATE_RIGHTS_OPERATION_TYPE,
  OPERATION_METHOD_TYPE,
  STOCKS_TYPE,
  REQUEST_FOR_LEGAL_PROCESSING,
  DOCUMENTS,
  COUNTERPARTY,
  OBJECTS,
} from '../../constants/ClassifiersNames';
import EnumToLabelsMap from '../../constants/EnumToLabelsMap';
import { getFeDate } from '../geters';

const DATE_FORMAT_FE = 'DD.MM.YYYY';
const DATE_TIME_FORMAT_FE = 'DD.MM.YYYY HH:mm:ss';

export const getPropsObject = (props, fieldNames) => {
  const madePropsObj = (rez, curName) => ({
    ...rez,
    [curName]: {
      ...props[curName],
      value: props[curName].value,
    },
  });

  return fieldNames.reduce(madePropsObj, {});
};

export const setArray = (field) => ({
  value: {
    $set: field ? field.map((item) => (item.guid ? item.guid : item)) : [],
  },
});

export const setString = (field) => ({
  value: {
    $set: field,
  },
});

const DATE_FORMAT_BE = 'YYYY-MM-DD HH:mm:ss.SSS Z';

export const getDate = (data) => (data ? moment(data, DATE_FORMAT_BE) : null);

export const setDate = (field) => ({
  value: {
    $set: field ? moment(field, DATE_FORMAT_BE) : null,
  },
});

export const selectFilter = (input, option) =>
  option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0;

export const mapStringsToFormObject = (stringArr = [], defaultValues = {}) =>
  stringArr.reduce(
    (curObj, field) => ({
      ...curObj,
      [field]: {
        value: defaultValues[field],
      },
    }),
    {},
  );

export const classifierTextGetters = {
  [PHONELIST]: (el) => el.phoneNumber,
  [EMAILLIST]: (el) => el.emailName,
  [WEBSITELIST]: (el) => el && el.wwwPage,
  [PROPERTY_PARENT_OBJECTS]: (el) => el.fullName,
  [REGISTRATION_STATE]: (el) => el,
  [DOCUMENTS]: (el) => `${el.docSerialNumber} ${el.docNumber} ${getFeDate(el.docDate)}`,
  [REQUEST_FOR_LEGAL_PROCESSING]: (el) => el.name || el.guid,
  // [COUNTERPARTY]: (el) => el.legalFullName || el.personShortOfficeName,
  [BASE_LEASE_PERIODS]: (el) => el,
  [SHARES_FORM_TYPE]: (el) => el,
  [CORPORATE_RIGHTS_OPERATION_TYPE]: (el) => el,
  [OPERATION_METHOD_TYPE]: (el) => el,
  [STOCKS_TYPE]: (el) => el,
  [LEGAL_PROCESSING_STATUS_ENUM]: (el) => el,
  [COURT_INSTANCE_LEVEL_ENUM]: (el) => el,
  [COURT_SESSION_STATUS_ENUM]: (el) => el,
  [OBJECTS]: (el) => el.fullName || el.fullname,
  [APPEAL_INIT_TYPE]: (el) => el,
  [PERSON_TYPE_ENUM]: (el) => el,
  [COUNTRIES_LIST]: (el) => el.countryName,
  [ENUM_JUDICIAL_SHOT_RESULT]: (el) => el,
};

export const mapRowsToTable = (rows, fields, classifiers, keyName = '') =>
  rows.map((row, id) =>
    Object.entries(row).reduce(
      (curObj, el) => {
        let [key, value] = el; // eslint-disable-line
        if (key === 'tableRows') return curObj;
        if (key === 'guid' || key === 'versionId' || key === 'type') {
          return {
            ...curObj,
            [key]: el[1],
          };
        }

        const elType = fields[key].type;

        if (fields[key].customRendered) {
          return {
            ...curObj,
            [key]: value,
          };
        }

        if (value === undefined || value === null) {
          return {
            ...curObj,
            [key]: '',
          };
        }

        if (elType === formItemTypes.SWITCH) {
          value = value ? fields[key].checkedChildren : fields[key].unCheckedChildren;
        }
        const elClassifier = fields[key].classifier;
        if (elType === formItemTypes.SELECT) {
          if (
            elClassifier !== DOCUMENTS &&
            elClassifier !== COUNTERPARTY &&
            elClassifier !== OBJECTS
          ) {
            const elTextGetter = classifierTextGetters[elClassifier];
            const selectedItem = classifiers[elClassifier].find(
              (option) => (option.guid || option) === value,
            );
            if (elTextGetter && typeof elTextGetter === 'function') {
              value = elTextGetter(selectedItem);
            } else {
              value = selectedItem ? selectedItem.name || selectedItem : undefined;
            }
          }
        }

        if (elType === formItemTypes.MULTISELECT) {
          value = value || [];
          if (
            elClassifier !== DOCUMENTS &&
            elClassifier !== COUNTERPARTY &&
            elClassifier !== OBJECTS
          ) {
            value = classifiers[elClassifier]
              .filter((option) => value.includes(option.guid))
              .map((obj) => obj.name)
              .join(', ');
          }
        }
        if (elType === formItemTypes.DATEPICKER) {
          value = value && moment(value).format(DATE_FORMAT_FE);
        }
        if (elType === formItemTypes.DATE_TIME_PICKER) {
          value = value && moment(value).format(DATE_TIME_FORMAT_FE);
        }
        return {
          ...curObj,
          [key]: EnumToLabelsMap[elClassifier] || EnumToLabelsMap[value] || value,
        };
      },
      {
        key: keyName + id,
      },
    ),
  );

export const makeGuidVersionStr = (obj) => `${obj.guid}`;

export const getGuidsArray = (arr) => (arr ? arr.map((item) => makeGuidVersionStr(item)) : []);

export const failedValidationNotification = (err, fields) => {
  const errorMassage = Object.keys(err).reduce((total, el) => {
    const configElem = fields[el];

    const isRequiredError = err[el].errors.some((error) =>
      configElem.rules.some((rule) => rule.required && rule.message === error.message),
    );

    if (isRequiredError) {
      return `${total}${configElem.name}\n`;
    }

    return total;
  }, '');

  if (errorMassage) {
    notification.warn({
      message: "Незаповнені обов'язкові поля:",
      description: errorMassage,
    });
  } else {
    message.error('Некоректно заповнені поля.');
  }
};

export const getFormEntityData = (values, formItemsClassifiers, formFieldsTamplate) => {
  const res = {};
  const fieldsWithValueNames = Object.keys(values);

  const getValueObj = ({ fieldClassifierObj, guid, fieldName, fieldValue, valuableFields }) => {
    const findFromGetResponse = Array.isArray(fieldValue)
      ? fieldValue.find((el) => el.guid || el.key === guid)
      : fieldValue;

    res[fieldName] = valuableFields.reduce((total, valuableFieldName) => {
      const prev = total;
      const takeFromClassifier =
        fieldClassifierObj &&
        (fieldClassifierObj[valuableFieldName] || fieldClassifierObj[valuableFieldName] === 0);

      prev[valuableFieldName] = takeFromClassifier
        ? fieldClassifierObj[valuableFieldName]
        : findFromGetResponse[valuableFieldName];

      return prev;
    }, {});
    return res[fieldName];
  };

  const getValueFromClassifier = ({ val, fieldName, fieldValue }) => {
    const fieldTamplate = formFieldsTamplate[fieldName];
    const valuableFields = fieldTamplate && fieldTamplate.valuableFields;

    const guid = typeof val === 'object' ? val.key || val.guid : val;

    const fieldClassifierObj = formItemsClassifiers[fieldTamplate.classifier].find(
      (item) => item.guid === guid,
    );
    return getValueObj({
      fieldClassifierObj,
      guid,
      fieldName,
      fieldValue,
      valuableFields,
    });
  };

  fieldsWithValueNames.forEach((fieldName) => {
    const fieldValue = values[fieldName];
    const fieldTamplate = formFieldsTamplate[fieldName];
    const valuableFields = fieldTamplate && fieldTamplate.valuableFields;

    if (fieldValue && valuableFields && fieldTamplate.classifier) {
      if (Array.isArray(fieldValue)) {
        res[fieldName] = fieldValue.map((val) =>
          getValueFromClassifier({ val, fieldName, fieldValue }),
        );
      } else {
        res[fieldName] = getValueFromClassifier({ val: fieldValue, fieldName, fieldValue });
      }
    } else {
      res[fieldName] = fieldValue;
    }
  });
  return res;
};
