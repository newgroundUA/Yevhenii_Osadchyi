import { FRONT_TO_BACKEND_FIELD } from '../constants/VocabularyForBE';

const generateParam = (field, param) => {
  switch (param) {
    case 'counterpartyTypes':
      return {
        [param]: Object.keys(field).filter((fieldName) => field[fieldName].isChecked),
      };
    case 'sortList':
      return {
        [param]: Object.keys(field).map(
          (fieldName) =>
            `${field[fieldName].value}${FRONT_TO_BACKEND_FIELD[fieldName] || fieldName}`,
        ),
      };
    case 'filter':
      return [];
    default:
      break;
  }
};

const getModifierValue = (value, modifier) => {
  const newValue = value;
  return modifier === 'lower' ? newValue.toLowerCase() : value;
};

export const createParams = (reqBody) => {
  const result = Object.keys(reqBody).reduce((prev, curr) => {
    const bodyField = reqBody[curr];

    if (typeof bodyField === 'object') {
      if (Array.isArray(bodyField)) {
        return {
          ...prev,
          [curr]: bodyField,
        };
      }
      return {
        ...prev,
        ...generateParam(bodyField, curr),
      };
    }
    return {
      ...prev,
      [curr]: bodyField,
    };
  }, {});

  return result;
};

export const createStringReqParams = (filters = {}, params = {}) => {
  const result = Object.keys(filters).map((key, i) => {
    const { mainParam = '', isFirstParam = true, isMultiple = false } = params;

    const filtersKey = filters[key];

    if (key === 'multiple' || !filtersKey) {
      return '';
    }

    const char = isFirstParam && i === 0 ? '?' : '&';
    let paramKey = mainParam ? `${mainParam}[${key}]` : key;
    if (isMultiple) {
      paramKey = mainParam ? `filters[${mainParam}][]` : mainParam;
    }
    let comparison = '=';
    let paramValue = `${filtersKey}`;
    let modifier = '';

    if (typeof filtersKey === 'object') {
      const { value: filterValue, multiple } = filtersKey;

      if (multiple) {
        return createStringReqParams(filtersKey, {
          mainParam: key,
          isFirstParam: false,
          isMultiple: true,
        });
      }
      if (filterValue === '') {
        return '';
      }
      if (filterValue) {
        const { comparison: filterComparison, modifier: filterModifier } = filtersKey;
        comparison = filterComparison ? `=${filterComparison}|` : '=';
        paramValue = encodeURIComponent(getModifierValue(filterValue, filterModifier));
        modifier = filterModifier ? `|${filterModifier}` : '';
      } else {
        return createStringReqParams(filtersKey, { mainParam: key, isFirstParam: false });
      }
    }
    const { multiple } = filtersKey;
    return `${char}${paramKey}${multiple ? '[]' : ''}${comparison}${paramValue}${modifier}`;
  });

  return result.join('');
};
