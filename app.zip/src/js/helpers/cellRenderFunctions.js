import React from 'react';
import { Link } from 'react-router-dom';
import { Dropdown, Icon } from 'antd';

/**
 * Render <a /> with link to component with guid
 * @param el - object, where el.link is route to component,
 * el.guid is id of entity, el.text is visual representation of link
 */
export const link = (el) => (el ? <Link to={`${el.link}`}>{el.text}</Link> : '');

export const dropDownWithLink = (items) => {
  if (!items) return;
  if (Array.isArray(items)) {
    if (items.length === 1) {
      // just a link
      return link(items[0]);
    }

    if (items.length > 1) {
      // dropDown with link
      const [firstItem] = items.slice();
      const outherItems = items.slice().splice(1, items.length - 1);

      const menu = (
        <div className="dropDownMenu">
          {outherItems.map((el) => <div className="borderLine">{link(el)}</div>)}
        </div>
      );

      return (
        <Dropdown overlay={menu}>
          <span className="dropDownSpan">
            {link(firstItem)}
            <Icon type="caret-down" />
          </span>
        </Dropdown>
      );
    }
  }
};

export const dropDown = (items) => {
  if (!items) return;
  if (Array.isArray(items)) {
    if (items.length === 1) {
      // just a text
      return items[0].text;
    }

    if (items.length > 1) {
      // dropDown
      const [firstItem] = items.slice();
      const outherItems = items.slice().splice(1, items.length - 1);

      const menu = (
        <div className="dropDownMenu">
          {outherItems.map((el) => <div className="borderLine">{el.text}</div>)}
        </div>
      );

      return (
        <Dropdown overlay={menu}>
          <span className="dropDownSpan">
            {firstItem.text}
            <Icon type="caret-down" />
          </span>
        </Dropdown>
      );
    }
  }
};
