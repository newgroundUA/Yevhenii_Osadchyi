import * as icon from '../constants/Icons';
import * as toolNames from '../constants/TableToolNames';
import * as iconNames from '../constants/IconNames';

const getIcon = (name, className) => {
  switch (name) {
    // Tools
    case toolNames.JOIN_GROUP:
      return icon.AddUserGroup(className);
    case toolNames.ASSIGN_ROLE:
      return icon.AssignRole(className);
    case toolNames.ARCHIVE_USER:
      return icon.ArchiveMedium(className);
    case toolNames.XLS:
      return icon.ExportToXLS(className);
    case toolNames.PDF:
      return icon.ExportToPDF(className);
    case toolNames.CSV:
      return icon.ExportToCSV(className);
    case toolNames.ALL_FORMATS:
      return icon.ExportToFile(className);
    case toolNames.TABLE_COLUMNS:
      return icon.TableRows(className);
    case toolNames.TOOLBAR_MANAGEMENT:
      return icon.ConfigMedium(className);
    case toolNames.FILTERS:
      return icon.Filter(className);
    case toolNames.SPEC_FILTERS:
      return icon.SpecFilter(className);
    case toolNames.ADDRESS_FILTERS:
      return icon.Address(className);
    case toolNames.SET_OWNER:
      return icon.UserCheck(className);
    case toolNames.SET_BALANCE_KEEPER:
      return icon.UserCheck(className);

    // table
    case iconNames.EYE:
      return icon.Eye(className);
    case iconNames.PENCIL:
      return icon.Pencil(className);
    case iconNames.ARROW:
      return icon.Arrow(className);
    case iconNames.SORT_ASC:
      return icon.SortAsc(className);
    case iconNames.SORT_DESC:
      return icon.SortDesc(className);
    case iconNames.ARCHIVE:
      return icon.Archive(className);
    case iconNames.CHECKBOX:
      return icon.Checkbox(className);
    case iconNames.CHECKBOX_CHECKED:
      return icon.CheckboxChecked(className);

    //
    case iconNames.CHECK:
      return icon.Check(className);
    case iconNames.CROSS:
      return icon.Cross(className);

    default:
      return false;
  }
};

export default getIcon;
