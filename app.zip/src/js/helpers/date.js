import moment from 'moment';

const DATE_FORMAT_FE = 'DD.MM.YYYY';
const DATE_FORMAT_BE = 'YYYY-MM-DD HH:mm:ss.SSS Z';

export const dateToFe = (date) => (date ? moment(date, DATE_FORMAT_BE).format(DATE_FORMAT_FE) : '');
