export default (initialState, ...reducers) => (state, action) =>
  state
    ? reducers.reduce(
        (prevState, reducer) => (prevState === state ? reducer(state, action) : prevState),
        state,
      )
    : initialState;
