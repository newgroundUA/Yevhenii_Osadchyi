import React from 'react';
import { Popconfirm, Icon } from 'antd';
import { COUNTERPARTY, DOCUMENTS, OBJECTS } from '../constants/ClassifiersNames';
import { MULTISELECT } from '../constants/FormItemTypes';
import CounterpartiesLabelsList from '../components/counterparties/CounterpartiesLabelsList';
import DocumentsLabelsList from '../components/documents/DocumentsLabelsList';
import AccountingItemsLabelsList from '../components/accountingItems/AccountingItemsLabelsList';
import CounterpartyLabel from '../components/counterparties/CounterpartyLabel';
import DocumentLabel from '../components/documents/DocumentLabel';
import AccountingItemLabel from '../components/accountingItems/AccountingItemLabel';
import { BUTTONS, CHECKBOX } from '../constants/CellTypes';

const createActions = ({ editParams, deleteParams }) => ({
  title: 'Дiя',
  width: 50,
  key: 'operation',
  render: (text, record, rowIndex) => (
    <span key={rowIndex}>
      {editParams && (
        <Icon
          onClick={() => {
            editParams.handler(rowIndex);
          }}
          type="edit"
        />
      )}
      {deleteParams &&
        !deleteParams.disabled && (
          <Popconfirm
            title="Ви впевнені?"
            onConfirm={() => {
              deleteParams.handler(rowIndex);
            }}
          >
            <Icon style={{ paddingLeft: '0.5rem' }} type="delete" />
          </Popconfirm>
        )}
    </span>
  ),
});

export const getTableColumns = ({ formFields, actionsData }) => {
  const columnsTemplate = Object.values(formFields).map((el) => {
    const columnTemplate = {
      title: el.name,
      dataIndex: el.field,
      key: el.field,
    };
    const entitiesToComponentsMap = {
      [COUNTERPARTY]: {
        getEntityComponent: (value) => <CounterpartyLabel counterpartyData={value} />,
        getEntitiesListComponent: (value) => <CounterpartiesLabelsList counterparties={value} />,
      },
      [DOCUMENTS]: {
        getEntityComponent: (value) => <DocumentLabel documentData={value} />,
        getEntitiesListComponent: (value) => <DocumentsLabelsList documents={value} />,
      },
      [OBJECTS]: {
        getEntityComponent: (value) => <AccountingItemLabel accountingItemData={value} />,
        getEntitiesListComponent: (value) => <AccountingItemsLabelsList accountingItems={value} />,
      },
    };
    const entity = entitiesToComponentsMap[el.classifier];
    if (entity) {
      columnTemplate.render = (text, record) => {
        const colValue = record[el.field];
        if (el.type === MULTISELECT) {
          return entity.getEntitiesListComponent(colValue);
        }

        return entity.getEntityComponent(colValue);
      };
    }

    return columnTemplate;
  });

  return actionsData ? [createActions(actionsData), ...columnsTemplate] : columnsTemplate;
};

export const getExportToXlsColumns = (columns) =>
  Object.values(columns)
    .filter((col) => col.type !== BUTTONS && col.type !== CHECKBOX && !!col.isVisible)
    .reduce(
      (prev, curr) => ({
        ...prev,
        [curr.colName]: curr.title,
      }),
      {},
    );
