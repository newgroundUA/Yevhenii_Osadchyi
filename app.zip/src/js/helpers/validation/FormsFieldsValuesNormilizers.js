const latinOrCyrillic = (value) => {
  const regexpr = new RegExp("(^[A-Za-z-]+$)|(^[А-Яа-яёЁЇїІіЄєҐґ`'ʼ-]+$)");
  if (value && !regexpr.test(value)) {
    const prevValue = value.length > 1 ? value.substring(0, value.length - 1) : '';
    return prevValue;
  }
  return value;
};

export default {
  personForm: {
    lastName: latinOrCyrillic,
    firstName: latinOrCyrillic,
    middleName: latinOrCyrillic,
  },
};
