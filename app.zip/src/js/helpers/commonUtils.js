import moment from 'moment';

const DATE_FORMAT_BE = 'YYYY-MM-DD HH:mm:ss.SSS Z';

export const getObjGuid = (value) => (value ? value.guid : null);
export const getObjGuidAndVersionId = (value) => {
  if (Array.isArray(value)) {
    return value.map((el) => ({
      guid: el.guid,
      versionId: el.versionId,
    }));
  }
  if (!value) {
    return value;
  }
  if (typeof value === 'object') {
    if (!value.guid) {
      return undefined;
    }

    return {
      guid: value.guid,
      versionId: value.versionId,
    };
  }
};

export const parseFileSizeToFE = (size) => {
  if (!size) {
    return;
  }

  let number = size;
  let type = ' B';

  if (number > 1024) {
    number /= 1024;
    type = ' KB';
  }
  if (number > 1024) {
    number /= 1024;
    type = ' MB';
  }

  return parseFloat(number.toFixed(1)) + type;
};

export const getFEDate = (data) => (data ? moment(data, DATE_FORMAT_BE) : null);

export const defaultFilterOption = (input, option) =>
  option.props.children
    .toString()
    .toLowerCase()
    .indexOf(input.toLowerCase()) >= 0;
