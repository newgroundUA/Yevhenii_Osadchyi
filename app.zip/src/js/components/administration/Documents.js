import React from 'react';

const Documents = () => <div>In Documents</div>;

export default Documents;
