import React from 'react';
import PropTypes from 'prop-types';

const Users = ({ parent }) => (
  <div className="content__table-items">
    <div className="content__top-info">{parent}</div>

    <div className="content__table-menu" />

    <div className="content__table" />
  </div>
);

Users.propTypes = {
  parent: PropTypes.string.isRequired,
};

export default Users;
