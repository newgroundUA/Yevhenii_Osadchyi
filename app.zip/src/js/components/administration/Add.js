import React from 'react';

const Add = () => <div>In Add</div>;

export default Add;
