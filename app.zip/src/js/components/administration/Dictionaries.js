import React from 'react';

const Dictionaries = () => <div>In Dictionaries</div>;

export default Dictionaries;
