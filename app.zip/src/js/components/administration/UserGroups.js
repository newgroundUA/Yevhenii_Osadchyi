import React from 'react';

const UserGroups = () => <div>In UserGroups</div>;

export default UserGroups;
