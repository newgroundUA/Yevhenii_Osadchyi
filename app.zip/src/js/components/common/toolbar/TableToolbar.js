import React from 'react';
import PropTypes from 'prop-types';

import { Modal, Row, Badge } from 'antd';

import * as toolNames from '../../../constants/TableToolNames';
import getIcon from '../../../helpers/getIcon';
import ColumnsPanel from './ColumnsPanel';
import ToolbarItemsSection from './ToolbarItemsSection';
import RegisterFiltersContainer from './RegisterFiltersContainer';
import ExtendedAddressSearch from '../../../containers/common/address/ExtendedAddressSearch';
import { EQUALS } from '../../../models/registers/filters/criterias';

class TableToolbar extends React.Component {
  constructor(props) {
    super(props);

    this.initialRow = {
      key: undefined,
      action: undefined,
      value: undefined,
    };

    this.defState = {
      columnsIsActive: false,
      showFiltersModal: false,
      showAddressFilterModal: false,
      toolsIsActive: false,
    };

    this.state = {
      ...this.defState,
    };
  }

  handleToggleModal = (el) => {
    switch (el.title) {
      case toolNames.TABLE_COLUMNS:
        this.setState({ columnsIsActive: true });
        break;
      case toolNames.TOOLBAR_MANAGEMENT:
        this.setState({ toolsIsActive: true });
        break;
      case toolNames.FILTERS:
        this.setState({ showFiltersModal: true });
        break;
      case toolNames.ADDRESS_FILTERS:
        this.setState({ showAddressFilterModal: true });
        break;
      default:
        this.props.handleClickToolbarItem(el);
        break;
    }
  };

  handleClose = () => {
    this.setState({
      columnsIsActive: false,
      showFiltersModal: false,
      showAddressFilterModal: false,
      toolsIsActive: false,
    });
  };

  closeFilterModal = () => {
    this.setState({
      showFiltersModal: false,
    });
  };

  closeAddressFilterModal = () => {
    this.setState({
      showAddressFilterModal: false,
    });
  };

  handleSubmitFilters = (selectedFilters) => {
    const {
      setValueRequestBody,
      requestBody: { filter },
    } = this.props;

    this.setState({
      showFiltersModal: false,
    });

    if (selectedFilters.length > 0) setValueRequestBody('filter', [...filter, ...selectedFilters]);
  };

  handleSubmitAddressFilter = (addressData) => {
    const {
      setValueRequestBody,
      requestBody,
      requestBody: { filter },
    } = this.props;
    const lastSelectedAddressPartGuid = addressData.addressGuid;
    const lastSelectedAddressPartName = addressData.addressUnitEntityName;
    if (lastSelectedAddressPartGuid && lastSelectedAddressPartName && requestBody) {
      setValueRequestBody('filter', [
        ...filter,
        {
          action: EQUALS.value,
          key: lastSelectedAddressPartName,
          value: lastSelectedAddressPartGuid,
        },
      ]);
    }
    this.closeAddressFilterModal();
  };

  render() {
    const {
      items,
      isActive,
      handleToggleToolbarItem,
      columns,
      handleChangeColumns,
      registryFiltersTemplate,
    } = this.props;

    const { showFiltersModal, showAddressFilterModal } = this.state;

    const sections = Object.values(items);

    return (
      <div className="table-menu">
        {registryFiltersTemplate && (
          <Modal
            title="Фільтрація за атрибутами"
            visible={showFiltersModal}
            width="780px"
            onCancel={this.closeFilterModal}
            footer={false}
            maskClosable={false}
          >
            {showFiltersModal && (
              <RegisterFiltersContainer
                registryFiltersTemplate={registryFiltersTemplate}
                handleSubmit={this.handleSubmitFilters}
                handleClose={this.closeFilterModal}
              />
            )}
          </Modal>
        )}
        {showAddressFilterModal && (
          <Modal
            title="Фільтрація за адресою"
            visible={showAddressFilterModal}
            width="780px"
            onCancel={this.closeAddressFilterModal}
            footer={false}
            maskClosable={false}
          >
            {showAddressFilterModal && (
              <ExtendedAddressSearch
                noAddressType
                allowEditFrom="localityArea"
                allowSubmitFrom="localityArea"
                onCancelClick={this.closeAddressFilterModal}
                handleSubmit={this.handleSubmitAddressFilter}
              />
            )}
          </Modal>
        )}
        <div className="table-menu__buttons-container">{this.props.children}</div>

        <div className="table-menu__icons-container">
          {sections.map((section, id) => {
            const key = Object.keys(items)[id];

            // if there is no visible items in section -> don't display all section
            const curObjects = Object.values(section).filter((el) => el.isVisible === true);
            if (curObjects.length <= 0) return false;

            // we have found some visible items in section
            // lets check if we have some users selected to display active action
            const sectionClass =
              !isActive && id === 0
                ? 'table-menu__icons-section--active'
                : 'table-menu__icons-section';

            return (
              <div className={sectionClass} key={key}>
                {Object.keys(section).map(
                  (item) =>
                    section[item].isVisible && (
                      <Badge key={item}>
                        <button
                          type="button"
                          className="table-menu__item"
                          onClick={() => {
                            this.handleToggleModal(section[item]);
                          }}
                        >
                          <div className="table-menu__icon">
                            {getIcon(section[item].title, 'icon__fill-blue')}
                          </div>
                          <div className="table-menu__text">{section[item].title}</div>
                        </button>
                      </Badge>
                    ),
                )}
              </div>
            );
          })}
        </div>

        {this.state.columnsIsActive && (
          <Modal
            title="Налаштування колонок"
            onCancel={() => {
              this.handleClose();
            }}
            visible={this.state.columnsIsActive}
            footer={false}
            width={900}
          >
            <Row>
              <ColumnsPanel columns={columns.fluid} handleChangeColumns={handleChangeColumns} />
            </Row>
          </Modal>
        )}
        {this.state.toolsIsActive && (
          <Modal
            title="Панель Інструментів"
            onCancel={() => {
              this.handleClose();
            }}
            visible={this.state.toolsIsActive}
            footer={false}
            width={480}
          >
            <div>
              <ToolbarItemsSection
                title="Масовi дії"
                elements={items.tasks}
                handleClick={handleToggleToolbarItem}
              />

              <ToolbarItemsSection
                title="Експорт"
                elements={items.export}
                handleClick={handleToggleToolbarItem}
              />

              <ToolbarItemsSection
                title="Фільтри"
                elements={items.filters}
                handleClick={handleToggleToolbarItem}
              />

              <ToolbarItemsSection
                title="Інше"
                elements={items.config}
                handleClick={handleToggleToolbarItem}
              />
            </div>
          </Modal>
        )}
      </div>
    );
  }
}

TableToolbar.defaultProps = {
  children: null,
  registryFiltersTemplate: null,
  requestBody: {},
};

TableToolbar.propTypes = {
  requestBody: PropTypes.objectOf(PropTypes.any),
  children: PropTypes.element,
  items: PropTypes.shape({
    tasks: PropTypes.object,
    export: PropTypes.object,
    config: PropTypes.object,
  }).isRequired,
  isActive: PropTypes.bool.isRequired,
  handleToggleToolbarItem: PropTypes.func.isRequired,
  handleClickToolbarItem: PropTypes.func.isRequired,
  setValueRequestBody: PropTypes.func.isRequired,
  registryFiltersTemplate: PropTypes.objectOf(PropTypes.any),

  columns: PropTypes.objectOf(PropTypes.object).isRequired,
  handleChangeColumns: PropTypes.func.isRequired,
};

export default TableToolbar;
