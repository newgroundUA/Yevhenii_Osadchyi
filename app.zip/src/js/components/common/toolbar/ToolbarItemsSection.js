import React from 'react';
import PropTypes from 'prop-types';

import getIcon from '../../../helpers/getIcon';
import * as toolNames from '../../../constants/TableToolNames';

const ColumnsSection = ({ title, elements, handleClick }) => {
  const items = Object.keys(elements);
  return (
    <div className="toolbar-items-section">
      <div className="toolbar-items-section__title">{title}</div>
      {items.map((key) => {
        const el = elements[key];

        // we don't want user to remove table management forever
        if (el.title === toolNames.TOOLBAR_MANAGEMENT) return false;

        const buttonClass = el.isVisible ? 'dkv-button' : 'dkv-button dkv-button--fill-blue';
        const buttonText = el.isVisible ? '-' : '+';

        return (
          <div className="toolbar-items-section__item" key={key}>
            <div className="toolbar-items-section__item-icon">
              {getIcon(el.title, 'icon__fill-blue')}
            </div>
            <div className="toolbar-items-section__item-text">{el.title}</div>
            <div className="toolbar-items-section__item-button">
              <button
                type="button"
                className={buttonClass}
                onClick={() => {
                  handleClick(key);
                }}
              >
                {buttonText}
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
};

ColumnsSection.defaultProps = {};

ColumnsSection.propTypes = {
  title: PropTypes.string.isRequired,
  elements: PropTypes.objectOf(
    PropTypes.shape({
      title: PropTypes.string.isRequired,
      isVisible: PropTypes.bool.isRequired,
    }),
  ).isRequired,
  handleClick: PropTypes.func.isRequired,
};

export default ColumnsSection;
