import React from 'react';
import PropTypes from 'prop-types';

import { Input, Icon } from 'antd';

class ColumnsPanel extends React.Component {
  state = {
    notPresent: '',
    present: '',
    visible: [],
    invisible: [],
    leftSelectValue: [],
    rightSelectValue: [],
    canDrag: false,
  };

  componentWillMount() {
    this.updateColumns(this.props.columns);
  }

  componentWillReceiveProps(nextProps) {
    this.updateColumns(nextProps.columns);
  }

  updateColumns = (
    columns = this.props.columns,
    presVal = this.state.present,
    norPresVal = this.state.notPresent,
  ) => {
    const visible = Object.values(columns)
      .filter((el) => el.isVisible)
      .map((el) => el.title)
      .filter((el) => el.toLowerCase().includes(presVal.toLowerCase()));
    const invisible = Object.values(columns)
      .filter((el) => !el.isVisible)
      .map((el) => el.title)
      .sort()
      .filter((el) => el.toLowerCase().includes(norPresVal.toLowerCase()));
    this.setState({ visible, invisible });
  };

  handleInputChange = (e) => {
    const target = e.target;

    this.setState({
      [target.name]: target.value,
    });

    if (target.name === 'present' && target.value !== '') {
      this.setState({ canDrag: false });
    }

    if (
      target.name === 'present' &&
      target.value === '' &&
      this.state.rightSelectValue.length === 1
    ) {
      this.setState({ canDrag: true });
    }

    if (target.name === 'notPresent') this.updateColumns(undefined, undefined, target.value);
    if (target.name === 'present') this.updateColumns(undefined, target.value, undefined);
  };

  handleChangeSelect = (e) => {
    const select = e.target;

    const options = select ? select.options : [];
    const result = [...options].filter((el) => el.selected).map((el) => el.value || el.text);

    if (select.name === 'rightSelectValue' && result.length === 1 && this.state.present === '') {
      this.setState({ canDrag: true });
    } else if (
      select.name === 'leftSelectValue' &&
      this.state.rightSelectValue.length === 1 &&
      this.state.present === ''
    ) {
      this.setState({ canDrag: true });
    } else if (this.state.canDrag) {
      this.setState({ canDrag: false });
    }

    this.setState({ [select.name]: result });
  };

  makeVisible = () => {
    const columnsArr = Object.values(this.props.columns);
    const visibleCount = this.state.visible.length;

    const newColumnsObj = this.state.leftSelectValue.reduce((curObj, title, id) => {
      const visObj = {
        ...columnsArr.find((el) => el.title === title),
        position: visibleCount + id,
        isVisible: true,
      };
      return {
        ...curObj,
        [visObj.colName]: visObj,
      };
    }, {});

    this.props.handleChangeColumns(newColumnsObj);
    this.setState({ leftSelectValue: [] });
  };

  makeInvisible = () => {
    const columnsArr = Object.values(this.props.columns);
    const selected = this.state.rightSelectValue;

    let counter = 0;
    const newColumnsObj = columnsArr
      .filter((el) => el.isVisible)
      .map((el) => {
        const isSelected = selected.includes(el.title);
        return !isSelected
          ? { ...el, position: counter++ }
          : { ...el, position: -1, isVisible: false };
      })
      .reduce((curObj, el) => ({ ...curObj, [el.colName]: el }), {});

    this.props.handleChangeColumns(newColumnsObj);
    this.setState({ rightSelectValue: [], canDrag: false });
  };

  turnPositionUp = () => {
    if (!this.state.canDrag) return;

    const [selected] = this.state.rightSelectValue;
    const columnsArr = Object.values(this.props.columns);
    const selectedId = columnsArr.findIndex((el) => el.title === selected);
    const curElement = columnsArr[selectedId];

    if (curElement.position === 0) return;

    const prevElement = columnsArr[selectedId - 1];
    this.props.handleChangeColumns({
      [curElement.colName]: { ...curElement, position: curElement.position - 1 },
      [prevElement.colName]: { ...prevElement, position: prevElement.position + 1 },
    });
  };

  turnPositionDown = () => {
    if (!this.state.canDrag) return;

    const [selected] = this.state.rightSelectValue;
    const columnsArr = Object.values(this.props.columns);
    const selectedId = columnsArr.findIndex((el) => el.title === selected);
    const curElement = columnsArr[selectedId];

    if (curElement.position >= this.state.visible.length) return;

    const nextElement = columnsArr[selectedId + 1];
    this.props.handleChangeColumns({
      [curElement.colName]: { ...curElement, position: curElement.position + 1 },
      [nextElement.colName]: { ...nextElement, position: nextElement.position - 1 },
    });
  };

  render() {
    const dragButtonClass = this.state.canDrag ? 'dkv-button' : 'dkv-button dkv-button--disabled';

    return (
      <div className="columns-panel">
        <div className="columns-panel__description">
          <div className="columns-panel__description-item">
            <div className="columns-panel__description-text">Відсутні</div>
            <div className="columns-panel__description-input">
              <Input
                name="notPresent"
                placeholder="Швидкий пошук колонки"
                value={this.state.notPresent}
                onChange={this.handleInputChange}
              />
            </div>
          </div>
          <div className="columns-panel__description-item">
            <div className="columns-panel__description-text">Присутні</div>
            <div className="columns-panel__description-input">
              <Input
                name="present"
                placeholder="Швидкий пошук колонки"
                value={this.state.present}
                onChange={this.handleInputChange}
              />
            </div>
          </div>
        </div>

        <div className="columns-panel__selects-container">
          <div className="columns-panel__select-item">
            <div className="columns-panel__select-container">
              <select
                multiple
                name="leftSelectValue"
                value={this.state.leftSelectValue}
                onChange={this.handleChangeSelect}
                className="columns-panel__select"
                size={20}
              >
                {this.state.invisible.map((el) => (
                  <option value={el} key={el}>
                    {el}
                  </option>
                ))}
              </select>
            </div>
            <div className="columns-panel__buttons-container">
              <button type="button" className="dkv-button" onClick={() => this.makeVisible()}>
                <Icon type="right" />
              </button>
              <button type="button" className="dkv-button" onClick={() => this.makeInvisible()}>
                <Icon type="left" />
              </button>
            </div>
          </div>
          <div className="columns-panel__select-item">
            <div className="columns-panel__select-container">
              <select
                multiple
                name="rightSelectValue"
                value={this.state.rightSelectValue}
                onChange={this.handleChangeSelect}
                className="columns-panel__select"
                size={20}
              >
                {this.state.visible.map((el) => (
                  <option value={el} key={el}>
                    {el}
                  </option>
                ))}
              </select>
            </div>
            <div className="columns-panel__buttons-container">
              <button
                type="button"
                className={dragButtonClass}
                onClick={() => this.turnPositionUp()}
              >
                <Icon type="up" />
              </button>
              <button
                type="button"
                className={dragButtonClass}
                onClick={() => this.turnPositionDown()}
              >
                <Icon type="down" />
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

ColumnsPanel.propTypes = {
  columns: PropTypes.objectOf(PropTypes.object).isRequired,
  handleChangeColumns: PropTypes.func.isRequired,
};

export default ColumnsPanel;
