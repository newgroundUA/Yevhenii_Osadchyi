import React from 'react';
import connect from 'react-redux/lib/connect/connect';
import PropTypes from 'prop-types';
import { uniqueId, omit } from 'lodash';
import { Row, Col, Button, Icon, Form } from 'antd';
import { getClassifiersNamesArr } from '../../../helpers/classifiers';
import * as classifiersActions from '../../../actions/classifiersActions';
import fakeClassifiers from '../../../models/classifiers/classifiers';
import { renderFormField } from '../../../helpers/formHelpers/mapFormHelper';
import { SELECT, INPUT, DOCUMENT_TYPE_CASCADER } from '../../../constants/FormItemTypes';
import {
  FILTER_CRITERIA,
  FILTER_TYPE,
  COUNTERPARTY,
  DOCUMENTS,
  OBJECTS,
  ADDRESS_LOCALITY_AREA,
  ADDRESS_STREET,
  ADDRESS_BUILDIND,
  ADDRESS_BUILDIND_SUB_OBJECT,
  ADDRESS_PREMISE,
  YEARS,
} from '../../../constants/ClassifiersNames';

const FormItem = Form.Item;

const CONTAINER_ACTIONS = {
  ...classifiersActions,
};

const formItemLayout = {
  wrapperCol: { span: 24 },
  labelCol: { span: 0 },
  style: {
    paddingRight: '0.5rem',
  },
};
// TODO: Component should be refactored after docs cascaser will be added to mapFormItems
class RegisterFiltersContainer extends React.Component {
  constructor(props) {
    super(props);

    this.filterNameClassifiers = Object.values(props.registryFiltersTemplate).map(
      (filterTemplate) => ({
        type: filterTemplate.type,
        label: filterTemplate.label,
      }),
    );

    this.defState = {
      selectedFiltersMap: {
        ...this.getNewFilterState(),
      },
    };

    this.state = {
      ...this.defState,
    };
  }

  componentDidMount() {
    const { registryFiltersTemplate, loadClassifiers } = this.props;
    const formFieldsObj = Object.values(registryFiltersTemplate).reduce(
      (prev, curr) =>
        curr.valueFormFieldModel && curr.valueFormFieldModel.field
          ? {
              ...prev,
              [curr.valueFormFieldModel.field]: curr.valueFormFieldModel,
            }
          : prev,
      {},
    );
    const classifiersNamesToLoad = getClassifiersNamesArr([formFieldsObj]).filter(
      (cn) =>
        cn !== COUNTERPARTY &&
        cn !== DOCUMENTS &&
        cn !== OBJECTS &&
        cn !== ADDRESS_LOCALITY_AREA &&
        cn !== ADDRESS_STREET &&
        cn !== ADDRESS_BUILDIND &&
        cn !== ADDRESS_BUILDIND_SUB_OBJECT &&
        cn !== ADDRESS_PREMISE,
    );

    loadClassifiers(classifiersNamesToLoad);
  }

  componentWillUnmount() {
    this.setState({
      ...this.defState,
    });
  }

  getFilterId = () => uniqueId('filter');

  getDisabledInputFormFieldModel = (field) => ({
    field,
    type: INPUT,
    placeholder: 'Спершу виберіть поле для фільтру',
    rules: [
      {
        required: true,
        message: "Значення фільтру обов'язкове до вибору",
      },
    ],
    readOnly: true,
    colSpan: 24,
  });

  getFilterTypeFormFieldModel = (field, filterId) => ({
    field,
    type: SELECT,
    classifier: FILTER_TYPE,
    placeholder: 'Виберіть поле для пошуку',
    rules: [{ required: true, message: "Поле фільтру обов'язковий до вибору" }],
    colSpan: 24,
    onChange: (filterName) => this.handleFilterFieldChange(filterId, filterName),
  });

  getCriteriaFormFiledModel = (field) => ({
    field,
    type: SELECT,
    classifier: FILTER_CRITERIA,
    placeholder: 'Виберіть критерій',
    rules: [{ required: true, message: "Критерій обов'язковий до вибору" }],
    colSpan: 24,
  });

  getValueFormFieldModel = (type, filterId) => {
    const { registryFiltersTemplate } = this.props;
    const defaultModel = registryFiltersTemplate[type].valueFormFieldModel;
    return {
      ...defaultModel,
      field: `${filterId}-${defaultModel.field}`,
    };
  };

  getNewFilterState = () => {
    const newFilterId = this.getFilterId();
    const filterField = `${newFilterId}-field`;
    const filterCriteria = `${newFilterId}-criteria`;
    const filterValue = `${newFilterId}-value`;
    return {
      [newFilterId]: {
        type: {
          formField: filterField,
          formFieldModel: this.getFilterTypeFormFieldModel(filterField, newFilterId),
        },
        criteria: {
          formField: filterCriteria,
          formFieldModel: this.getCriteriaFormFiledModel(filterCriteria),
          classifiers: [],
        },
        value: {
          formField: filterValue,
          formFieldModel: this.getDisabledInputFormFieldModel(filterValue),
        },
      },
    };
  };

  handleAddFilter = () => {
    this.setState((prevState) => ({
      selectedFiltersMap: {
        ...prevState.selectedFiltersMap,
        ...this.getNewFilterState(),
      },
    }));
  };

  getDeleteFilterHendler = (filterId) => () => {
    this.setState((prevState) => ({
      selectedFiltersMap: omit(prevState.selectedFiltersMap, filterId),
    }));
  };

  handleResetFilters = () => {
    this.setState((prevState) => {
      const newState = Object.keys(prevState.selectedFiltersMap).reduce(
        (prev, curr) => ({
          ...prev,
          [curr]: {
            ...prevState.selectedFiltersMap[curr],
            value: {
              ...prevState.selectedFiltersMap[curr].value,
              formFieldModel: this.getDisabledInputFormFieldModel(`${curr}-value`),
            },
          },
        }),
        {},
      );
      return {
        selectedFiltersMap: newState,
      };
    });
    this.props.form.resetFields();
  };

  handleFilterFieldChange = (filterId, filterName) => {
    const { registryFiltersTemplate, form } = this.props;
    const { selectedFiltersMap } = this.state;
    const filterTemplate = registryFiltersTemplate[filterName];
    this.setState((prevState) => ({
      selectedFiltersMap: {
        ...prevState.selectedFiltersMap,
        [filterId]: {
          ...prevState.selectedFiltersMap[filterId],
          criteria: {
            ...prevState.selectedFiltersMap[filterId].criteria,
            classifiers: filterTemplate.criterias,
          },
          value: {
            ...prevState.selectedFiltersMap[filterId].value,
            formFieldModel: this.getValueFormFieldModel(filterName, filterId),
          },
        },
      },
    }));
    const criteriaFormField = selectedFiltersMap[filterId].criteria.formField;
    form.setFieldsValue({
      [criteriaFormField]: undefined,
    });
  };

  handleClose = () => {
    this.props.handleClose();
  };

  getFilterFormFiledValue = ({ filterId, filterFormFormValue, formFieldModel }) => {
    const { type } = formFieldModel;
    const { selectedDocumentsTypes } = this.props;

    if (type === DOCUMENT_TYPE_CASCADER) return selectedDocumentsTypes[filterId].data.name;
    if (type === SELECT) return filterFormFormValue.key || filterFormFormValue;
    return filterFormFormValue;
  };

  handleSubmit = () => {
    const { selectedFiltersMap } = this.state;
    const { form, handleSubmit } = this.props;

    const filtersValuesFields = Object.keys(this.getFilterFormFields());

    form.validateFields(filtersValuesFields, (err, values) => {
      if (!err) {
        const filtersData = Object.keys(selectedFiltersMap).map((filterId) => {
          const filter = selectedFiltersMap[filterId];
          const filterType = values[filter.type.formField];
          const filterValue = this.getFilterFormFiledValue({
            filterId,
            filterFormFormValue: values[filter.value.formFieldModel.field],
            formFieldModel: filter.value.formFieldModel,
          });

          return {
            action: values[filter.criteria.formField],
            key: filterType,
            value: filterValue,
          };
        });
        handleSubmit(filtersData);
      }
    });
  };

  renderFilterValue = (filterId) => {
    const { classifiers, form } = this.props;
    const { value } = this.state.selectedFiltersMap[filterId];
    const defFormItemParams = {
      classifiers: {
        ...classifiers,
        [YEARS]: fakeClassifiers[YEARS],
      },
      formItemLayout,
      form,
    };

    const fieldType = value.formFieldModel.type;
    return renderFormField({
      item: value.formFieldModel,
      key: value.formFieldModel.field,
      formItemParams: {
        ...defFormItemParams,
        ...(fieldType === DOCUMENT_TYPE_CASCADER ? { isModal: true, storeKey: filterId } : {}),
      },
    });
  };

  getFilterFormFields = () => {
    const { selectedFiltersMap } = this.state;
    return Object.values(selectedFiltersMap).reduce(
      (prev, curr) => ({
        ...prev,
        [curr.type.formField]: curr.type.formFieldModel,
        [curr.criteria.formField]: curr.criteria.formFieldModel,
        [curr.value.formFieldModel.field]: curr.value.formFieldModel,
      }),
      {},
    );
  };

  renderFilter = (filterId) => {
    const { form } = this.props;
    const { selectedFiltersMap } = this.state;
    const filterState = this.state.selectedFiltersMap[filterId];
    const filterType = form.getFieldValue(filterState.type.formField);
    const filtersCount = Object.keys(selectedFiltersMap).length;

    return (
      <Row style={{ marginTop: '0.5rem' }} key={filterId}>
        <Col span="8">
          {renderFormField({
            item: filterState.type.formFieldModel,
            key: filterState.type.formFieldModel.field,
            formItemParams: {
              form,
              formItemLayout,
              classifiers: {
                [FILTER_TYPE]: this.filterNameClassifiers,
              },
            },
          })}
        </Col>
        <Col span="5">
          {renderFormField({
            item: filterState.criteria.formFieldModel,
            key: filterState.criteria.formFieldModel.field,
            formItemParams: {
              form,
              formItemLayout,
              disabled: !filterType,
              classifiers: {
                [FILTER_CRITERIA]: filterState.criteria.classifiers,
              },
            },
          })}
        </Col>
        <Col span="9">{this.renderFilterValue(filterId)}</Col>
        {filtersCount > 1 && (
          <Col span="2">
            <FormItem style={{ marginBottom: '0' }}>
              <Button
                type="danger"
                style={{ marginLeft: '0.3rem' }}
                onClick={this.getDeleteFilterHendler(filterId)}
              >
                <Icon type="delete" />
              </Button>
            </FormItem>
          </Col>
        )}
      </Row>
    );
  };

  render() {
    const { selectedFiltersMap } = this.state;
    return (
      <div>
        <Row>
          <Col span="8">
            <b>Поле для фільтру</b>
          </Col>
          <Col span="5">
            <b>Критерій</b>
          </Col>
          <Col span="9">
            <b>Значення</b>
          </Col>
          <Col span="2">
            <b>Дія</b>
          </Col>
        </Row>
        <Form>
          {(Object.keys(selectedFiltersMap) || []).map((filterId) => this.renderFilter(filterId))}
          <Row style={{ marginTop: '10px' }}>
            <div key="modalFooter" style={{ display: 'flex', justifyContent: 'space-between' }}>
              <div>
                <Button key="add" onClick={this.handleAddFilter}>
                  <Icon type="plus" />
                  Додати поле
                </Button>
                <Button
                  key="del"
                  type="dashed"
                  style={{ marginLeft: '3px' }}
                  onClick={this.handleResetFilters}
                >
                  <Icon type="delete" />
                  Очистити поля
                </Button>
              </div>
              <div>
                <Button key="back" onClick={this.handleClose}>
                  <Icon type="close" />
                  Закрити
                </Button>
                <Button
                  key="submit"
                  type="primary"
                  style={{ marginLeft: '3px' }}
                  onClick={this.handleSubmit}
                >
                  <Icon type="check" />
                  Застосувати
                </Button>
              </div>
            </div>
          </Row>
        </Form>
      </div>
    );
  }
}

RegisterFiltersContainer.defaultProps = {};

RegisterFiltersContainer.propTypes = {
  registryFiltersTemplate: PropTypes.objectOf(PropTypes.any).isRequired,
  handleSubmit: PropTypes.func.isRequired,
  handleClose: PropTypes.func.isRequired,
  loadClassifiers: PropTypes.func.isRequired,
  classifiers: PropTypes.objectOf(PropTypes.array).isRequired,
  form: PropTypes.objectOf(PropTypes.any).isRequired,
  selectedDocumentsTypes: PropTypes.objectOf(PropTypes.any).isRequired,
};

const mapStateToProps = (state) => ({
  classifiers: state.classifiers,
  selectedDocumentsTypes: state.documentForms.documentCascader.selectedValue,
});

export default connect(mapStateToProps, CONTAINER_ACTIONS)(Form.create()(RegisterFiltersContainer));
