import React from 'react';
import PropTypes from 'prop-types';
import { Button, Icon } from 'antd';

const FastFiltersPanel = ({ useAll, cancelAll, children }) => (
  <div className="fast-filters">
    <div className="fast-filters__filters">
      {children}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-around',
          width: 70,
          marginLeft: 3,
        }}
      >
        <Button size="small" shape="circle-outline" onClick={useAll} type="primary">
          <Icon type="check" />
        </Button>
        <Button size="small" shape="circle-outline" onClick={cancelAll} type="danger">
          <Icon type="close" />
        </Button>
      </div>
    </div>

    <div className="fast-filters__buttons" />
  </div>
);

FastFiltersPanel.propTypes = {
  children: PropTypes.node.isRequired,
  useAll: PropTypes.func.isRequired,
  cancelAll: PropTypes.func.isRequired,
};

export default FastFiltersPanel;
