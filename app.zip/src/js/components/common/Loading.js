import React from 'react';
import { Spin } from 'antd';

const Loading = () => (
  <div>
    <Spin />
  </div>
);

export default Loading;
