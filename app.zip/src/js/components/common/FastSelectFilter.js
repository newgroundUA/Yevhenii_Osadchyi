import React from 'react';
import PropTypes from 'prop-types';
import { Icon, Select } from 'antd';

const Option = Select.Option;

const FastSelectFilter = ({ fastFilters, handleChangeSelect, value }) => (
  <div className="fast-filters">
    <div className="fast-filters__filters">
      <div className="table-menu__icon">
        <Icon type="filter" />
      </div>
      <Select
        showSearch
        style={{ width: 200 }}
        placeholder="Select a person"
        optionFilterProp="children"
        value={value}
        onChange={handleChangeSelect}
        filterOption={(input, option) =>
          option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
        }
      >
        {fastFilters.map((opt) => (
          <Option key={opt.label} value={opt.key}>
            {opt.label}
          </Option>
        ))}
      </Select>
    </div>
  </div>
);

FastSelectFilter.propTypes = {
  fastFilters: PropTypes.arrayOf(PropTypes.object).isRequired,
  handleChangeSelect: PropTypes.func.isRequired,
  value: PropTypes.string.isRequired,
};

export default FastSelectFilter;
