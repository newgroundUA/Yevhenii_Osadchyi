import React from 'react';
import PropTypes from 'prop-types';

import * as cellTypes from '../../../constants/CellTypes';

import CellText from './cells/CellText';
import CellDropDown from './cells/CellDropDown';
import CellCheckbox from './cells/CellCheckbox';
import CellButtons from './cells/CellButtons';
import CellSort from './cells/CellSort';
import CellLink from './cells/CellLink';

const TableRow = (props) => {
  const {
    cells,
    columnsData,
    widths,
    minHeight,
    buttons,
    history,
    rowId,
    openedDrop,
    handleOpenDrop,
    checkboxes,
    handleCheckboxCheck,
  } = props;
  const rowClass = checkboxes.indexOf(rowId) > -1 ? 'dkv-table-row--active' : 'dkv-table-row';

  const cellsArr = Object.keys(columnsData);
  return (
    <div className="dkv-table-row__wrap">
      <div className={rowClass} style={{ minHeight: `${minHeight / 10}rem` }}>
        {cellsArr.map((cellName, id) => {
          if (columnsData[cellName].render !== undefined) {
            return (
              <div
                className="dkv-table-cell--text"
                style={{ width: `${widths[id] / 10}rem` }}
                key={id}
              >
                {columnsData[cellName].render(cells[cellName])}
              </div>
            );
          }
          if (columnsData[cellName].type === cellTypes.LINK) {
            return (
              <CellLink width={widths[id]} minHeight={minHeight} text={cells[cellName]} key={id} />
            );
          }
          if (columnsData[cellName].type === cellTypes.SORT) {
            return (
              <CellSort
                width={widths[id]}
                minHeight={minHeight}
                text={cells[cellName] ? cells[cellName].toString() : ''}
                key={id}
              />
            );
          }
          if (columnsData[cellName].type === cellTypes.DROP_DOWN) {
            return cells[cellName] && cells[cellName].length > 1 ? (
              <CellDropDown
                width={widths[id]}
                minHeight={minHeight}
                texts={cells[cellName]}
                cellName={cellName}
                rowId={rowId}
                openedDrop={openedDrop}
                handleOpenDrop={handleOpenDrop}
                key={`${rowId}-${id}`}
              />
            ) : (
              <CellText
                cellName={cellName} // wrote for debug
                width={widths[id]}
                minHeight={minHeight}
                text={
                  cells[cellName] // eslint-disable-line
                    ? cells[cellName].length === 1
                      ? cells[cellName][0].title
                      : ''
                    : ''
                }
                key={`cellText_${id}`}
              />
            );
          }
          if (columnsData[cellName].type === cellTypes.CHECKBOX) {
            return (
              <CellCheckbox
                width={widths[id]}
                minHeight={minHeight}
                rowId={rowId}
                checkboxes={checkboxes}
                handleCheckboxCheck={handleCheckboxCheck}
                key={id}
              />
            );
          }
          if (columnsData[cellName].type === cellTypes.BUTTONS) {
            return (
              <CellButtons
                width={widths[id]}
                buttons={buttons}
                history={history}
                guid={cells.guid}
                key={id}
              />
            );
          }
          return (
            <CellText
              cellName={cellName} // wrote for debug
              width={widths[id]}
              minHeight={minHeight}
              text={cells[cellName]}
              key={id}
            />
          );
        })}
      </div>
    </div>
  );
};

TableRow.defaultProps = {
  handleCheckboxCheck: () => {},
  handleOpenDrop: () => {},
  buttons: [],
  history: {},
  minHeight: 10,
};

TableRow.propTypes = {
  cells: PropTypes.objectOf(PropTypes.any).isRequired,
  columnsData: PropTypes.objectOf(PropTypes.any).isRequired,

  widths: PropTypes.arrayOf(PropTypes.number).isRequired,
  minHeight: PropTypes.number,
  rowId: PropTypes.number.isRequired,
  checkboxes: PropTypes.arrayOf(PropTypes.number).isRequired,

  history: PropTypes.objectOf(PropTypes.any),
  buttons: PropTypes.arrayOf(PropTypes.object),
  openedDrop: PropTypes.string.isRequired,

  handleOpenDrop: PropTypes.func,
  handleCheckboxCheck: PropTypes.func,
};

export default TableRow;
