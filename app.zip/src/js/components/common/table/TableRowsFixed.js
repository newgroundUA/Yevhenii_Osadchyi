import React from 'react';
import PropTypes from 'prop-types';

import TableRow from './TableRow';

const TableRowsFixed = ({
  columns,
  rows,
  widths,
  minHeights,
  scrollWidth,
  checkboxes,
  history,
  handleCheckboxCheck,
}) => {
  const columnsShifts = widths.reduce(
    (curObj, el) => {
      const sum = curObj.sum + el;
      return { sum, arr: curObj.arr.concat([sum]) };
    },
    { sum: 0, arr: [] },
  ).arr;
  return (
    <div className="dkv-table-row__container">
      {rows.map((el, id) => (
        <TableRow
          cells={el}
          columnsData={columns}
          widths={widths}
          minHeight={minHeights[id]}
          buttons={el.action}
          history={history}
          rowId={id}
          openedDrop="-1"
          checkboxes={checkboxes}
          handleCheckboxCheck={handleCheckboxCheck}
          key={`TableRowFixed${id}`}
        />
      ))}
      {columnsShifts.map((el) => (
        <div className="dkv-table-row__line" style={{ left: `${el / 10}rem` }} key={el} />
      ))}
      <div style={{ height: `${scrollWidth + 1}px` }} />
    </div>
  );
};

TableRowsFixed.propTypes = {
  history: PropTypes.objectOf(PropTypes.any).isRequired,
  widths: PropTypes.arrayOf(PropTypes.number).isRequired,
  minHeights: PropTypes.arrayOf(PropTypes.number).isRequired,
  checkboxes: PropTypes.arrayOf(PropTypes.number).isRequired,

  columns: PropTypes.objectOf(PropTypes.object).isRequired,

  rows: PropTypes.arrayOf(PropTypes.object).isRequired,
  scrollWidth: PropTypes.number.isRequired,

  handleCheckboxCheck: PropTypes.func.isRequired,
};

export default TableRowsFixed;
