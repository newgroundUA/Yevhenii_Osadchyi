import React from 'react';
import PropTypes from 'prop-types';
import { Checkbox } from 'antd';

const CellCheckbox = ({ width, rowId, checkboxes, handleCheckboxCheck }) => {
  const checked = checkboxes.indexOf(rowId) > -1;
  return (
    <div className="dkv-table-cell--checkbox " style={{ width: `${width / 10}rem` }}>
      <Checkbox
        checked={checked}
        onChange={() => {
          handleCheckboxCheck(rowId);
        }}
      />
    </div>
  );
};

CellCheckbox.propTypes = {
  width: PropTypes.number.isRequired,
  rowId: PropTypes.number.isRequired,
  checkboxes: PropTypes.arrayOf(PropTypes.number).isRequired,
  handleCheckboxCheck: PropTypes.func.isRequired,
};

export default CellCheckbox;
