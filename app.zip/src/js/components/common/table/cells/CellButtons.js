import React from 'react';
import PropTypes from 'prop-types';
import { push } from 'connected-react-router';
import { connect } from 'react-redux';

import { Button, Menu, Dropdown, Icon } from 'antd';

const ButtonGroup = Button.Group;

const generateDropdown = (arr, history, guid) => (
  <Menu>
    {arr.map((el, key) => (
      <Menu.Item key={key}>
        <Button style={{ width: '100%' }} onClick={() => el.onClick(history, guid)}>
          <Icon type={el.icon} />
          {el.text}
        </Button>
      </Menu.Item>
    ))}
  </Menu>
);

const CellButtons = ({ width, guid, history, buttons }) => (
  <div className="dkv-table-cell--buttons" style={{ width: `${width / 10}rem` }}>
    <ButtonGroup size="small">
      <Button onClick={() => buttons[0].onClick(history, guid)}>
        <Icon type="eye" />
      </Button>
      <Dropdown overlay={generateDropdown(buttons, history, guid)}>
        <Button>
          <Icon type="down" />
        </Button>
      </Dropdown>
    </ButtonGroup>
  </div>
);

CellButtons.propTypes = {
  width: PropTypes.number.isRequired,
  guid: PropTypes.string.isRequired,
  history: PropTypes.objectOf(PropTypes.any).isRequired,
  buttons: PropTypes.arrayOf(PropTypes.object).isRequired,
};

const mapDispatchToProps = (dispatch) => ({
  history: {
    push: (url) => dispatch(push(url)),
  },
});
export default connect(null, mapDispatchToProps)(CellButtons);
