import React from 'react';
import PropTypes from 'prop-types';

const CellLink = ({ width, text }) => (
  <div className="dkv-table-cell--link" style={{ width: `${width / 10}rem` }}>
    {text}
  </div>
);

CellLink.propTypes = {
  width: PropTypes.number.isRequired,
  text: PropTypes.string,
};

CellLink.defaultProps = {
  text: '',
};

export default CellLink;
