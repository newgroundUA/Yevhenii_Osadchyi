import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';

import _get from 'lodash/get';
import getIcon from '../../../../helpers/getIcon';
import { SORT_ASC } from '../../../../constants/IconNames';

import * as cellTypes from '../../../../constants/CellTypes';

class CellHeader extends React.Component {
  constructor(props) {
    super(props);

    this.drag = this.drag.bind(this);
    this.removeListener = this.removeListener.bind(this);

    this.isDragging = false;
  }

  componentDidMount() {
    this.resizer.addEventListener('mousedown', (e) => {
      this.startX = e.screenX;
      this.isDragging = true;
      window.addEventListener('mousemove', this.drag);
      window.addEventListener('mouseup', this.removeListener);
    });
  }

  componentWillUnmount() {
    window.removeEventListener('mouseup', this.removeListener);
  }

  drag(e) {
    const curX = e.screenX;
    const dx = curX - this.startX;

    if (this.props.width + dx >= 100) {
      this.props.handleWidthChange(this.props.isFixed, this.props.id, this.props.width + dx);
      this.startX = curX;
    }
  }

  removeListener() {
    if (this.isDragging) {
      this.props.saveTableWidthSettings();
      this.isDragging = false;
    }

    window.removeEventListener('mousemove', this.drag);
  }

  render() {
    const { width, name, type, handleSortColumn, colName, sortList } = this.props;

    return (
      <div className="dkv-table-cell--header" style={{ width: `${width / 10}rem` }}>
        <div className="dkv-table-cell-header">
          <div className="dkv-table-cell-header__text">{name}</div>
          {type === cellTypes.SORT && (
            <button
              type="button"
              className={classNames('dkv-table-cell-header__icon', {
                'dkv-table-cell-header__icon--rotate': _get(sortList[colName], 'value') === '-',
              })}
              title={sortList[colName] ? (sortList[colName].value === '-' ? 'Я-А' : 'А-Я') : 'А-Я'} // eslint-disable-line
              onClick={() => handleSortColumn(colName)}
            >
              {getIcon(SORT_ASC, 'icon__fill-blue')}
            </button>
          )}
          <div
            className="dkv-table-cell-header__resizer"
            ref={(el) => {
              this.resizer = el;
            }}
          />
        </div>
      </div>
    );
  }
}

CellHeader.defaultProps = {
  handleSortColumn: () => {},
  colName: '',
};

CellHeader.propTypes = {
  id: PropTypes.number.isRequired,
  isFixed: PropTypes.bool.isRequired,
  width: PropTypes.number.isRequired,
  name: PropTypes.string.isRequired,
  type: PropTypes.string.isRequired,
  colName: PropTypes.string,
  handleWidthChange: PropTypes.func.isRequired,
  saveTableWidthSettings: PropTypes.func.isRequired,
  handleSortColumn: PropTypes.func,
  sortList: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default CellHeader;
