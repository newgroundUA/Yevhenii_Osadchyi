import React from 'react';
import PropTypes from 'prop-types';
import { Checkbox } from 'antd';

const CellCheckboxHeader = ({ width, handleCheckboxCheck, checked }) => (
  <div className="dkv-table-cell--checkbox " style={{ width: `${width / 10}rem` }}>
    <Checkbox checked={checked} onChange={handleCheckboxCheck} />
  </div>
);

CellCheckboxHeader.propTypes = {
  width: PropTypes.number.isRequired,
  handleCheckboxCheck: PropTypes.func.isRequired,
  checked: PropTypes.bool.isRequired,
};

export default CellCheckboxHeader;
