import React from 'react';
import PropTypes from 'prop-types';

const CellSort = ({ width, text }) => (
  <div className="dkv-table-cell--sort" style={{ width: `${width / 10}rem` }}>
    {text}
  </div>
);

CellSort.propTypes = {
  width: PropTypes.number.isRequired,
  text: PropTypes.string.isRequired,
};

export default CellSort;
