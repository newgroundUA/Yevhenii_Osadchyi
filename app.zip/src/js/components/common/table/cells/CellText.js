import React from 'react';
import PropTypes from 'prop-types';

const CellText = ({
  width,
  text,
  // cellName
}) => (
  <div className="dkv-table-cell--text" style={{ width: `${width / 10}rem` }}>
    {
      // !console.log('text', cellName, text) && // wrote for debug
      text
    }
  </div>
);

CellText.propTypes = {
  width: PropTypes.number.isRequired,
  text: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
};

CellText.defaultProps = {
  text: '',
};

export default CellText;
