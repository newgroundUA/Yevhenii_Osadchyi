import React from 'react';
import PropTypes from 'prop-types';

import getIcon from '../../../../helpers/getIcon';
import { ARROW } from '../../../../constants/IconNames';

const CellDropDown = ({ width, texts, cellName, rowId, openedDrop, handleOpenDrop }) => {
  const isOpen = rowId + cellName === openedDrop;

  const cellTextClass = isOpen
    ? 'dkv-table-cell-dropdown__text--active'
    : 'dkv-table-cell-dropdown__text';

  return (
    <div className="dkv-table-cell--drop-down" style={{ width: `${width / 10}rem` }}>
      <div className="dkv-table-cell-dropdown">
        <div className={cellTextClass}>{texts && texts[0].title}</div>
        <button
          type="button"
          className="dkv-table-cell-dropdown__icon-container"
          onClick={() => handleOpenDrop(rowId, cellName)}
        >
          <div className="dkv-table-cell-dropdown__icon">{texts && getIcon(ARROW)}</div>
        </button>
        {isOpen && (
          <div className="dkv-table-cell-dropdown__drop-container">
            {texts &&
              texts.filter((el, id) => id !== 0).map((el, id) => (
                <div className="dkv-table-cell-dropdown__drop-item" key={id}>
                  {el.title}
                </div>
              ))}
          </div>
        )}
      </div>
    </div>
  );
};

CellDropDown.propTypes = {
  texts: PropTypes.arrayOf(PropTypes.object),
  cellName: PropTypes.string,
  handleOpenDrop: PropTypes.func.isRequired,
  openedDrop: PropTypes.oneOfType([PropTypes.number, PropTypes.string]).isRequired,
  rowId: PropTypes.number.isRequired,
  width: PropTypes.number.isRequired,
};

CellDropDown.defaultProps = {
  texts: [],
  cellName: '',
};

export default CellDropDown;
