import React from 'react';
import PropTypes from 'prop-types';

import CellHeader from './cells/CellHeader';

const TableHeader = ({
  headers,
  scrollWidth,
  handleWidthChange,
  saveTableWidthSettings,
  widths,
  handleSortColumn,
  sortList,
}) => {
  const columnsShifts = widths.reduce(
    (curObj, el) => {
      const sum = curObj.sum + el;
      return { sum, arr: curObj.arr.concat([sum]) };
    },
    { sum: 0, arr: [] },
  ).arr;

  return (
    <div className="dkv-table-header">
      {headers.map((el, id) => (
        <CellHeader
          name={el.title}
          colName={el.colName}
          type={el.type}
          sortList={sortList}
          width={widths[id]}
          handleWidthChange={handleWidthChange}
          handleSortColumn={handleSortColumn}
          saveTableWidthSettings={saveTableWidthSettings}
          id={id}
          isFixed={false}
          key={el.title}
        />
      ))}
      {columnsShifts.map((el) => (
        <div className="dkv-table-row__line" style={{ left: `${el / 10}rem` }} key={el} />
      ))}
      {/* we need this coz container without scroll have smaller width */}
      <div style={{ height: 1, width: `${scrollWidth + 1}px`, flexShrink: 0 }} />
    </div>
  );
};

TableHeader.propTypes = {
  headers: PropTypes.arrayOf(PropTypes.object).isRequired,
  scrollWidth: PropTypes.number.isRequired,
  handleWidthChange: PropTypes.func.isRequired,
  saveTableWidthSettings: PropTypes.func.isRequired,
  handleSortColumn: PropTypes.func.isRequired,
  widths: PropTypes.arrayOf(PropTypes.number).isRequired,
  sortList: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default TableHeader;
