import React from 'react';
import PropTypes from 'prop-types';

import TableRow from './TableRow';

const TableRows = ({
  columns,
  rows,
  widths,
  minHeights,
  openedDrop,
  handleOpenDrop,
  checkboxes,
}) => {
  const columnsShifts = widths.reduce(
    (curObj, el) => {
      const sum = curObj.sum + el;
      return { sum, arr: curObj.arr.concat([sum]) };
    },
    { sum: 0, arr: [] },
  ).arr;

  return (
    <div className="dkv-table-row__container">
      {rows.map((el, id) => (
        <TableRow
          cells={el}
          columnsData={columns}
          widths={widths}
          minHeight={minHeights[id]}
          rowId={id}
          openedDrop={openedDrop}
          handleOpenDrop={handleOpenDrop}
          checkboxes={checkboxes}
          key={`TableRow${id}`}
        />
      ))}
      {columnsShifts.map((el) => (
        <div className="dkv-table-row__line" style={{ left: `${el / 10}rem` }} key={el} />
      ))}
    </div>
  );
};

TableRows.propTypes = {
  columns: PropTypes.objectOf(PropTypes.object).isRequired,
  rows: PropTypes.arrayOf(PropTypes.object).isRequired,
  widths: PropTypes.arrayOf(PropTypes.number).isRequired,
  minHeights: PropTypes.arrayOf(PropTypes.number).isRequired,

  openedDrop: PropTypes.string.isRequired,

  handleOpenDrop: PropTypes.func.isRequired,
  checkboxes: PropTypes.arrayOf(PropTypes.number).isRequired,
};

export default TableRows;
