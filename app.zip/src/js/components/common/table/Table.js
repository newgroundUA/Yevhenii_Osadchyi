import React from 'react';
import PropTypes from 'prop-types';

import { getScrollbarWidth } from '../../../helpers/index';

import TableHeader from './TableHeader';
import TableHeaderFixed from './TableHeaderFixed';

import TableRows from './TableRows';
import TableRowsFixed from './TableRowsFixed';

class DataTable extends React.Component {
  constructor(props) {
    super(props);
    this.scrollbarWidth = getScrollbarWidth();

    this.state = {
      widths: {
        fixed: [],
        fluid: [],
      },
      minHeights: [],
      checkedCheckboxes: [],
      allCheckboxesChecked: false,
      openedDrop: '-1',
      visibleColumns: {},
    };
  }

  componentWillMount() {
    const { columnsData } = this.props;
    const visibleColumns = {
      fixed: this.getVisibleSortedColumns(columnsData.fixed),
      fluid: this.getVisibleSortedColumns(columnsData.fluid),
    };
    const widthsObj = this.getWidthsArr(visibleColumns);

    const minHeightsArr = Array(100).fill(0);
    this.setState({
      widths: widthsObj,
      minHeights: minHeightsArr,
      visibleColumns,
    });
  }

  componentDidMount() {
    // we need 2 separate scroll-bars: [in fixed, in fluid] containers to be synced
    this.scrollTable.addEventListener('scroll', () => {
      this.scrollVerticalHidden.scrollTop = this.scrollTable.scrollTop;
      this.scrollHorizontalHidden.scrollLeft = this.scrollTable.scrollLeft;
    });
    this.mapRowsFromRefs();
    // heights depends on loaded content so we need this hook with 'load'
    this.adjustHeights();
    window.addEventListener('load', this.adjustHeights);
    setTimeout(() => this.adjustHeights(), 0);
  }

  componentWillReceiveProps(nextProps) {
    const { columnsData } = nextProps;
    const visibleColumns = {
      fixed: this.getVisibleSortedColumns(columnsData.fixed),
      fluid: this.getVisibleSortedColumns(columnsData.fluid),
    };

    const widthsObj = this.getWidthsArr(visibleColumns);
    this.setState({
      widths: widthsObj,
      visibleColumns,
      checkedCheckboxes: [],
      allCheckboxesChecked: false,
    });

    setTimeout(() => {
      this.mapRowsFromRefs();
      this.adjustHeights();
    }, 0);
  }

  componentWillUnmount() {
    window.removeEventListener('load', this.adjustHeights);
  }

  getVisibleSortedColumns = (columns) =>
    Object.values(columns)
      .filter((el) => el.isVisible)
      .sort((a, b) => a.position - b.position)
      .reduce((sum, el) => ({ ...sum, [el.colName]: el }), {});

  getWidthsArr = (data) => {
    const mapWidths = (arr) => Object.values(arr).map((el) => el.width);
    return {
      fixed: mapWidths(data.fixed),
      fluid: mapWidths(data.fluid),
    };
  };

  handleWidthChange = (isFixed, position, count) => {
    if (isFixed) {
      this.setState((prevState) => {
        const curArr = prevState.widths.fixed.slice();
        curArr[position] = count;
        return {
          widths: {
            fixed: curArr,
            fluid: prevState.widths.fluid,
          },
        };
      });
    } else {
      this.setState((prevState) => {
        const curArr = prevState.widths.fluid.slice();
        curArr[position] = count;
        return {
          widths: {
            fixed: prevState.widths.fixed,
            fluid: curArr,
          },
        };
      });
    }
    this.adjustHeights();
  };

  mapRowsFromRefs = () => {
    const refFixedRows = Array.from(this.fixedRows.children[0].children)
      .map((el) => el.children[0])
      .filter((el) => el !== undefined);
    const refFluidRows = Array.from(this.rows.children[0].children)
      .map((el) => el.children[0])
      .filter((el) => el !== undefined);
    this.refCells = refFixedRows.map((el, id) =>
      Array.from(el.children).concat(Array.from(refFluidRows[id].children)),
    );
  };

  adjustHeights = () => {
    if (this.fixedRows !== null) {
      const len = this.refCells.length;
      const heights = [];

      for (let i = 0; i < len; i++) {
        const cellsInRow = this.refCells[i];
        const maxCellHeight = cellsInRow.reduce((curMax, el) => {
          const cellHeight = el.offsetHeight;
          return cellHeight > curMax ? cellHeight : curMax;
        }, 0);
        heights.push(maxCellHeight);
      }

      this.setState({
        minHeights: heights.length !== 0 ? heights : Array(100).fill(0),
      });
    }
  };

  handleOpenDrop = (rowId, cellName) => {
    if (this.state.openedDrop === rowId + cellName) {
      this.setState({ openedDrop: '-1' });
    } else {
      this.setState({ openedDrop: rowId + cellName });
    }
  };

  handleCheckboxCheck = (id) => {
    const { rows, syncronizeCheckedArr } = this.props;
    const curArr = this.state.checkedCheckboxes.slice();
    const index = curArr.indexOf(id);

    if (index >= 0) {
      curArr.splice(index, 1);
      syncronizeCheckedArr(curArr, rows);
      this.setState({
        checkedCheckboxes: curArr,
        allCheckboxesChecked: false,
      });
    } else {
      const newArr = [...curArr, id];
      syncronizeCheckedArr(newArr, rows);
      const isAllChecked = newArr.length === rows.length;
      this.setState({
        checkedCheckboxes: newArr,
        allCheckboxesChecked: isAllChecked,
      });
    }
  };

  handleHeaderCheckbox = () => {
    const { rows, syncronizeCheckedArr } = this.props;
    const curArr = this.state.checkedCheckboxes;
    const rowCount = rows.length;
    const isAllChecked = curArr.length === rowCount;

    if (isAllChecked) {
      syncronizeCheckedArr([], rows);
      this.setState({
        checkedCheckboxes: [],
        allCheckboxesChecked: false,
      });
    } else {
      const newArr = [];
      for (let i = 0; i < rowCount; i++) {
        newArr.push(i);
      }
      syncronizeCheckedArr(newArr, rows);
      this.setState({
        checkedCheckboxes: newArr,
        allCheckboxesChecked: true,
      });
    }
  };

  saveTableWidthSettings = () => {
    const { columnsData, saveTableWidthSettings } = this.props;

    const {
      widths: { fixed: fixedWidth, fluid: fluidWidth },
      visibleColumns,
    } = this.state;

    const saveTableWidth = (objForSave, widthArr) =>
      Object.keys(objForSave).reduce(
        (prev, currColName, key) => ({
          ...prev,
          [currColName]: {
            ...objForSave[currColName],
            width: widthArr[key],
          },
        }),
        {},
      );

    saveTableWidthSettings({
      fixed: {
        ...columnsData.fixed,
        ...saveTableWidth(visibleColumns.fixed, fixedWidth),
      },
      fluid: {
        ...columnsData.fluid,
        ...saveTableWidth(visibleColumns.fluid, fluidWidth),
      },
    });
  };

  render() {
    const { rows, handleSortColumn, sortList, history } = this.props;

    const { visibleColumns } = this.state;

    const minHeights = this.state.minHeights.slice();
    return (
      <div className="dkv-table__container--wrap">
        <div className="dkv-table__container">
          <div className="dkv-table__header">
            <div className="dkv-table__header-fixed-items">
              <TableHeaderFixed
                sortList={sortList}
                headers={Object.values(visibleColumns.fixed)}
                widths={this.state.widths.fixed}
                handleSortColumn={handleSortColumn}
                handleHeaderCheckbox={this.handleHeaderCheckbox}
                allCheckboxesChecked={this.state.allCheckboxesChecked}
                handleWidthChange={this.handleWidthChange}
                saveTableWidthSettings={this.saveTableWidthSettings}
              />
            </div>
            <div
              className="dkv-table__hzl-scroll"
              ref={(el) => {
                this.scrollHorizontalHidden = el;
              }}
            >
              <div className="dkv-table__header-scroll-items">
                <TableHeader
                  sortList={sortList}
                  headers={Object.values(visibleColumns.fluid)}
                  handleSortColumn={handleSortColumn}
                  scrollWidth={this.scrollbarWidth}
                  widths={this.state.widths.fluid}
                  handleWidthChange={this.handleWidthChange}
                  saveTableWidthSettings={this.saveTableWidthSettings}
                />
              </div>
            </div>
          </div>

          <div className="dkv-table--wrap">
            <div className="dkv-table">
              <div
                className="dkv-table__scrollable--hidden"
                ref={(el) => {
                  this.scrollVerticalHidden = el;
                }}
              >
                <div
                  className="dkv-table__fixed-rows"
                  ref={(el) => {
                    this.fixedRows = el;
                  }}
                >
                  <TableRowsFixed
                    columns={visibleColumns.fixed}
                    rows={rows}
                    widths={this.state.widths.fixed}
                    minHeights={minHeights}
                    scrollWidth={this.scrollbarWidth}
                    history={history}
                    checkboxes={this.state.checkedCheckboxes}
                    handleCheckboxCheck={this.handleCheckboxCheck}
                  />
                </div>
              </div>
              <div
                className="dkv-table__scrollable"
                ref={(el) => {
                  this.scrollTable = el;
                }}
              >
                <div
                  className="dkv-table__rows"
                  ref={(el) => {
                    this.rows = el;
                  }}
                >
                  <TableRows
                    columns={visibleColumns.fluid}
                    rows={rows}
                    widths={this.state.widths.fluid}
                    minHeights={minHeights}
                    openedDrop={this.state.openedDrop}
                    handleOpenDrop={this.handleOpenDrop}
                    checkboxes={this.state.checkedCheckboxes}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

DataTable.propTypes = {
  history: PropTypes.objectOf(PropTypes.any).isRequired,
  columnsData: PropTypes.objectOf(PropTypes.object).isRequired,
  rows: PropTypes.arrayOf(PropTypes.object).isRequired,
  handleSortColumn: PropTypes.func.isRequired,
  saveTableWidthSettings: PropTypes.func.isRequired,
  syncronizeCheckedArr: PropTypes.func.isRequired,
  sortList: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default DataTable;
