import React from 'react';
import PropTypes from 'prop-types';

import * as cellTypes from '../../../constants/CellTypes';

import CellHeader from './cells/CellHeader';
import CellCheckboxHeader from './cells/CellCheckboxHeader';

const TableHeaderFixed = (props) => {
  const {
    headers,
    widths,
    handleWidthChange,
    saveTableWidthSettings,
    handleHeaderCheckbox,
    allCheckboxesChecked,
    sortList,
    handleSortColumn,
  } = props;

  const columnsShifts = widths.reduce(
    (curObj, el) => {
      const sum = curObj.sum + el;
      return { sum, arr: curObj.arr.concat([sum]) };
    },
    { sum: 0, arr: [] },
  ).arr;

  return (
    <div className="dkv-table-header">
      {headers.map((el, id) => {
        if (el.type === cellTypes.CHECKBOX) {
          return (
            <CellCheckboxHeader
              width={widths[id]}
              handleCheckboxCheck={handleHeaderCheckbox}
              checked={allCheckboxesChecked}
              key={el.title}
            />
          );
        }
        if (el.type === cellTypes.BUTTONS) {
          return (
            <div
              className="dkv-table-cell--buttons-header"
              style={{ width: `${widths[id] / 10}rem` }}
              key={el.title}
            >
              {el.title}
            </div>
          );
        }
        return (
          <CellHeader
            name={el.title}
            type={el.type}
            colName={el.colName}
            sortList={sortList}
            width={widths[id]}
            handleSortColumn={handleSortColumn}
            handleWidthChange={handleWidthChange}
            saveTableWidthSettings={saveTableWidthSettings}
            id={id}
            isFixed
            key={el.title}
          />
        );
      })}
      {columnsShifts.map((el) => (
        <div className="dkv-table-row__line" style={{ left: `${el / 10}rem` }} key={el} />
      ))}
    </div>
  );
};

TableHeaderFixed.propTypes = {
  headers: PropTypes.arrayOf(PropTypes.object).isRequired,
  widths: PropTypes.arrayOf(PropTypes.number).isRequired,
  handleWidthChange: PropTypes.func.isRequired,
  saveTableWidthSettings: PropTypes.func.isRequired,
  handleHeaderCheckbox: PropTypes.func.isRequired,
  allCheckboxesChecked: PropTypes.bool.isRequired,
  sortList: PropTypes.objectOf(PropTypes.any).isRequired,
  handleSortColumn: PropTypes.func.isRequired,
};

export default TableHeaderFixed;
