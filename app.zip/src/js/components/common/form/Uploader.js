import React from 'react';
import PropTypes from 'prop-types';
import { Upload } from 'antd';

export default class Uploader extends React.Component {
  static defaultProps = {
    // value: null,
    onChange: null,
  };

  static propTypes = {
    value: PropTypes.objectOf(PropTypes.any), // eslint-disable-line
    onChange: PropTypes.func,
    name: PropTypes.string.isRequired,
  };

  beforeUpload = (file) => {
    if (this.props.onChange) {
      this.props.onChange(file);
    }
    return false;
  };

  onRemove = () => {
    if (this.props.onChange) {
      this.props.onChange(undefined);
    }
  };

  render() {
    const list = this.props.value ? [this.props.value] : [];

    return (
      <div style={{ marginBottom: 20 }}>
        <Upload.Dragger
          name={this.props.name}
          fileList={list}
          multiple={false}
          beforeUpload={this.beforeUpload}
          onRemove={this.onRemove}
        >
          Перетягніть файл сюди
        </Upload.Dragger>
      </div>
    );
  }
}
