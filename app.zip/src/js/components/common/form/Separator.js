import React from 'react';
import PropTypes from 'prop-types';

const Separator = ({ text, pxSize, color }) => (
  <div className="dkv-form-separator" style={{ borderColor: color }}>
    <span className="dkv-form-separator__text" style={{ fontSize: `${pxSize}px`, color }}>
      {text}
    </span>
  </div>
);

Separator.propTypes = {
  text: PropTypes.oneOfType([PropTypes.string, PropTypes.node]),
  pxSize: PropTypes.string,
  color: PropTypes.string,
};

Separator.defaultProps = {
  pxSize: '16',
  text: '',
  color: null,
};

export default Separator;
