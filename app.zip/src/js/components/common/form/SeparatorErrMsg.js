import React from 'react';
import PropTypes from 'prop-types';

const SeparatorErrMsg = ({ text }) => (
  <div className="dkv-form-separator-err-msg">
    <span className="dkv-form-separator-err-msg__text">{text}</span>
  </div>
);

SeparatorErrMsg.propTypes = {
  text: PropTypes.string.isRequired,
};

export default SeparatorErrMsg;
