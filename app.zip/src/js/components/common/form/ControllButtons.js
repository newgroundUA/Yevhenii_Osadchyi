import React from 'react';
import PropTypes from 'prop-types';
import { Button, Row, Icon } from 'antd';

const ButtonGroup = Button.Group;

const ControlButtons = ({
  history,
  curMode,
  clearForm,
  urlToRegister,
  urlToEditMode,
  className,
  inModal,
}) => {
  const changeRouteTo = (route) => {
    history.push(route);
  };
  const switchToEditMode = () => {
    changeRouteTo(urlToEditMode);
  };
  const goToRegister = () => {
    changeRouteTo(urlToRegister);
  };

  const isViewMode = curMode === 'view';

  return (
    <Row type="flex" justify="center" className={className}>
      <ButtonGroup>
        {isViewMode && (
          <Button onClick={switchToEditMode}>
            <Icon type="edit" />
            Редагувати
          </Button>
        )}
        {!isViewMode && (
          <Button onClick={clearForm}>
            <Icon type="delete" />
            Очистити поля
          </Button>
        )}
        {!inModal && (
          <Button onClick={goToRegister}>
            <Icon type="logout" />
            Перейти до реєстру
          </Button>
        )}
      </ButtonGroup>
    </Row>
  );
};

ControlButtons.defaultProps = {
  className: '',
  inModal: false,
};

ControlButtons.propTypes = {
  curMode: PropTypes.string.isRequired,
  clearForm: PropTypes.func.isRequired,
  history: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
  urlToRegister: PropTypes.string.isRequired,
  urlToEditMode: PropTypes.string.isRequired,
  className: PropTypes.string,
  inModal: PropTypes.bool,
};

export default ControlButtons;
