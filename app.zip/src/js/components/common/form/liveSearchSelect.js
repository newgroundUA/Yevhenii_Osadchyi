import React from 'react';
import { Select, Spin, Form } from 'antd';
import _debounce from 'lodash/debounce';
import PropTypes from 'prop-types';

const Option = Select.Option;
const FormItem = Form.Item;

class LiveSearchSelect extends React.Component {
  constructor(props) {
    super(props);
    this.lastFetchId = 0;
    this.fetchUser = _debounce(this.fetchUser, 800);
  }

  state = {
    data: [],
    fetching: false,
  };

  fetchUser = (value) => {
    if (value.length < this.props.minCountSymbolsSearch) {
      return;
    }

    this.lastFetchId += 1;
    const fetchId = this.lastFetchId;
    this.setState({ data: [], fetching: true });
    this.props.fetchAction(value).then((resp) => {
      if (fetchId !== this.lastFetchId) {
        // for fetch callback order
        return;
      }
      const responseData = this.props.parseToFe(resp.data.content);
      this.setState({ data: responseData, fetching: false });
    });
  };

  render() {
    const { fetching, data } = this.state;
    const { type, className, form, params } = this.props;

    return (
      <FormItem label={params.label} {...params.formItemLayout} className={params.className}>
        {form.getFieldDecorator(params.fieldName)(
          <Select
            className={className}
            mode={type || 'default'}
            labelInValue
            placeholder={params.placeholder}
            notFoundContent={fetching ? <Spin size="small" /> : null}
            filterOption={false}
            onSearch={this.fetchUser}
            style={{ width: '100%' }}
          >
            {data.map((d) => <Option key={d.value}>{d.text}</Option>)}
          </Select>,
        )}
      </FormItem>
    );
  }
}

LiveSearchSelect.defaultProps = {
  parseToFe: (el) => el,
  minCountSymbolsSearch: 0,
  params: {},
};

LiveSearchSelect.propTypes = {
  type: PropTypes.string.isRequired,
  params: PropTypes.objectOf(PropTypes.any),
  fetchAction: PropTypes.func.isRequired,
  form: PropTypes.objectOf(PropTypes.any).isRequired,
  className: PropTypes.string.isRequired,
  parseToFe: PropTypes.func,
  minCountSymbolsSearch: PropTypes.number,
};

export default LiveSearchSelect;
