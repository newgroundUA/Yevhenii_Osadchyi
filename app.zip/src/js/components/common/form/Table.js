import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Collapse, Button, Table, Row, Icon } from 'antd';

import { mapFormItems } from '../../../helpers/formHelpers/mapFormHelper';
import { getFormEntityData, mapRowsToTable } from '../../../helpers/formHelpers/formHelpers';
import { getTableColumns } from '../../../helpers/table';

const Panel = Collapse.Panel;
class FormTable extends Component {
  constructor(props) {
    super(props);
    this.isEditing = false;
    this.state = {
      collapsed: false,
      activeKey: '0',
      curIndex: null,
      columns: [],
      rows: [],
    };

    this.columns = this.getColumns(props.fields);
  }

  componentWillMount() {
    this.setState({
      columns: this.getColumns(this.props.fields),
      rows: this.getTableRows(this.props),
    });
  }

  componentWillReceiveProps(nextProps) {
    if (
      !this.isEditing &&
      (nextProps.rows !== this.props.rows ||
        nextProps.fields !== this.props.fields ||
        nextProps.classifiers !== this.props.classifiers ||
        nextProps.parserToFE !== this.props.parserToFE)
    ) {
      this.setState({
        columns: this.getColumns(nextProps.fields),
        rows: this.getTableRows(nextProps),
      });
    }
  }

  getColumns = (fields) =>
    getTableColumns({
      formFields: fields,
      actionsData: {
        editParams: {
          handler: this.handleEditRow,
        },
        deleteParams: {
          handler: this.handleDeleteRow,
          disabled: this.props.deleteDisabled,
        },
      },
    });

  getTableRows = ({ rows, fields, classifiers, parserToFE }) => {
    const rowsToTable = rows.map((el) => parserToFE(el));
    return mapRowsToTable(rowsToTable, fields, classifiers);
  };

  handleAddTableRow = () => {
    this.props.form.resetFields(Object.keys(this.props.fields));
    this.setState({
      collapsed: true,
      activeKey: 1,
    });
  };

  handleCancelTableRow = () => {
    this.props.form.resetFields(Object.keys(this.props.fields));
    this.isEditing = false;
    this.setState({
      collapsed: false,
      activeKey: 0,
    });
  };

  handleSaveTableForm = () => {
    const fields = this.props.fields;
    const curFields = Object.keys(this.props.fields);

    this.props.form.validateFields(curFields, (err, values) => {
      if (err) {
        return this.props.onSave({ err });
      }

      if (!err) {
        const normilizedValues = getFormEntityData(values, this.props.classifiers, fields);
        this.props.onSave({
          obj: {
            ...normilizedValues,
            beObj: this.props.rows[this.state.curIndex],
          },
        });

        this.isEditing = false;
        this.setState(() => ({
          collapsed: false,
          curIndex: null,
          activeKey: 0,
        }));
      }
    });
  };

  handleEditRow = (rowIndex) => {
    const { guid, versionId, ...fields } = this.props.parserToFE(this.props.rows[rowIndex]);
    this.isEditing = true;
    this.setState(
      () => ({
        collapsed: true,
        activeKey: 1,
        curIndex: rowIndex,
      }),
      () => this.props.form.setFieldsValue(fields),
    );
  };

  handleDeleteRow = (rowIndex) => {
    this.props.onDelete(this.props.rows[rowIndex].guid, rowIndex);
    this.setState((prevState) => {
      const curArr = prevState.rows.slice();
      curArr.splice(rowIndex, 1);
      return { rows: curArr };
    });
  };

  renderCollapse = () => (
    <Collapse
      style={this.state.collapsed ? { marginBottom: '1rem' } : { display: 'none' }}
      bordered={false}
      activeKey={`${this.state.activeKey}`}
    >
      <Panel header="Форма створення" key="1" disabled={!this.state.collapsed}>
        {mapFormItems({
          viewMode: this.props.viewMode,
          fields: this.props.fields,
          classifiers: this.props.classifiers,
          isViewMode: this.props.isViewMode,
          form: this.props.form,
        })}
        <Row>
          {this.props.customFields.length > 0 &&
            this.props.customFields.map((el) => el.render('component'))}
        </Row>
        <Row>
          <Button
            disabled={this.props.isViewMode}
            style={{ marginRight: '1rem' }}
            onClick={this.handleSaveTableForm}
            type="primary"
          >
            <Icon type="save" />
            {`Зберегти`}
          </Button>
          <Button disabled={this.props.isViewMode} onClick={this.handleCancelTableRow}>
            <Icon type="close" />
            {`Вiдмiнити`}
          </Button>
        </Row>
      </Panel>
    </Collapse>
  );

  render() {
    const { collapsed, columns, rows } = this.state;

    const {
      isViewMode,
      withCollapse,
      actionElement,
      expandedRowRender,
      scroll,
      minWidth,
    } = this.props;
    const rowStyle = minWidth ? { overflowX: 'auto' } : {};

    return (
      <Row style={rowStyle}>
        {!collapsed && (
          <Button
            disabled={isViewMode}
            onClick={this.handleAddTableRow}
            size="small"
            type="primary"
          >
            {actionElement}
          </Button>
        )}
        {withCollapse
          ? this.renderCollapse()
          : this.props.customRender({
              isDisplayed: collapsed,
              onCancel: this.handleCancelTableRow,
            })}
        <Table
          scroll={scroll}
          style={{ margin: '1rem 0', background: '#fff', minWidth }}
          bordered
          rowKey="guid"
          pagination={false}
          columns={columns}
          dataSource={rows}
          expandedRowRender={expandedRowRender}
          onExpand={this.props.onExpand}
        />
      </Row>
    );
  }
}

FormTable.defaultProps = {
  withCollapse: true,
  rows: [],
  scroll: {},
  actionElement: (
    <span>
      <Icon type="plus" />
      {`Додати`}
    </span>
  ),
  onSave: () => {},
  onDelete: () => {},
  onExpand: () => {},
  customRender: () => {},
  customFields: [],
  expandedRowRender: null,
  deleteDisabled: false,
  minWidth: null,
};

FormTable.propTypes = {
  onSave: PropTypes.func,
  onDelete: PropTypes.func,
  classifiers: PropTypes.objectOf(PropTypes.array).isRequired,
  fields: PropTypes.objectOf(PropTypes.object).isRequired,
  customFields: PropTypes.arrayOf(PropTypes.object),
  rows: PropTypes.arrayOf(PropTypes.object),
  viewMode: PropTypes.string.isRequired,
  deleteDisabled: PropTypes.bool,
  isViewMode: PropTypes.bool.isRequired,
  parserToFE: PropTypes.func.isRequired,
  onExpand: PropTypes.func,
  customRender: PropTypes.func,
  withCollapse: PropTypes.bool,
  minWidth: PropTypes.string,
  actionElement: PropTypes.oneOfType([PropTypes.element, PropTypes.string]),
  expandedRowRender: PropTypes.func,
  scroll: PropTypes.shape({
    x: PropTypes.any,
    y: PropTypes.any,
  }),
  form: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default FormTable;
