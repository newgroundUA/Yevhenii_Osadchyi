import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import { Table, Row } from 'antd';
import { Resizable } from 'react-resizable';

// import ResizeableTitle from './ResizeableTitle';

const ResizeableTitle = (props, ...rest) => {
  // console.log('log ------>', props); //eslint-disable-line
  const { onResize, width, ...restProps } = props;

  if (!width) {
    return <th {...restProps} />;
  }

  return (
    <Resizable width={width} height={0} onResize={onResize}>
      <th {...restProps} />
    </Resizable>
  );
};

class RegisterTableComponent extends PureComponent {
  state = {
    selectedRowKeys: [],
    columns: [],
  };

  componentDidMount() {
    this.setState({
      columns: this.props.columns,
    });
  }

  onSelectChange = (selectedRowKeys) => {
    this.setState({
      selectedRowKeys,
    });
  };

  handleResize = (index, minSize) => (e, { size }) => {
    this.setState(({ columns }) => {
      const nextColumns = [...columns];
      nextColumns[index] = {
        ...nextColumns[index],
        width: minSize >= size.width ? minSize : size.width,
      };

      return { columns: nextColumns };
    });
  };

  components = {
    header: {
      cell: ResizeableTitle,
    },
  };

  render() {
    const {
      dataSource,
    } = this.props;

    const { selectedRowKeys } = this.state;

    const rowSelection = {
      selectedRowKeys,
      onChange: this.onSelectChange,
      hideDefaultSelections: true,
      columnWidth: 100,
      // onSelection: this.onSelection,
    };

    let totalWidth = 100;
    const columns = this.state.columns.map((col, index) => {
      totalWidth += col.width || 0;
      return {
        ...col,
        onHeaderCell: (column) => ({
          width: column.width,
          onResize: this.handleResize(index, column.minWidth),
        }),
      }
    });

    return (
      <Row className="content__table">
        <Table
          bordered
          rowKey="guid"
          components={this.components}
          columns={columns}
          dataSource={dataSource}
          rowSelection={rowSelection}
          pagination={false}
          scroll={{ x: totalWidth, y: 'calc(100vh - 32.6rem)' }}
        />
      </Row>
    );
  }
}

RegisterTableComponent.propTypes = {
  columns: PropTypes.arrayOf(PropTypes.object).isRequired,
  dataSource: PropTypes.arrayOf(PropTypes.object).isRequired,
};

export default RegisterTableComponent;
