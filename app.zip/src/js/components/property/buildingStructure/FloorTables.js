import React from 'react';
import PropTypes from 'prop-types';
import { Button, Table, Row, Modal } from 'antd';

import {
  FLOOR_COLUMNS as floorColumns,
  GENERAL_PREMISE_COLUMNS as premiseColumns,
} from '../../../models/formFields/property/BuildingStructureTables';

import PremiseGroupFormContainer from '../../../containers/property/forms/building/PremiseGroupFormContainer';
import PremisesFormContainer from '../../../containers/property/forms/building/PremisesFormContainer';
import FloorFormContainer from '../../../containers/property/forms/building/FloorFormContainer';

class FloorTables extends React.Component {
  constructor(props) {
    super(props);

    this.modalTitleMap = {
      openPremise: 'Картка приміщення',
      openPremiseGroup: 'Картка групи приміщень',
      openEditFloor: 'Картка поверху',
    };

    this.state = {
      dialogOpen: false,
      openPremise: false,
      openPremiseGroup: false,
      openEditFloor: false,
      modalTitle: '',
    };
  }

  handleToggleDialog = (isOpened) => {
    if (isOpened !== undefined) this.setState({ dialogOpen: isOpened });
    else this.setState((prevState) => ({ dialogOpen: !prevState.dialogOpen }));
  };

  onCreated = () => {
    this.handleToggleDialog(false);
    this.props.updateBuilding();
  };

  handleOpenForm = (formName) => {
    this.setState({
      openPremise: formName === 'openPremise',
      openPremiseGroup: formName === 'openPremiseGroup',
      openEditFloor: formName === 'openEditFloor',
      modalTitle: this.modalTitleMap[formName],
    });
    this.handleToggleDialog();
  };

  render() {
    const { item, buildingData, isViewMode } = this.props;

    const { dialogOpen, modalTitle, openPremise, openEditFloor, openPremiseGroup } = this.state;

    const dataSourceFloors = [
      {
        key: item.guid,
        number: item.floorNumber,
        groupCount: (item.groupOfPremises || []).length,
        premisesCount: (item.premises || []).length,
        livingSpace: item.floorLivingSpace,
        unLivingSpace: item.floorUnlivingSpace,
        usefulUnLivingSpace: item.floorUsefullUnLivingSpace ? item.floorUsefullUnLivingSpace : '',
        technicalSpace: item.floorTechSpace,
        socialUseSpace: item.floorCommonSpace,
      },
    ];

    const dataSourcePremises = (item.premises || []).map((premise) => ({
      key: premise.guid,
      code: premise.accountingItemId,
      name: premise.fullName,
      type: premise.premiseConstruction.name,
      area: premise.premiseSpace,
      usefulUnLivingSpace: premise.usefullSpace,
      socialUseSpace: premise.commonUse ? 'Так' : 'Ні',
      decoration: premise.premiseEquip.name,
    }));

    const availablePremises = (item.premises || []).filter((el) => !el.groupOfPremise);

    return (
      <Row>
        <Modal
          title={modalTitle}
          visible={dialogOpen}
          width={1300}
          footer={false}
          onCancel={() => {
            this.handleToggleDialog(false);
          }}
        >
          <Row>
            {dialogOpen && (
              <Row>
                {openPremiseGroup ? (
                  <PremiseGroupFormContainer
                    floorItem={item}
                    match={{ params: { mode: 'create' } }}
                    onPremiseGroupCreated={this.onCreated}
                    availablePremises={availablePremises}
                    inModal
                  />
                ) : (
                  ''
                )}
                {openPremise ? (
                  <PremisesFormContainer
                    floorItem={item}
                    match={{ params: { mode: 'create' } }}
                    onPremiseCreated={this.onCreated}
                    inModal
                    buildingData={buildingData}
                  />
                ) : (
                  ''
                )}
                {openEditFloor ? (
                  <FloorFormContainer
                    buildingData={buildingData}
                    match={{ params: { mode: 'edit', guid: item.guid } }}
                    onFloorCreated={this.onCreated}
                    visible={dialogOpen}
                    inModal
                  />
                ) : (
                  ''
                )}
              </Row>
            )}
          </Row>
        </Modal>
        <Row style={{ marginBottom: '1rem' }}>
          <Button
            onClick={() => {
              this.handleOpenForm('openEditFloor');
            }}
            disabled={isViewMode}
          >
            Редагувати поверх
          </Button>
          <Button
            onClick={() => {
              this.handleOpenForm('openPremise');
            }}
            disabled={isViewMode}
          >
            Додати приміщення
          </Button>
          <Button
            onClick={() => {
              this.handleOpenForm('openPremiseGroup');
            }}
            disabled={isViewMode}
          >
            Додати группу приміщень
          </Button>
        </Row>
        <Row>Параметри поверха:</Row>
        <Row style={{ marginBottom: '1rem' }}>
          <Table dataSource={dataSourceFloors} columns={floorColumns} pagination={false} bordered />
        </Row>
        <Row>Приміщення:</Row>
        <Row>
          <Table
            dataSource={dataSourcePremises}
            columns={premiseColumns}
            pagination={false}
            bordered
          />
        </Row>
      </Row>
    );
  }
}

FloorTables.propTypes = {
  buildingData: PropTypes.objectOf(PropTypes.any).isRequired,
  updateBuilding: PropTypes.func.isRequired,
  item: PropTypes.objectOf(PropTypes.any).isRequired,
  isViewMode: PropTypes.bool.isRequired,
};

export default FloorTables;
