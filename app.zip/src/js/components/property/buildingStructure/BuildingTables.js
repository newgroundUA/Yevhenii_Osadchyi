import React from 'react';
import PropTypes from 'prop-types';
import { Button, Table, Row, Modal } from 'antd';

import {
  BUILDING_COLUMNS as buildingColumns,
  GENERAL_FLOORS_COLUMNS as floorColumns,
} from '../../../models/formFields/property/BuildingStructureTables';

import FloorFormContainer from '../../../containers/property/forms/building/FloorFormContainer';

class BuildingTables extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      dialogOpen: false,
    };
  }

  handleToggleDialog = (isOpened) => {
    if (isOpened !== undefined) this.setState({ dialogOpen: isOpened });
    else this.setState((prevState) => ({ dialogOpen: !prevState.dialogOpen }));
  };

  onFloorCreated = () => {
    this.handleToggleDialog(false);
    this.props.updateBuilding();
  };

  render() {
    const { item, isViewMode } = this.props;

    const dataSourceBuildings = [
      {
        key: item.buildingData,
        name: item.fullName,
        num: item.accountingItemId,
        letterBTI: item.buildingBTILetter,
        amountFloors: item.floorAmount,
        premiseGroup: item.groupsOfPremisesCount,
        premises: item.premisesCount,
        fields: item.fieldsCount,
      },
    ];

    const dataSourceFloors = (item.floors || []).map((floor) => ({
      key: floor.guid,
      name: floor.floorName,
      type: floor.floorType !== null ? floor.floorType.name : '',
      livingSpace: floor.floorLivingSpace,
      unLivingSpace: floor.floorUnlivingSpace,
      usefulUnLivingSpace: floor.floorUnlivingSpace,
      technicalSpace: floor.floorTechSpace,
      floorCommonSpace: floor.floorCommonSpace,
      groupOfPremise: (floor.groupOfPremises || []).length,
      premises: (floor.premises || []).length,
    }));

    return (
      <Row>
        <Modal
          title="Картка поверху"
          visible={this.state.dialogOpen}
          width={1300}
          footer={false}
          onCancel={() => {
            this.handleToggleDialog(false);
          }}
        >
          <Row>
            {this.state.dialogOpen && (
              <FloorFormContainer
                buildingData={this.props.buildingData}
                match={{ params: { mode: 'create' } }}
                onFloorCreated={this.onFloorCreated}
                visible={this.state.dialogOpen}
                inModal
              />
            )}
          </Row>
        </Modal>
        <Row style={{ marginBottom: '1rem' }}>
          <Button
            onClick={() => {
              this.handleToggleDialog();
            }}
            disabled={isViewMode}
          >
            Додати поверх
          </Button>
        </Row>
        <Row>Параметри будівлі:</Row>
        <Row style={{ marginBottom: '1rem' }}>
          <Table
            dataSource={dataSourceBuildings}
            columns={buildingColumns}
            pagination={false}
            bordered
          />
        </Row>
        <Row>Поверхи:</Row>
        <Row>
          <Table dataSource={dataSourceFloors} columns={floorColumns} pagination={false} bordered />
        </Row>
      </Row>
    );
  }
}

BuildingTables.propTypes = {
  buildingData: PropTypes.objectOf({
    guid: PropTypes.string.isRequired,
    versionId: PropTypes.string.isRequired,
  }).isRequired,
  item: PropTypes.objectOf(PropTypes.any).isRequired,
  updateBuilding: PropTypes.func.isRequired,
  isViewMode: PropTypes.bool.isRequired,
};

export default BuildingTables;
