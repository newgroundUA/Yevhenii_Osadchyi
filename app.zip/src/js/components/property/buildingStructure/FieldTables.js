import React from 'react';
import PropTypes from 'prop-types';
import { Table, Row, Modal, Button } from 'antd';

import { FIELD as fieldColumns } from '../../../models/formFields/property/BuildingStructureTables';
import FieldsFormContainer from '../../../containers/property/forms/building/FieldsFormContainer';

class FieldTables extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      dialogOpen: false,
      openFields: false,
    };
  }

  handleToggleDialog = (isOpened) => {
    if (isOpened !== undefined) this.setState({ dialogOpen: isOpened });
    else this.setState((prevState) => ({ dialogOpen: !prevState.dialogOpen }));
  };

  onCreated = () => {
    this.handleToggleDialog(false);
    this.props.updateBuilding();
  };

  handleOpenForm = (formName) => {
    this.setState({
      openFields: formName === 'openFields',
    });
    this.handleToggleDialog();
  };

  render() {
    const { item, isViewMode } = this.props;

    const dataSourceField = [
      {
        key: item.guid,
        name: item.fullName,
        num: '',
        length: item.fieldLength,
        width: item.fieldWidth,
        area: item.commonFieldSpace,
      },
    ];

    return (
      <Row>
        <Modal
          title="Картка частини приміщення"
          visible={this.state.dialogOpen}
          width={1300}
          footer={false}
          onCancel={() => {
            this.handleToggleDialog(false);
          }}
        >
          <Row>
            {this.state.dialogOpen && (
              <Row>
                {this.state.openFields ? (
                  <FieldsFormContainer
                    match={{ params: { mode: 'edit', guid: item.guid } }}
                    onFieldCreated={this.onCreated}
                    inModal
                  />
                ) : (
                  false
                )}
              </Row>
            )}
          </Row>
        </Modal>
        <Row style={{ marginBottom: '1rem' }}>
          <Button
            onClick={() => {
              this.handleOpenForm('openFields');
            }}
            disabled={isViewMode}
          >
            Редагувати частину приміщення
          </Button>
        </Row>
        <Row>Параметри частини приміщення:</Row>
        <Row style={{ marginBottom: '1rem' }}>
          <Table dataSource={dataSourceField} columns={fieldColumns} pagination={false} bordered />
        </Row>
      </Row>
    );
  }
}

FieldTables.propTypes = {
  item: PropTypes.objectOf(PropTypes.any).isRequired,
  updateBuilding: PropTypes.func.isRequired,
  isViewMode: PropTypes.bool.isRequired,
};

export default FieldTables;
