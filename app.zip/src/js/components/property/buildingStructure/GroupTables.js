import React from 'react';
import PropTypes from 'prop-types';
import { Table, Row, Modal, Button } from 'antd';

import {
  GROUP_OF_PREMISES as groupColumns,
  GENERAL_PREMISES as premiseColumns,
} from '../../../models/formFields/property/BuildingStructureTables';

import PremiseGroupFormContainer from '../../../containers/property/forms/building/PremiseGroupFormContainer';

class GroupTables extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      dialogOpen: false,
      openEditGroup: false,
    };
  }

  handleToggleDialog = (isOpened) => {
    if (isOpened !== undefined) this.setState({ dialogOpen: isOpened });
    else this.setState((prevState) => ({ dialogOpen: !prevState.dialogOpen }));
  };

  onCreated = () => {
    this.handleToggleDialog(false);
    this.props.updateBuilding();
  };

  handleOpenForm = (formName) => {
    this.setState({
      openEditGroup: formName === 'openEditGroup',
    });
    this.handleToggleDialog();
  };

  render() {
    const { item, data, isViewMode } = this.props;

    const parentFloor = data[item.parent];
    const availablePremises = (parentFloor.premises || [])
      .filter((el) => !el.groupOfPremise)
      .map((el) => ({ ...el, name: el.fullName }));

    const dataSourceGroups = [
      {
        key: item.guid,
        num: item.groupNumber,
        premisesCount: (item.premises || []).length,
        livingSpace: item.groupLivingSpace,
        unLivingSpace: item.groupUnlivingSpace,
        usefulUnLivingSpace: item.groupUsefullUnlivingSpace,
      },
    ];

    const dataSourcePremises = (item.premises || []).map((premise) => ({
      key: premise.guid,
      code: premise.accountingItemId,
      name: premise.fullName,
      type: premise.premiseConstruction.name,
      area: premise.premiseSpace,
      usefulUnLivingSpace: premise.usefullSpace,
      socialUseSpace: premise.commonUse ? 'Так' : 'Ні',
      decoration: premise.premiseEquip.name,
    }));

    return (
      <Row>
        <Modal
          title="Картка групи приміщень"
          visible={this.state.dialogOpen}
          width={1300}
          footer={false}
          onCancel={() => {
            this.handleToggleDialog(false);
          }}
        >
          <Row>
            {this.state.dialogOpen && (
              <Row>
                {this.state.openEditGroup ? (
                  <PremiseGroupFormContainer
                    floorItem={parentFloor}
                    match={{ params: { mode: 'edit', guid: item.guid } }}
                    onPremiseGroupCreated={this.onCreated}
                    availablePremises={availablePremises}
                    inModal
                  />
                ) : (
                  false
                )}
              </Row>
            )}
          </Row>
        </Modal>
        <Row style={{ marginBottom: '1rem' }}>
          <Button
            onClick={() => {
              this.handleOpenForm('openEditGroup');
            }}
            disabled={isViewMode}
          >
            Редагувати групу приміщень
          </Button>
        </Row>
        <Row>Параметри групи:</Row>
        <Row style={{ marginBottom: '1rem' }}>
          <Table dataSource={dataSourceGroups} columns={groupColumns} pagination={false} bordered />
        </Row>
        <Row>Приміщення:</Row>
        <Row>
          <Table
            dataSource={dataSourcePremises}
            columns={premiseColumns}
            pagination={false}
            bordered
          />
        </Row>
      </Row>
    );
  }
}

GroupTables.propTypes = {
  item: PropTypes.objectOf(PropTypes.any).isRequired,
  updateBuilding: PropTypes.func.isRequired,
  data: PropTypes.objectOf(PropTypes.any).isRequired,
  isViewMode: PropTypes.bool.isRequired,
};

export default GroupTables;
