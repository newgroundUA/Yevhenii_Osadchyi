import React from 'react';
import PropTypes from 'prop-types';
import { Button, Table, Row, Modal } from 'antd';

import {
  PREMISES as premiseColumns,
  FIELDS as fieldsColumns,
} from '../../../models/formFields/property/BuildingStructureTables';

import FieldsFormContainer from '../../../containers/property/forms/building/FieldsFormContainer';
import PremisesFormContainer from '../../../containers/property/forms/building/PremisesFormContainer';

class PremiseTables extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      dialogOpen: false,
      openFields: false,
      openEditPremise: false,
    };
  }

  handleToggleDialog = (isOpened) => {
    if (isOpened !== undefined) this.setState({ dialogOpen: isOpened });
    else this.setState((prevState) => ({ dialogOpen: !prevState.dialogOpen }));
  };

  onFieldCreated = () => {
    this.handleToggleDialog(false);
    this.props.updateBuilding();
  };

  handleOpenForm = (formName) => {
    this.setState({
      openFields: formName === 'openFields',
      openEditPremise: formName === 'openEditPremise',
    });
    this.handleToggleDialog();
  };

  render() {
    const { item, data, isViewMode, buildingData } = this.props;

    const dataSourcePremise = [
      {
        key: item.guid,
        num: item.fullName,
        type: item.premiseConstruction.name,
        group: data[item.parentGroup] ? data[item.parentGroup].groupName : '',
        area: item.premiseSpace,
        socialUseSpaceBool: item.commonUse ? 'Так' : 'Ні',
        unLivingSpace: item.usefullSpace,
        premisePurpose: (item.premisePurpose || {}).name,
        socialUseSpace: item.premiseSpace,
      },
    ];

    const dataSourceFields = (item.fields || []).map((field) => ({
      key: field.guid,
      num: '',
      name: field.fullName,
      area: field.commonFieldSpace,
      length: field.fieldLength,
      width: field.fieldWidth,
      info: field.extraFeatureDescription,
    }));

    const floorData = data[item.parent];

    return (
      <Row>
        <Modal
          title="Картка приміщення"
          visible={this.state.dialogOpen}
          width={1300}
          footer={false}
          onCancel={() => {
            this.handleToggleDialog(false);
          }}
        >
          <Row>
            {this.state.dialogOpen && (
              <Row>
                {this.state.openFields ? (
                  <FieldsFormContainer
                    premiseItem={this.props.item}
                    match={{ params: { mode: 'create' } }}
                    onFieldCreated={this.onFieldCreated}
                    inModal
                  />
                ) : (
                  false
                )}
                {this.state.openEditPremise ? (
                  <PremisesFormContainer
                    floorItem={floorData}
                    match={{ params: { mode: 'edit', guid: item.guid } }}
                    onPremiseCreated={this.onFieldCreated}
                    inModal
                    buildingData={buildingData}
                  />
                ) : (
                  false
                )}
              </Row>
            )}
          </Row>
        </Modal>

        <Row style={{ marginBottom: '1rem' }}>
          <Button
            onClick={() => {
              this.handleOpenForm('openEditPremise');
            }}
            disabled={isViewMode}
          >
            Редагувати приміщення
          </Button>
          <Button
            onClick={() => {
              this.handleOpenForm('openFields');
            }}
            disabled={isViewMode}
          >
            Додати частину приміщення
          </Button>
        </Row>
        <Row>Параметри приміщення:</Row>
        <Row style={{ marginBottom: '1rem' }}>
          <Table
            dataSource={dataSourcePremise}
            columns={premiseColumns}
            pagination={false}
            bordered
          />
        </Row>
        <Row>Частини приміщеннь:</Row>
        <Row>
          <Table
            dataSource={dataSourceFields}
            columns={fieldsColumns}
            pagination={false}
            bordered
          />
        </Row>
      </Row>
    );
  }
}

PremiseTables.propTypes = {
  item: PropTypes.objectOf(PropTypes.any).isRequired,
  data: PropTypes.objectOf(PropTypes.object).isRequired,
  updateBuilding: PropTypes.func.isRequired,
  isViewMode: PropTypes.bool.isRequired,
  buildingData: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default PremiseTables;
