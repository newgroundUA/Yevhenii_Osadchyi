import React from 'react';
import PropTypes from 'prop-types';
import AccountingItemLabel from './AccountingItemLabel';

const AccountingItemsLabelsList = ({ accountingItems }) => (
  <div>
    {(accountingItems || []).map((el) => (
      <AccountingItemLabel key={el.guid} accountingItemData={el} />
    ))}
  </div>
);

AccountingItemsLabelsList.defaultProps = {
  accountingItems: [],
};

AccountingItemsLabelsList.propTypes = {
  accountingItems: PropTypes.arrayOf(PropTypes.object),
};

export default AccountingItemsLabelsList;
