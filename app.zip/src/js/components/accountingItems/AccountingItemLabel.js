import React from 'react';
import PropTypes from 'prop-types';
import { getAccountingItemLabel } from '../../helpers/entities/accountingItem';

const AccountingItemLabel = ({ accountingItemData }) => (
  <div>
    {getAccountingItemLabel({
      accountingItem: accountingItemData,
    })}
  </div>
);

AccountingItemLabel.defaultProps = {
  accountingItemData: {},
};

AccountingItemLabel.propTypes = {
  accountingItemData: PropTypes.objectOf(PropTypes.any),
};

export default AccountingItemLabel;
