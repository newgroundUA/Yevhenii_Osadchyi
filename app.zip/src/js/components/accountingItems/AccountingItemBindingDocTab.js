import React, { PureComponent } from 'react';
import { Modal, Button, Row, Table, Icon } from 'antd';
import _get from 'lodash/get';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import BindingDocumentsFormFields, {
  cascaderStoreKey,
} from '../../containers/documents/common/bindingDocumentComponent/BindingDocumentFormFields';
import { liveSearchDocuments } from '../../actions/modules/documents/bindingDocumentsActions';
import {
  getBoundToPropertyDocumentToFE,
  getLiveSearchedDocumentToFE,
  liveSearchColumns,
} from '../../models/formFields/documents/bindingDocumentFields';
import LockDocumentModal from '../../containers/documents/common/modals/LockDocumentModal';
import * as RouteNames from '../../constants/RouteNames';
import GeneralControlButtons from '../../containers/documents/common/GeneralControlButtons';
import DocumentCascader from '../../containers/documents/common/DocumentCascader';
import LiveSearchFieldsWithTable from '../../containers/documents/common/LiveSearchFieldsWithTable';
import Separator from '../common/form/Separator';
import { defStoreKey } from '../../helpers/reducers/documents/commonActionsHandlers';
import {
  bindDocumentToAccountingItem,
  getAccountingItemBoundDocuments,
  unBindDocumentToAccountingItem,
} from '../../actions/modules/accountingItem/bindingDocuments';
import ViewDocumentModal from '../../containers/documents/common/bindingDocumentComponent/ViewDocumentModal';

class AccountingItemBindingDocTab extends PureComponent {
  constructor(props) {
    super(props);

    this.state = {
      lockDocumentModalIsOpen: false,
      boundDocuments: [],
      viewDocumentModal: false,
      modalData: null,
    };
  }

  componentDidMount() {
    this.props
      .getAccountingItemBoundDocuments({ guid: this.props.curGuid })
      .then((res) => this.setState(() => ({ boundDocuments: res.data || [] })));
  }

  handleLockDocumentModal = () => {
    this.setState((prevState) => ({
      lockDocumentModalIsOpen: !prevState.lockDocumentModalIsOpen,
    }));
  };

  boundDocumentsColumns = () => [
    {
      title: 'Тип документа',
      dataIndex: 'documentType',
    },
    {
      title: 'Серія та номер',
      dataIndex: 'docNumber',
    },
    {
      title: 'Чинність',
      dataIndex: 'validityStatus',
    },
    {
      title: 'Короткий опис',
      dataIndex: 'docDescription',
      width: 300,
    },
    {
      title: 'Дата',
      dataIndex: 'docDate',
    },
    {
      title: 'Дія',
      dataIndex: 'dataForActions',
      render: this.getOperationButtons,
    },
  ];

  getOperationButtons = (actionData) => (
    <span style={{ whiteSpace: 'nowrap' }} key={actionData.guid}>
      <Icon
        type="eye"
        style={{ fontSize: '20px', marginRight: '10px', cursor: 'pointer' }}
        onClick={this.openDocumentInModal(actionData)}
      />
      <Button onClick={this.handleUnBind(actionData)}>
        <Icon
          type="close"
          style={{ fontSize: '20px', color: '#e31b1c', fontWeight: '1000', cursor: 'pointer' }}
        />
      </Button>
    </span>
  );

  handleUnBind = (data) => () => {
    this.props
      .unBindDocumentToAccountingItem({
        accountingItem: this.props.curGuid,
        documentGuid: data.guid,
      })
      .then((res) => this.setState(() => ({ boundDocuments: res.data || [] })));
  };

  getBoundDocuments = () =>
    this.state.boundDocuments.map((data) => getBoundToPropertyDocumentToFE(data));

  setBoundDocuments = (data) => {
    this.props
      .bindDocumentToAccountingItem({
        accountingItem: this.props.curGuid,
        documentGuid: data.guid,
      })
      .then((res) => {
        this.setState(() => ({
          boundDocuments: res.data || [],
        }));
      });
  };

  openDocumentInModal = (modalData) => () => {
    this.setState({
      viewDocumentModal: true,
      modalData,
    });
  };

  handleCloseModal = () => {
    this.setState({
      viewDocumentModal: false,
    });
  };

  render() {
    const { formParam, form, curGuid } = this.props;
    const { modalData } = this.state;
    const locDocVersionId = _get(formParam, ['createdForm', 'versionId']);

    return (
      <Row>
        <Modal
          title="Блокування документа"
          visible={this.state.lockDocumentModalIsOpen}
          onCancel={this.handleLockDocumentModal}
          footer={null}
          width="1000px"
          maskClosable={false}
          destroyOnClose
        >
          <LockDocumentModal
            handleCloseModal={this.handleLockDocumentModal}
            childrenDocuments={formParam.createdForm.childrenDocuments}
            guid={curGuid}
            versionId={locDocVersionId}
            updateForm={() => {}} // lockDocToGeneralDocument
            loadDocument={() => {}} // this.props.getGeneralDocument(this.curGuid, this.props.storeKey)
          />
        </Modal>
        <div>
          <Row>
            <GeneralControlButtons
              form={form}
              guid={curGuid}
              documentType="PROPERTY"
              urlToEditMode={`/${RouteNames.PROPERTY}/${this.props.routeName}/edit/${curGuid}`}
              urlToRegister={`/${RouteNames.PROPERTY}/${RouteNames.REGISTER}`}
            />
          </Row>
          {`Тип документа`}
          <div className="global_mb20 df">
            <div style={{ width: '100%' }} className="global_mr20">
              <DocumentCascader resultAfterStep="2" />
            </div>
            <Button
              style={{ marginRight: '1.5rem' }}
              type="primary"
              onClick={this.handleCreate}
              disabled={!this.props.cascaderValue.data}
            >
              {`Новий документ`}
            </Button>
          </div>
          <LiveSearchFieldsWithTable
            LiveSearchFormFields={BindingDocumentsFormFields}
            liveSearchAction={this.props.liveSearchDocuments}
            bindAction={this.setBoundDocuments}
            parseToFE={getLiveSearchedDocumentToFE}
            title="Пошук документів"
            columns={liveSearchColumns}
          />
        </div>
        <div className="global_mt20">
          <Separator text="Зв'язані документи" />
          <Table
            rowKey="guid"
            columns={this.boundDocumentsColumns()}
            dataSource={this.getBoundDocuments()}
            pagination={false}
          />
        </div>
        <Modal
          visible={this.state.viewDocumentModal}
          footer={false}
          onCancel={this.handleCloseModal}
          width="95%"
          maskClosable={false}
          destroyOnClose
        >
          {modalData &&
            modalData.documentType && (
              <ViewDocumentModal
                documentType={modalData.documentType}
                storeKey={cascaderStoreKey}
                guid={modalData.guid}
              />
            )}
        </Modal>
      </Row>
    );
  }
}

AccountingItemBindingDocTab.propTypes = {
  form: PropTypes.objectOf(PropTypes.any).isRequired,
  curGuid: PropTypes.string.isRequired,
  routeName: PropTypes.string.isRequired,

  formParam: PropTypes.shape().isRequired,
  cascaderValue: PropTypes.shape({
    data: PropTypes.object,
  }).isRequired,

  getAccountingItemBoundDocuments: PropTypes.func.isRequired,
  bindDocumentToAccountingItem: PropTypes.func.isRequired,
  unBindDocumentToAccountingItem: PropTypes.func.isRequired,
  liveSearchDocuments: PropTypes.func.isRequired,
};

const mapStateToProps = (state, { stepGuid }) => ({
  formParam: state.property.propertyBuildings.forms.buildingForm,
  cascaderValue: state.documentForms.documentCascader.selectedValue[stepGuid || defStoreKey],
});

const CONTAINER_ACTIONS = {
  getAccountingItemBoundDocuments,
  bindDocumentToAccountingItem,
  unBindDocumentToAccountingItem,
  liveSearchDocuments,
};

export default connect(mapStateToProps, CONTAINER_ACTIONS)(AccountingItemBindingDocTab);
