import React from 'react';
import PropTypes from 'prop-types';
import { getCounterpartyLabel } from '../../helpers/entities/countrerparty';

const CounterpartyLabel = ({ counterpartyData }) => (
  <div>
    {getCounterpartyLabel({
      counterparty: counterpartyData,
    })}
  </div>
);

CounterpartyLabel.defaultProps = {
  counterpartyData: {},
};

CounterpartyLabel.propTypes = {
  counterpartyData: PropTypes.objectOf(PropTypes.any),
};

export default CounterpartyLabel;
