import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Form, Row, Button, message } from 'antd';

import selector from '../../selectors/modules/bankDetailsSelector';
import * as classifiersActions from '../../actions/classifiersActions';
import * as commonCounterpartiesActions from '../../actions/modules/counterparties/commonActions';
import { BANK_DETAILS_FORM_CONTAINER } from '../../constants/ContainerNames';
import { mapFormItems } from '../../helpers/formHelpers/mapFormHelper';
import { bankDetailsFields } from '../../models/formFields/counterparty/bankDetailsFields';
import { getCounterpartyLabel, getCounterpartyITN } from '../../helpers/entities/countrerparty';
import { getObjGuidAndVersionId } from '../../helpers/commonUtils';

const CONTAINER_ACTIONS = {
  ...classifiersActions,
  ...commonCounterpartiesActions,
};

class BankDetailsForm extends Component {
  componentDidMount() {
    const {
      loadClassifiersForContainer,
      accountOwner: counterparty,
      form,
      bankDetail,
    } = this.props;

    loadClassifiersForContainer(BANK_DETAILS_FORM_CONTAINER);

    let fields = {
      name: getCounterpartyLabel({
        counterparty,
        withoutType: true,
      }),
      edrpou: getCounterpartyITN({
        counterparty,
      }),
    };

    if (bankDetail.guid) {
      fields = {
        ...fields,
        mfo: bankDetail.bank.guid,
        account: bankDetail.account,
        notes: bankDetail.notes,
      };
    }

    form.setFieldsValue(fields);
  }

  onSave = () => {
    const {
      form,
      accountOwner,
      putBankDetails,
      postBankDetails,
      bankDetail,
      classifiers,
      onSave,
    } = this.props;

    form.validateFields((err, val) => {
      if (!err) {
        const readResponse = (res) => {
          if (res.statusCode === 200) {
            message.success('Форма успішно збереглася.');
            form.resetFields();
            onSave();
          } else {
            message.error(res.errors ? res.errors.message : 'Виникла помилка при збереженні.');
          }
        };

        const post = {
          account: val.account,
          accountOwner: getObjGuidAndVersionId(accountOwner),
          bank: classifiers.banks.find((el) => el.guid === val.mfo),
          notes: val.notes,
        };

        if (bankDetail.guid) {
          const put = {
            ...bankDetail,
            ...post,
          };
          putBankDetails(put).then(readResponse);
        } else {
          postBankDetails(post).then(readResponse);
        }
      }
    });
  };

  onCancel = () => {
    this.props.form.resetFields();
    this.props.onCancel();
  };

  render() {
    const { classifiers, form } = this.props;

    return (
      <Row>
        {mapFormItems({
          fields: bankDetailsFields,
          form,
          classifiers,
        })}
        <Button.Group style={{ margin: '0 0 15px 15px' }}>
          <Button type="primary" onClick={this.onSave}>
            Додати
          </Button>
          <Button type="danger" onClick={this.onCancel}>
            Відміна
          </Button>
        </Button.Group>
      </Row>
    );
  }
}

BankDetailsForm.defaultProps = {
  bankDetail: {},
};

BankDetailsForm.propTypes = {
  classifiers: PropTypes.objectOf(PropTypes.array).isRequired,
  loadClassifiersForContainer: PropTypes.func.isRequired,
  postBankDetails: PropTypes.func.isRequired,
  putBankDetails: PropTypes.func.isRequired,
  onSave: PropTypes.func.isRequired,
  onCancel: PropTypes.func.isRequired,
  bankDetail: PropTypes.objectOf(PropTypes.any),
  accountOwner: PropTypes.objectOf(PropTypes.any).isRequired,
  form: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default connect(selector, CONTAINER_ACTIONS)(Form.create()(BankDetailsForm));
