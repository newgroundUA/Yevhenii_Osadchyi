import React from 'react';
import PropTypes from 'prop-types';
import CounterpartyLabel from './CounterpartyLabel';

const CounterpartiesLabelsList = ({ counterparties }) => (
  <div>
    {(counterparties || []).map((el) => (
      <CounterpartyLabel key={el.guid || el.key} counterpartyData={el} />
    ))}
  </div>
);

CounterpartiesLabelsList.defaultProps = {
  counterparties: [],
};

CounterpartiesLabelsList.propTypes = {
  counterparties: PropTypes.arrayOf(PropTypes.object),
};

export default CounterpartiesLabelsList;
