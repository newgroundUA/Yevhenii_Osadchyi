import React, { PureComponent } from 'react';
import { Modal, Button, Row, Table, Icon } from 'antd';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import BindingDocumentsFormFields, {
  cascaderStoreKey,
} from '../../containers/documents/common/bindingDocumentComponent/BindingDocumentFormFields';
import { liveSearchDocuments } from '../../actions/modules/documents/bindingDocumentsActions';
import {
  getBoundToPropertyDocumentToFE,
  getLiveSearchedDocumentToFE,
  liveSearchColumns,
} from '../../models/formFields/documents/bindingDocumentFields';
import * as RouteNames from '../../constants/RouteNames';
import GeneralControlButtons from '../../containers/documents/common/GeneralControlButtons';
import LiveSearchFieldsWithTable from '../../containers/documents/common/LiveSearchFieldsWithTable';
import Separator from '../common/form/Separator';
import { defStoreKey } from '../../helpers/reducers/documents/commonActionsHandlers';
import {
  bindDocumentToCounterparty,
  getCounterpartyBoundDocuments,
  unBindDocumentToCounterparty,
} from '../../actions/modules/counterparties/bindingDocuments';
import ViewDocumentModal from '../../containers/documents/common/bindingDocumentComponent/ViewDocumentModal';

class CounterpartyBindingDocTab extends PureComponent {
  constructor(props) {
    super(props);

    this.state = {
      boundDocuments: [],
      viewDocumentModal: false,
      modalData: null,
    };
  }

  componentDidMount() {
    this.props
      .getCounterpartyBoundDocuments({ counterpartyGuid: this.props.curGuid })
      .then((res) => this.setState(() => ({ boundDocuments: res.data || [] })));
  }

  boundDocumentsColumns = () => [
    {
      title: 'Тип документа',
      dataIndex: 'documentType',
    },
    {
      title: 'Серія та номер',
      dataIndex: 'docNumber',
    },
    {
      title: 'Чинність',
      dataIndex: 'validityStatus',
    },
    {
      title: 'Короткий опис',
      dataIndex: 'docDescription',
      width: 300,
    },
    {
      title: 'Дата',
      dataIndex: 'docDate',
    },
    {
      title: 'Дія',
      dataIndex: 'dataForActions',
      render: this.getOperationButtons,
    },
  ];

  getOperationButtons = (actionData) => (
    <span style={{ whiteSpace: 'nowrap' }} key={actionData.guid}>
      <Icon
        type="eye"
        style={{ fontSize: '20px', marginRight: '10px', cursor: 'pointer' }}
        onClick={this.openDocumentInModal(actionData)}
      />
      <Button onClick={this.handleUnBind(actionData)}>
        <Icon
          type="close"
          style={{ fontSize: '20px', color: '#e31b1c', fontWeight: '1000', cursor: 'pointer' }}
        />
      </Button>
    </span>
  );

  handleUnBind = (data) => () => {
    this.props
      .unBindDocumentToCounterparty({
        counterpartyGuid: this.props.curGuid,
        documentGuid: data.guid,
      })
      .then((res) => this.setState(() => ({ boundDocuments: res.data || [] })));
  };

  getBoundDocuments = () =>
    this.state.boundDocuments.map((data) => getBoundToPropertyDocumentToFE(data));

  setBoundDocuments = (data) => {
    this.props
      .bindDocumentToCounterparty({
        counterpartyGuid: this.props.curGuid,
        documentGuid: data.guid,
      })
      .then((res) => {
        this.setState(() => ({
          boundDocuments: res.data || [],
        }));
      });
  };

  openDocumentInModal = (modalData) => () => {
    this.setState({
      viewDocumentModal: true,
      modalData,
    });
  };

  handleCloseModal = () => {
    this.setState({
      viewDocumentModal: false,
    });
  };

  render() {
    const { form, curGuid } = this.props;
    const { modalData } = this.state;

    return (
      <Row>
        <div>
          <Row>
            <GeneralControlButtons
              form={form}
              guid={curGuid}
              documentType="PROPERTY"
              urlToEditMode={`/${RouteNames.COUNTERPARTIES}/${
                this.props.routeName
              }/edit/${curGuid}`}
              urlToRegister={`/${RouteNames.COUNTERPARTIES}/${RouteNames.REGISTER}`}
            />
          </Row>
          <LiveSearchFieldsWithTable
            LiveSearchFormFields={BindingDocumentsFormFields}
            liveSearchAction={this.props.liveSearchDocuments}
            bindAction={this.setBoundDocuments}
            parseToFE={getLiveSearchedDocumentToFE}
            title="Пошук документів"
            columns={liveSearchColumns}
          />
        </div>
        <div className="global_mt20">
          <Separator text="Зв'язані документи" />
          <Table
            rowKey="guid"
            columns={this.boundDocumentsColumns()}
            dataSource={this.getBoundDocuments()}
            pagination={false}
          />
        </div>
        <Modal
          visible={this.state.viewDocumentModal}
          footer={false}
          onCancel={this.handleCloseModal}
          width="95%"
          maskClosable={false}
          destroyOnClose
        >
          {modalData &&
            modalData.documentType && (
              <ViewDocumentModal
                documentType={modalData.documentType}
                storeKey={cascaderStoreKey}
                guid={modalData.guid}
              />
            )}
        </Modal>
      </Row>
    );
  }
}

CounterpartyBindingDocTab.propTypes = {
  form: PropTypes.objectOf(PropTypes.any).isRequired,
  curGuid: PropTypes.string.isRequired,
  routeName: PropTypes.string.isRequired,

  getCounterpartyBoundDocuments: PropTypes.func.isRequired,
  bindDocumentToCounterparty: PropTypes.func.isRequired,
  unBindDocumentToCounterparty: PropTypes.func.isRequired,
  liveSearchDocuments: PropTypes.func.isRequired,
};

const mapStateToProps = (state, { stepGuid }) => ({
  formParam: state.property.propertyBuildings.forms.buildingForm,
  cascaderValue: state.documentForms.documentCascader.selectedValue[stepGuid || defStoreKey],
});

const CONTAINER_ACTIONS = {
  getCounterpartyBoundDocuments,
  bindDocumentToCounterparty,
  unBindDocumentToCounterparty,
  liveSearchDocuments,
};

export default connect(mapStateToProps, CONTAINER_ACTIONS)(CounterpartyBindingDocTab);
