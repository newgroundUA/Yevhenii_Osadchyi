import React from 'react';
import PropTypes from 'prop-types';
import { getDocumentLabel } from '../../helpers/entities/documents';

const DocumentLabel = ({ documentData }) => (
  <div>
    {getDocumentLabel({
      documentData,
    })}
  </div>
);

DocumentLabel.defaultProps = {
  documentData: {},
};

DocumentLabel.propTypes = {
  documentData: PropTypes.objectOf(PropTypes.any),
};

export default DocumentLabel;
