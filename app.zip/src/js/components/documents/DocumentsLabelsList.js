import React from 'react';
import PropTypes from 'prop-types';
import DocumentLabel from './DocumentLabel';

const DocumentsLabelsList = ({ documents }) => (
  <div>{(documents || []).map((el) => <DocumentLabel key={el.guid} documentData={el} />)}</div>
);

DocumentsLabelsList.defaultProps = {
  documents: [],
};

DocumentsLabelsList.propTypes = {
  documents: PropTypes.arrayOf(PropTypes.object),
};

export default DocumentsLabelsList;
