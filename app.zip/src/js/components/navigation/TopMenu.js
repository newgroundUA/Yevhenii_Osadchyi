import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Menu } from 'antd';
import { Link } from 'react-router-dom';

// import findTranslation from '../../api/vocabulary';

class TopMenu extends Component {
  constructor(props) {
    super(props);
    this.state = {
      currentElement: this.props.route,
    };
  }

  componentWillReceiveProps(nextProps) {
    this.setState({
      currentElement: nextProps.route,
    });
  }

  handleClick = (e) => {
    this.setState({
      currentElement: e.key,
    });
  };

  render() {
    const { items } = this.props;
    return (
      <div className="top-menu">
        <ul className="top-menu__items">
          <Menu
            onClick={this.handleClick}
            selectedKeys={[this.state.currentElement]}
            mode="horizontal"
          >
            {Object.values(items).map((el) => (
              <Menu.Item key={el.route}>
                <Link to={`/${el.route}`}>{el.text}</Link>
              </Menu.Item>
            ))}
          </Menu>
        </ul>
      </div>
    );
  }
}

TopMenu.propTypes = {
  items: PropTypes.objectOf(PropTypes.object).isRequired,
  route: PropTypes.string.isRequired,
};

export default TopMenu;
