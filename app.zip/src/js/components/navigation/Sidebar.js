import React from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import { Menu } from 'antd';

const SubMenu = Menu.SubMenu;

class Sidebar extends React.Component {
  state = {
    openKeys: [],
    selectedKeys: [],
  };

  rootSubmenuKeys = [];

  componentDidMount() {
    this.setSidebarSettings(this.props);
  }

  componentWillReceiveProps(nextProps) {
    this.setSidebarSettings(nextProps);
  }

  setSidebarSettings = (props) => {
    const { routeComponent, items } = props;

    this.rootSubmenuKeys = Object.keys(items).filter((el) => items[el].parent === undefined);
    const currentElement = Object.values(items).find(
      (el) => el.route && el.route.replace('/create', '') === routeComponent,
    ) || { parent: '', route: '' };
    let openKeys;

    if (currentElement.parent === undefined) {
      openKeys = currentElement.route ? currentElement.route.replace('/create', '') : [''];
    } else {
      openKeys = currentElement.parent;
    }

    this.setState({
      openKeys: [`${openKeys}`],
      selectedKeys: [`${currentElement.route.replace('/create', '')}`],
    });
  };

  onOpenChange = (openKeys) => {
    const latestOpenKey = openKeys.find((key) => this.state.openKeys.indexOf(key) === -1);
    if (this.rootSubmenuKeys.indexOf(latestOpenKey) === -1) {
      this.setState({ openKeys });
    } else {
      this.setState({
        openKeys: latestOpenKey ? [latestOpenKey] : [],
      });
    }
  };

  renderSubMenu = (subMenuId) => {
    const { items } = this.props;

    return (
      <SubMenu key={subMenuId} title={<span>{items[subMenuId].text}</span>}>
        {items[subMenuId].children.map((childId) => this.renderMenuItems(childId))}
      </SubMenu>
    );
  };

  renderMenuItems = (MenuId) => {
    const { items, routePage } = this.props;

    return (
      <Menu.Item key={MenuId}>
        <Link to={`/${routePage}/${items[MenuId].route}`}>
          <span>{items[MenuId].text}</span>
        </Link>
      </Menu.Item>
    );
  };

  render() {
    const { items } = this.props;

    const { openKeys, selectedKeys } = this.state;

    return (
      <Menu
        mode="inline"
        openKeys={openKeys}
        onOpenChange={this.onOpenChange}
        selectedKeys={selectedKeys}
        style={{ width: 220 }}
      >
        {this.rootSubmenuKeys.map(
          (MenuId) =>
            items[MenuId].children && items[MenuId].children.length > 0
              ? this.renderSubMenu(MenuId)
              : this.renderMenuItems(MenuId),
        )}
      </Menu>
    );
  }
}

Sidebar.propTypes = {
  items: PropTypes.objectOf(PropTypes.object).isRequired,
  routePage: PropTypes.string.isRequired,
  // routeComponent: PropTypes.string.isRequired,
};

export default Sidebar;
