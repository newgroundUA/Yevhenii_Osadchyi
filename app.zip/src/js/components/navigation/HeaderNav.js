import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Menu, Icon } from 'antd';
import { Link } from 'react-router-dom';
import * as routes from '../../constants/RouteNames';
import { clearDkvStorage } from '../../helpers/OAuth2Service';

const SubMenu = Menu.SubMenu;
const MenuItem = Menu.Item;

class HeaderNav extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedMenuItem: this.props.route,
    };
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.route !== nextProps.route) {
      this.setState(() => ({
        selectedMenuItem: nextProps.route,
      }));
    }
  }

  handleMenuClick = (e) => {
    this.setState({
      selectedMenuItem: e.key,
    });
  };

  handleLogoutClick = () => {
    const { history, doLogOut } = this.props;
    doLogOut();
    clearDkvStorage();
    history.push('/');
  };

  render() {
    return (
      <ul className="navigation">
        <Menu
          onClick={this.handleMenuClick}
          selectedKeys={[this.state.selectedMenuItem]}
          mode="horizontal"
        >
          <MenuItem key={routes.ADMINISTRATION}>
            <Link to={`/${routes.ADMINISTRATION}`}>
              <span>
                <Icon type="setting" /> Адміністрування
              </span>
            </Link>
          </MenuItem>
          <SubMenu
            key="currentUser"
            title={
              <span>
                <Icon type="user" />
                Степаненко С
              </span>
            }
            style={{ width: '160px', textAlign: 'center' }}
          >
            <MenuItem>
              <span onClick={this.handleLogoutClick}>
                <Icon type="logout" /> Вийти з системи
              </span>
            </MenuItem>
          </SubMenu>
        </Menu>
      </ul>
    );
  }
}

HeaderNav.propTypes = {
  route: PropTypes.string.isRequired,
  history: PropTypes.objectOf(PropTypes.any).isRequired,
  doLogOut: PropTypes.func.isRequired,
};

export default HeaderNav;
