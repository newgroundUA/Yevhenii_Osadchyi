import React from 'react';

const Title = () => (
  <div className="title">
    <div className="title__logo"> </div>
    <div className="title__text">Єдина Інформаційна Система ДКВ м.Києва</div>
  </div>
);

export default Title;
