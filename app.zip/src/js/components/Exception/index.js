import React, { createElement } from 'react';
import PropTypes from 'prop-types';
import { Button } from 'antd';
import config from './typeConfig';

const Exception = ({ className, linkElement = 'a', type, title, desc, img, actions, ...rest }) => {
  const pageType = type in config ? type : '404';
  return (
    <div className="exception" {...rest}>
      <div className="imgBlock">
        <div
          className="imgEle"
          style={{ backgroundImage: `url(${img || config[pageType].img})` }}
        />
      </div>
      <div className="content-exception">
        <h1>{title || config[pageType].title}</h1>
        <div className="desc">{desc || config[pageType].desc}</div>
        <div className="actions">
          {actions ||
            createElement(
              linkElement,
              {
                to: '/',
                href: '/',
              },
              <Button type="primary">На головну</Button>,
            )}
        </div>
      </div>
    </div>
  );
};

Exception.propTypes = {
  className: PropTypes.string,
  linkElement: PropTypes.string,
  type: PropTypes.string,
  title: PropTypes.string,
  desc: PropTypes.string,
  img: PropTypes.string,
  actions: PropTypes.string,
};

Exception.defaultProps = {
  className: undefined,
  linkElement: undefined,
  type: undefined,
  title: undefined,
  desc: undefined,
  img: undefined,
  actions: undefined,
};

export default Exception;
