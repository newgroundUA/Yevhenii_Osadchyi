import api from '../api-v2';
import counterparty from './counterparty';

export default {
  counterparty: counterparty(api),
};
