import { getPersonByGuid } from './person';

export default (api) => {
  return {
    getPersonByGuid: getPersonByGuid(api),
  };
};
