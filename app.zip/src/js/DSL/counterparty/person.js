import { normalize } from 'normalizr';
import { isGuidFormat } from '../../services/validator/valiators';
import * as schemas from './schemas';

export const getPersonByGuid = (api) => async (guid) => {
  if (!isGuidFormat(guid)) {
    throw new Error('Incorrect "guid" format');
  }
  const { data } = await api.counterparty.person.getPersonByGuid(guid);
  const {
    entities: { person },
  } = normalize(data, schemas.person);
  return person;
};
