import { schema } from 'normalizr';

export const person = new schema.Entity('person', {}, { idAttribute: 'guid' });
