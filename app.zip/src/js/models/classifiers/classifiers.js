import moment from 'moment';

import * as classifiers from '../../constants/ClassifiersNames';

// TODO: DELETE THIS FILE AND ALL CONNECTIONS WITH HIM
const mapFunction = (el, id) => ({ guid: `${id}`, name: el });

export default {
  tempOptions: [{ guid: '123', name: 'Temp option1' }, { guid: '456', name: 'Temp option1' }],
  [classifiers.YES_NO]: [{ guid: false, name: 'Ні' }, { guid: true, name: 'Так' }],
  [classifiers.PERSON_TYPE_ENUM_ON_FE]: [
    {
      guid: 'REGULAR',
      name: 'Звичайна',
    },
    // {
    //   guid: 'RELIGIOUS',
    //   name: 'Релігійна'
    // },
    // {
    //   guid: 'FOREIGNER',
    //   name: 'Іноземна'
    // },
    {
      guid: 'OTHER',
      name: 'Інша',
    },
  ],
  [classifiers.APPEAL]: [{ guid: 'MALE', name: 'Чоловічий' }, { guid: 'FEMALE', name: 'Жіночий' }],

  [classifiers.BANKDETAILS]: [].map(mapFunction),

  [classifiers.PROCESS]: ['Процес 1', 'Процес 2'].map(mapFunction),

  [classifiers.STATE]: ['Стан 1', 'Стан 2'].map(mapFunction),

  [classifiers.CASE_CLASIFICATION]: ['Case classification 1', 'Case classification 2'].map(
    mapFunction,
  ),

  [classifiers.BODIES]: ['Орган 1', 'Орган 2'].map(mapFunction),

  [classifiers.BASE_LEASE_PERIODS]: ['HOURLY', 'DAILY', 'MONTHLY'],

  [classifiers.ENUM_JUDICIAL_SHOT_RESULT]: [
    'NO_SATISFY',
    'SATISFY',
    'SATISFY_IN_PART',
    'CANCEL',
    'DIRECTED_FOR_NEW_REVIEW',
  ],

  [classifiers.LAND_LORDS_TO_LEASE_OBJECTS]: [],

  [classifiers.IS_MODEL_STATUT]: [
    'Model status 1',
    'Model status 2',
    'Model status 3',
    'Model status 4',
  ].map(mapFunction),

  [classifiers.CL_MANUFACTURER]: [
    'Manufacturer 1',
    'Manufacturer 2',
    'Manufacturer 3',
    'Manufacturer 4',
  ].map(mapFunction),

  [classifiers.EQUIPMENT_TYPE]: [
    'Equipment type 1',
    'Equipment type 2',
    'Equipment type 3',
    'Equipment type 4',
  ].map(mapFunction),

  [classifiers.CL_ROAD_MOVE_LINE]: [
    'Road move line 1',
    'Road move line 2',
    'Road move line 3',
    'Road move line 4',
  ].map(mapFunction),

  [classifiers.CL_ROAD_TECHNOLOGY]: [
    'Road technology 1',
    'Road technology 2',
    'Road technology 3',
    'Road technology 4',
  ].map(mapFunction),

  [classifiers.REF_WH_TRANSPORT_TYPE]: [
    'Vehicle transport type 1',
    'Vehicle transport type 2',
    'Vehicle transport type 3',
    'Vehicle transport type 4',
  ].map(mapFunction),

  [classifiers.REF_WH_TRANSPORT_COLOR_TYPE]: [
    'Vehicle transport color type 1',
    'Vehicle transport color type 2',
    'Vehicle transport color type 3',
    'Vehicle transport color type 4',
  ].map(mapFunction),

  [classifiers.REF_RAIL_ROAD_MATERIAL]: [
    'Rail road material 1',
    'Rail road material 2',
    'Rail road material 3',
    'Rail road material 4',
  ].map(mapFunction),

  [classifiers.REF_RAIL_ROAD_BALAST_MATERIAL]: [
    'Rail road balst material 1',
    'Rail road balst material 2',
    'Rail road balst material 3',
    'Rail road balst material 4',
  ].map(mapFunction),

  [classifiers.REF_RAIL_ROAD_SLEEPERS_MATERIAL]: [
    'Rail road sleepers material 1',
    'Rail road sleepers material 2',
    'Rail road sleepers material 3',
    'Rail road sleepers material 4',
  ].map(mapFunction),

  [classifiers.REF_RAIL_ROAD_TECHNOLOGY]: [
    'Rail road technology 1',
    'Rail road technology 2',
    'Rail road technology 3',
    'Rail road technology 4',
  ].map(mapFunction),

  [classifiers.CL_PLANT]: ['Plant type 1', 'Plant type 2', 'Plant type 3', 'Plant type 4'].map(
    mapFunction,
  ),

  [classifiers.CL_PLANT_PURPOSE]: [
    'Plant purpose 1',
    'Plant purpose 2',
    'Plant purpose 3',
    'Plant purpose 4',
  ].map(mapFunction),

  [classifiers.CL_INTELL_CREATION_TYPE]: [
    'Intell creation type 1',
    'Intell creation type 2',
    'Intell creation type 3',
    'Intell creation type 4',
  ].map(mapFunction),

  [classifiers.CL_INTELL_LICENSE_TYPE]: [
    'Intell license type 1',
    'Intell license type 2',
    'Intell license type 3',
    'Intell license type 4',
  ].map(mapFunction),

  [classifiers.CL_INTELL_PATENT_DATA]: [
    'Intell patent data 1',
    'Intell patent data 2',
    'Intell patent data 3',
    'Intell patent data 4',
  ].map(mapFunction),

  [classifiers.REF_ANIMAL_CLASSIFIER]: [
    'Класс та порода 1',
    'Класс та порода 2',
    'Класс та порода 3',
    'Класс та порода 4',
  ].map(mapFunction),

  [classifiers.CL_ANIMAL_PURPOSE]: [
    'Призначаення 1',
    'Призначаення 2',
    'Призначаення 3',
    'Призначаення 4',
  ].map(mapFunction),

  [classifiers.EVALUATION_STAGE]: [
    'Вхідний документ',
    'Введення данних',
    'Підписання',
    'Вихідний документ',
  ].map(mapFunction),

  [classifiers.CLASSIFICATION_PROCESS]: ['Приватизація', 'Оренда'].map(mapFunction),

  [classifiers.CONCLUSION_EVALUATION_LEASE]: [
    'Може бути використано',
    'Не може бути використано',
  ].map(mapFunction),

  [classifiers.APPEAL_INIT_TYPE]: ['INTERNAL', 'EXTERNAL'],

  [classifiers.CONTRACT_SUBJECT_EVALUATION_ACTIVITY]: [
    "Договір з суб'єктом оціночної діяльності-1",
    "Договір з суб'єктом оціночної діяльності-2",
    "Договір з суб'єктом оціночної діяльності-3",
    "Договір з суб'єктом оціночної діяльності-4",
    "Договір з суб'єктом оціночної діяльності-5",
  ].map(mapFunction),

  [classifiers.INCOMING_DOCUMENT]: [
    'Вхідний Документ-1',
    'Вхідний Документ-2',
    'Вхідний Документ-3',
    'Вхідний Документ-4',
    'Вхідний Документ-5',
  ].map(mapFunction),

  [classifiers.STATEMENT]: ['Заява-1', 'Заява-2', 'Заява-3', 'Заява-4', 'Заява-5'].map(mapFunction),

  [classifiers.INVENTORY]: [
    'Інвентаризаційний Документ-1',
    'Інвентаризаційний Документ-2',
    'Інвентаризаційний Документ-3',
    'Інвентаризаційний Документ-4',
    'Інвентаризаційний Документ-5',
  ].map(mapFunction),

  [classifiers.OUTGOING_DOCUMENT]: [
    'Вихідний Документ-1',
    'Вихідний Документ-2',
    'Вихідний Документ-3',
    'Вихідний Документ-4',
    'Вихідний Документ-5',
  ].map(mapFunction),

  [classifiers.OBJECT_ADDRESS]: [
    'Украина, 49074, Днепропетровская область, Днепр, ул. Батумская, 11',
    'Украина, 04116, Киев, ул. Шолуденко 3, офис 202',
    'Украина, 04119, Киев, ул. Дегтяревская, 27-Т (буква А)',
    'Украина, 03150, Киев, ул. Деловая, 9-А',
    'Украина, 04136, Киев, ул. Стеценко, 6',
    'Украина, 01033, Киев, ул. Тарасовская, 19',
    'Украина, 04070, Киев, ул. Спасская, 30а',
    'Украина, 69037, Запорожская область, Запорожье, ул. Независимой Украины, 39-Д',
    'Украина, 04070, Киев, ул. Андреевская, 4',
    'Украина, 49054, Днепропетровская область, Днепр, пр. А.Поля, 46',
    'Украина, 01011, Киев, ул. Лeскова, 9',
    'Украина, 04107, Киев, ул. Тропинина, 7-Г',
  ].map(mapFunction),

  [classifiers.OBJECT_EVALUATION]: [
    'Земельна ділянка сільськогосподарського типу',
    'Земля житлової та громадської забудови',
    'Будинок багатоквартирний масової забудови',
    'Будинок житловий готельного типу',
  ].map(mapFunction),

  [classifiers.YEARS]: (() => {
    const years = [];
    const currYear = moment().year() + 50;
    for (let year = 1700; year < currYear; year++) {
      years.push(year);
    }
    return years;
  })(),

  [classifiers.REVIEW_CATEGORY]: [
    'без рецензії',
    'без рецинзування (повтор)*',
    'без розгляду',
    'відповідає вимогам',
    'залишкова вартість 0,00 грн.',
    'копія звіту',
    'не відповідає вимогам',
    'провести с/о',
    'створити комісію',
  ].map(mapFunction),

  [classifiers.CL_CABLE_ELECTRICITY_PURPOSE]: [
    'Призначення електрокомунікації 1',
    'Призначення електрокомунікації 2',
  ].map(mapFunction),

  [classifiers.CL_CABLE_CLASSIFIER]: ['Марка проводу 1', 'Марка проводу 2'].map(mapFunction),

  [classifiers.CL_CABLE_PILLAR_MATERIAL]: ['Матеріал опор 1', 'Матеріал опор 2'].map(mapFunction),

  [classifiers.CL_CABLE_TECHNOLOGY]: ['Технологія прокладки 1', 'Технологія прокладки 2'].map(
    mapFunction,
  ),

  [classifiers.CL_PROPERTY_TUBE_CLASSIFIER]: ['Марка труб 1', 'Марка труб 2'].map(mapFunction),

  [classifiers.CL_PROPERTY_TUBE_TEHNOLOGY]: [
    'Технологія покладки труб 1',
    'Технологія покладки труб 2',
  ].map(mapFunction),

  [classifiers.CL_PROPERTY_TUBE_BASE_MATERIAL]: [
    'Матеріал опори труб 1',
    'Матеріал опори труб 2',
  ].map(mapFunction),
};
