import * as tableConstants from '../../constants/TableToolNames';
import * as cellTypes from '../../constants/CellTypes';

const initialSettings = {
  corporateRights: {
    register: {
      tableToolbar: {
        tasks: {
          archiveUser: {
            title: tableConstants.ARCHIVE_USER,
            isVisible: true,
          },
        },
        export: {
          pdf: {
            title: tableConstants.PDF,
            isVisible: true,
          },
        },
        filters: {
          filters: {
            title: tableConstants.FILTERS,
            isVisible: true,
          },
          specFilters: {
            title: tableConstants.SPEC_FILTERS,
            isVisible: true,
          },
        },
        config: {
          tableColumns: {
            title: tableConstants.TABLE_COLUMNS,
            isVisible: true,
          },
          toolbarManagement: {
            title: tableConstants.TOOLBAR_MANAGEMENT,
            isVisible: true,
          },
        },
      },
      tableBody: {
        columns: {
          fixed: {
            // checkbox: {
            //   isVisible: true,
            //   colName: 'checkbox',
            //   width: 30,
            //   position: 0,
            //   title: 'checkbox',
            //   type: cellTypes.CHECKBOX,
            // },
            fullName: {
              isVisible: true,
              colName: 'fullName',
              width: 200,
              position: 0,
              title: 'Назва / ФІО власника корпправа',
              type: cellTypes.LINK,
            },
            // action: {
            //   isVisible: true,
            //   colName: 'action',
            //   width: 70,
            //   position: 2,
            //   title: 'Дія',
            //   type: cellTypes.BUTTONS,
            // },
          },
          fluid: {
            itn_edrpou: {
              isVisible: true,
              colName: 'itn_edrpou',
              width: 200,
              position: 1,
              title: 'ЄДПРОУ / ІНН власника корпправа',
              type: cellTypes.TEXT,
            },
            kopfgtype: {
              isVisible: true,
              colName: 'kopfgtype',
              width: 200,
              position: 2,
              title: 'КОПФГ власника корпправа',
              type: cellTypes.TEXT,
            },
            address: {
              isVisible: true,
              colName: 'address',
              width: 200,
              position: 3,
              title: 'ЮрАдреса власника корпправа',
              type: cellTypes.TEXT,
            },
            isFounder: {
              isVisible: true,
              colName: 'isFounder',
              width: 200,
              position: 4,
              title: 'Є засновником',
              type: cellTypes.TEXT,
            },
            stocksQuantity: {
              isVisible: true,
              colName: 'stocksQuantity',
              width: 200,
              position: 5,
              title: 'Кількість акцій у власника, шт',
              type: cellTypes.TEXT,
            },
            percentShareSize: {
              isVisible: true,
              colName: 'percentShareSize',
              width: 200,
              position: 6,
              title: 'Частка власника, %',
              type: cellTypes.TEXT,
            },
            shareSize: {
              isVisible: true,
              colName: 'shareSize',
              width: 200,
              position: 7,
              title: 'Частка власника, грн',
              type: cellTypes.TEXT,
            },
            legalentityFullname: {
              isVisible: true,
              colName: 'legalentityFullname',
              width: 200,
              position: 8,
              title: "Назва  об'єкту корпоративної власності",
              type: cellTypes.TEXT,
            },
            legalentityEdrpou: {
              isVisible: true,
              colName: 'legalentityEdrpou',
              width: 200,
              position: 9,
              title: "ЄДПРОУ об'єкту корпоративної власності",
              type: cellTypes.TEXT,
            },
            legalentityKopfgtypeFullname: {
              isVisible: true,
              colName: 'legalentityKopfgtypeFullname',
              width: 200,
              position: 10,
              title: "КОПФГ об'єкту корпоративної власності",
              type: cellTypes.TEXT,
            },
            counterpartyAddress: {
              isVisible: true,
              colName: 'counterpartyAddress',
              width: 200,
              position: 11,
              title: "ЮрАдреса об'єкту корпоративної власності",
              type: cellTypes.TEXT,
            },
            shareCapital: {
              isVisible: true,
              colName: 'shareCapital',
              width: 200,
              position: 12,
              title: "Статутний капітал об'єкту корпоративної власності",
              type: cellTypes.TEXT,
            },
            shareParValue: {
              isVisible: true,
              colName: 'shareParValue',
              width: 200,
              position: 13,
              title: "Номінальна вартість акцій об'єкту корпоративної власності, грн",
              type: cellTypes.TEXT,
            },
            sharesFormType: {
              isVisible: true,
              colName: 'sharesFormType',
              width: 200,
              position: 14,
              title: "Форма існування акцій об'єкту корпоративної власності",
              type: cellTypes.TEXT,
            },
            statusOfStateRegistration: {
              isVisible: true,
              colName: 'statusOfStateRegistration',
              width: 200,
              position: 15,
              title: "Ознака банкрутства (стан реєстрації)  об'єкту корпоративної власності",
              type: cellTypes.TEXT,
            },
            mainKvedActivity: {
              isVisible: true,
              colName: 'mainKvedActivity',
              width: 200,
              position: 16,
              title: "основний КВЕД об'єкту корпоративної власності",
              type: cellTypes.TEXT,
            },
          },
        },
      },
    },
  },
};

export default initialSettings;
