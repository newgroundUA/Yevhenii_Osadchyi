import * as tableConstants from '../../constants/TableToolNames';
import * as cellTypes from '../../constants/CellTypes';
import * as renderFunc from '../../helpers/cellRenderFunctions';

const initialSettings = {
  corporateRightsMovement: {
    register: {
      tableToolbar: {
        tasks: {
          archiveUser: {
            title: tableConstants.ARCHIVE_USER,
            isVisible: true,
          },
        },
        export: {
          pdf: {
            title: tableConstants.PDF,
            isVisible: true,
          },
        },
        filters: {
          filters: {
            title: tableConstants.FILTERS,
            isVisible: true,
          },
          specFilters: {
            title: tableConstants.SPEC_FILTERS,
            isVisible: true,
          },
        },
        config: {
          tableColumns: {
            title: tableConstants.TABLE_COLUMNS,
            isVisible: true,
          },
          toolbarManagement: {
            title: tableConstants.TOOLBAR_MANAGEMENT,
            isVisible: true,
          },
        },
      },
      tableBody: {
        columns: {
          fixed: {
            // checkbox: {
            //   isVisible: true,
            //   colName: 'checkbox',
            //   width: 30,
            //   position: 0,
            //   title: 'checkbox',
            //   type: cellTypes.CHECKBOX,
            // },
            corporateRightsStructureEdrpou: {
              isVisible: true,
              colName: 'corporateRightsStructureEdrpou',
              width: 200,
              position: 0,
              title: "ЄДПРОУ об'єкта корпоративної власності",
              // type: cellTypes.LINK,
              render: renderFunc.link,
            },
            corporateRightsStructureFullName: {
              isVisible: true,
              colName: 'corporateRightsStructureFullName',
              width: 200,
              position: 1,
              title: "Назва об'єкту корпоративної власності",
              // type: cellTypes.LINK,
              render: renderFunc.link,
            },
            // action: {
            //   isVisible: true,
            //   colName: 'action',
            //   width: 70,
            //   position: 2,
            //   title: 'Дія',
            //   type: cellTypes.BUTTONS,
            // },
          },
          fluid: {
            corporateRightsMovementDate: {
              isVisible: true,
              colName: 'corporateRightsMovementDate',
              width: 200,
              position: 0,
              title: 'Дата операції',
              type: cellTypes.TEXT,
            },
            corporateRightsMovementRegNumber: {
              isVisible: true,
              colName: 'corporateRightsMovementRegNumber',
              width: 200,
              position: 1,
              title: 'Реєстровий номер операції',
              type: cellTypes.LINK,
            },
            shareReceiver: {
              isVisible: true,
              colName: 'shareReceiver',
              width: 200,
              position: 2,
              title: 'Учасник отримувач',
              type: cellTypes.TEXT,
              render: renderFunc.link,
            },
            shareSender: {
              isVisible: true,
              colName: 'shareSender',
              width: 200,
              position: 3,
              title: 'Учасник передавач',
              type: cellTypes.TEXT,
              render: renderFunc.link,
            },
            corporateRightsOperationType: {
              isVisible: true,
              colName: 'corporateRightsOperationType',
              width: 200,
              position: 4,
              title: 'Тип правової операції',
              type: cellTypes.TEXT,
            },
            stocksQuantity: {
              isVisible: true,
              colName: 'stocksQuantity',
              width: 200,
              position: 5,
              title: 'Кількість акцій',
              type: cellTypes.TEXT,
            },
            stocksPrice: {
              isVisible: true,
              colName: 'stocksPrice',
              width: 200,
              position: 6,
              title: 'Вартість акції, грн',
              type: cellTypes.TEXT,
            },
            stocksType: {
              isVisible: true,
              colName: 'stocksType',
              width: 200,
              position: 7,
              title: 'Тип акцій',
              type: cellTypes.TEXT,
            },
            shareSizeInOperationFact: {
              isVisible: true,
              colName: 'shareSizeInOperationFact',
              width: 200,
              position: 8,
              title: 'Розмір долі у СК фактичний',
              type: cellTypes.TEXT,
            },
            shareSizeInOperationPlan: {
              isVisible: true,
              colName: 'shareSizeInOperationPlan',
              width: 200,
              position: 9,
              title: 'Розмір долі у СК за планом',
              type: cellTypes.TEXT,
            },
            operationMethodType: {
              isVisible: true,
              colName: 'operationMethodType',
              width: 200,
              position: 10,
              title: 'Метод проведення операції',
              type: cellTypes.TEXT,
            },
            corporateRightsMovementDocs: {
              isVisible: true,
              colName: 'corporateRightsMovementDocs',
              width: 200,
              position: 11,
              title: 'Документ щодо операції',
              render: renderFunc.dropDownWithLink,
            },
            moneySendersInOperation: {
              isVisible: true,
              colName: 'moneySendersInOperation',
              width: 200,
              position: 12,
              title: 'Платник коштів по операції',
              type: cellTypes.TEXT,
              render: renderFunc.link,
            },
            moneyReceiversInOperation: {
              isVisible: true,
              colName: 'moneyReceiversInOperation',
              width: 200,
              position: 13,
              title: 'Одержувач коштів по операції',
              type: cellTypes.TEXT,
              render: renderFunc.link,
            },
          },
        },
      },
    },
  },
};

export default initialSettings;
