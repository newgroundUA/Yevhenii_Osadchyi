import * as tableConstants from '../../constants/TableToolNames';
import * as cellTypes from '../../constants/CellTypes';

const initialSettings = {
  evaluation: {
    register: {
      tableToolbar: {
        tasks: {
          archiveUser: {
            title: tableConstants.ARCHIVE_USER,
            isVisible: true,
          },
        },
        export: {
          pdf: {
            title: tableConstants.PDF,
            isVisible: true,
          },
        },
        filters: {
          filters: {
            title: tableConstants.FILTERS,
            isVisible: true,
          },
          specFilters: {
            title: tableConstants.SPEC_FILTERS,
            isVisible: true,
          },
        },
        config: {
          tableColumns: {
            title: tableConstants.TABLE_COLUMNS,
            isVisible: true,
          },
          toolbarManagement: {
            title: tableConstants.TOOLBAR_MANAGEMENT,
            isVisible: true,
          },
        },
      },
      tableBody: {
        columns: {
          fixed: {
            checkbox: {
              isVisible: true,
              colName: 'checkbox',
              width: 30,
              position: 0,
              title: 'checkbox',
              type: cellTypes.CHECKBOX,
            },
            caseRegNumber: {
              isVisible: true,
              colName: 'caseRegNumber',
              width: 200,
              position: 1,
              title: 'Реєстраційний номер справи',
              type: cellTypes.LINK,
            },
            action: {
              isVisible: true,
              colName: 'action',
              width: 70,
              position: 2,
              title: 'Дія',
              type: cellTypes.BUTTONS,
            },
          },
          fluid: {
            startDate: {
              isVisible: true,
              colName: 'startDate',
              width: 200,
              position: 3,
              title: 'Дата початку рецензування',
              type: cellTypes.TEXT,
            },
            endDatePlan: {
              isVisible: true,
              colName: 'endDatePlan',
              width: 200,
              position: 4,
              title: 'Дата завершення рецензування (план)',
              type: cellTypes.TEXT,
            },
            controlDate: {
              isVisible: true,
              colName: 'controlDate',
              width: 200,
              position: 5,
              title: 'Контрольна дата процесу рецензування',
              type: cellTypes.TEXT,
            },
            state: {
              isVisible: true,
              colName: 'state',
              width: 200,
              position: 6,
              title: 'Стан процесс рецензування',
              type: cellTypes.TEXT,
            },
            evaluationReasonType: {
              isVisible: true,
              colName: 'evaluationReasonType',
              width: 200,
              position: 7,
              title: 'Мета оцінки майна',
              type: cellTypes.TEXT,
            },
            balanceHolder: {
              isVisible: true,
              colName: 'balanceHolder',
              width: 200,
              position: 8,
              title: 'Балансоутримувач',
              type: cellTypes.TEXT,
            },
            appraiser: {
              isVisible: true,
              colName: 'appraiser',
              width: 200,
              position: 9,
              title: 'Контрагент-СОД',
              type: cellTypes.TEXT,
            },
            assessmentContract: {
              isVisible: true,
              colName: 'assessmentContract',
              width: 200,
              position: 10,
              title: 'Договір з СОД',
              type: cellTypes.TEXT,
            },
            reviewer: {
              isVisible: true,
              colName: 'reviewer',
              width: 200,
              position: 11,
              title: 'Рецензент',
              type: cellTypes.TEXT,
            },
            reviewingCategory: {
              isVisible: true,
              colName: 'reviewingCategory',
              width: 200,
              position: 12,
              title: 'Категорія рецензії',
              type: cellTypes.TEXT,
            },
            docForReviewing: {
              isVisible: true,
              colName: 'docForReviewing',
              width: 200,
              position: 13,
              title: 'Документ що рецензується',
              type: cellTypes.TEXT,
            },
            assessmentDate: {
              isVisible: true,
              colName: 'assessmentDate',
              width: 200,
              position: 14,
              title: 'Дата оцінки',
              type: cellTypes.TEXT,
            },
            reviewingConclusion: {
              isVisible: true,
              colName: 'reviewingConclusion',
              width: 200,
              position: 15,
              title: 'Висновок рецензування',
              type: cellTypes.TEXT,
            },
            endFactDate: {
              isVisible: true,
              colName: 'endFactDate',
              width: 200,
              position: 16,
              title: 'Дата завершення рецензування (факт)',
              type: cellTypes.TEXT,
            },
            aplicationToLease: {
              isVisible: true,
              colName: 'aplicationToLease',
              width: 200,
              position: 17,
              title: 'Заява на оренду майна',
              type: cellTypes.TEXT,
            },
            assessmentType: {
              isVisible: true,
              colName: 'assessmentType',
              width: 200,
              position: 18,
              title: 'Тип оцінки',
              type: cellTypes.TEXT,
            },
            renter: {
              isVisible: true,
              colName: 'renter',
              width: 200,
              position: 19,
              title: 'Контрагент - орендар',
              type: cellTypes.TEXT,
            },
            leaseObjects: {
              isVisible: true,
              colName: 'leaseObjects',
              width: 200,
              position: 20,
              title: "Об'єкт оренди для оцінки",
              type: cellTypes.TEXT,
            },
            // localityArea: {
            //   isVisible: true,
            //   colName: 'localityArea',
            //   width: 200,
            //   position: 21,
            //   title: 'Адреса розташування Об\'єкту оцінки: Адмінрайон міста',
            //   type: cellTypes.TEXT
            // },
            // assessmentObjectStreet: {
            //   isVisible: true,
            //   colName: 'assessmentObjectStreet',
            //   width: 200,
            //   position: 22,
            //   title: 'Адреса розташування Об\'єкту оцінки: вулиця',
            //   type: cellTypes.TEXT
            // },
            // assessmentObjectAdrObLegalno: {
            //   isVisible: true,
            //   colName: 'assessmentObjectAdrObLegalno',
            //   width: 200,
            //   position: 23,
            //   title: 'Адреса розташування Об\'єкту оцінки: номер будівлі / комплексу',
            //   type: cellTypes.TEXT
            // },
            // assessmentObjectBuildingBTIletter: {
            //   isVisible: true,
            //   colName: 'assessmentObjectBuildingBTIletter',
            //   width: 200,
            //   position: 24,
            //   title: 'Адреса розташування Об\'єкту оцінки: номер корпусу / секції / БТІ',
            //   type: cellTypes.TEXT
            // },
            // assessmentObjectFloor: {
            //   isVisible: true,
            //   colName: 'assessmentObjectFloor',
            //   width: 200,
            //   position: 25,
            //   title: 'Адреса розташування Об\'єкту оцінки: Поверхи розташування',
            //   type: cellTypes.TEXT
            // }
          },
        },
      },
    },
  },
};

export default initialSettings;
