import * as tableConstants from '../../constants/TableToolNames';
import * as cellTypes from '../../constants/CellTypes';
import * as renderFunc from '../../helpers/cellRenderFunctions';

const initialSettings = {
  documents: {
    register: {
      tableToolbar: {
        tasks: {
          archiveUser: {
            title: tableConstants.ARCHIVE_USER,
            isVisible: true,
          },
        },
        export: {
          pdf: {
            title: tableConstants.PDF,
            isVisible: true,
          },
        },
        filters: {
          filters: {
            title: tableConstants.FILTERS,
            isVisible: true,
          },
          specFilters: {
            title: tableConstants.SPEC_FILTERS,
            isVisible: true,
          },
        },
        config: {
          tableColumns: {
            title: tableConstants.TABLE_COLUMNS,
            isVisible: true,
          },
          toolbarManagement: {
            title: tableConstants.TOOLBAR_MANAGEMENT,
            isVisible: true,
          },
        },
      },
      tableBody: {
        columns: {
          fixed: {
            checkbox: {
              isVisible: true,
              colName: 'checkbox',
              width: 30,
              position: 0,
              title: 'checkbox',
              type: cellTypes.CHECKBOX,
            },
            docRegNumber: {
              isVisible: true,
              colName: 'docRegNumber',
              width: 230,
              position: 1,
              title: 'Внутрішній реєстраційний номер',
              type: cellTypes.SORT,
            },
            action: {
              isVisible: true,
              colName: 'action',
              width: 70,
              position: 2,
              title: 'Дія',
              type: cellTypes.BUTTONS,
            },
          },
          fluid: {
            refDocumentType: {
              isVisible: true,
              colName: 'refDocumentType',
              width: 230,
              position: 3,
              title: 'Тип документу',
              type: cellTypes.TEXT,
            },
            docRegDate: {
              isVisible: true,
              colName: 'docRegDate',
              width: 130,
              position: 4,
              title: 'Дата реєстаціїї документа в системі',
              type: cellTypes.SORT,
            },
            docSerialNumber: {
              isVisible: true,
              colName: 'docSerialNumber',
              width: 140,
              position: 5,
              title: 'Серія документа',
              type: cellTypes.SORT,
            },
            docNumber: {
              isVisible: true,
              colName: 'docNumber',
              width: 230,
              position: 6,
              title: 'Номер документа',
              type: cellTypes.SORT,
            },
            docDate: {
              isVisible: true,
              colName: 'docDate',
              width: 130,
              position: 7,
              title: 'Дата видачі документа',
              type: cellTypes.SORT,
            },
            publishers: {
              isVisible: true,
              colName: 'publishers',
              width: 230,
              position: 8,
              title: 'Контрагент видавач документа',
              // type: cellTypes.DROP_DOWN
              render: renderFunc.dropDownWithLink,
            },
            recipients: {
              isVisible: true,
              colName: 'recipients',
              width: 230,
              position: 9,
              title: 'Контранент отримувач документа',
              // type: cellTypes.DROP_DOWN
              render: renderFunc.dropDownWithLink,
            },
            docDescription: {
              isVisible: true,
              colName: 'docDescription',
              width: 230,
              position: 10,
              title: 'Короткий опис документа',
              type: cellTypes.SORT,
            },
            docWWWPage: {
              isVisible: true,
              colName: 'docWWWPage',
              width: 230,
              position: 11,
              title: 'Веб посилання',
              type: cellTypes.TEXT,
            },
            docValidityStatus: {
              isVisible: true,
              colName: 'docValidityStatus',
              width: 230,
              position: 12,
              title: 'Стан чинності документа',
              type: cellTypes.SORT,
            },
            parentDocument: {
              isVisible: true,
              colName: 'parentDocument',
              width: 230,
              position: 13,
              title: 'Головний документ',
              type: cellTypes.SORT, // type is not required if there is a render parameter
              render: renderFunc.link,
            },
            childrenDocuments: {
              isVisible: true,
              colName: 'childrenDocuments',
              width: 230,
              position: 14,
              title: 'Підпорядковані документи',
              // type: cellTypes.DROP_DOWN
              render: renderFunc.dropDownWithLink,
            },
            linkedDocuments: {
              isVisible: true,
              colName: 'linkedDocuments',
              width: 230,
              position: 15,
              title: "Пов'язані документи",
              // type: cellTypes.DROP_DOWN
              render: renderFunc.dropDownWithLink,
            },
            creator: {
              isVisible: true,
              colName: 'creator',
              width: 230,
              position: 16,
              title: 'Автор документа',
              type: cellTypes.SORT,
              render: renderFunc.link,
            },
            receptionist: {
              isVisible: true,
              colName: 'receptionist',
              width: 230,
              position: 17,
              title: 'Реєстратор документа',
              type: cellTypes.SORT,
              render: renderFunc.link,
            },
            validFrom: {
              isVisible: true,
              colName: 'validFrom',
              width: 100,
              position: 18,
              title: 'Дійсний з',
              type: cellTypes.SORT,
            },
            validTill: {
              isVisible: true,
              colName: 'validTill',
              width: 100,
              position: 19,
              title: 'Дійсний до',
              type: cellTypes.SORT,
            },
          },
        },
      },
    },
  },
};

export default initialSettings;
