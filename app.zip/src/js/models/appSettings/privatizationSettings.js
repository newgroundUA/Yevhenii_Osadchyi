import * as tableConstants from '../../constants/TableToolNames';
import * as cellTypes from '../../constants/CellTypes';

const initialSettings = {
  privatization: {
    register: {
      tableToolbar: {
        tasks: {
          archiveUser: {
            title: tableConstants.ARCHIVE_USER,
            isVisible: true,
          },
        },
        export: {
          pdf: {
            title: tableConstants.PDF,
            isVisible: true,
          },
        },
        filters: {
          filters: {
            title: tableConstants.FILTERS,
            isVisible: true,
          },
          specFilters: {
            title: tableConstants.SPEC_FILTERS,
            isVisible: true,
          },
        },
        config: {
          tableColumns: {
            title: tableConstants.TABLE_COLUMNS,
            isVisible: true,
          },
          toolbarManagement: {
            title: tableConstants.TOOLBAR_MANAGEMENT,
            isVisible: true,
          },
        },
      },
      tableBody: {
        columns: {
          fixed: {
            checkbox: {
              isVisible: true,
              colName: 'checkbox',
              width: 30,
              position: 0,
              title: 'checkbox',
              type: cellTypes.CHECKBOX,
            },
            privatObjectFullName: {
              isVisible: true,
              colName: 'privatObjectFullName',
              width: 200,
              position: 1,
              title: "Назва об'єкту приватизації",
              type: cellTypes.LINK,
            },
            action: {
              isVisible: true,
              colName: 'action',
              width: 70,
              position: 2,
              title: 'Дія',
              type: cellTypes.BUTTONS,
            },
          },
          fluid: {
            // visible

            privatObjectNumber: {
              isVisible: true,
              colName: 'privatObjectNumber',
              width: 200,
              position: 0,
              title: "Обліковий номер об'єкту приватизації",
              type: cellTypes.TEXT,
            },
            privatisationOrganisation: {
              isVisible: true,
              colName: 'privatisationOrganisation',
              width: 200,
              position: 0,
              title: 'Орган приватизації',
              type: cellTypes.TEXT,
            },
            privatisationOrganisationType: {
              isVisible: true,
              colName: 'privatisationOrganisationType',
              width: 200,
              position: 0,
              title: 'Тип органу приватизації',
              type: cellTypes.TEXT,
            },
            balanceKeepers: {
              isVisible: true,
              colName: 'balanceKeepers',
              width: 200,
              position: 0,
              title: 'Балансоутримувач',
              type: cellTypes.DROP_DOWN,
            },

            derivativePropertyRightsTypeList: {
              isVisible: true,
              colName: 'derivativePropertyRightsTypeList',
              width: 200,
              position: 0,
              title: 'Тип речового права',
              type: cellTypes.DROP_DOWN,
            },

            renters: {
              isVisible: true,
              colName: 'renters',
              width: 200,
              position: 0,
              title: 'Орендарі',
              type: cellTypes.DROP_DOWN,
            },

            localityArea: {
              isVisible: true,
              colName: 'localityArea',
              width: 200,
              position: 0,
              title: 'Адреса: Адмінрайон міста',
              type: cellTypes.TEXT,
            },

            streetTypeAndName: {
              isVisible: true,
              colName: 'streetTypeAndName',
              width: 200,
              position: 0,
              title: 'Адреса: вулиця',
              type: cellTypes.TEXT,
            },

            externalAddress: {
              isVisible: true,
              colName: 'externalAddress',
              width: 200,
              position: 0,
              title: 'Адреса: номер будівлі / комплексу',
              type: cellTypes.TEXT,
            },

            externalBuilding: {
              isVisible: true,
              colName: 'externalBuilding',
              width: 200,
              position: 0,
              title: 'Адреса: номер корпусу / секції / БТІ',
              type: cellTypes.TEXT,
            },

            floors: {
              isVisible: true,
              colName: 'floors',
              width: 200,
              position: 0,
              title: 'Поверхи розташування',
              type: cellTypes.DROP_DOWN,
            },

            privatObjectTotalSpace: {
              isVisible: true,
              colName: 'privatObjectTotalSpace',
              width: 200,
              position: 0,
              title: 'Загальна площа м.кв.',
              type: cellTypes.TEXT,
            },

            privatObjectUsefullSpace: {
              isVisible: true,
              colName: 'privatObjectUsefullSpace',
              width: 200,
              position: 0,
              title: 'Корисна площа м.кв.',
              type: cellTypes.TEXT,
            },

            privatObjectCommonUseSpace: {
              isVisible: true,
              colName: 'privatObjectCommonUseSpace',
              width: 200,
              position: 0,
              title: 'Площа заг. користування',
              type: cellTypes.TEXT,
            },

            accountingItemTypes: {
              isVisible: true,
              colName: 'accountingItemTypes',
              width: 200,
              position: 0,
              title: "Кількість майнових об'єктів в складі",
              type: cellTypes.TEXT,
            },

            privatObjectGroupType: {
              isVisible: true,
              colName: 'privatObjectGroupType',
              width: 200,
              position: 0,
              title: "Тип об'єкту приватизації",
              type: cellTypes.TEXT,
            },

            privatisationMethodType: {
              isVisible: true,
              colName: 'privatisationMethodType',
              width: 200,
              position: 0,
              title: 'Спосіб приватизації',
              type: cellTypes.TEXT,
            },

            privatisationObjectStatus: {
              isVisible: true,
              colName: 'privatisationObjectStatus',
              width: 200,
              position: 0,
              title: "Стан об'єкту приватизації",
              type: cellTypes.TEXT,
            },

            privatisationStageType: {
              isVisible: true,
              colName: 'privatisationStageType',
              width: 200,
              position: 0,
              title: 'Етап приватизації',
              type: cellTypes.TEXT,
            },

            privatisationProcStartDate: {
              isVisible: true,
              colName: 'privatisationProcStartDate',
              width: 200,
              position: 0,
              title: 'Дата початку процесу приватизації',
              type: cellTypes.TEXT,
            },

            privatisationProcEndDate: {
              isVisible: true,
              colName: 'privatisationProcEndDate',
              width: 200,
              position: 0,
              title: 'Дата закінчення процесу приватизації',
              type: cellTypes.TEXT,
            },

            privatisationProcNextControlDate: {
              isVisible: true,
              colName: 'privatisationProcNextControlDate',
              width: 200,
              position: 0,
              title: 'Чергова контрольна дата',
              type: cellTypes.TEXT,
            },

            docAboutPrivatisation: {
              isVisible: true,
              colName: 'docAboutPrivatisation',
              width: 200,
              position: 0,
              title: 'Документ підстава приватизації',
              type: cellTypes.DROP_DOWN,
            },

            orderNumberInDoc: {
              isVisible: true,
              colName: 'orderNumberInDoc',
              width: 200,
              position: 0,
              title: "Порядковий номер об'єкта в документі",
              type: cellTypes.TEXT,
            },

            privContract: {
              isVisible: true,
              colName: 'privContract',
              width: 200,
              position: 0,
              title: 'Договор купівлі продажу',
              type: cellTypes.DROP_DOWN,
            },

            buyer: {
              isVisible: true,
              colName: 'buyer',
              width: 200,
              position: 0,
              title: 'Покупець',
              type: cellTypes.TEXT,
            },

            sellPrice: {
              isVisible: true,
              colName: 'sellPrice',
              width: 200,
              position: 0,
              title: 'Ціна продажу',
              type: cellTypes.TEXT,
            },
          },
        },
      },
    },
  },
};

export default initialSettings;
