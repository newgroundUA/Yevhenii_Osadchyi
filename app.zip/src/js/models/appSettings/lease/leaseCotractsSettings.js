import * as tableConstants from '../../../constants/TableToolNames';
import * as cellTypes from '../../../constants/CellTypes';
import * as renderFunc from '../../../helpers/cellRenderFunctions';

const initialSettings = {
  leaseContracts: {
    register: {
      tableToolbar: {
        tasks: {
          // joinGroup: {
          //   title: tableConstants.JOIN_GROUP,
          //   isVisible: true
          // },
          // assignRole: {
          //   title: tableConstants.ASSIGN_ROLE,
          //   isVisible: true
          // },
          archiveUser: {
            title: tableConstants.ARCHIVE_USER,
            isVisible: true,
          },
        },
        export: {
          // xls: {
          //   title: tableConstants.XLS,
          //   isVisible: true
          // },
          pdf: {
            title: tableConstants.PDF,
            isVisible: true,
          },
          // csv: {
          //   title: tableConstants.CSV,
          //   isVisible: true
          // }
        },
        filters: {
          filters: {
            title: tableConstants.FILTERS,
            isVisible: true,
          },
          specFilters: {
            title: tableConstants.SPEC_FILTERS,
            isVisible: true,
          },
        },
        config: {
          tableColumns: {
            title: tableConstants.TABLE_COLUMNS,
            isVisible: true,
          },
          toolbarManagement: {
            title: tableConstants.TOOLBAR_MANAGEMENT,
            isVisible: true,
          },
        },
      },
      tableBody: {
        columns: {
          fixed: {
            checkbox: {
              isVisible: true,
              colName: 'checkbox',
              width: 30,
              position: 0,
              title: 'checkbox',
              type: cellTypes.CHECKBOX,
            },
            docSerialAndNumber: {
              isVisible: true,
              colName: 'docSerialAndNumber',
              width: 200,
              position: 1,
              title: 'Серія та номер Договору',
              type: cellTypes.SORT,
              render: renderFunc.link,
            },
            action: {
              isVisible: true,
              colName: 'action',
              width: 70,
              position: 2,
              title: 'Дія',
              type: cellTypes.BUTTONS,
            },
          },
          fluid: {
            // hidden

            basementcontractdocs: {
              isVisible: true,
              colName: 'basementcontractdocs',
              width: 200,
              position: -11,
              title: 'Підстава Договору',
              type: cellTypes.DROP_DOWN,
            },
            rentpaymentallowedterm: {
              isVisible: true,
              colName: 'rentpaymentallowedterm',
              width: 200,
              position: -10,
              title: 'Термін на сплату з початку місяця, днів',
              type: cellTypes.TEXT,
            },
            suranceDate: {
              isVisible: true,
              colName: 'suranceDate',
              width: 200,
              position: -9,
              title: 'Макс дата на укладання страхдоговору',
              type: cellTypes.TEXT,
            },
            insurancedocs: {
              isVisible: true,
              colName: 'insurancedocs',
              width: 200,
              position: -8,
              title: 'Страхові документи',
              type: cellTypes.DROP_DOWN,
            },
            additionalregistrationTypeAndDate: {
              isVisible: true,
              colName: 'additionalregistrationTypeAndDate',
              width: 200,
              position: -7,
              title: 'Додаткова реєстрація',
              type: cellTypes.TEXT,
            },
            autoprolongation: {
              isVisible: true,
              colName: 'autoprolongation',
              width: 200,
              position: -6,
              title: 'Автоматична пролонгація',
              type: cellTypes.TEXT,
            },
            // numlistMonthAndYear: {
            //   isVisible: true,
            //   colName: 'numlistMonthAndYear',
            //   width: 200,
            //   position: -5,
            //   title: 'Стартовий місяц для розрахунків',
            //   type: cellTypes.TEXT
            // },
            paymentRateAndPeriodShort: {
              isVisible: true,
              colName: 'paymentRateAndPeriodShort',
              width: 200,
              position: -4,
              title: 'Параметри пені: %, днів',
              type: cellTypes.TEXT,
            },
            paymentRateAndPeriodLong: {
              isVisible: true,
              colName: 'paymentRateAndPeriodLong',
              width: 200,
              position: -3,
              title: 'Параметри штрафу: %, днів',
              type: cellTypes.TEXT,
            },
            committalperiod: {
              isVisible: true,
              colName: 'committalperiod',
              width: 200,
              position: -2,
              title: 'Термін на передачу, днів',
              type: cellTypes.TEXT,
            },
            cautionEndDate: {
              isVisible: true,
              colName: 'cautionEndDate',
              width: 200,
              position: -1,
              title: 'Макс дата на попередження про закінчення',
              type: cellTypes.TEXT,
            },

            // visible

            docregnumber: {
              isVisible: true,
              colName: 'docregnumber',
              width: 200,
              position: 0,
              title: 'Внутрішній реєстраційний номер',
              type: cellTypes.TEXT,
            },
            docDate: {
              isVisible: true,
              colName: 'docDate',
              width: 200,
              position: 1,
              title: 'Діє З',
              type: cellTypes.SORT,
            },
            dvalidtillDate: {
              isVisible: true,
              colName: 'dvalidtillDate',
              width: 200,
              position: 2,
              title: 'Діє По',
              type: cellTypes.SORT,
            },
            landlord: {
              isVisible: true,
              colName: 'landlord',
              width: 200,
              position: 3,
              title: 'Орендодавець',
              type: cellTypes.SORT,
              render: renderFunc.link,
            },
            renter: {
              isVisible: true,
              colName: 'renter',
              width: 200,
              position: 4,
              title: 'Орендар',
              type: cellTypes.SORT,
              render: renderFunc.link,
            },
            balanceKeeper: {
              isVisible: true,
              colName: 'balanceKeeper',
              width: 200,
              position: 5,
              title: 'Балансоутримувач',
              type: cellTypes.SORT,
              render: renderFunc.link,
            },
            objectsCount: {
              isVisible: true,
              colName: 'objectsCount',
              width: 200,
              position: 6,
              title: 'Кількість та тип корисних МО',
              type: cellTypes.TEXT,
            },
            objectsSquare: {
              isVisible: true,
              colName: 'objectsSquare',
              width: 200,
              position: 7,
              title: 'Загальна площа корисних МО, кв. м.',
              type: cellTypes.TEXT,
            },
            objectsCUCount: {
              isVisible: true,
              colName: 'objectsCUCount',
              width: 200,
              position: 8,
              title: 'Кількість МО загального користування',
              type: cellTypes.TEXT,
            },
            objectsCUSquare: {
              isVisible: true,
              colName: 'objectsCUSquare',
              width: 200,
              position: 9,
              title: 'Загальна площа МО загального користування, кв. м.',
              type: cellTypes.TEXT,
            },
            leaseratedetectmethods: {
              isVisible: true,
              colName: 'leaseratedetectmethods',
              width: 200,
              position: 10,
              title: 'Методи визначення орендної ставки',
              type: cellTypes.DROP_DOWN,
            },
            leasebaseperiods: {
              isVisible: true,
              colName: 'leasebaseperiods',
              width: 200,
              position: 11,
              title: 'Режими оренди та розрахунків',
              type: cellTypes.DROP_DOWN,
            },
            leaseratedirectories: {
              isVisible: true,
              colName: 'leaseratedirectories',
              width: 200,
              position: 12,
              title: 'Цільові призначення',
              type: cellTypes.DROP_DOWN,
            },
            initialtotalleasepriceyearSum: {
              isVisible: true,
              colName: 'initialtotalleasepriceyearSum',
              width: 200,
              position: 13,
              title: 'Сумарна стартова річна орендна плата без ПДВ за Методікою, грн',
              type: cellTypes.TEXT,
            },
            actualtotalleasepriceyearSum: {
              isVisible: true,
              colName: 'actualtotalleasepriceyearSum',
              width: 200,
              position: 14,
              title: 'Сумарна актуальна річна орендна плата без ПДВ, грн',
              type: cellTypes.TEXT,
            },
            totalleasepriceperbasemonthSum: {
              isVisible: true,
              colName: 'totalleasepriceperbasemonthSum',
              width: 200,
              position: 15,
              title: 'Сумарна стартова  орендна плата за місяць без ПДВ, грн',
              type: cellTypes.TEXT,
            },
            // totalleasepriceperbasedaySum: {
            //   isVisible: true,
            //   colName: 'totalleasepriceperbasedaySum',
            //   width: 200,
            //   position: 16,
            //   title: 'Сумарна стартова  орендна плата за добу без ПДВ, грн',
            //   type: cellTypes.TEXT
            // },
            // totalleasepriceperbasehourSum: {
            //   isVisible: true,
            //   colName: 'totalleasepriceperbasehourSum',
            //   width: 200,
            //   position: 17,
            //   title: 'Сумарна стартова орендна плата за годину без ПДВ, грн',
            //   type: cellTypes.TEXT
            // },
            // leasepriceperoneunitmonthSum: {
            //   isVisible: true,
            //   colName: 'leasepriceperoneunitmonthSum',
            //   width: 200,
            //   position: 18,
            //   title: 'Сумарна орендна плата за одну одиницю в місяць без ПДВ, грн',
            //   type: cellTypes.TEXT
            // }
          },
        },
      },
    },
  },
};

export default initialSettings;
