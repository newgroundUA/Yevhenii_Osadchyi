import * as tableConstants from '../../../constants/TableToolNames';
import * as cellTypes from '../../../constants/CellTypes';

const initialSettings = {
  leaseCases: {
    register: {
      tableToolbar: {
        tasks: {
          archiveUser: {
            title: tableConstants.ARCHIVE_USER,
            isVisible: true,
          },
        },
        export: {
          pdf: {
            title: tableConstants.PDF,
            isVisible: true,
          },
        },
        filters: {
          filters: {
            title: tableConstants.FILTERS,
            isVisible: true,
          },
          specFilters: {
            title: tableConstants.SPEC_FILTERS,
            isVisible: true,
          },
        },
        config: {
          tableColumns: {
            title: tableConstants.TABLE_COLUMNS,
            isVisible: true,
          },
          toolbarManagement: {
            title: tableConstants.TOOLBAR_MANAGEMENT,
            isVisible: true,
          },
        },
      },
      tableBody: {
        columns: {
          fixed: {
            checkbox: {
              isVisible: true,
              colName: 'checkbox',
              width: 30,
              position: 0,
              title: 'checkbox',
              type: cellTypes.CHECKBOX,
            },
            leaseCasesNumber: {
              isVisible: true,
              colName: 'leaseCasesNumber',
              width: 200,
              position: 1,
              title: 'Реєстраційний номер ОС',
              type: cellTypes.LINK,
            },
            action: {
              isVisible: true,
              colName: 'action',
              width: 70,
              position: 2,
              title: 'Дія',
              type: cellTypes.BUTTONS,
            },
          },
          fluid: {
            // hidden

            // visible

            leaseCaseStatus: {
              isVisible: true,
              colName: 'leaseCaseStatus',
              width: 200,
              position: 0,
              title: 'Операційний стан',
              type: cellTypes.DROP_DOWN,
            },
            caseDateFrom: {
              isVisible: true,
              colName: 'caseDateFrom',
              width: 200,
              position: 1,
              title: 'Дата відкриття справи',
              type: cellTypes.TEXT,
            },
            caseDateTo: {
              isVisible: true,
              colName: 'caseDateTo',
              width: 200,
              position: 2,
              title: 'Дата закриття справи',
              type: cellTypes.TEXT,
            },
            leaseObjectNameAndNumber: {
              isVisible: true,
              colName: 'leaseObjectNameAndNumber',
              width: 200,
              position: 3,
              title: "Номер та Назва об'єкту оренди",
              type: cellTypes.TEXT,
            },
            landlord: {
              isVisible: true,
              colName: 'landlord',
              width: 200,
              position: 4,
              title: 'Орендодавець',
              type: cellTypes.TEXT,
            },
            holders: {
              isVisible: true,
              colName: 'holders',
              width: 200,
              position: 5,
              title: 'Балансоутримувач',
              type: cellTypes.DROP_DOWN,
            },
            lessee: {
              isVisible: true,
              colName: 'lessee',
              width: 200,
              position: 6,
              title: 'Орендар',
              type: cellTypes.TEXT,
            },
            localityArea: {
              isVisible: true,
              colName: 'localityarea',
              width: 200,
              position: 7,
              title: 'Адреса: Адмінрайон міста',
              type: cellTypes.TEXT,
            },
            streetTypeAndName: {
              isVisible: true,
              colName: 'streetTypeAndName',
              width: 200,
              position: 8,
              title: 'Адреса: вулиця',
              type: cellTypes.TEXT,
            },
            externalAddress: {
              isVisible: true,
              colName: 'externalAddress',
              width: 200,
              position: 9,
              title: 'Адреса: номер будівлі / комплексу',
              type: cellTypes.TEXT,
            },
            externalBuilding: {
              isVisible: true,
              colName: 'externalBuilding',
              width: 200,
              position: 10,
              title: 'Адреса: номер корпусу / секції / БТІ',
              type: cellTypes.TEXT,
            },
            floors: {
              isVisible: true,
              colName: 'floors',
              width: 200,
              position: 11,
              title: 'Поверхи розташування',
              type: cellTypes.DROP_DOWN,
            },
            leaseObjectUsefullSpace: {
              isVisible: true,
              colName: 'leaseObjectUsefullSpace',
              width: 200,
              position: 12,
              title: 'Корисна площа м.кв.',
              type: cellTypes.TEXT,
            },
            objectsInLeaseNumber: {
              isVisible: true,
              colName: 'objectsInLeaseNumber',
              width: 200,
              position: 13,
              title: "Кількість майнових об'єктів в складі",
              type: cellTypes.TEXT,
            },
            plannedLeasePurpose: {
              isVisible: true,
              colName: 'plannedLeasePurpose',
              width: 200,
              position: 14,
              title: 'Планові призначення та ставка',
              type: cellTypes.DROP_DOWN,
            },
            applicationToLeaseCounter: {
              isVisible: true,
              colName: 'applicationToLeaseCounter',
              width: 200,
              position: 15,
              title: 'Кількість актуальних Заяв на оренду',
              type: cellTypes.TEXT,
            },
            contractsDocCounter: {
              isVisible: true,
              colName: 'contractsDocCounter',
              width: 200,
              position: 16,
              title: 'Кількість договорних документів',
              type: cellTypes.TEXT,
            },
            leaseObjectEvaluationDocsCounter: {
              isVisible: true,
              colName: 'leaseObjectEvaluationDocsCounter',
              width: 200,
              position: 17,
              title: 'Кількість документів про оцінку',
              type: cellTypes.TEXT,
            },
            insuranceDocCounter: {
              isVisible: true,
              colName: 'insuranceDocCounter',
              width: 200,
              position: 18,
              title: 'Кількість документів про страхування',
              type: cellTypes.TEXT,
            },
          },
        },
      },
    },
  },
};

export default initialSettings;
