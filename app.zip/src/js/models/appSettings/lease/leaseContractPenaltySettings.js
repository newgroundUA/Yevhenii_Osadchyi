import * as tableConstants from '../../../constants/TableToolNames';
import * as cellTypes from '../../../constants/CellTypes';

const initialSettings = {
  leaseContractPenalty: {
    register: {
      tableToolbar: {
        tasks: {
          archiveUser: {
            title: tableConstants.ARCHIVE_USER,
            isVisible: true,
          },
        },
        export: {
          pdf: {
            title: tableConstants.PDF,
            isVisible: true,
          },
        },
        filters: {
          filters: {
            title: tableConstants.FILTERS,
            isVisible: true,
          },
          specFilters: {
            title: tableConstants.SPEC_FILTERS,
            isVisible: true,
          },
        },
        config: {
          tableColumns: {
            title: tableConstants.TABLE_COLUMNS,
            isVisible: true,
          },
          toolbarManagement: {
            title: tableConstants.TOOLBAR_MANAGEMENT,
            isVisible: true,
          },
        },
      },
      tableBody: {
        columns: {
          fixed: {
            checkbox: {
              isVisible: true,
              colName: 'checkbox',
              width: 30,
              position: 0,
              title: 'checkbox',
              type: cellTypes.CHECKBOX,
            },
            penaltyRegNumber: {
              isVisible: true,
              colName: 'penaltyRegNumber',
              width: 200,
              position: 1,
              title: 'Реєстраційний номер неустойки',
              type: cellTypes.TEXT,
            },
            action: {
              isVisible: true,
              colName: 'action',
              width: 70,
              position: 2,
              title: 'Дія',
              type: cellTypes.BUTTONS,
            },
          },
          fluid: {
            leaseContract: {
              isVisible: true,
              colName: 'leaseContract',
              width: 200,
              position: 0,
              title: 'Неустойка за Договором',
              type: cellTypes.TEXT,
            },
            // common
            reportingPeriodYear: {
              isVisible: true,
              colName: 'reportingPeriodYear',
              width: 200,
              position: 0,
              title: 'Звітний період: рік',
              type: cellTypes.TEXT,
            },

            reportingPeriodMonth: {
              isVisible: true,
              colName: 'reportingPeriodMonth',
              width: 200,
              position: 0,
              title: 'Звітний період: місяць',
              type: cellTypes.TEXT,
            },

            landlord: {
              isVisible: true,
              colName: 'landlord',
              width: 200,
              position: 0,
              title: 'Орендодавець',
              type: cellTypes.TEXT,
            },

            balancekeeper: {
              isVisible: true,
              colName: 'balancekeeper',
              width: 200,
              position: 0,
              title: 'Балансоутримувач',
              type: cellTypes.TEXT,
            },

            renter: {
              isVisible: true,
              colName: 'renter',
              width: 200,
              position: 0,
              title: 'Орендар',
              type: cellTypes.TEXT,
            },

            planningPaymentDate: {
              isVisible: true,
              colName: 'planningPaymentDate',
              width: 200,
              position: 0,
              title: 'Планова дата оплати',
              type: cellTypes.TEXT,
            },

            factPaymentDate: {
              isVisible: true,
              colName: 'factPaymentDate',
              width: 200,
              position: 0,
              title: 'Фактична дата оплати',
              type: cellTypes.TEXT,
            },

            planningPaymentAmount: {
              isVisible: true,
              colName: 'planningPaymentAmount',
              width: 200,
              position: 0,
              title: 'Планова сума оплати',
              type: cellTypes.TEXT,
            },

            factPaymentAmount: {
              isVisible: true,
              colName: 'factPaymentAmount',
              width: 200,
              position: 0,
              title: 'Фактична сума оплати',
              type: cellTypes.TEXT,
            },

            penaltyType: {
              isVisible: true,
              colName: 'penaltyType',
              width: 200,
              position: 0,
              title: 'Тип нарахованої неустойки',
              type: cellTypes.TEXT,
            },

            penaltySizeSource: {
              isVisible: true,
              colName: 'penaltySizeSource',
              width: 200,
              position: 0,
              title: 'Джерело розміру неустойкі',
              type: cellTypes.TEXT,
            },

            penaltySize: {
              isVisible: true,
              colName: 'penaltySize',
              width: 200,
              position: 0,
              title: 'Розмір неустойки (ставка)',
              type: cellTypes.TEXT,
            },

            penaltyAmount: {
              isVisible: true,
              colName: 'penaltyAmount',
              width: 200,
              position: 0,
              title: 'Сума неустойки',
              type: cellTypes.TEXT,
            },

            residualAmount: {
              isVisible: true,
              colName: 'residualAmount',
              width: 200,
              position: 0,
              title: 'Остаточна сума до сплати',
              type: cellTypes.TEXT,
            },
          },
        },
      },
    },
  },
};

export default initialSettings;
