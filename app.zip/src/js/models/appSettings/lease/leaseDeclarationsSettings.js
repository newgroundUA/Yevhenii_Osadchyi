import * as tableConstants from '../../../constants/TableToolNames';
import * as cellTypes from '../../../constants/CellTypes';

const initialSettings = {
  leaseDeclarations: {
    register: {
      tableToolbar: {
        tasks: {
          archiveUser: {
            title: tableConstants.ARCHIVE_USER,
            isVisible: true,
          },
        },
        export: {
          pdf: {
            title: tableConstants.PDF,
            isVisible: true,
          },
        },
        filters: {
          filters: {
            title: tableConstants.FILTERS,
            isVisible: true,
          },
          specFilters: {
            title: tableConstants.SPEC_FILTERS,
            isVisible: true,
          },
        },
        config: {
          tableColumns: {
            title: tableConstants.TABLE_COLUMNS,
            isVisible: true,
          },
          toolbarManagement: {
            title: tableConstants.TOOLBAR_MANAGEMENT,
            isVisible: true,
          },
        },
      },
      tableBody: {
        columns: {
          fixed: {
            checkbox: {
              isVisible: true,
              colName: 'checkbox',
              width: 30,
              position: 0,
              title: 'checkbox',
              type: cellTypes.CHECKBOX,
            },
            docSerialAndNumber: {
              isVisible: true,
              colName: 'docSerialAndNumber',
              width: 200,
              position: 1,
              title: 'Серія та номер Заяви',
              type: cellTypes.LINK,
            },
            action: {
              isVisible: true,
              colName: 'action',
              width: 70,
              position: 2,
              title: 'Дія',
              type: cellTypes.BUTTONS,
            },
          },
          fluid: {
            // hidden

            // visible

            docregnumber: {
              isVisible: true,
              colName: 'docregnumber',
              width: 200,
              position: 0,
              title: 'Внутрішній реєстраційний номер',
              type: cellTypes.TEXT,
            },
            docDate: {
              isVisible: true,
              colName: 'docDate',
              width: 200,
              position: 1,
              title: 'Дата створення заяви',
              type: cellTypes.TEXT,
            },
            dateTo: {
              isVisible: true,
              colName: 'dateTo',
              width: 200,
              position: 2,
              title: 'Дата закриття заяви',
              type: cellTypes.TEXT,
            },
            applicant: {
              isVisible: true,
              colName: 'applicant',
              width: 200,
              position: 3,
              title: 'Контрагент Заявник',
              type: cellTypes.TEXT,
            },
            landlord: {
              isVisible: true,
              colName: 'landlord',
              width: 200,
              position: 4,
              title: 'Контрагент Орендодавець',
              type: cellTypes.TEXT,
            },
            holders: {
              isVisible: true,
              colName: 'holders',
              width: 200,
              position: 5,
              title: 'Контрагенти-Балансоутримувачі',
              type: cellTypes.DROP_DOWN,
            },
            objectsInApplicationToLeaseListCount: {
              isVisible: true,
              colName: 'objectsInApplicationToLeaseListCount',
              width: 200,
              position: 6,
              title: "Кількість майнових об'єктів",
              type: cellTypes.TEXT,
            },
            leaseRateDirectoriesInObjects: {
              isVisible: true,
              colName: 'leaseRateDirectoriesInObjects',
              width: 200,
              position: 7,
              title: 'Запропоновані призначення для МО',
              type: cellTypes.TEXT,
            },
            planLeaseBasePeriodsInObjects: {
              isVisible: true,
              colName: 'planLeaseBasePeriodsInObjects',
              width: 200,
              position: 8,
              title: 'Запропоновані режими для МО',
              type: cellTypes.TEXT,
            },
            planLeaseTermsInObjects: {
              isVisible: true,
              colName: 'planLeaseTermsInObjects',
              width: 200,
              position: 9,
              title: 'Запропоновані терміни оренди для МО, місяців',
              type: cellTypes.DROP_DOWN,
            },
            leaseObjectsCountAndObjectsSum: {
              isVisible: true,
              colName: 'leaseObjectsCountAndObjectsSum',
              width: 200,
              position: 10,
              title: "Кількість об'єктів оренди та МО в складі",
              type: cellTypes.TEXT,
            },
            leaseRateDirectoriesInLeaseObjects: {
              isVisible: true,
              colName: 'leaseRateDirectoriesInLeaseObjects',
              width: 200,
              position: 11,
              title: 'Запропоновані призначення для ОО',
              type: cellTypes.DROP_DOWN,
            },
            planLeaseBasePeriodsInLeaseObjects: {
              isVisible: true,
              colName: 'planLeaseBasePeriodsInLeaseObjects',
              width: 200,
              position: 12,
              title: 'Запропоновані режими для ОО',
              type: cellTypes.DROP_DOWN,
            },
            planLeaseTermsInLeaseObjects: {
              isVisible: true,
              colName: 'planLeaseTermsInLeaseObjects',
              width: 200,
              position: 13,
              title: 'Запропоновані терміни оренди для ОО, місяців',
              type: cellTypes.DROP_DOWN,
            },
          },
        },
      },
    },
  },
};

export default initialSettings;
