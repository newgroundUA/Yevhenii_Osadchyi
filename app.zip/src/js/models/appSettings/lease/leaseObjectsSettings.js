import * as tableConstants from '../../../constants/TableToolNames';
import * as cellTypes from '../../../constants/CellTypes';

const initialSettings = {
  leaseObjects: {
    register: {
      tableToolbar: {
        tasks: {
          archiveUser: {
            title: tableConstants.ARCHIVE_USER,
            isVisible: true,
          },
        },
        export: {
          pdf: {
            title: tableConstants.PDF,
            isVisible: true,
          },
        },
        filters: {
          filters: {
            title: tableConstants.FILTERS,
            isVisible: true,
          },
          specFilters: {
            title: tableConstants.SPEC_FILTERS,
            isVisible: true,
          },
        },
        config: {
          tableColumns: {
            title: tableConstants.TABLE_COLUMNS,
            isVisible: true,
          },
          toolbarManagement: {
            title: tableConstants.TOOLBAR_MANAGEMENT,
            isVisible: true,
          },
        },
      },
      tableBody: {
        columns: {
          fixed: {
            checkbox: {
              isVisible: true,
              colName: 'checkbox',
              width: 30,
              position: 0,
              title: 'checkbox',
              type: cellTypes.CHECKBOX,
            },
            shortname: {
              isVisible: true,
              colName: 'shortname',
              width: 200,
              position: 1,
              title: "Назва об'єкту оренди",
              type: cellTypes.LINK,
            },
            action: {
              isVisible: true,
              colName: 'action',
              width: 70,
              position: 2,
              title: 'Дія',
              type: cellTypes.BUTTONS,
            },
          },
          fluid: {
            // hidden

            // visible

            leaseobjectnumber: {
              isVisible: true,
              colName: 'leaseobjectnumber',
              width: 200,
              position: 0,
              title: "Обліковий номер об'єкту оренди",
              type: cellTypes.TEXT,
            },
            landlord: {
              isVisible: true,
              colName: 'landlord',
              width: 200,
              position: 1,
              title: 'Орендодавець',
              type: cellTypes.TEXT,
            },
            landlordlegaltype: {
              isVisible: true,
              colName: 'landlordlegaltype',
              width: 200,
              position: 2,
              title: 'Тип орендодавця',
              type: cellTypes.TEXT,
            },
            holder: {
              isVisible: true,
              colName: 'holder',
              width: 200,
              position: 3,
              title: 'Балансоутримувач',
              type: cellTypes.DROP_DOWN,
            },
            rightstype: {
              isVisible: true,
              colName: 'rightstype',
              width: 200,
              position: 4,
              title: 'Тип речового права',
              type: cellTypes.DROP_DOWN,
            },
            localityarea: {
              isVisible: true,
              colName: 'localityarea',
              width: 200,
              position: 5,
              title: 'Адреса: Адмінрайон міста',
              type: cellTypes.TEXT,
            },
            streetTypeAndName: {
              isVisible: true,
              colName: 'streetTypeAndName',
              width: 200,
              position: 6,
              title: 'Адреса: вулиця',
              type: cellTypes.TEXT,
            },
            externalAddress: {
              isVisible: true,
              colName: 'externalAddress',
              width: 200,
              position: 7,
              title: 'Адреса: номер будівлі / комплексу',
              type: cellTypes.TEXT,
            },
            externalBuilding: {
              isVisible: true,
              colName: 'externalBuilding',
              width: 200,
              position: 8,
              title: 'Адреса: номер корпусу / секції / БТІ',
              type: cellTypes.TEXT,
            },
            floor: {
              isVisible: true,
              colName: 'floor',
              width: 200,
              position: 9,
              title: 'Поверхи розташування',
              type: cellTypes.DROP_DOWN,
            },
            leaseobjecttotalspace: {
              isVisible: true,
              colName: 'leaseobjecttotalspace',
              width: 200,
              position: 10,
              title: 'Загальна площа м.кв.',
              type: cellTypes.TEXT,
            },
            leaseobjectusefullspace: {
              isVisible: true,
              colName: 'leaseobjectusefullspace',
              width: 200,
              position: 11,
              title: 'Корисна площа м.кв.',
              type: cellTypes.TEXT,
            },
            leaseobjectcommonusespace: {
              isVisible: true,
              colName: 'leaseobjectcommonusespace',
              width: 200,
              position: 12,
              title: 'Площа заг. користування',
              type: cellTypes.TEXT,
            },
            objectsCount: {
              isVisible: true,
              colName: 'objectsCount',
              width: 200,
              position: 13,
              title: "Кількість майнових об'єктів в складі",
              type: cellTypes.TEXT,
            },
            leaseobjecttype: {
              isVisible: true,
              colName: 'leaseobjecttype',
              width: 200,
              position: 14,
              title: "Тип об'єкту оренди",
              type: cellTypes.TEXT,
            },
            plannedleasepurpose: {
              isVisible: true,
              colName: 'plannedleasepurpose',
              width: 200,
              position: 15,
              title: 'Планові призначення та ставка',
              type: cellTypes.DROP_DOWN,
            },
            fromDate: {
              isVisible: true,
              colName: 'fromDate',
              width: 200,
              position: 16,
              title: 'Дата формування',
              type: cellTypes.TEXT,
            },
            tillDate: {
              isVisible: true,
              colName: 'tillDate',
              width: 200,
              position: 17,
              title: 'Дата деактивації',
              type: cellTypes.TEXT,
            },
            declarationsCount: {
              isVisible: true,
              colName: 'declarationsCount',
              width: 200,
              position: 18,
              title: 'Кількість актуальних Заяв на оренду',
              type: cellTypes.TEXT,
            },
            leasecases: {
              isVisible: true,
              colName: 'leasecases',
              width: 200,
              position: 19,
              title: "Орендна справа об'єкту",
              type: cellTypes.DROP_DOWN,
            },
          },
        },
      },
    },
  },
};

export default initialSettings;
