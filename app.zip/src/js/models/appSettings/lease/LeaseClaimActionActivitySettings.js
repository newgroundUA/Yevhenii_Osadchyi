import * as tableConstants from '../../../constants/TableToolNames';
import * as cellTypes from '../../../constants/CellTypes';
import * as renderFunc from '../../../helpers/cellRenderFunctions';

const initialSettings = {
  claimActionActivity: {
    register: {
      tableToolbar: {
        tasks: {},
        export: {
          xls: {
            title: tableConstants.XLS,
            isVisible: true,
          },
        },
        filters: {
          filters: {
            title: tableConstants.FILTERS,
            isVisible: true,
          },
        },
        config: {
          tableColumns: {
            title: tableConstants.TABLE_COLUMNS,
            isVisible: true,
          },
          toolbarManagement: {
            title: tableConstants.TOOLBAR_MANAGEMENT,
            isVisible: true,
          },
        },
      },
      tableBody: {
        columns: {
          fixed: {
            checkbox: {
              isVisible: true,
              colName: 'checkbox',
              width: 30,
              position: 0,
              title: 'checkbox',
              type: cellTypes.CHECKBOX,
            },
            regNumber: {
              isVisible: true,
              colName: 'regNumber',
              width: 200,
              position: 1,
              title: 'Реєстраційний номер',
              type: cellTypes.SORT,
            },
            action: {
              isVisible: true,
              colName: 'action',
              width: 70,
              position: 2,
              title: 'Дія',
              type: cellTypes.BUTTONS,
            },
          },
          fluid: {
            contractNumber: {
              isVisible: true,
              colName: 'contractNumber',
              width: 200,
              position: 3,
              title: 'Номер договору оренди',
              type: cellTypes.SORT,
              render: renderFunc.link,
            },
            contractRegDate: {
              isVisible: true,
              colName: 'contractRegDate',
              width: 200,
              position: 4,
              title: 'Дата договору оренди',
              type: cellTypes.SORT,
            },
            landlordName: {
              isVisible: true,
              colName: 'landlordName',
              width: 200,
              position: 5,
              title: 'Орендодавець',
              type: cellTypes.SORT,
              render: renderFunc.link,
            },
            renterName: {
              isVisible: true,
              colName: 'renterName',
              width: 200,
              position: 6,
              title: 'Орендар',
              type: cellTypes.SORT,
              render: renderFunc.link,
            },
            balanceKeeperName: {
              isVisible: true,
              colName: 'balanceKeeperName',
              width: 200,
              position: 7,
              title: 'Балансоутримувач',
              type: cellTypes.SORT,
              render: renderFunc.link,
            },
            initialDebtTotal: {
              isVisible: true,
              colName: 'initialDebtTotal',
              width: 200,
              position: 8,
              title: 'Початкова сума заборгованості - загальна',
              type: cellTypes.SORT,
            },
            initialDebtLease: {
              isVisible: true,
              colName: 'initialDebtLease',
              width: 200,
              position: 9,
              title: 'Початкова сума заборгованості - по оренді',
              type: cellTypes.SORT,
            },
            initialDebtFine: {
              isVisible: true,
              colName: 'initialDebtFine',
              width: 200,
              position: 10,
              title: 'Початкова сума заборгованості - штраф/пеня',
              type: cellTypes.SORT,
            },
            currentDebtTotal: {
              isVisible: true,
              colName: 'currentDebtTotal',
              width: 200,
              position: 11,
              title: 'Поточна сума заборгованості - загальна',
              type: cellTypes.SORT,
            },
            currentDebtLease: {
              isVisible: true,
              colName: 'currentDebtLease',
              width: 200,
              position: 12,
              title: 'Поточна сума заборгованості - по оренді',
              type: cellTypes.SORT,
            },
            currentDebtFine: {
              isVisible: true,
              colName: 'currentDebtFine',
              width: 200,
              position: 13,
              title: 'Поточна сума заборгованості - штраф/пеня',
              type: cellTypes.SORT,
            },
            statusType: {
              isVisible: true,
              colName: 'statusType',
              width: 200,
              position: 14,
              title: 'Стан ППД',
              type: cellTypes.SORT,
            },
            stepsCount: {
              isVisible: true,
              colName: 'stepsCount',
              width: 200,
              position: 15,
              title: 'Кількість заходів',
              type: cellTypes.TEXT,
            },
            legalAffairs: {
              isVisible: true,
              colName: 'legalAffairs',
              width: 200,
              position: 16,
              title: 'Юридична справа',
              render: renderFunc.dropDownWithLink,
            },
          },
        },
      },
    },
  },
};

export default initialSettings;
