import * as tableConstants from '../../../constants/TableToolNames';
import * as cellTypes from '../../../constants/CellTypes';

const initialSettings = {
  leaseRooms: {
    register: {
      tableToolbar: {
        tasks: {
          archiveUser: {
            title: tableConstants.ARCHIVE_USER,
            isVisible: true,
          },
        },
        export: {
          pdf: {
            title: tableConstants.PDF,
            isVisible: true,
          },
        },
        filters: {
          filters: {
            title: tableConstants.FILTERS,
            isVisible: true,
          },
          specFilters: {
            title: tableConstants.SPEC_FILTERS,
            isVisible: true,
          },
        },
        config: {
          tableColumns: {
            title: tableConstants.TABLE_COLUMNS,
            isVisible: true,
          },
          toolbarManagement: {
            title: tableConstants.TOOLBAR_MANAGEMENT,
            isVisible: true,
          },
        },
      },
      tableBody: {
        columns: {
          fixed: {
            checkbox: {
              isVisible: true,
              colName: 'checkbox',
              width: 30,
              position: 0,
              title: 'checkbox',
              type: cellTypes.CHECKBOX,
            },
            shortName: {
              isVisible: true,
              colName: 'shortName',
              width: 200,
              position: 1,
              title: 'Назва приміщення',
              type: cellTypes.LINK,
            },
            action: {
              isVisible: true,
              colName: 'action',
              width: 70,
              position: 2,
              title: 'Дія',
              type: cellTypes.BUTTONS,
            },
          },
          fluid: {
            // hidden

            // visible

            accountingItemId: {
              isVisible: true,
              colName: 'accountingItemId',
              width: 200,
              position: 0,
              title: 'Обліковий номер',
              type: cellTypes.TEXT,
            },
            holder: {
              isVisible: true,
              colName: 'holder',
              width: 200,
              position: 1,
              title: 'Балансоутримувач',
              type: cellTypes.DROP_DOWN,
            },
            propertyLawType: {
              isVisible: true,
              colName: 'propertyLawType',
              width: 200,
              position: 2,
              title: 'Тип речового права',
              type: cellTypes.DROP_DOWN,
            },
            localityArea: {
              isVisible: true,
              colName: 'localityArea',
              width: 200,
              position: 3,
              title: 'Адреса: Адмінрайон міста',
              type: cellTypes.TEXT,
            },
            streetTypeAndName: {
              isVisible: true,
              colName: 'streetTypeAndName',
              width: 200,
              position: 4,
              title: 'Адреса: вулиця',
              type: cellTypes.TEXT,
            },
            adrObjAndType: {
              isVisible: true,
              colName: 'adrObjAndType',
              width: 200,
              position: 5,
              title: 'Адреса: номер будівлі / комплексу',
              type: cellTypes.TEXT,
            },
            adrBuilding: {
              isVisible: true,
              colName: 'adrBuilding',
              width: 200,
              position: 6,
              title: 'Адреса: номер корпусу / секції / БТІ',
              type: cellTypes.TEXT,
            },
            floor: {
              isVisible: true,
              colName: 'floor',
              width: 200,
              position: 7,
              title: 'Адреса: поверх',
              type: cellTypes.DROP_DOWN,
            },
            premiseSpace: {
              isVisible: true,
              colName: 'premiseSpace',
              width: 200,
              position: 8,
              title: 'Загальна площа м.кв.',
              type: cellTypes.TEXT,
            },
            usefullSpace: {
              isVisible: true,
              colName: 'usefullSpace',
              width: 200,
              position: 9,
              title: 'Корисна площа м.кв.',
              type: cellTypes.TEXT,
            },
            premisePurpose: {
              isVisible: true,
              colName: 'premisePurpose',
              width: 200,
              position: 10,
              title: 'Призначення приміщення',
              type: cellTypes.TEXT,
            },
            premiseEquip: {
              isVisible: true,
              colName: 'premiseEquip',
              width: 200,
              position: 11,
              title: 'Оздоблення приміщення',
              type: cellTypes.TEXT,
            },
            totalFieldSpace: {
              isVisible: true,
              colName: 'totalFieldSpace',
              width: 200,
              position: 12,
              title: 'Загальна площа орендованих ділянок, кв.м.',
              type: cellTypes.TEXT,
            },
            freeDate: {
              isVisible: true,
              colName: 'freeDate',
              width: 200,
              position: 13,
              title: 'Дата з якої "вільний до оренди',
              type: cellTypes.TEXT,
            },
            declarationsCount: {
              isVisible: true,
              colName: 'declarationsCount',
              width: 200,
              position: 14,
              title: 'Кількість актуальних Заяв на оренду',
              type: cellTypes.TEXT,
            },
          },
        },
      },
    },
  },
};

export default initialSettings;
