import * as tableConstants from '../../../constants/TableToolNames';
import * as cellTypes from '../../../constants/CellTypes';

const initialSettings = {
  leaseContractPaymentSchedule: {
    register: {
      tableToolbar: {
        tasks: {
          archiveUser: {
            title: tableConstants.ARCHIVE_USER,
            isVisible: true,
          },
        },
        export: {
          pdf: {
            title: tableConstants.PDF,
            isVisible: true,
          },
        },
        filters: {
          filters: {
            title: tableConstants.FILTERS,
            isVisible: true,
          },
          specFilters: {
            title: tableConstants.SPEC_FILTERS,
            isVisible: true,
          },
        },
        config: {
          tableColumns: {
            title: tableConstants.TABLE_COLUMNS,
            isVisible: true,
          },
          toolbarManagement: {
            title: tableConstants.TOOLBAR_MANAGEMENT,
            isVisible: true,
          },
        },
      },
      tableBody: {
        columns: {
          fixed: {
            checkbox: {
              isVisible: true,
              colName: 'checkbox',
              width: 30,
              position: 0,
              title: 'checkbox',
              type: cellTypes.CHECKBOX,
            },
            leaseContract: {
              isVisible: true,
              colName: 'leaseContract',
              width: 200,
              position: 1,
              title: 'Договір оренди',
              type: cellTypes.LINK,
            },
            action: {
              isVisible: true,
              colName: 'action',
              width: 70,
              position: 2,
              title: 'Дія',
              type: cellTypes.BUTTONS,
            },
          },
          fluid: {
            periodYear: {
              isVisible: true,
              colName: 'periodYear',
              width: 200,
              position: 0,
              title: 'Звітний період: рік',
              type: cellTypes.TEXT,
            },
            periodMonth: {
              isVisible: true,
              colName: 'periodMonth',
              width: 200,
              position: 1,
              title: 'Звітний період: місяць',
              type: cellTypes.TEXT,
            },
            landlord: {
              isVisible: true,
              colName: 'landlord',
              width: 200,
              position: 2,
              title: 'Орендодавець',
              type: cellTypes.TEXT,
            },
            balanceKeeper: {
              isVisible: true,
              colName: 'balanceKeeper',
              width: 200,
              position: 3,
              title: 'Балансоутримувач',
              type: cellTypes.TEXT,
            },
            renter: {
              isVisible: true,
              colName: 'renter',
              width: 200,
              position: 4,
              title: 'Орендар',
              type: cellTypes.TEXT,
            },
            paymentDatePlan: {
              isVisible: true,
              colName: 'paymentDatePlan',
              width: 200,
              position: 5,
              title: 'Запланована дата платежу',
              type: cellTypes.TEXT,
            },
            // leaseOperationMode: {
            //   isVisible: true,
            //   colName: 'leaseOperationMode',
            //   width: 200,
            //   position: 6,
            //   title: 'Режим оренди об\'єкту',
            //   type: cellTypes.TEXT
            // },
            // forecastMLTQuantityByPeriod: {
            //   isVisible: true,
            //   colName: 'forecastMLTQuantityByPeriod',
            //   width: 200,
            //   position: 7,
            //   title: 'Кількість МСО в ЗП Прогнозна',
            //   type: cellTypes.TEXT
            // },
            forecastRental: {
              isVisible: true,
              colName: 'forecastRental',
              width: 200,
              position: 8,
              title: 'Орендна плата за прогнозним ІІ, грн',
              type: cellTypes.TEXT,
            },
            forecastLeaseTotalAmount: {
              isVisible: true,
              colName: 'forecastLeaseTotalAmount',
              width: 200,
              position: 9,
              title: 'Прогнозна за ІІ сума до сплати, грн*',
              type: cellTypes.TEXT,
            },
            contractRental: {
              isVisible: true,
              colName: 'contractRental',
              width: 200,
              position: 10,
              title: 'Договірна орендна плата, грн.',
              type: cellTypes.TEXT,
            },
            contractLeaseTotalAmount: {
              isVisible: true,
              colName: 'contractLeaseTotalAmount',
              width: 200,
              position: 11,
              title: 'Договірна сума до сплати за оренду, грн.',
              type: cellTypes.TEXT,
            },
            // factMLTQuantityByPeriod: {
            //   isVisible: true,
            //   colName: 'factMLTQuantityByPeriod',
            //   width: 200,
            //   position: 12,
            //   title: 'Фактична кількістіь МСО в ЗП',
            //   type: cellTypes.TEXT
            // },
            factRental: {
              isVisible: true,
              colName: 'factRental',
              width: 200,
              position: 13,
              title: 'Фактична орендна плата, грн.',
              type: cellTypes.TEXT,
            },
            factLeaseTotalAmount: {
              isVisible: true,
              colName: 'factLeaseTotalAmount',
              width: 200,
              position: 14,
              title: 'Фактична сума до сплати за оренду, грн.',
              type: cellTypes.TEXT,
            },
          },
        },
      },
    },
  },
};

export default initialSettings;
