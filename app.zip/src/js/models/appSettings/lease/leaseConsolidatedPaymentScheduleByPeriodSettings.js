import * as tableConstants from '../../../constants/TableToolNames';
import * as cellTypes from '../../../constants/CellTypes';

const initialSettings = {
  leaseConsolidatedPaymentScheduleByPeriod: {
    register: {
      tableToolbar: {
        tasks: {
          archiveUser: {
            title: tableConstants.ARCHIVE_USER,
            isVisible: true,
          },
        },
        export: {
          pdf: {
            title: tableConstants.PDF,
            isVisible: true,
          },
        },
        filters: {
          filters: {
            title: tableConstants.FILTERS,
            isVisible: true,
          },
          specFilters: {
            title: tableConstants.SPEC_FILTERS,
            isVisible: true,
          },
        },
        config: {
          tableColumns: {
            title: tableConstants.TABLE_COLUMNS,
            isVisible: true,
          },
          toolbarManagement: {
            title: tableConstants.TOOLBAR_MANAGEMENT,
            isVisible: true,
          },
        },
      },
      tableBody: {
        columns: {
          fixed: {
            checkbox: {
              isVisible: true,
              colName: 'checkbox',
              width: 30,
              position: 0,
              title: 'checkbox',
              type: cellTypes.CHECKBOX,
            },
            reportingPeriodYear: {
              isVisible: true,
              colName: 'reportingPeriodYear',
              width: 200,
              position: 1,
              title: 'Звітний період: рік',
              type: cellTypes.TEXT,
            },
            // action: {
            //   isVisible: true,
            //   colName: 'action',
            //   width: 70,
            //   position: 2,
            //   title: 'Дія',
            //   type: cellTypes.BUTTONS
            // }
          },
          fluid: {
            reportingPeriodMonth: {
              isVisible: true,
              colName: 'reportingPeriodMonth',
              width: 200,
              position: 0,
              title: 'Звітний період: місяць',
              type: cellTypes.TEXT,
            },
            // common
            landlord: {
              isVisible: true,
              colName: 'landlord',
              width: 200,
              position: 0,
              title: 'Орендодавець',
              type: cellTypes.TEXT,
            },

            balanceKeeper: {
              isVisible: true,
              colName: 'balanceKeeper',
              width: 200,
              position: 0,
              title: 'Балансоутримувач',
              type: cellTypes.TEXT,
            },

            renter: {
              isVisible: true,
              colName: 'renter',
              width: 200,
              position: 0,
              title: 'Орендар',
              type: cellTypes.TEXT,
            },

            forecastLeaseTotalAmount: {
              isVisible: true,
              colName: 'forecastLeaseTotalAmount',
              width: 200,
              position: 0,
              title: 'Загальна прогнозна за ИИ сума до сплати',
              type: cellTypes.TEXT,
            },

            contractLeaseTotalAmount: {
              isVisible: true,
              colName: 'contractLeaseTotalAmount',
              width: 200,
              position: 0,
              title: 'Загальна договірна сума до сплати',
              type: cellTypes.TEXT,
            },

            factLeaseTotalAmount: {
              isVisible: true,
              colName: 'factLeaseTotalAmount',
              width: 200,
              position: 0,
              title: 'Загальна фактична сума до сплати',
              type: cellTypes.TEXT,
            },

            receivedMoneyTotal: {
              isVisible: true,
              colName: 'receivedMoneyTotal',
              width: 200,
              position: 0,
              title: 'Загальна отримана оплата за оренду',
              type: cellTypes.TEXT,
            },

            penaltyGrossAmountTotal: {
              isVisible: true,
              colName: 'penaltyGrossAmountTotal',
              width: 200,
              position: 0,
              title: 'Загальна нарахована сума неустойкі',
              type: cellTypes.TEXT,
            },

            penaltyReceivedGrossAmountTotal: {
              isVisible: true,
              colName: 'penaltyReceivedGrossAmountTotal',
              width: 200,
              position: 0,
              title: 'Загальна отримана оплата за неустойкі',
              type: cellTypes.TEXT,
            },

            balanceAtTheEndOfThePeriod: {
              isVisible: true,
              colName: 'balanceAtTheEndOfThePeriod',
              width: 200,
              position: 0,
              title: 'Балансовий стан на кінець періоду',
              type: cellTypes.TEXT,
            },
          },
        },
      },
    },
  },
};

export default initialSettings;
