import * as tableConstants from '../../../constants/TableToolNames';
import * as cellTypes from '../../../constants/CellTypes';

const initialSettings = {
  leasePaymentToPurpose: {
    register: {
      tableToolbar: {
        tasks: {
          archiveUser: {
            title: tableConstants.ARCHIVE_USER,
            isVisible: true,
          },
        },
        export: {
          pdf: {
            title: tableConstants.PDF,
            isVisible: true,
          },
        },
        filters: {
          filters: {
            title: tableConstants.FILTERS,
            isVisible: true,
          },
          specFilters: {
            title: tableConstants.SPEC_FILTERS,
            isVisible: true,
          },
        },
        config: {
          tableColumns: {
            title: tableConstants.TABLE_COLUMNS,
            isVisible: true,
          },
          toolbarManagement: {
            title: tableConstants.TOOLBAR_MANAGEMENT,
            isVisible: true,
          },
        },
      },
      tableBody: {
        columns: {
          fixed: {
            checkbox: {
              isVisible: true,
              colName: 'checkbox',
              width: 30,
              position: 0,
              title: 'checkbox',
              type: cellTypes.CHECKBOX,
            },
            // leaseContract: {
            //   isVisible: true,
            //   colName: 'leaseContract',
            //   width: 200,
            //   position: 1,
            //   title: 'Договір оренди',
            //   type: cellTypes.LINK
            // },
            // action: {
            //   isVisible: true,
            //   colName: 'action',
            //   width: 70,
            //   position: 2,
            //   title: 'Дія',
            //   type: cellTypes.BUTTONS
            // }
          },
          fluid: {
            leaseContractGUID: {
              isVisible: true,
              colName: 'leaseContractGUID',
              width: 200,
              position: 0,
              title: 'Оплата по Договору',
              type: cellTypes.TEXT,
            },
            ReportingPeriodYear: {
              isVisible: true,
              colName: 'ReportingPeriodYear',
              width: 200,
              position: 1,
              title: 'Звітний період: рік',
              type: cellTypes.TEXT,
            },
            ReportingPeriodMonth: {
              isVisible: true,
              colName: 'ReportingPeriodMonth',
              width: 200,
              position: 2,
              title: 'Звітний період: місяць',
              type: cellTypes.TEXT,
            },
            LandlordGUID: {
              isVisible: true,
              colName: 'LandlordGUID',
              width: 200,
              position: 3,
              title: 'Орендодавець',
              type: cellTypes.TEXT,
            },
            BalancekeeperGUID: {
              isVisible: true,
              colName: 'BalancekeeperGUID',
              width: 200,
              position: 4,
              title: 'Балансоутримувач',
              type: cellTypes.TEXT,
            },
            RenterGUID: {
              isVisible: true,
              colName: 'RenterGUID',
              width: 200,
              position: 5,
              title: 'Орендар',
              type: cellTypes.TEXT,
            },
            PlanningPaymentDate: {
              isVisible: true,
              colName: 'PlanningPaymentDate',
              width: 200,
              position: 6,
              title: 'Планова дата оплати',
              type: cellTypes.TEXT,
            },
            Docdate: {
              isVisible: true,
              colName: 'Docdate',
              width: 200,
              position: 7,
              title: 'Фактична дата оплати',
              type: cellTypes.TEXT,
            },
            RecievedMoneyList: {
              isVisible: true,
              colName: 'RecievedMoneyList',
              width: 200,
              position: 8,
              title: 'Фактична сума оплати, грн',
              type: cellTypes.TEXT,
            },
          },
        },
      },
    },
  },
};

export default initialSettings;
