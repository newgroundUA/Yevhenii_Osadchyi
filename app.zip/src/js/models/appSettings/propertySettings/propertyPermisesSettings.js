import * as cellTypes from '../../../constants/CellTypes';
import { changePropertySortTypeForModels } from '../../../helpers/utils/propertyUtils';
import templatePropertyInitialSettings from './registersCommonColumns';

export const permisesSortList = ['premiseSpace', 'premiseUsefullSpace', 'premiseCommonUse'];

const permisesFluidColumns = {
  floorNumber: {
    isVisible: true,
    colName: 'floorNumber',
    width: 200,
    position: -1,
    title: 'Поверх',
    type: cellTypes.TEXT,
  },
  groupNumber: {
    isVisible: true,
    colName: 'groupNumber',
    width: 200,
    position: -1,
    title: 'Група приміщень',
    type: cellTypes.TEXT,
  },
  premiseSpace: {
    isVisible: true,
    colName: 'premiseSpace',
    width: 200,
    position: -1,
    title: 'Загальна площа приміщення, м. кв.',
    type: cellTypes.TEXT,
  },
  premisePurpose: {
    isVisible: true,
    colName: 'premisePurpose',
    width: 200,
    position: -1,
    title: 'Тип за призначенням',
    type: cellTypes.TEXT,
  },
  premiseConstruction: {
    isVisible: true,
    colName: 'premiseConstruction',
    width: 200,
    position: -1,
    title: 'Тип побудови',
    type: cellTypes.TEXT,
  },
  premiseUsefullSpace: {
    isVisible: true,
    colName: 'premiseUsefullSpace',
    width: 200,
    position: -1,
    title: 'Корисна площа нежитлового приміщення, м.кв.',
    type: cellTypes.TEXT,
  },
  premiseCommonUse: {
    isVisible: true,
    colName: 'premiseCommonUse',
    width: 200,
    position: -1,
    title: 'Приміщення загального користування',
    type: cellTypes.TEXT,
  },
  premiseEquip: {
    isVisible: true,
    colName: 'premiseEquip',
    width: 200,
    position: -1,
    title: 'Оздоблення приміщення',
    type: cellTypes.TEXT,
  },
  premiseFields: {
    isVisible: true,
    colName: 'premiseFields',
    width: 200,
    position: -1,
    title: 'Площадки в приміщенні',
    type: cellTypes.TEXT,
  },
};

changePropertySortTypeForModels(permisesFluidColumns, permisesSortList);

const initialSettings = {
  propertyPremises: templatePropertyInitialSettings({
    fluidColumns: permisesFluidColumns,
  }),
};

export default initialSettings;
