import * as cellTypes from '../../../constants/CellTypes';
import templatePropertyInitialSettings from './registersCommonColumns';
import { changePropertySortTypeForModels } from '../../../helpers/utils/propertyUtils';

export const whTransportsSortList = [
  'transportVinCode',
  'transportStateNumber',
  'transportEngineNumber',
  'transportChasisNumber',
  'transportBodyNumber',
  'transportBearingCapacity',
  'transportNetWeight',
];

const whTransportsFluidColumns = {
  transportTypeManufactor: {
    isVisible: true,
    colName: 'transportTypeManufactor',
    width: 200,
    position: -1,
    title: 'Виробник т/з',
    type: cellTypes.TEXT,
  },
  transportTypeMark: {
    isVisible: true,
    colName: 'transportTypeMark',
    width: 200,
    position: -1,
    title: 'Назва марки',
    type: cellTypes.TEXT,
  },
  transportTypeModel: {
    isVisible: true,
    colName: 'transportTypeModel',
    width: 200,
    position: -1,
    title: 'Назва моделі',
    type: cellTypes.TEXT,
  },
  transportCategory: {
    isVisible: true,
    colName: 'transportCategory',
    width: 200,
    position: -1,
    title: 'Категорія т/з',
    type: cellTypes.TEXT,
  },
  engineType: {
    isVisible: true,
    colName: 'engineType',
    width: 200,
    position: -1,
    title: "Тип та об'єм двигуна",
    type: cellTypes.TEXT,
  },
  fuelType: {
    isVisible: true,
    colName: 'fuelType',
    width: 200,
    position: -1,
    title: 'Тип пального',
    type: cellTypes.TEXT,
  },
  transportVinCode: {
    isVisible: true,
    colName: 'transportVinCode',
    width: 200,
    position: -1,
    title: 'Ідентифікаційний номер VIN',
    type: cellTypes.TEXT,
  },
  transportStateNumber: {
    isVisible: true,
    colName: 'transportStateNumber',
    width: 200,
    position: -1,
    title: 'Державний номер',
    type: cellTypes.TEXT,
  },
  transportEngineNumber: {
    isVisible: true,
    colName: 'transportEngineNumber',
    width: 200,
    position: -1,
    title: 'Номер двигуна',
    type: cellTypes.TEXT,
  },
  transportChasisNumber: {
    isVisible: true,
    colName: 'transportChasisNumber',
    width: 200,
    position: -1,
    title: 'Номер шасси',
    type: cellTypes.TEXT,
  },
  transportBodyNumber: {
    isVisible: true,
    colName: 'transportBodyNumber',
    width: 200,
    position: -1,
    title: 'Номер кузова',
    type: cellTypes.TEXT,
  },
  transportColor: {
    isVisible: true,
    colName: 'transportColor',
    width: 200,
    position: -1,
    title: 'Колір кузова',
    type: cellTypes.TEXT,
  },
  transportBearingCapacity: {
    isVisible: true,
    colName: 'transportBearingCapacity',
    width: 200,
    position: -1,
    title: "Дозволена вантажопід'ємність, кг",
    type: cellTypes.TEXT,
  },
  transportNetWeight: {
    isVisible: true,
    colName: 'transportNetWeight',
    width: 200,
    position: -1,
    title: 'Маса без навантаження, кг',
    type: cellTypes.TEXT,
  },
};

changePropertySortTypeForModels(whTransportsFluidColumns, whTransportsSortList);

const initialSettings = {
  propertyWhTransports: templatePropertyInitialSettings({
    fluidColumns: whTransportsFluidColumns,
  }),
};

export default initialSettings;
