import * as cellTypes from '../../../constants/CellTypes';
import templatePropertyInitialSettings from './registersCommonColumns';
import { changePropertySortTypeForModels } from '../../../helpers/utils/propertyUtils';

export const intellRightSortList = ['intelAuthors', 'intelPatentData'];

const intellRightFluidColumns = {
  intelCreationType: {
    isVisible: true,
    colName: 'intelCreationType',
    width: 200,
    position: -1,
    title: 'Тип твору за класифікатором',
    type: cellTypes.TEXT,
  },
  intelLicence: {
    isVisible: true,
    colName: 'intelLicence',
    width: 200,
    position: -1,
    title: 'Тип ліцензії',
    type: cellTypes.TEXT,
  },
  intelManufacture: {
    isVisible: true,
    colName: 'intelManufacture',
    width: 200,
    position: -1,
    title: 'Виробник',
    type: cellTypes.TEXT,
  },
  intelAuthors: {
    isVisible: true,
    colName: 'intelAuthors',
    width: 200,
    position: -1,
    title: 'Автори',
    type: cellTypes.TEXT,
  },
  intelPatentData: {
    isVisible: true,
    colName: 'intelPatentData',
    width: 200,
    position: -1,
    title: 'Номер та дата свідотства',
    type: cellTypes.TEXT,
  },
};

changePropertySortTypeForModels(intellRightFluidColumns, intellRightSortList);

const initialSettings = {
  propertyIntellRights: templatePropertyInitialSettings({
    fluidColumns: intellRightFluidColumns,
  }),
};

export default initialSettings;
