import * as cellTypes from '../../../constants/CellTypes';
import templatePropertyInitialSettings from './registersCommonColumns';

const plantsFluidColumns = {
  plantClassifier: {
    isVisible: true,
    colName: 'plantClassifier',
    width: 200,
    position: -1,
    title: 'Клас та різновид рослини',
    type: cellTypes.TEXT,
  },
  plantPurpose: {
    isVisible: true,
    colName: 'plantPurpose',
    width: 200,
    position: -1,
    title: 'Призначення',
    type: cellTypes.TEXT,
  },
};

const initialSettings = {
  propertyPlants: templatePropertyInitialSettings({ fluidColumns: plantsFluidColumns }),
};

export default initialSettings;
