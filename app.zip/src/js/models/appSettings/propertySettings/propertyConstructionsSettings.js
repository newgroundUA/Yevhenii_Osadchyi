import * as cellTypes from '../../../constants/CellTypes';
import templatePropertyInitialSettings from './registersCommonColumns';
import { changePropertySortTypeForModels } from '../../../helpers/utils/propertyUtils';

export const constructionSortList = [
  'constructionCadastreNumber',
  'constructionBuildingBTILetter',
  'constructionBuildingDMALetter',
  'constructionAddressNote',
  'constructionLength',
  'constructionWidth',
  'constructionHeight',
  'constructionDiameter',
  'constructionWeight',
  'constructionVolume',
  'constructionUsefullVolume',
  'constructionTotalSpace',
];

const constructionFluidColumns = {
  constructionCadastreNumber: {
    isVisible: true,
    colName: 'constructionCadastreNumber',
    width: 200,
    position: -1,
    title: 'Кадастровий номер будвлі',
    type: cellTypes.TEXT,
  },
  constructionBuildingBTILetter: {
    isVisible: true,
    colName: 'constructionBuildingBTILetter',
    width: 200,
    position: -1,
    title: 'Литера за БТІ',
    type: cellTypes.TEXT,
  },
  constructionBuildingDMALetter: {
    isVisible: true,
    colName: 'constructionBuildingDMALetter',
    width: 200,
    position: -1,
    title: 'Литера за ДМА',
    type: cellTypes.TEXT,
  },
  constructionAddressNote: {
    isVisible: true,
    colName: 'constructionAddressNote',
    width: 200,
    position: -1,
    title: 'Додатковий адресний опис',
    type: cellTypes.TEXT,
  },
  constructionLength: {
    isVisible: true,
    colName: 'constructionLength',
    width: 200,
    position: -1,
    title: 'Довжина, м.',
    type: cellTypes.TEXT,
  },
  constructionWidth: {
    isVisible: true,
    colName: 'constructionWidth',
    width: 200,
    position: -1,
    title: 'Ширина, м.',
    type: cellTypes.TEXT,
  },
  constructionHeight: {
    isVisible: true,
    colName: 'constructionHeight',
    width: 200,
    position: -1,
    title: 'Висота будівлі, м.',
    type: cellTypes.TEXT,
  },
  constructionDiameter: {
    isVisible: true,
    colName: 'constructionDiameter',
    width: 200,
    position: -1,
    title: 'Діаметр, м',
    type: cellTypes.TEXT,
  },
  constructionWeight: {
    isVisible: true,
    colName: 'constructionWeight',
    width: 200,
    position: -1,
    title: 'Маса споруди, т',
    type: cellTypes.TEXT,
  },
  constructionVolume: {
    isVisible: true,
    colName: 'constructionVolume',
    width: 200,
    position: -1,
    title: "Будівельний об'єм будівлі, м.куб.",
    type: cellTypes.TEXT,
  },
  constructionUsefullVolume: {
    isVisible: true,
    colName: 'constructionUsefullVolume',
    width: 200,
    position: -1,
    title: "Корисний об'єм,, м. куб.",
    type: cellTypes.TEXT,
  },
  constructionTotalSpace: {
    isVisible: true,
    colName: 'constructionTotalSpace',
    width: 200,
    position: -1,
    title: 'Загальна площа',
    type: cellTypes.TEXT,
  },
  constructionMaterials: {
    isVisible: true,
    colName: 'constructionMaterials',
    width: 200,
    position: -1,
    title: 'Матеріали споруди',
    type: cellTypes.TEXT,
  },
};

changePropertySortTypeForModels(constructionFluidColumns, constructionSortList);

const initialSettings = {
  propertyConstructions: templatePropertyInitialSettings({
    fluidColumns: constructionFluidColumns,
  }),
};

export default initialSettings;
