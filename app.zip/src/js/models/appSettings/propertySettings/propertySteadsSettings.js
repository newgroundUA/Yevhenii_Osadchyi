import * as cellTypes from '../../../constants/CellTypes';
import templatePropertyInitialSettings from './registersCommonColumns';
import { changePropertySortTypeForModels } from '../../../helpers/utils/propertyUtils';

export const steadsSortList = ['steadCadastreNumber', 'steadSteadTotalSpace'];

const steadsFluidColumns = {
  steadCadastreNumber: {
    isVisible: true,
    colName: 'steadCadastreNumber',
    width: 200,
    position: -1,
    title: 'Кадастровий номер будвлі',
    type: cellTypes.TEXT,
  },
  steadSteadTotalSpace: {
    isVisible: true,
    colName: 'steadSteadTotalSpace',
    width: 200,
    position: -1,
    title: 'Загальна площа ділянки',
    type: cellTypes.TEXT,
  },
  steadLandCategory: {
    isVisible: true,
    colName: 'steadLandCategory',
    width: 200,
    position: -1,
    title: 'Категорія земель',
    type: cellTypes.TEXT,
  },
  steadLandPurpose: {
    isVisible: true,
    colName: 'steadLandPurpose',
    width: 200,
    position: -1,
    title: 'Призначення земель',
    type: cellTypes.TEXT,
  },
};

changePropertySortTypeForModels(steadsFluidColumns, steadsSortList);

const initialSettings = {
  propertySteads: templatePropertyInitialSettings({ fluidColumns: steadsFluidColumns }),
};

export default initialSettings;
