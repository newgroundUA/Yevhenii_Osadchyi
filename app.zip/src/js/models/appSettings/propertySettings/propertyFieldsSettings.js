import * as cellTypes from '../../../constants/CellTypes';
import templatePropertyInitialSettings from './registersCommonColumns';
import { changePropertySortTypeForModels } from '../../../helpers/utils/propertyUtils';

export const fieldSortList = [
  'fieldCoordX',
  'fieldCoordY',
  'fieldLength',
  'fieldWidth',
  'fieldCommonSpace',
];

const fieldFluidColumns = {
  fieldCommonSpace: {
    isVisible: true,
    colName: 'fieldCommonSpace',
    width: 200,
    position: -1,
    title: 'Загальна площа, м2',
    type: cellTypes.TEXT,
  },
  fieldLength: {
    isVisible: true,
    colName: 'fieldLength',
    width: 200,
    position: -1,
    title: 'Довжина, м',
    type: cellTypes.TEXT,
  },
  fieldWidth: {
    isVisible: true,
    colName: 'fieldWidth',
    width: 200,
    position: -1,
    title: 'Ширина, м',
    type: cellTypes.TEXT,
  },
  fieldPremiseFullname: {
    isVisible: true,
    colName: 'fieldPremiseFullname',
    width: 200,
    position: -1,
    title: 'Батьківське приміщення',
    type: cellTypes.TEXT,
  },
  fieldFloorNumber: {
    isVisible: true,
    colName: 'fieldFloorNumber',
    width: 200,
    position: -1,
    title: 'Поверх',
    type: cellTypes.TEXT,
  },
  fieldPremisePurpose: {
    isVisible: true,
    colName: 'fieldPremisePurpose',
    width: 200,
    position: -1,
    title: 'Тип приміщення за призначенням',
    type: cellTypes.TEXT,
  },
  premiseCommonUse: {
    isVisible: true,
    colName: 'premiseCommonUse',
    width: 200,
    position: -1,
    title: 'Приміщення загального користування',
    type: cellTypes.TEXT,
  },
};

changePropertySortTypeForModels(fieldFluidColumns, fieldSortList);

const initialSettings = {
  propertyFields: templatePropertyInitialSettings({
    fluidColumns: fieldFluidColumns,
  }),
};

export default initialSettings;
