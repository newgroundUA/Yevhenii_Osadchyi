import * as cellTypes from '../../../constants/CellTypes';
import templatePropertyInitialSettings from './registersCommonColumns';
import { changePropertySortTypeForModels } from '../../../helpers/utils/propertyUtils';

export const railRoadSortList = [
  'railRoadLength',
  'railRoadWidth',
  'railRoadHeight',
  'railRoadDept',
  'railRoadTunnelDiameter',
  'railRoadTunnelVolume',
  'railRoadTrackQty',
  'railRoadCrossQty',
  'railRoadTrackCrossQty',
];

const railRoadsFluidColumns = {
  railRoadLength: {
    isVisible: true,
    colName: 'railRoadLength',
    width: 200,
    position: -1,
    title: 'Довжина, м',
    type: cellTypes.TEXT,
  },
  railRoadWidth: {
    isVisible: true,
    colName: 'railRoadWidth',
    width: 200,
    position: -1,
    title: 'Ширина колії, м',
    type: cellTypes.TEXT,
  },
  railRoadHeight: {
    isVisible: true,
    colName: 'railRoadHeight',
    width: 200,
    position: -1,
    title: 'Висота (для мостів), м',
    type: cellTypes.TEXT,
  },
  railRoadDept: {
    isVisible: true,
    colName: 'railRoadDept',
    width: 200,
    position: -1,
    title: 'Глибина (для тунелів), м',
    type: cellTypes.TEXT,
  },
  railRoadTunnelDiameter: {
    isVisible: true,
    colName: 'railRoadTunnelDiameter',
    width: 200,
    position: -1,
    title: 'Діаметр (для тунелів), м',
    type: cellTypes.TEXT,
  },
  railRoadTunnelVolume: {
    isVisible: true,
    colName: 'railRoadTunnelVolume',
    width: 200,
    position: -1,
    title: "Об'єм (для тунелів), м",
    type: cellTypes.TEXT,
  },
  railRoadWeight: {
    isVisible: true,
    colName: 'railRoadWeight',
    width: 200,
    position: -1,
    title: 'Маса (для споруд), т',
    type: cellTypes.TEXT,
  },
  railRoadTrackQty: {
    isVisible: true,
    colName: 'railRoadTrackQty',
    width: 200,
    position: -1,
    title: 'Кількість колій',
    type: cellTypes.TEXT,
  },
  railRoadCrossQty: {
    isVisible: true,
    colName: 'railRoadCrossQty',
    width: 200,
    position: -1,
    title: 'Кількість переїздів',
    type: cellTypes.TEXT,
  },
  railRoadTrackCrossQty: {
    isVisible: true,
    colName: 'railRoadTrackCrossQty',
    width: 200,
    position: -1,
    title: 'Кількість залізничних стрілок',
    type: cellTypes.TEXT,
  },
  railRoadMaterial: {
    isVisible: true,
    colName: 'railRoadMaterial',
    width: 200,
    position: -1,
    title: 'Матеріал рейки',
    type: cellTypes.TEXT,
  },
  railRoadBalastMaterial: {
    isVisible: true,
    colName: 'railRoadBalastMaterial',
    width: 200,
    position: -1,
    title: 'Матеріал баластного шару',
    type: cellTypes.TEXT,
  },
  railRoadSleepersMaterial: {
    isVisible: true,
    colName: 'railRoadSleepersMaterial',
    width: 200,
    position: -1,
    title: 'Матеріал шпал',
    type: cellTypes.TEXT,
  },
  railRoadTechnology: {
    isVisible: true,
    colName: 'railRoadTechnology',
    width: 200,
    position: -1,
    title: 'Технологія будівництва',
    type: cellTypes.TEXT,
  },
};

// function to change type to sort
changePropertySortTypeForModels(railRoadsFluidColumns, railRoadSortList);

const initialSettings = {
  propertyRailRoads: templatePropertyInitialSettings({
    fluidColumns: railRoadsFluidColumns,
  }),
};

export default initialSettings;
