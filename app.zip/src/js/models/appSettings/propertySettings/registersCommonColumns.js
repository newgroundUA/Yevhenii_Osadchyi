import * as cellTypes from '../../../constants/CellTypes';
import * as tableConstants from '../../../constants/TableToolNames';

const commonPropertyFixedColumns = {
  checkbox: {
    isVisible: true,
    colName: 'checkbox',
    width: 30,
    position: 0,
    title: 'checkbox',
    type: cellTypes.CHECKBOX,
  },
  fullName: {
    isVisible: true,
    colName: 'fullName',
    width: 200,
    position: 1,
    title: 'Повна назва',
    type: cellTypes.SORT,
  },
  action: {
    isVisible: true,
    colName: 'action',
    width: 70,
    position: 2,
    title: 'Дія',
    type: cellTypes.BUTTONS,
  },
};

const commonPropertyFluidColumns = {
  accountingItemType: {
    isVisible: true,
    colName: 'accountingItemType',
    width: 200,
    position: -1,
    title: 'Тип ООМ',
    type: cellTypes.SORT,
  },
  shortName: {
    isVisible: true,
    colName: 'shortName',
    width: 200,
    position: -1,
    title: 'Скорочена назва',
    type: cellTypes.SORT,
  },
  parentName: {
    isVisible: true,
    colName: 'parentName',
    width: 200,
    position: -1,
    title: "Батьківський об'єкт",
    type: cellTypes.TEXT,
  },
  addressLocality: {
    isVisible: true,
    colName: 'addressLocality',
    width: 200,
    position: 0,
    title: 'Адреса: місто',
    type: cellTypes.TEXT,
  },
  addressLocalityDstrict: {
    isVisible: true,
    colName: 'addressLocalityDstrict',
    width: 200,
    position: 0,
    title: 'Адреса: адмінрайон міста',
    type: cellTypes.TEXT,
  },
  addressStreet: {
    isVisible: true,
    colName: 'addressStreet',
    width: 200,
    position: 0,
    title: 'Адреса: вулиця',
    type: cellTypes.TEXT,
  },
  addressBuilding: {
    isVisible: true,
    colName: 'addressBuilding',
    width: 200,
    position: 0,
    title: 'Адреса: будівля',
    type: cellTypes.TEXT,
  },
  addressInheritAddressObject: {
    isVisible: true,
    colName: 'addressInheritAddressObject',
    width: 200,
    position: 0,
    title: 'Адреса: корпус',
    type: cellTypes.TEXT,
  },
  addressPremise: {
    isVisible: true,
    colName: 'addressPremise',
    width: 200,
    position: 0,
    title: 'Адреса: приміщення',
    type: cellTypes.TEXT,
  },
  guid: {
    isVisible: true,
    colName: 'guid',
    width: 200,
    position: -1,
    title: 'Обліковий номер в ЄІС',
    type: cellTypes.TEXT,
  },
  objectType: {
    isVisible: true,
    colName: 'objectType',
    width: 200,
    position: -1,
    title: "Тип об'єкту за КДМ",
    type: cellTypes.TEXT,
  },
  creationDate: {
    isVisible: true,
    colName: 'creationDate',
    width: 200,
    position: -1,
    title: 'Дата виробництва (побудови)',
    type: cellTypes.SORT,
  },
  usablePeriod: {
    isVisible: true,
    colName: 'usablePeriod',
    width: 200,
    position: -1,
    title: 'Загальний строк корисного використання, років',
    type: cellTypes.SORT,
  },
  currentNumber: {
    isVisible: true,
    colName: 'currentNumber',
    width: 200,
    position: -1,
    title: 'Поточний інв. номер',
    type: cellTypes.TEXT,
  },
  operationDate: {
    isVisible: true,
    colName: 'operationDate',
    width: 200,
    position: -1,
    title: 'Дата введення в експлуатацію',
    type: cellTypes.TEXT,
  },
  initialCost: {
    isVisible: true,
    colName: 'initialCost',
    width: 200,
    position: -1,
    title: 'Первісна вартість (грн.)',
    type: cellTypes.TEXT,
  },
  revaluedCost: {
    isVisible: true,
    colName: 'revaluedCost',
    width: 200,
    position: -1,
    title: 'Переоцінена вартість (грн.)',
    type: cellTypes.TEXT,
  },
  wearCost: {
    isVisible: true,
    colName: 'wearCost',
    width: 200,
    position: -1,
    title: 'Вартість зносу (грн.)',
    type: cellTypes.TEXT,
  },
  residualValue: {
    isVisible: true,
    colName: 'residualValue',
    width: 200,
    position: -1,
    title: 'Залишкова вартість (грн.)',
    type: cellTypes.TEXT,
  },
  calculationDate: {
    isVisible: true,
    colName: 'calculationDate',
    width: 200,
    position: -1,
    title: 'Дата розрахунку залишкової та зносу',
    type: cellTypes.TEXT,
  },
  marketCost: {
    isVisible: true,
    colName: 'marketCost',
    width: 200,
    position: -1,
    title: 'Ринкова вартість (грн.)',
    type: cellTypes.TEXT,
  },
  definitionMarketConstDate: {
    isVisible: true,
    colName: 'definitionMarketConstDate',
    width: 200,
    position: -1,
    title: 'Дата визначення ринкової вартості',
    type: cellTypes.TEXT,
  },
  physicalObjectState: {
    isVisible: true,
    colName: 'physicalObjectState',
    width: 200,
    position: -1,
    title: "Фізичний стан об'єкта",
    type: cellTypes.TEXT,
  },
  functionalObjectMatching: {
    isVisible: true,
    colName: 'functionalObjectMatching',
    width: 200,
    position: -1,
    title: "Функціональна відповідність об'єкта",
    type: cellTypes.TEXT,
  },
  assetSpecialization: {
    isVisible: true,
    colName: 'assetSpecialization',
    width: 200,
    position: -1,
    title: 'Спеціалізація активу',
    type: cellTypes.TEXT,
  },
  amortizationCountMethod: {
    isVisible: true,
    colName: 'amortizationCountMethod',
    width: 200,
    position: -1,
    title: 'Метод нарахування амортизації',
    type: cellTypes.TEXT,
  },
  writingOffWay: {
    isVisible: true,
    colName: 'writingOffWay',
    width: 200,
    position: -1,
    title: 'Шлях списання',
    type: cellTypes.TEXT,
  },
  liquidationDate: {
    isVisible: true,
    colName: 'liquidationDate',
    width: 200,
    position: -1,
    title: 'Дата ліквідації',
    type: cellTypes.SORT,
  },
};

const templatePropertyInitialSettings = (
  { fluidColumns = {} } = {
    fluidColumns: {},
  },
) => ({
  register: {
    tableToolbar: {
      tasks: {
        setOwner: {
          title: tableConstants.SET_OWNER,
          isVisible: true,
        },
        setBalanceKeeper: {
          title: tableConstants.SET_BALANCE_KEEPER,
          isVisible: true,
        },
        archiveUser: {
          title: tableConstants.ARCHIVE_USER,
          isVisible: true,
        },
      },
      export: {
        xls: {
          title: tableConstants.XLS,
          isVisible: true,
        },
        pdf: {
          title: tableConstants.PDF,
          isVisible: true,
        },
        csv: {
          title: tableConstants.CSV,
          isVisible: true,
        },
      },
      filters: {
        filters: {
          title: tableConstants.FILTERS,
          isVisible: true,
        },
        specFilters: {
          title: tableConstants.SPEC_FILTERS,
          isVisible: true,
        },
      },
      config: {
        tableColumns: {
          title: tableConstants.TABLE_COLUMNS,
          isVisible: true,
        },
        toolbarManagement: {
          title: tableConstants.TOOLBAR_MANAGEMENT,
          isVisible: true,
        },
      },
    },
    tableBody: {
      columns: {
        fixed: commonPropertyFixedColumns,
        fluid: { ...commonPropertyFluidColumns, ...fluidColumns },
      },
    },
  },
});

export default templatePropertyInitialSettings;
