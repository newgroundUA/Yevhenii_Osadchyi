import * as cellTypes from '../../../constants/CellTypes';
import { changePropertySortTypeForModels } from '../../../helpers/utils/propertyUtils';
import templatePropertyInitialSettings from './registersCommonColumns';

export const pipelineSortList = [
  'pipelineLength',
  'pipelineDiameter',
  'pipelineHeight',
  'pipelineDepth',
  'pipelineTunnelDiameter',
  'pipelineTunnelVolume',
  'pipelineWeight',
];

const pipelinesFluidColumns = {
  pipelineLength: {
    isVisible: true,
    colName: 'pipelineLength',
    width: 200,
    position: -1,
    title: 'Довжина, м',
    type: cellTypes.TEXT,
  },
  pipelineDiameter: {
    isVisible: true,
    colName: 'pipelineDiameter',
    width: 200,
    position: -1,
    title: 'Діаметр, м',
    type: cellTypes.TEXT,
  },
  pipelineTubeClassifier: {
    isVisible: true,
    colName: 'pipelineTubeClassifier',
    width: 200,
    position: -1,
    title: 'Марка труб',
    type: cellTypes.TEXT,
  },
  pipelineHeight: {
    isVisible: true,
    colName: 'pipelineHeight',
    width: 200,
    position: -1,
    title: 'Висота зовнішнього монтажу, м',
    type: cellTypes.TEXT,
  },
  pipelineDepth: {
    isVisible: true,
    colName: 'pipelineDepth',
    width: 200,
    position: -1,
    title: 'Глибина закладання, м',
    type: cellTypes.TEXT,
  },
  pipelineTunnelDiameter: {
    isVisible: true,
    colName: 'pipelineTunnelDiameter',
    width: 200,
    position: -1,
    title: 'Діаметр тунеля, м',
    type: cellTypes.TEXT,
  },
  pipelineTunnelVolume: {
    isVisible: true,
    colName: 'pipelineTunnelVolume',
    width: 200,
    position: -1,
    title: "Об'єм тунелю, м",
    type: cellTypes.TEXT,
  },
  pipelineWeight: {
    isVisible: true,
    colName: 'pipelineWeight',
    width: 200,
    position: -1,
    title: 'Маса опори, т',
    type: cellTypes.TEXT,
  },
  pipelineTubeBaseMaterial: {
    isVisible: true,
    colName: 'pipelineTubeBaseMaterial',
    width: 200,
    position: -1,
    title: 'Матеріал опори',
    type: cellTypes.TEXT,
  },
  pipelineTubeTechnology: {
    isVisible: true,
    colName: 'pipelineTubeTechnology',
    width: 200,
    position: -1,
    title: 'Технологія прокладки труб',
    type: cellTypes.TEXT,
  },
};

changePropertySortTypeForModels(pipelinesFluidColumns, pipelineSortList);

const initialSettings = {
  propertyPipelines: templatePropertyInitialSettings({
    fluidColumns: pipelinesFluidColumns,
  }),
};

export default initialSettings;
