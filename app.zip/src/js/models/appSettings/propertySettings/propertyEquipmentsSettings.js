import * as cellTypes from '../../../constants/CellTypes';
import templatePropertyInitialSettings from './registersCommonColumns';
import { changePropertySortTypeForModels } from '../../../helpers/utils/propertyUtils';

export const equipmentSortList = [
  'equipmentDateOfManufacture',
  'equipmentWarrantyPeriod',
  'equipmentTechNote',
];

const equipmentFluidColumns = {
  equipmentManufacture: {
    isVisible: true,
    colName: 'equipmentManufacture',
    width: 200,
    position: -1,
    title: 'Виробник',
    type: cellTypes.TEXT,
  },
  equipmentClassifier: {
    isVisible: true,
    colName: 'equipmentClassifier',
    width: 200,
    position: -1,
    title: 'Тип обладнання',
    type: cellTypes.TEXT,
  },
  equipmentWarrantyPeriod: {
    isVisible: true,
    colName: 'equipmentWarrantyPeriod',
    width: 200,
    position: -1,
    title: 'Гарантійний термін, м',
    type: cellTypes.TEXT,
  },
  equipmentTechNote: {
    isVisible: true,
    colName: 'equipmentTechNote',
    width: 200,
    position: -1,
    title: 'Технічний опис',
    type: cellTypes.TEXT,
  },
};

changePropertySortTypeForModels(equipmentFluidColumns, equipmentSortList);

const initialSettings = {
  propertyEquipments: templatePropertyInitialSettings({ fluidColumns: equipmentFluidColumns }),
};

export default initialSettings;
