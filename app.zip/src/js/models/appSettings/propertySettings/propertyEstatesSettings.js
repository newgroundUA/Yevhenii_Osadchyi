import templatePropertyInitialSettings from './registersCommonColumns';

const initialSettings = {
  propertyEstates: templatePropertyInitialSettings(),
};

export default initialSettings;
