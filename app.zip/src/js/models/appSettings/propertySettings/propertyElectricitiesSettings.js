import * as cellTypes from '../../../constants/CellTypes';
import templatePropertyInitialSettings from './registersCommonColumns';
import { changePropertySortTypeForModels } from '../../../helpers/utils/propertyUtils';

export const electricityCableSortList = [
  'cableVoltage',
  'cableLenght',
  'cableDiameter',
  'cableHeight',
  'cablePillarQty',
  'cableDepth',
  'cableWellQty',
];

const electricityCableFluidColumns = {
  cableElectricityPurpose: {
    isVisible: true,
    colName: 'cableElectricityPurpose',
    width: 200,
    position: -1,
    title: 'Призначення електрокомунікації',
    type: cellTypes.TEXT,
  },
  cableVoltage: {
    isVisible: true,
    colName: 'cableVoltage',
    width: 200,
    position: -1,
    title: 'Робоча напруга, В',
    type: cellTypes.TEXT,
  },
  cableLenght: {
    isVisible: true,
    colName: 'cableLenght',
    width: 200,
    position: -1,
    title: 'Довжина, м',
    type: cellTypes.TEXT,
  },
  cableDiameter: {
    isVisible: true,
    colName: 'cableDiameter',
    width: 200,
    position: -1,
    title: 'Діаметр носія, мм',
    type: cellTypes.TEXT,
  },
  cableClassifier: {
    isVisible: true,
    colName: 'cableClassifier',
    width: 200,
    position: -1,
    title: 'Марка проводу',
    type: cellTypes.TEXT,
  },
  cableHeight: {
    isVisible: true,
    colName: 'cableHeight',
    width: 200,
    position: -1,
    title: 'Висота зовнішнього монтажу, м',
    type: cellTypes.TEXT,
  },
  cablePillarQty: {
    isVisible: true,
    colName: 'cablePillarQty',
    width: 200,
    position: -1,
    title: 'Кількість опор',
    type: cellTypes.TEXT,
  },
  cablePillarMaterial: {
    isVisible: true,
    colName: 'cablePillarMaterial',
    width: 200,
    position: -1,
    title: 'Матеріал опор',
    type: cellTypes.TEXT,
  },
  cableDepth: {
    isVisible: true,
    colName: 'cableDepth',
    width: 200,
    position: -1,
    title: 'Глибина закладання, м',
    type: cellTypes.TEXT,
  },
  cableWellQty: {
    isVisible: true,
    colName: 'cableWellQty',
    width: 200,
    position: -1,
    title: 'Кількість колодязів',
    type: cellTypes.TEXT,
  },
  cableTechnology: {
    isVisible: true,
    colName: 'cableTechnology',
    width: 200,
    position: -1,
    title: 'Технологія прокладки',
    type: cellTypes.TEXT,
  },
};

changePropertySortTypeForModels(electricityCableFluidColumns, electricityCableSortList);

const initialSettings = {
  propertyElectricities: templatePropertyInitialSettings({
    fluidColumns: electricityCableFluidColumns,
  }),
};

export default initialSettings;
