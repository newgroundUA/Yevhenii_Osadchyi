import * as cellTypes from '../../../constants/CellTypes';
import templatePropertyInitialSettings from './registersCommonColumns';
import { changePropertySortTypeForModels } from '../../../helpers/utils/propertyUtils';

export const roadSortList = [
  'roadLength',
  'roadMaxWidth',
  'roadMinWidth',
  'roadAverageWidth',
  'roadFullSpace',
  'roadHeight',
  'roadDepth',
  'roadTunnelDiameter',
  'roadTunnelVolume',
  'roadWeight',
  'roadMoveLine',
  'roadCrossQty',
];

const roadsFluidColumns = {
  roadLength: {
    isVisible: true,
    colName: 'roadLength',
    width: 200,
    position: -1,
    title: 'Довжина, м',
    type: cellTypes.TEXT,
  },
  roadMaxWidth: {
    isVisible: true,
    colName: 'roadMaxWidth',
    width: 200,
    position: -1,
    title: 'Максимальна ширина, м',
    type: cellTypes.TEXT,
  },
  roadMinWidth: {
    isVisible: true,
    colName: 'roadMinWidth',
    width: 200,
    position: -1,
    title: 'Мінімальна ширина, м',
    type: cellTypes.TEXT,
  },
  roadAverageWidth: {
    isVisible: true,
    colName: 'roadAverageWidth',
    width: 200,
    position: -1,
    title: 'Середня ширина, м',
    type: cellTypes.TEXT,
  },
  roadFullSpace: {
    isVisible: true,
    colName: 'roadFullSpace',
    width: 200,
    position: -1,
    title: 'Загальна площа, м.кв',
    type: cellTypes.TEXT,
  },
  roadHeight: {
    isVisible: true,
    colName: 'roadHeight',
    width: 200,
    position: -1,
    title: 'Висота (для мостів), м',
    type: cellTypes.TEXT,
  },
  roadDepth: {
    isVisible: true,
    colName: 'roadDepth',
    width: 200,
    position: -1,
    title: 'Глибина (для тунелів), м',
    type: cellTypes.TEXT,
  },
  roadTunnelDiameter: {
    isVisible: true,
    colName: 'roadTunnelDiameter',
    width: 200,
    position: -1,
    title: 'Діаметр (для тунелів), м',
    type: cellTypes.TEXT,
  },
  roadTunnelVolume: {
    isVisible: true,
    colName: 'roadTunnelVolume',
    width: 200,
    position: -1,
    title: "Об'єм (для тунелів), м",
    type: cellTypes.TEXT,
  },
  roadWeight: {
    isVisible: true,
    colName: 'roadWeight',
    width: 200,
    position: -1,
    title: 'Маса (для споруд), т',
    type: cellTypes.TEXT,
  },
  roadMoveLine: {
    isVisible: true,
    colName: 'roadMoveLine',
    width: 200,
    position: -1,
    title: 'Кількість полос для руху (в усіх напр)',
    type: cellTypes.TEXT,
  },
  roadClMoveLine: {
    isVisible: true,
    colName: 'roadClMoveLine',
    width: 200,
    position: -1,
    title: 'Типи полоси для руху',
    type: cellTypes.TEXT,
  },
  roadCrossQty: {
    isVisible: true,
    colName: 'roadCrossQty',
    width: 200,
    position: -1,
    title: 'Кількість перетинів',
    type: cellTypes.TEXT,
  },
  roadClBuildingMaterial: {
    isVisible: true,
    colName: 'roadClBuildingMaterial',
    width: 200,
    position: -1,
    title: 'Матеріал',
    type: cellTypes.TEXT,
  },
  roadClRoadTechnology: {
    isVisible: true,
    colName: 'roadClRoadTechnology',
    width: 200,
    position: -1,
    title: 'Технологія',
    type: cellTypes.TEXT,
  },
};

// function to change type to sort
changePropertySortTypeForModels(roadsFluidColumns, roadSortList);

const initialSettings = {
  propertyRoads: templatePropertyInitialSettings({
    fluidColumns: roadsFluidColumns,
  }),
};

export default initialSettings;
