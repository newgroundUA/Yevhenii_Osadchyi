import * as cellTypes from '../../../constants/CellTypes';
import templatePropertyInitialSettings from './registersCommonColumns';

const animalsFluidColumns = {
  animalClassifier: {
    isVisible: true,
    colName: 'animalClassifier',
    width: 200,
    position: -1,
    title: 'Клас та порода',
    type: cellTypes.TEXT,
  },
  animalPurpose: {
    isVisible: true,
    colName: 'animalPurpose',
    width: 200,
    position: -1,
    title: 'Призначення',
    type: cellTypes.TEXT,
  },
};

const initialSettings = {
  propertyAnimals: templatePropertyInitialSettings({ fluidColumns: animalsFluidColumns }),
};

export default initialSettings;
