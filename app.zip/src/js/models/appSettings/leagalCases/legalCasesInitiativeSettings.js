import * as tableConstants from '../../../constants/TableToolNames';
import * as cellTypes from '../../../constants/CellTypes';

const initialSettings = {
  legalCasesInitiatives: {
    register: {
      tableToolbar: {
        tasks: {
          archiveUser: {
            title: tableConstants.ARCHIVE_USER,
            isVisible: true,
          },
        },
        export: {
          pdf: {
            title: tableConstants.PDF,
            isVisible: true,
          },
        },
        filters: {
          filters: {
            title: tableConstants.FILTERS,
            isVisible: true,
          },
          specFilters: {
            title: tableConstants.SPEC_FILTERS,
            isVisible: true,
          },
        },
        config: {
          tableColumns: {
            title: tableConstants.TABLE_COLUMNS,
            isVisible: true,
          },
          toolbarManagement: {
            title: tableConstants.TOOLBAR_MANAGEMENT,
            isVisible: true,
          },
        },
      },
      tableBody: {
        columns: {
          fixed: {
            checkbox: {
              isVisible: true,
              colName: 'checkbox',
              width: 30,
              position: 0,
              title: 'checkbox',
              type: cellTypes.CHECKBOX,
            },
            fullName: {
              isVisible: true,
              colName: 'fullName',
              width: 200,
              position: 1,
              title: 'Повна назва ООМ',
              type: cellTypes.LINK,
            },
            action: {
              isVisible: true,
              colName: 'action',
              width: 70,
              position: 2,
              title: 'Дія',
              type: cellTypes.BUTTONS,
            },
          },
          fluid: {
            // hidden

            // 0: {
            //   isVisible: false,
            //   colName: '',
            //   width: 200,
            //   position: -1,
            //   title: '',
            //   type: cellTypes.TEXT
            // },

            // visible

            receivingDate: {
              isVisible: true,
              colName: 'receivingDate',
              width: 200,
              position: 0,
              title: 'Дата отримання',
              type: cellTypes.TEXT,
            },
            initiator: {
              isVisible: true,
              colName: 'initiator',
              width: 200,
              position: 1,
              title: 'Ініціатор',
              type: cellTypes.TEXT,
            },
            documentTitle: {
              isVisible: true,
              colName: 'documentTitle',
              width: 200,
              position: 2,
              title: 'Назва документа',
              type: cellTypes.TEXT,
            },
            documentNumber: {
              isVisible: true,
              colName: 'documentNumber',
              width: 200,
              position: 3,
              title: '№ документа',
              type: cellTypes.TEXT,
            },
          },
        },
      },
    },
  },
};

export default initialSettings;
