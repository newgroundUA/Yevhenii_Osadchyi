import * as tableConstants from '../../../constants/TableToolNames';
import * as cellTypes from '../../../constants/CellTypes';

const initialSettings = {
  legalCasesAffairs: {
    register: {
      tableToolbar: {
        tasks: {
          archiveUser: {
            title: tableConstants.ARCHIVE_USER,
            isVisible: true,
          },
        },
        export: {
          pdf: {
            title: tableConstants.PDF,
            isVisible: true,
          },
        },
        filters: {
          filters: {
            title: tableConstants.FILTERS,
            isVisible: true,
          },
          specFilters: {
            title: tableConstants.SPEC_FILTERS,
            isVisible: true,
          },
        },
        config: {
          tableColumns: {
            title: tableConstants.TABLE_COLUMNS,
            isVisible: true,
          },
          toolbarManagement: {
            title: tableConstants.TOOLBAR_MANAGEMENT,
            isVisible: true,
          },
        },
      },
      tableBody: {
        columns: {
          fixed: {
            checkbox: {
              isVisible: true,
              colName: 'checkbox',
              width: 30,
              position: 0,
              title: 'checkbox',
              type: cellTypes.CHECKBOX,
            },
            regNumber: {
              isVisible: true,
              colName: 'regNumber',
              width: 200,
              position: 1,
              title: 'Реєстраційний номер справи',
              type: cellTypes.SORT,
            },
            action: {
              isVisible: true,
              colName: 'action',
              width: 70,
              position: 2,
              title: 'Дія',
              type: cellTypes.BUTTONS,
            },
          },
          fluid: {
            courtNumber: {
              isVisible: true,
              colName: 'courtNumber',
              width: 200,
              position: 3,
              title: 'Судовий номер справи',
              type: cellTypes.SORT,
            },
            legalAffairsType: {
              isVisible: true,
              colName: 'legalAffairsType',
              width: 200,
              position: 4,
              title: 'Класифікація справи',
              type: cellTypes.SORT,
            },
            legalAffairsStartDate: {
              isVisible: true,
              colName: 'legalAffairsStartDate',
              width: 200,
              position: 5,
              title: 'Дата відкриття справи',
              type: cellTypes.SORT,
            },
            legalAffairsEndDate: {
              isVisible: true,
              colName: 'legalAffairsEndDate',
              width: 200,
              position: 6,
              title: 'Дата закриття справи',
              type: cellTypes.SORT,
            },
            legalAffairsStages: {
              isVisible: true,
              colName: 'legalAffairsStages',
              width: 200,
              position: 7,
              title: 'Поточний етап',
              type: cellTypes.DROP_DOWN,
            },
            legalAffairCourt: {
              isVisible: true,
              colName: 'legalAffairCourt',
              width: 200,
              position: 8,
              title: 'Поточний суд справи',
              type: cellTypes.DROP_DOWN,
            },
            courtSessionPlannings: {
              isVisible: true,
              colName: 'courtSessionPlannings',
              width: 200,
              position: 9,
              title: 'Дата найближчого засідання',
              type: cellTypes.DROP_DOWN,
            },
            startRequest: {
              isVisible: true,
              colName: 'startRequest',
              width: 200,
              position: 10,
              title: 'Запит на юридичне провадження',
              type: cellTypes.TEXT,
            },
            responsibleLawyer: {
              isVisible: true,
              colName: 'responsibleLawyer',
              width: 200,
              position: 11,
              title: 'Відповідальний юрист по справі',
              type: cellTypes.TEXT,
            },
            complainants: {
              isVisible: true,
              colName: 'complainants',
              width: 200,
              position: 12,
              title: 'Позивач',
              type: cellTypes.DROP_DOWN,
            },
            defendants: {
              isVisible: true,
              colName: 'defendants',
              width: 200,
              position: 13,
              title: 'Відповідач',
              type: cellTypes.DROP_DOWN,
            },
            thirdPartys: {
              isVisible: true,
              colName: 'thirdPartys',
              width: 200,
              position: 14,
              title: 'Третя сторона',
              type: cellTypes.DROP_DOWN,
            },
            prosecutor: {
              isVisible: true,
              colName: 'prosecutor',
              width: 200,
              position: 15,
              title: 'Прокурор по справі',
              type: cellTypes.TEXT,
            },
            bailsman: {
              isVisible: true,
              colName: 'bailsman',
              width: 200,
              position: 16,
              title: 'Орган, який представляємо',
              type: cellTypes.DROP_DOWN,
            },
            accountingItems: {
              isVisible: true,
              colName: 'accountingItems',
              width: 200,
              position: 17,
              title: "Майнові об'єкти по запиту",
              type: cellTypes.DROP_DOWN,
            },
          },
        },
      },
    },
  },
};

export default initialSettings;
