import * as tableConstants from '../../../constants/TableToolNames';
import * as cellTypes from '../../../constants/CellTypes';
import * as renderFunc from '../../../helpers/cellRenderFunctions';

const initialSettings = {
  legalCasesRequestForLegalProcessing: {
    register: {
      tableToolbar: {
        tasks: {
          archiveUser: {
            title: tableConstants.ARCHIVE_USER,
            isVisible: true,
          },
        },
        export: {
          pdf: {
            title: tableConstants.PDF,
            isVisible: true,
          },
        },
        filters: {
          filters: {
            title: tableConstants.FILTERS,
            isVisible: true,
          },
          specFilters: {
            title: tableConstants.SPEC_FILTERS,
            isVisible: true,
          },
        },
        config: {
          tableColumns: {
            title: tableConstants.TABLE_COLUMNS,
            isVisible: true,
          },
          toolbarManagement: {
            title: tableConstants.TOOLBAR_MANAGEMENT,
            isVisible: true,
          },
        },
      },
      tableBody: {
        columns: {
          fixed: {
            checkbox: {
              isVisible: true,
              colName: 'checkbox',
              width: 30,
              position: 0,
              title: 'checkbox',
              type: cellTypes.CHECKBOX,
            },
            requestNumber: {
              isVisible: true,
              colName: 'requestNumber',
              width: 200,
              position: 1,
              title: 'Реєстраційний номер запиту',
              type: cellTypes.SORT,
              render: renderFunc.link,
            },
            action: {
              isVisible: true,
              colName: 'action',
              width: 70,
              position: 2,
              title: 'Дія',
              type: cellTypes.BUTTONS,
            },
          },
          fluid: {
            // hidden

            // visible

            requestStartDate: {
              isVisible: true,
              colName: 'requestStartDate',
              width: 200,
              position: 3,
              title: 'Дата створення запиту',
              type: cellTypes.SORT,
            },
            requestEndDate: {
              isVisible: true,
              colName: 'requestEndDate',
              width: 200,
              position: 4,
              title: 'Дата прийняття рішення',
              type: cellTypes.SORT,
            },
            requestStatus: {
              isVisible: true,
              colName: 'requestStatus',
              width: 200,
              position: 5,
              title: 'Стан обробки запиту',
              type: cellTypes.SORT,
            },
            requestInitiator: {
              isVisible: true,
              colName: 'requestInitiator',
              width: 200,
              position: 6,
              title: 'Ініціатор запиту (юо)',
              type: cellTypes.SORT,
              render: renderFunc.link,
            },
            requestAuthor: {
              isVisible: true,
              colName: 'requestAuthor',
              width: 200,
              position: 7,
              title: 'Ініціатор запиту (особа)',
              type: cellTypes.SORT,
              render: renderFunc.link,
            },
            requestResponsibleLawyer: {
              isVisible: true,
              colName: 'requestResponsibleLawyer',
              width: 200,
              position: 8,
              title: 'Відповідальний юрист по запиту',
              type: cellTypes.SORT,
              render: renderFunc.link,
            },
            clLegalAffairs: {
              isVisible: true,
              colName: 'clLegalAffairs',
              width: 200,
              position: 9,
              title: 'Класифікація запиту',
              type: cellTypes.SORT,
            },
            accountingItems: {
              isVisible: true,
              colName: 'accountingItems',
              width: 200,
              position: 10,
              title: "Майнові об'єкти по запиту",
              render: renderFunc.dropDownWithLink,
            },
            // accountingItemsAdresses: {
            //   isVisible: true,
            //   colName: 'accountingItemsAdresses',
            //   width: 200,
            //   position: 11,
            //   title: "Адреса майнового об'єкту",
            //   type: cellTypes.DROP_DOWN,
            // },
            requestDocuments: {
              isVisible: true,
              colName: 'requestDocuments',
              width: 200,
              position: 11,
              title: 'Документи до запиту',
              render: renderFunc.dropDownWithLink,
            },
          },
        },
      },
    },
  },
};

export default initialSettings;
