import * as tableConstants from '../../../constants/TableToolNames';
import * as cellTypes from '../../../constants/CellTypes';

const initialSettings = {
  legalCasesCourtSessionsPlannings: {
    register: {
      tableToolbar: {
        tasks: {
          archiveUser: {
            title: tableConstants.ARCHIVE_USER,
            isVisible: true,
          },
        },
        export: {
          pdf: {
            title: tableConstants.PDF,
            isVisible: true,
          },
        },
        filters: {
          filters: {
            title: tableConstants.FILTERS,
            isVisible: true,
          },
          specFilters: {
            title: tableConstants.SPEC_FILTERS,
            isVisible: true,
          },
        },
        config: {
          tableColumns: {
            title: tableConstants.TABLE_COLUMNS,
            isVisible: true,
          },
          toolbarManagement: {
            title: tableConstants.TOOLBAR_MANAGEMENT,
            isVisible: true,
          },
        },
      },
      tableBody: {
        columns: {
          fixed: {
            checkbox: {
              isVisible: true,
              colName: 'checkbox',
              width: 30,
              position: 0,
              title: 'checkbox',
              type: cellTypes.CHECKBOX,
            },
            legalAffairRegNumber: {
              isVisible: true,
              colName: 'legalAffairRegNumber',
              width: 200,
              position: 1,
              title: 'Реєстраційний номер справи',
              type: cellTypes.TEXT,
            },
            action: {
              isVisible: true,
              colName: 'action',
              width: 70,
              position: 2,
              title: 'Дія',
              type: cellTypes.BUTTONS,
            },
          },
          fluid: {
            courtSessionDate: {
              isVisible: true,
              colName: 'courtSessionDate',
              width: 200,
              position: 3,
              title: 'Дата засідання',
              type: cellTypes.TEXT,
            },
            legalAffairCourtNumber: {
              isVisible: true,
              colName: 'legalAffairCourtNumber',
              width: 200,
              position: 4,
              title: 'Судовий номер справи',
              type: cellTypes.TEXT,
            },
            legalAffairType: {
              isVisible: true,
              colName: 'legalAffairType',
              width: 200,
              position: 5,
              title: 'Класифікація справи',
              type: cellTypes.TEXT,
            },
            representers: {
              isVisible: true,
              colName: 'representers',
              width: 200,
              position: 6,
              title: 'Наш представник на засіданні',
              type: cellTypes.DROP_DOWN,
            },
            court: {
              // ?
              isVisible: true,
              colName: 'court',
              width: 200,
              position: 7,
              title: 'Відбувається в суді',
              type: cellTypes.TEXT,
            },
            // // courtAddress: { // ?
            // //   isVisible: true,
            // //   colName: 'courtAddress',
            // //   width: 200,
            // //   position: 8,
            // //   title: 'Адреса суду',
            // //   type: cellTypes.TEXT
            // // },
            courtSessionRoomNumber: {
              isVisible: true,
              colName: 'courtSessionRoomNumber',
              width: 200,
              position: 8,
              title: 'Номер кімнати (залу)',
              type: cellTypes.TEXT,
            },
            judjes: {
              isVisible: true,
              colName: 'judjes',
              width: 200,
              position: 9,
              title: 'Судді',
              type: cellTypes.DROP_DOWN,
            },
            responsibleLawyer: {
              isVisible: true,
              colName: 'responsibleLawyer',
              width: 200,
              position: 10,
              title: 'Відповідальний юрист по справі',
              type: cellTypes.TEXT,
            },
            complainants: {
              isVisible: true,
              colName: 'complainants',
              width: 200,
              position: 11,
              title: 'Позивач',
              type: cellTypes.DROP_DOWN,
            },
            defendants: {
              isVisible: true,
              colName: 'defendants',
              width: 200,
              position: 12,
              title: 'Відповідач',
              type: cellTypes.DROP_DOWN,
            },
            thirdPartys: {
              isVisible: true,
              colName: 'thirdPartys',
              width: 200,
              position: 13,
              title: 'Третя сторона',
              type: cellTypes.DROP_DOWN,
            },
          },
        },
      },
    },
  },
};

export default initialSettings;
