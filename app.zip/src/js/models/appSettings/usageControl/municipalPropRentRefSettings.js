import * as tableConstants from '../../../constants/TableToolNames';
import * as cellTypes from '../../../constants/CellTypes';

const initialSettings = {
  municipalPropRentReference: {
    register: {
      tableToolbar: {
        tasks: {
          // joinGroup: {
          //   title: tableConstants.JOIN_GROUP,
          //   isVisible: true
          // },
          // assignRole: {
          //   title: tableConstants.ASSIGN_ROLE,
          //   isVisible: true
          // },
          archiveUser: {
            title: tableConstants.ARCHIVE_USER,
            isVisible: true,
          },
        },
        export: {
          // xls: {
          //   title: tableConstants.XLS,
          //   isVisible: true
          // },
          pdf: {
            title: tableConstants.PDF,
            isVisible: true,
          },
          // csv: {
          //   title: tableConstants.CSV,
          //   isVisible: true
          // }
        },
        filters: {
          filters: {
            title: tableConstants.FILTERS,
            isVisible: true,
          },
          specFilters: {
            title: tableConstants.SPEC_FILTERS,
            isVisible: true,
          },
        },
        config: {
          tableColumns: {
            title: tableConstants.TABLE_COLUMNS,
            isVisible: true,
          },
          toolbarManagement: {
            title: tableConstants.TOOLBAR_MANAGEMENT,
            isVisible: true,
          },
        },
      },
      tableBody: {
        columns: {
          fixed: {
            checkbox: {
              isVisible: true,
              colName: 'checkbox',
              width: 30,
              position: 0,
              title: 'checkbox',
              type: cellTypes.CHECKBOX,
            },
            balanceKeeper: {
              isVisible: true,
              colName: 'balanceKeeper',
              width: 200,
              position: 0,
              title: 'Балансоутримувач: назва',
              type: cellTypes.TEXT,
            },
            // action: {
            //   isVisible: true,
            //   colName: 'action',
            //   width: 70,
            //   position: 2,
            //   title: 'Дія',
            //   type: cellTypes.BUTTONS
            // }
          },
          fluid: {
            // visible
            balanceKeeperGovID: {
              isVisible: true,
              colName: 'balanceKeeperGovID',
              width: 200,
              position: 1,
              title: 'Балансоутримувач: ЕДРПОУ',
              type: cellTypes.TEXT,
            },
            renter: {
              isVisible: true,
              colName: 'renter',
              width: 200,
              position: 2,
              title: 'Орендар: назва',
              type: cellTypes.TEXT,
            },
            renterGovID: {
              isVisible: true,
              colName: 'renterGovID',
              width: 200,
              position: 3,
              title: 'Орендар: ЕДРПОУ',
              type: cellTypes.TEXT,
            },
            landlord: {
              isVisible: true,
              colName: 'landlord',
              width: 200,
              position: 4,
              title: 'Орендодавець: назва',
              type: cellTypes.TEXT,
            },
            landlordGovID: {
              isVisible: true,
              colName: 'landlordGovID',
              width: 200,
              position: 5,
              title: 'Орендодавець: ЕДРПОУ',
              type: cellTypes.TEXT,
            },
            leaseRateDirectories: {
              isVisible: true,
              colName: 'leaseRateDirectories',
              width: 200,
              position: 6,
              title: 'Використання приміщень за цільовим призначенням відповідно до договору',
              type: cellTypes.DROP_DOWN,
            },
            objectsCommonSpaceRepPeriod: {
              isVisible: true,
              colName: 'objectsCommonSpaceRepPeriod',
              width: 200,
              position: 7,
              title: 'Загальна площа надана в орендне користування, кв. м',
              type: cellTypes.TEXT,
            },
            objectsCommonSpaceRepPeriodBy1UAH: {
              isVisible: true,
              colName: 'objectsCommonSpaceRepPeriodBy1UAH',
              width: 200,
              position: 8,
              title: 'Площа, передана в орендне користування за 1 грн на рік, кв. м',
              type: cellTypes.TEXT,
            },
            objectsCommonSpaceRepPeriodByCompetition: {
              isVisible: true,
              colName: 'objectsCommonSpaceRepPeriodByCompetition',
              width: 200,
              position: 9,
              title:
                'Площа, передана в орендне користування за ОС меншою, ніж встановлено Положенням про оренду',
              type: cellTypes.TEXT,
            },
            leaseContract: {
              isVisible: true,
              colName: 'leaseContract',
              width: 200,
              position: 10,
              title: 'Договір оренди',
              type: cellTypes.TEXT,
            },
            leaseCotractBeginDate: {
              isVisible: true,
              colName: 'leaseCotractBeginDate',
              width: 200,
              position: 11,
              title: 'Початок строку дії договору оренди',
              type: cellTypes.TEXT,
            },
            leaseCotractEndDate: {
              isVisible: true,
              colName: 'leaseCotractEndDate',
              width: 200,
              position: 12,
              title: 'Закінчення строку дії договору оренди',
              type: cellTypes.TEXT,
            },
            factLeaseTotalAmountRepPeriod: {
              isVisible: true,
              colName: 'factLeaseTotalAmountRepPeriod',
              width: 200,
              position: 13,
              title:
                'Нараховано фактично коштів від оренди майна, грн за звітний період, грн,(без ПДВ)',
              type: cellTypes.TEXT,
            },
            finStatamentForEndOfRepPeriod: {
              isVisible: true,
              colName: 'finStatamentForEndOfRepPeriod',
              width: 200,
              position: 14,
              title: 'Переплачено орендарем на початок звітного періоду, грн (без ПДВ)',
              type: cellTypes.TEXT,
            },
            totalRecievedAmountRepPeriodInAll: {
              isVisible: true,
              colName: 'totalRecievedAmountRepPeriodInAll',
              width: 200,
              position: 15,
              title:
                'Всього отримано коштів з початку дії договору по кінець звітного періоду, грн (без ПДВ)',
              type: cellTypes.TEXT,
            },
            totalRecievedAmountRepPeriod: {
              isVisible: true,
              colName: 'totalRecievedAmountRepPeriod',
              width: 200,
              position: 16,
              title: 'Отримано коштів за звітний період, грн (без ПДВ)',
              type: cellTypes.TEXT,
            },
            debtsInAll: {
              isVisible: true,
              colName: 'debtsInAll',
              width: 200,
              position: 17,
              title: 'Заборгованість з орендної плати ВСЬОГО, грн (без ПДВ)',
              type: cellTypes.TEXT,
            },
            debtsUpTo3Months: {
              isVisible: true,
              colName: 'debtsUpTo3Months',
              width: 200,
              position: 18,
              title: 'Заборгованість з орендної плати ДО 3-Х міс, грн (без ПДВ)',
              type: cellTypes.TEXT,
            },
            tenantDebtLess3M1: {
              isVisible: true,
              colName: 'tenantDebtLess3M1',
              width: 200,
              position: 19,
              title: 'Заборгованість з орендної плати ДО 3-Х міс, грн (без ПДВ) (dublicate?)',
              type: cellTypes.TEXT,
            },
            debtsFrom3UpTo12Months: {
              isVisible: true,
              colName: 'debtsFrom3UpTo12Months',
              width: 200,
              position: 20,
              title: 'Заборгованість з орендної плати ВІД 3-Х до 12-ТІ міс, грн (без ПДВ)',
              type: cellTypes.TEXT,
            },
            debtsFrom1UpTo3Years: {
              isVisible: true,
              colName: 'debtsFrom1UpTo3Years',
              width: 200,
              position: 21,
              title: 'Заборгованість з орендної плати ВІД 1-ГО до 3-Х років, грн (без ПДВ)',
              type: cellTypes.TEXT,
            },
            debtsMoreThan3Years: {
              isVisible: true,
              colName: 'debtsMoreThan3Years',
              width: 200,
              position: 22,
              title: 'Заборгованість з орендної плати БІЛЬШЕ 3-Х років, грн (без ПДВ)',
              type: cellTypes.TEXT,
            },
            debtsBadMoreThan3Months: {
              isVisible: true,
              colName: 'debtsBadMoreThan3Months',
              width: 200,
              position: 23,
              title:
                'Безнадійна заборгованість з орендної плати, яка перевищує 3 міс ВСЬОГО, грн (без ПДВ)',
              type: cellTypes.TEXT,
            },
            debtsPotentiallyBadMoreThan3Months: {
              isVisible: true,
              colName: 'debtsPotentiallyBadMoreThan3Months',
              width: 200,
              position: 24,
              title:
                'Потенційно-безнадійна заборгованість з орендної плати, яка перевищує 3 міс ВСЬОГО, грню (без ПДВ)',
              type: cellTypes.TEXT,
            },
            debtsOtherBadInAll: {
              isVisible: true,
              colName: 'debtsOtherBadInAll',
              width: 200,
              position: 25,
              title: 'Інша безнадійна заборгованість з орендної платі ВСЬОГО, грн. (без ПДВ)',
              type: cellTypes.TEXT,
            },
            debtsSizeWithinCostsInAll: {
              isVisible: true,
              colName: 'debtsSizeWithinCostsInAll',
              width: 200,
              position: 26,
              title:
                'Заборгованість з орендної плати, розмір якої встановлено в межах витрат на утримання ВСЬОГО, грн (без ПДВ)',
              type: cellTypes.TEXT,
            },
            debtsDebitedInAll: {
              isVisible: true,
              colName: 'debtsDebitedInAll',
              width: 200,
              position: 27,
              title: 'Списано заборгованості з орендної плати ВСЬОГО, грн (без ПДВ)',
              type: cellTypes.TEXT,
            },
            debtTotalNumberEventsInAll: {
              isVisible: true,
              colName: 'debtTotalNumberEventsInAll',
              width: 200,
              position: 28,
              title: 'Загальна кількість заходів по стягненню заборгованості ВСЬОГО',
              type: cellTypes.TEXT,
            },
            debtTotalNumberEvents: {
              isVisible: true,
              colName: 'debtTotalNumberEvents',
              width: 200,
              position: 29,
              title: 'Загальна кількість заходів по стягненню заборгованості за ЗВІТНИЙ ПЕРІОД',
              type: cellTypes.TEXT,
            },
            courtAppealQuantityInAll: {
              isVisible: true,
              colName: 'courtAppealQuantityInAll',
              width: 200,
              position: 30,
              title: 'Загальна кількість позовів до суду ВСЬОГО',
              type: cellTypes.TEXT,
            },
            courtAppealQuantity: {
              isVisible: true,
              colName: 'courtAppealQuantity',
              width: 200,
              position: 31,
              title: 'Загальна кількість позовів до суду ЗВІТНИЙ ПЕРІОД',
              type: cellTypes.TEXT,
            },
            satisfactoryCourtAppealQuantityInAll: {
              isVisible: true,
              colName: 'satisfactoryCourtAppealQuantityInAll',
              width: 200,
              position: 32,
              title: 'Загальна кількість задовольнених позовів ВСЬОГО',
              type: cellTypes.TEXT,
            },
            satisfactoryCourtAppealQuantity: {
              isVisible: true,
              colName: 'satisfactoryCourtAppealQuantity',
              width: 200,
              position: 33,
              title: 'Загальна кількість задовольнених позовів ЗВІТНИЙ ПЕРІОД',
              type: cellTypes.TEXT,
            },
            enforcementQuantityInAll: {
              isVisible: true,
              colName: 'enforcementQuantityInAll',
              width: 200,
              position: 34,
              title: 'Загальна кількість відкритих виконавчих проваджень ВСЬОГО',
              type: cellTypes.TEXT,
            },
            enforcementQuantity: {
              isVisible: true,
              colName: 'enforcementQuantity',
              width: 200,
              position: 35,
              title: 'Загальна кількість відкритих виконавчих проваджень ЗВІТНИЙ ПЕРІОД',
              type: cellTypes.TEXT,
            },
            enforcementRepaymentDebtsInAll: {
              isVisible: true,
              colName: 'enforcementRepaymentDebtsInAll',
              width: 200,
              position: 36,
              title: 'Сума погашеної заборгованості по заходах ВСЬОГО, грн. (без ПДВ)',
              type: cellTypes.TEXT,
            },
            enforcementRepaymentDebts: {
              isVisible: true,
              colName: 'enforcementRepaymentDebts',
              width: 200,
              position: 37,
              title: 'Сума погашеної заборгованості по заходах ЗВІТНИЙ ПЕРІОД, грн. (без ПДВ)',
              type: cellTypes.TEXT,
            },
            judicalProceedingTotalValue: {
              isVisible: true,
              colName: 'judicalProceedingTotalValue',
              width: 200,
              position: 39,
              title: 'Сума коштів, за якими порушено судове провадження про стягнення, . грн',
              type: cellTypes.TEXT,
            },
            enforcementTotalValue: {
              isVisible: true,
              colName: 'enforcementTotalValue',
              width: 200,
              position: 40,
              title: 'Сума коштів по яких здійснюються виконавчі дії, . грн',
              type: cellTypes.TEXT,
            },
          },
        },
      },
    },
  },
};

export default initialSettings;
