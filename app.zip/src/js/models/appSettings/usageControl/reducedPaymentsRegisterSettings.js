import * as tableConstants from '../../../constants/TableToolNames';
import * as cellTypes from '../../../constants/CellTypes';

const initialSettings = {
  reducedPaymentsRegister: {
    register: {
      tableToolbar: {
        tasks: {
          // joinGroup: {
          //   title: tableConstants.JOIN_GROUP,
          //   isVisible: true
          // },
          // assignRole: {
          //   title: tableConstants.ASSIGN_ROLE,
          //   isVisible: true
          // },
          archiveUser: {
            title: tableConstants.ARCHIVE_USER,
            isVisible: true,
          },
        },
        export: {
          // xls: {
          //   title: tableConstants.XLS,
          //   isVisible: true
          // },
          pdf: {
            title: tableConstants.PDF,
            isVisible: true,
          },
          // csv: {
          //   title: tableConstants.CSV,
          //   isVisible: true
          // }
        },
        filters: {
          filters: {
            title: tableConstants.FILTERS,
            isVisible: true,
          },
          specFilters: {
            title: tableConstants.SPEC_FILTERS,
            isVisible: true,
          },
        },
        config: {
          tableColumns: {
            title: tableConstants.TABLE_COLUMNS,
            isVisible: true,
          },
          toolbarManagement: {
            title: tableConstants.TOOLBAR_MANAGEMENT,
            isVisible: true,
          },
        },
      },
      tableBody: {
        columns: {
          fixed: {
            checkbox: {
              isVisible: true,
              colName: 'checkbox',
              width: 30,
              position: 0,
              title: 'checkbox',
              type: cellTypes.CHECKBOX,
            },
            counterpartyPayerName: {
              isVisible: true,
              colName: 'counterpartyPayerName',
              width: 200,
              position: 0,
              title: 'Контрагент платник: назва',
              type: cellTypes.TEXT,
            },
            // action: {
            //   isVisible: true,
            //   colName: 'action',
            //   width: 70,
            //   position: 2,
            //   title: 'Дія',
            //   type: cellTypes.BUTTONS
            // }
          },
          fluid: {
            // visible

            counterpartyPayerNameGovID: {
              isVisible: true,
              colName: 'counterpartyPayerNameGovID',
              width: 200,
              position: 1,
              title: 'Контрагент платник: ЕДРПОУ',
              type: cellTypes.TEXT,
            },
            repMonth: {
              isVisible: true,
              colName: 'repMonth',
              width: 200,
              position: 2,
              title: 'Звітний місяць',
              type: cellTypes.TEXT,
            },
            repYear: {
              isVisible: true,
              colName: 'repYear',
              width: 200,
              position: 3,
              title: 'Звітний рік',
              type: cellTypes.TEXT,
            },
            paidAmount: {
              isVisible: true,
              colName: 'paidAmount',
              width: 200,
              position: 4,
              title: 'Сплачено коштів, грн',
              type: cellTypes.TEXT,
            },
          },
        },
      },
    },
  },
};

export default initialSettings;
