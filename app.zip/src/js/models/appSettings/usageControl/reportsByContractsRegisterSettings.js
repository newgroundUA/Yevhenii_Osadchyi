import * as tableConstants from '../../../constants/TableToolNames';
import * as cellTypes from '../../../constants/CellTypes';

const initialSettings = {
  reportsByContractsRegister: {
    register: {
      tableToolbar: {
        tasks: {
          // joinGroup: {
          //   title: tableConstants.JOIN_GROUP,
          //   isVisible: true
          // },
          // assignRole: {
          //   title: tableConstants.ASSIGN_ROLE,
          //   isVisible: true
          // },
          archiveUser: {
            title: tableConstants.ARCHIVE_USER,
            isVisible: true,
          },
        },
        export: {
          // xls: {
          //   title: tableConstants.XLS,
          //   isVisible: true
          // },
          pdf: {
            title: tableConstants.PDF,
            isVisible: true,
          },
          // csv: {
          //   title: tableConstants.CSV,
          //   isVisible: true
          // }
        },
        filters: {
          filters: {
            title: tableConstants.FILTERS,
            isVisible: true,
          },
          specFilters: {
            title: tableConstants.SPEC_FILTERS,
            isVisible: true,
          },
        },
        config: {
          tableColumns: {
            title: tableConstants.TABLE_COLUMNS,
            isVisible: true,
          },
          toolbarManagement: {
            title: tableConstants.TOOLBAR_MANAGEMENT,
            isVisible: true,
          },
        },
      },
      tableBody: {
        columns: {
          fixed: {
            checkbox: {
              isVisible: true,
              colName: 'checkbox',
              width: 30,
              position: 0,
              title: 'checkbox',
              type: cellTypes.CHECKBOX,
            },
            repRegNum: {
              isVisible: true,
              colName: 'repRegNum',
              width: 200,
              position: 0,
              title: 'Реєстраційний номер звіту',
              type: cellTypes.TEXT,
            },
            action: {
              isVisible: true,
              colName: 'action',
              width: 70,
              position: 2,
              title: 'Дія',
              type: cellTypes.BUTTONS,
            },
          },
          fluid: {
            // visible

            balanceKeeperName: {
              isVisible: true,
              colName: 'balanceKeeperName',
              width: 200,
              position: 0,
              title: 'Балансоутримувач: назва',
              type: cellTypes.TEXT,
            },
            balanceKeeperGovID: {
              isVisible: true,
              colName: 'balanceKeeperGovID',
              width: 200,
              position: 1,
              title: 'Балансоутримувач: ЕДРПОУ',
              type: cellTypes.TEXT,
            },
            tenantName: {
              isVisible: true,
              colName: 'tenantName',
              width: 200,
              position: 2,
              title: 'Орендар: назва',
              type: cellTypes.TEXT,
            },
            tenantGovID: {
              isVisible: true,
              colName: 'tenantGovID',
              width: 200,
              position: 3,
              title: 'Орендар: ЕДРПОУ',
              type: cellTypes.TEXT,
            },
            landlordName: {
              isVisible: true,
              colName: 'landlordName',
              width: 200,
              position: 4,
              title: 'Орендодавець: назва',
              type: cellTypes.TEXT,
            },
            landlordGovID: {
              isVisible: true,
              colName: 'landlordGovID',
              width: 200,
              position: 5,
              title: 'Орендодавець: ЕДРПОУ',
              type: cellTypes.TEXT,
            },
            leaseContract: {
              isVisible: true,
              colName: 'leaseContract',
              width: 200,
              position: 6,
              title: 'Договір оренди',
              type: cellTypes.TEXT,
            },
            repMonth: {
              isVisible: true,
              colName: 'repMonth',
              width: 200,
              position: 7,
              title: 'Звітний місяць',
              type: cellTypes.TEXT,
            },
            repYear: {
              isVisible: true,
              colName: 'repYear',
              width: 200,
              position: 8,
              title: 'Звітний рік',
              type: cellTypes.TEXT,
            },
            createdByName: {
              isVisible: true,
              colName: 'createdByName',
              width: 200,
              position: 9,
              title: 'Звіт створено: ФІО',
              type: cellTypes.TEXT,
            },
            createdDate: {
              isVisible: true,
              colName: 'createdDate',
              width: 200,
              position: 10,
              title: 'Звіт створено дата',
              type: cellTypes.TEXT,
            },
            lastModifiedByName: {
              isVisible: true,
              colName: 'lastModifiedByName',
              width: 200,
              position: 11,
              title: 'Звіт в останне модифіковано: ФІО',
              type: cellTypes.TEXT,
            },
            lastModifiedDate: {
              isVisible: true,
              colName: 'lastModifiedDate',
              width: 200,
              position: 12,
              title: 'Звіт в останне модифіковано: дата',
              type: cellTypes.TEXT,
            },
          },
        },
      },
    },
  },
};

export default initialSettings;
