import * as tableConstants from '../../../constants/TableToolNames';
import * as cellTypes from '../../../constants/CellTypes';

const initialSettings = {
  reportsByPeriodsRegister: {
    register: {
      tableToolbar: {
        tasks: {
          // joinGroup: {
          //   title: tableConstants.JOIN_GROUP,
          //   isVisible: true
          // },
          // assignRole: {
          //   title: tableConstants.ASSIGN_ROLE,
          //   isVisible: true
          // },
          archiveUser: {
            title: tableConstants.ARCHIVE_USER,
            isVisible: true,
          },
        },
        export: {
          // xls: {
          //   title: tableConstants.XLS,
          //   isVisible: true
          // },
          pdf: {
            title: tableConstants.PDF,
            isVisible: true,
          },
          // csv: {
          //   title: tableConstants.CSV,
          //   isVisible: true
          // }
        },
        filters: {
          filters: {
            title: tableConstants.FILTERS,
            isVisible: true,
          },
          specFilters: {
            title: tableConstants.SPEC_FILTERS,
            isVisible: true,
          },
        },
        config: {
          tableColumns: {
            title: tableConstants.TABLE_COLUMNS,
            isVisible: true,
          },
          toolbarManagement: {
            title: tableConstants.TOOLBAR_MANAGEMENT,
            isVisible: true,
          },
        },
      },
      tableBody: {
        columns: {
          fixed: {
            checkbox: {
              isVisible: true,
              colName: 'checkbox',
              width: 30,
              position: 0,
              title: 'checkbox',
              type: cellTypes.CHECKBOX,
            },
            leasePeriodicalByBalanceHolderReportRegNum: {
              isVisible: true,
              colName: 'leasePeriodicalByBalanceHolderReportRegNum',
              width: 200,
              position: 1,
              title: 'Реєстраційний номер звіту',
              type: cellTypes.TEXT,
            },
            action: {
              isVisible: true,
              colName: 'action',
              width: 70,
              position: 2,
              title: 'Дія',
              type: cellTypes.BUTTONS,
            },
          },
          fluid: {
            balanceHolder: {
              isVisible: true,
              colName: 'balanceHolder',
              width: 200,
              position: 2,
              title: 'Балансоутримувач: назва',
              type: cellTypes.TEXT,
            },
            // balanceKeeperGovID: { question???
            //   isVisible: true,
            //   colName: 'balanceKeeperGovID',
            //   width: 200,
            //   position: 2,
            //   title: 'Балансоутримувач: ЕДРПОУ',
            //   type: cellTypes.TEXT
            // },
            reportPeriodMonth: {
              isVisible: true,
              colName: 'reportPeriodMonth',
              width: 200,
              position: 3,
              title: 'Звітний місяць',
              type: cellTypes.TEXT,
            },
            reportPeriodYear: {
              isVisible: true,
              colName: 'reportPeriodYear',
              width: 200,
              position: 4,
              title: 'Звітний рік',
              type: cellTypes.TEXT,
            },
            createdRecBy: {
              isVisible: true,
              colName: 'createdRecBy',
              width: 200,
              position: 5,
              title: 'Звіт створено: ФІО',
              type: cellTypes.TEXT,
            },
            createdRecOn: {
              isVisible: true,
              colName: 'createdRecOn',
              width: 200,
              position: 6,
              title: 'Звіт створено дата',
              type: cellTypes.TEXT,
            },
            updatedRecBy: {
              isVisible: true,
              colName: 'updatedRecBy',
              width: 200,
              position: 7,
              title: 'Звіт в останне модифіковано: ФІО',
              type: cellTypes.TEXT,
            },
            updatedRecOn: {
              isVisible: true,
              colName: 'updatedRecOn',
              width: 200,
              position: 8,
              title: 'Звіт в останне модифіковано: дата',
              type: cellTypes.TEXT,
            },
          },
        },
      },
    },
  },
};

export default initialSettings;
