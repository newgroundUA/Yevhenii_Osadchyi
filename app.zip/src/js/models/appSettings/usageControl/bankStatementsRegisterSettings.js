import * as tableConstants from '../../../constants/TableToolNames';
import * as cellTypes from '../../../constants/CellTypes';

const initialSettings = {
  bankStatementsRegister: {
    register: {
      tableToolbar: {
        tasks: {
          // joinGroup: {
          //   title: tableConstants.JOIN_GROUP,
          //   isVisible: true
          // },
          // assignRole: {
          //   title: tableConstants.ASSIGN_ROLE,
          //   isVisible: true
          // },
          archiveUser: {
            title: tableConstants.ARCHIVE_USER,
            isVisible: true,
          },
        },
        export: {
          // xls: {
          //   title: tableConstants.XLS,
          //   isVisible: true
          // },
          pdf: {
            title: tableConstants.PDF,
            isVisible: true,
          },
          // csv: {
          //   title: tableConstants.CSV,
          //   isVisible: true
          // }
        },
        filters: {
          filters: {
            title: tableConstants.FILTERS,
            isVisible: true,
          },
          specFilters: {
            title: tableConstants.SPEC_FILTERS,
            isVisible: true,
          },
        },
        config: {
          tableColumns: {
            title: tableConstants.TABLE_COLUMNS,
            isVisible: true,
          },
          toolbarManagement: {
            title: tableConstants.TOOLBAR_MANAGEMENT,
            isVisible: true,
          },
        },
      },
      tableBody: {
        columns: {
          fixed: {
            checkbox: {
              isVisible: true,
              colName: 'checkbox',
              width: 30,
              position: 0,
              title: 'checkbox',
              type: cellTypes.CHECKBOX,
            },
            intRegNum: {
              isVisible: true,
              colName: 'intRegNum',
              width: 200,
              position: 0,
              title: 'Внутрішній реєстраційний номер',
              type: cellTypes.TEXT,
            },
            action: {
              isVisible: true,
              colName: 'action',
              width: 70,
              position: 2,
              title: 'Дія',
              type: cellTypes.BUTTONS,
            },
          },
          fluid: {
            // visible

            statementDate: {
              isVisible: true,
              colName: 'statementDate',
              width: 200,
              position: 1,
              title: 'Дата виписки',
              type: cellTypes.TEXT,
            },
            counterpartyName: {
              isVisible: true,
              colName: 'counterpartyName',
              width: 200,
              position: 2,
              title: 'Контрагент (власник рахунку) назва',
              type: cellTypes.TEXT,
            },
            counterpartyGovID: {
              isVisible: true,
              colName: 'counterpartyGovID',
              width: 200,
              position: 3,
              title: 'Контрагент (власник рахунку) ЕДРПОУ',
              type: cellTypes.TEXT,
            },
            docState: {
              isVisible: true,
              colName: 'docState',
              width: 200,
              position: 4,
              title: 'Стан чинності документу',
              type: cellTypes.DROP_DOWN,
            },
            docAuthor: {
              isVisible: true,
              colName: 'docAuthor',
              width: 200,
              position: 5,
              title: 'Автор документу',
              type: cellTypes.TEXT,
            },
            totalAmount: {
              isVisible: true,
              colName: 'totalAmount',
              width: 200,
              position: 6,
              title: 'Загальна сума отриманих коштів',
              type: cellTypes.TEXT,
            },
            totalPaymentCount: {
              isVisible: true,
              colName: 'totalPaymentCount',
              width: 200,
              position: 7,
              title: 'Загальна кількість отриманих платежів',
              type: cellTypes.TEXT,
            },
            totalPaymentAimCount: {
              isVisible: true,
              colName: 'totalPaymentAimCount',
              width: 200,
              position: 8,
              title: 'Загальна кількість отриманих та рознесених призначень',
              type: cellTypes.TEXT,
            },
            totalSentAmount: {
              isVisible: true,
              colName: 'totalSentAmount',
              width: 200,
              position: 9,
              title: 'Загальна сума відправлених коштів',
              type: cellTypes.TEXT,
            },
            totalSentPayment: {
              isVisible: true,
              colName: 'totalSentPayment',
              width: 200,
              position: 10,
              title: 'Загальна кількість відправлених платежів',
              type: cellTypes.TEXT,
            },
            totalSentPaymentAim: {
              isVisible: true,
              colName: 'totalSentPaymentAim',
              width: 200,
              position: 11,
              title: 'Згальна кількість відправлених та рознесених призначень',
              type: cellTypes.TEXT,
            },
          },
        },
      },
    },
  },
};

export default initialSettings;
