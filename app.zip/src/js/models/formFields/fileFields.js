import * as formItemTypes from '../../constants/FormItemTypes';
import * as classifiers from '../../constants/ClassifiersNames';

const getArr = (fields = []) => fields.map((el) => el.guid);

export const fileFields = {
  // eslint-disable-line import/prefer-default-export
  file: {
    field: 'file',
    name: 'Файл',
    type: formItemTypes.FILE,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  fileContentType: {
    field: 'fileContentType',
    name: 'Тип за змістом',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.FILE_CONTENT_TYPE,
    valuableFields: ['versionId', 'type', 'guid'],
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  notice: {
    field: 'notice',
    name: 'Примітка',
    type: formItemTypes.TEXTAREA,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  uploadDate: {
    field: 'uploadDate',
    name: 'Дата завантаження',
    type: formItemTypes.DATEPICKER,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
};

export const getMappedForm = (props) => ({
  notice: props.notice,
  types: props.fileContentType,
  file: props.file,
});

export const getParsedForm = (props) => ({
  notice: props.fileNotes,
  fileContentType: props.contentTypes ? getArr(props.contentTypes) : [],
  file: props.fileLink,
});
