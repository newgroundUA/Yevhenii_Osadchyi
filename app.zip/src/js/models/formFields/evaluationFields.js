import * as formItemTypes from '../../constants/FormItemTypes';
import * as classifiers from '../../constants/ClassifiersNames';

export const ApplicationForEvaluationFields = {
  objectAddress: {
    field: 'objectAddress',
    name: "Адреса об'єкту",
    type: formItemTypes.SELECT,
    classifier: classifiers.OBJECT_ADDRESS,
    placeholder: 'Виберіть поле',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  initiator: {
    field: 'initiator',
    name: 'Ініціатор',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    placeholder: 'Виберіть поле',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  classificationProcess: {
    field: 'classificationProcess',
    name: 'Класифікація процесу',
    type: formItemTypes.SELECT,
    classifier: classifiers.CLASSIFICATION_PROCESS,
    placeholder: 'Виберіть поле',
    rules: [{ required: false, message: 'Поле обов`язкове для вибору!' }],
  },
};

export const ObjectEvaluationFields = {
  objectEvaluation: {
    field: 'objectEvaluation',
    name: "Об'єкт оцінки",
    type: formItemTypes.SELECT,
    classifier: classifiers.OBJECT_EVALUATION,
    placeholder: 'Виберіть поле',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  territorialCasePrivatizationImprovements: {
    field: 'territorialCasePrivatizationImprovements',
    name: 'Частка територіальної громади у разі приватизації з невід’ємними поліпшеннями (%)',
    type: formItemTypes.INPUT,
    placeholder: 'Виберіть поле',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  costObjectEvaluationWithoutVATprivatization: {
    field: 'costObjectEvaluationWithoutVATprivatization',
    name: "Вартість об'єкта оцінки без ПДВ, для приватизації (грн.)",
    type: formItemTypes.INPUT,
    placeholder: 'Виберіть поле',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  costTerritorial: {
    field: 'costTerritorial',
    name: 'Вартість територіальної громади у разі приватизації з невід’ємними поліпшеннями (грн.)',
    type: formItemTypes.INPUT,
    placeholder: 'Виберіть поле',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  cost1kvmWithoutVAT: {
    field: 'cost1kvmWithoutVAT',
    name: 'Вартість 1 кв.м. без ПДВ (дол. США.)',
    type: formItemTypes.INPUT,
    placeholder: 'Виберіть поле',
    rules: [{ required: false, message: 'Поле обов`язкове для вибору!' }],
  },
  evaluationDate: {
    field: 'evaluationDate',
    name: 'Дата оцінки',
    type: formItemTypes.DATEPICKER,
    placeholder: 'Виберіть поле',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  costObjectVAT: {
    field: 'costObjectVAT',
    name: "Вартість об'єкта оцінки з ПДВ (грн.)",
    type: formItemTypes.INPUT,
    placeholder: 'Виберіть поле',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  costFixedAssets: {
    field: 'costFixedAssets',
    name: 'Вартість основних засобів (грн.)',
    type: formItemTypes.INPUT,
    placeholder: 'Виберіть поле',
    rules: [{ required: false, message: 'Поле обов`язкове для вибору!' }],
  },
  costObjectEvaluationWithoutVAT: {
    field: 'costObjectEvaluationWithoutVAT',
    name:
      "Вартість об'єкта оцінки без ПДВ (частка тер.громади, у разі приватизації з невід’ємними поліпшеннями) (грн.)",
    type: formItemTypes.INPUT,
    placeholder: 'Виберіть поле',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  costIntangibleAssets: {
    field: 'costIntangibleAssets',
    name: 'Вартість нематеріальних активів (грн.)',
    type: formItemTypes.INPUT,
    placeholder: 'Виберіть поле',
    rules: [{ required: false, message: 'Поле обов`язкове для вибору!' }],
  },
  costObjectEvaluationVAT: {
    field: 'costObjectEvaluationVAT',
    name:
      "Вартість об'єкта оцінки з ПДВ (частка тер.громади, у разі приватизації з невід’ємними поліпшеннями) (грн.)",
    type: formItemTypes.INPUT,
    placeholder: 'Виберіть поле',
    rules: [{ required: false, message: 'Поле обов`язкове для вибору!' }],
  },
};

export const EvaluationProcessFields = {
  evaluationStage: {
    field: 'evaluationStage',
    name: 'Етап оцінки',
    type: formItemTypes.SELECT,
    classifier: classifiers.EVALUATION_STAGE,
    placeholder: 'Виберіть поле',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  conclusionEvaluationLease: {
    field: 'conclusionEvaluationLease',
    name: 'Висновок про можливість застосування результату оцінки об’єкта оренди',
    type: formItemTypes.SELECT,
    classifier: classifiers.CONCLUSION_EVALUATION_LEASE,
    placeholder: 'Виберіть поле',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  reviewCategory: {
    field: 'reviewCategory',
    name: 'Категорія рецензії',
    type: formItemTypes.SELECT,
    classifier: classifiers.REVIEW_CATEGORY,
    placeholder: 'Виберіть поле',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  reviewer: {
    field: 'reviewer',
    name: 'Рецензент',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    placeholder: 'Виберіть поле',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  startProcess: {
    field: 'startProcess',
    name: 'Початок процесу',
    type: formItemTypes.DATEPICKER,
    placeholder: 'Виберіть поле',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  endProcess: {
    field: 'endProcess',
    name: 'Закінчення процесу',
    type: formItemTypes.DATEPICKER,
    placeholder: 'Виберіть поле',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  checkDate: {
    field: 'checkDate',
    name: 'Контрольна дата',
    type: formItemTypes.DATEPICKER,
    placeholder: 'Виберіть поле',
    rules: [{ required: false, message: 'Поле обов`язкове для вибору!' }],
  },
  comment: {
    field: 'comment',
    name: 'Коментар / пояснення',
    type: formItemTypes.TEXTAREA,
    placeholder: 'Виберіть поле',
    rules: [{ required: false, message: 'Поле обов`язкове для вибору!' }],
  },
};
