import _get from 'lodash/get';

import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';
import { createValueCreator } from '../../../helpers/formHelpers/dropdownValueCreators';
import { getDate } from '../../../helpers/formHelpers/formHelpers';

const createCounterpartyValue = createValueCreator('counterparty');
const createDocumentValue = createValueCreator('document');

const defaultValuableFields = ['guid', 'versionId'];

// Раздел "Параметри справи з рецензування"
export const reviewCaseOptionsFields = {
  assessmentReasonType: {
    field: 'assessmentReasonType',
    name: 'Мета оцінки майна',
    type: formItemTypes.SELECT,
    defaultValue: 'PRIVATIZATION',
    readOnly: true,
    classifier: classifiers.ASSESSMENT_REASON_TYPE,
    placeholder: 'Нічого не вибрано',
    rules: [{ required: true, message: 'Поле обов`язкове для заповнення!' }],
  },
  assessementReviewingState: {
    field: 'assessementReviewingState',
    name: 'Стан процесу рецензування оцінки',
    type: formItemTypes.SELECT,
    // Класифікатор станів справи на рецензування оцінки
    classifier: classifiers.CL_ASSESSMENT_REVIEWING_STATE,
    placeholder: 'Нічого не вибрано',
    valuableFields: [...defaultValuableFields, 'type'],
    rules: [{ required: true, message: 'Поле обов`язкове для заповнення!' }],
  },
  assessementReviewingCaseNum: {
    field: 'assessementReviewingCaseNum',
    name: 'Реєстраційний номер справи з рецензування',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для заповнення!' }],
  },
  assessementReviewingStartDate: {
    field: 'assessementReviewingStartDate',
    name: 'Дата початку рецензування',
    type: formItemTypes.DATEPICKER,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  assessementReviewingEndPlanDate: {
    field: 'assessementReviewingEndPlanDate',
    name: 'Дата завершення рецензування (планова)',
    type: formItemTypes.DATEPICKER,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  assessementReviewingControlDate: {
    field: 'assessementReviewingControlDate',
    name: 'Контрольна дата процесу рецензування',
    type: formItemTypes.DATEPICKER,
    rules: [{ required: false, message: '' }],
  },
};

// Раздел "Вхідні документи по справі"
export const caseIncomingDocumentsFields = {
  applicationToPrivatization: {
    field: 'applicationToPrivatization',
    name: 'Заява на приватизацію майна',
    type: formItemTypes.SELECT,
    classifier: classifiers.DOCUMENTS,
    // documentType: 'ApplicationToLease',
    colSpan: 24,
    placeholder: 'Нічого не вибрано',
    valuableFields: [...defaultValuableFields],
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  docForReviewing: {
    // от него зависит обьект оценки
    field: 'docForReviewing',
    name: 'Документ про оцінку що рецензується',
    type: formItemTypes.SELECT,
    classifier: classifiers.DOCUMENTS,
    documentType: 'MarketPriceDetect',
    colSpan: 24,
    placeholder: 'Нічого не вибрано',
    valuableFields: [...defaultValuableFields],
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  // privatizationAssessementType: {
  //   field: 'privatizationAssessementType',
  //   name: 'Тип оцінки по приватизації',
  //   type: formItemTypes.SELECT,
  //   classifier: classifiers.LEASE_ASSESSMENT_TYPE, change
  //   placeholder: 'Нічого не вибрано',
  //   rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }]
  // },
  assessementDate: {
    field: 'assessementDate',
    name: 'Дата оцінки',
    type: formItemTypes.DATEPICKER,
    rules: [{ required: true, message: '' }],
  },
  assessementContract: {
    field: 'assessementContract',
    name: 'Договір з контрагентом-СОД',
    type: formItemTypes.SELECT,
    classifier: classifiers.DOCUMENTS,
    colSpan: 24,
    placeholder: 'Нічого не вибрано',
    valuableFields: [...defaultValuableFields],
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  privatCompetitionProtocol: {
    field: 'privatCompetitionProtocol',
    name: 'Протокол конкурсу на відбір СОД',
    type: formItemTypes.SELECT,
    classifier: classifiers.DOCUMENTS,
    colSpan: 24,
    placeholder: 'Нічого не вибрано',
    valuableFields: [...defaultValuableFields],
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
};

// Раздел "Результати рецензування по справі"
export const caseReviewingResultrsFields = {
  reviewer: {
    field: 'reviewer',
    name: 'Рецензент',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY, // тут должен быть только ФО
    placeholder: 'Нічого не вибрано',
    valuableFields: [...defaultValuableFields],
    rules: [{ required: false, message: '' }],
  },
  assessementReviewingConclusionDoc: {
    field: 'assessementReviewingConclusionDoc',
    name: 'Документ-висновок рецензування',
    type: formItemTypes.SELECT,
    classifier: classifiers.DOCUMENTS,
    colSpan: 24,
    placeholder: 'Нічого не вибрано',
    valuableFields: [...defaultValuableFields],
    rules: [{ required: false, message: '' }],
  },
  assessementReviewingConclusion: {
    field: 'assessementReviewingConclusion',
    name: 'Висновок рецензування',
    type: formItemTypes.SELECT,
    classifier: classifiers.ASSESSMENT_REVIEWING_CONCLUSION,
    placeholder: 'Нічого не вибрано',
    rules: [{ required: false, message: '' }],
  },
  assessementReviewingCategory: {
    field: 'assessementReviewingCategory',
    name: 'Категорія рецензії',
    type: formItemTypes.SELECT,
    classifier: classifiers.ASSESSMENT_REVIEWING_CATEGORY,
    placeholder: 'Нічого не вибрано',
    valuableFields: [...defaultValuableFields, 'type'],
    rules: [{ required: false, message: '' }],
  },
  assessementReviewingEndFactDate: {
    field: 'assessementReviewingEndFactDate',
    name: 'Дата завершення рецензування (факт)',
    type: formItemTypes.DATEPICKER,
    rules: [{ required: false, message: '' }],
  },
  assessementReviewingNotes: {
    field: 'assessementReviewingNotes',
    name: 'Додаткові коментарі',
    type: formItemTypes.TEXTAREA,
    rules: [{ required: false, message: '' }],
  },
};

// Раздел "Контрагенти по справі"
export const caseCounterpartiesFields = {
  balanceHolder: {
    field: 'balanceHolder',
    name: 'Балансоутримувач',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    placeholder: 'Нічого не вибрано',
    valuableFields: [...defaultValuableFields],
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  buyer: {
    field: 'buyer',
    name: 'Контрагент-покупець',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    placeholder: 'Нічого не вибрано',
    valuableFields: [...defaultValuableFields],
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  appraiser: {
    field: 'appraiser',
    name: 'Контрагент-оцінювач',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    placeholder: 'Нічого не вибрано',
    valuableFields: [...defaultValuableFields],
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
};

export const evaluationObjectFields = {
  evaluationObjectNumber: {
    field: 'evaluationObjectNumber',
    name: "Реєстровий номер об'єкту приватизації",
    type: formItemTypes.INPUT,
    readOnly: true,
  },
  evaluationObjectName: {
    field: 'evaluationObjectName',
    name: "Назва об'єкту приватизації",
    type: formItemTypes.INPUT,
    readOnly: true,
  },
  evaluationObjectAddress: {
    field: 'evaluationObjectAddress',
    name: "Адреса об'єкту приватизації",
    type: formItemTypes.INPUT,
    readOnly: true,
  },
  evaluationObjectTotalSpace: {
    field: 'evaluationObjectTotalSpace',
    name: 'Загальна площа, кв. м.',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
  evaluationObjectUsefullSpace: {
    field: 'evaluationObjectUsefullSpace',
    name: 'Загальна корисна площа, кв. м.',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
  evaluationObjectCommonUsesSpace: {
    field: 'evaluationObjectCommonUsesSpace',
    name: 'Площа приміщень загального користування, кв.м.',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
};

export const parseToBE = (props) => ({
  arcType: 'PrivatizationARC',
  arcNumber: props.assessementReviewingCaseNum || null,
  arcStartDate: props.assessementReviewingStartDate || null,
  arcEndPlanDate: props.assessementReviewingEndPlanDate || null,
  controlDate: props.assessementReviewingControlDate || null,
  assessmentReasonType: props.assessmentReasonType || null,
  arcState: props.assessementReviewingState,
  arcCategory: props.assessementReviewingCategory,
  docForReviewing: props.docForReviewing,
  assessmentDate: props.assessementDate || null,
  arcConclusion: props.assessementReviewingConclusion ? props.assessementReviewingConclusion : null,
  arcEndFactDate: props.assessementReviewingEndFactDate || null,
  assessmentReviewingConclusionDoc: props.assessementReviewingConclusionDoc,
  reviewer: props.reviewer,
  balanceHolder: props.balanceHolder,
  appraiser: props.appraiser,
  assessmentContract: props.assessementContract,
  assessmentReviewingNotes: props.assessementReviewingNotes || null,
  buyer: props.buyer,
  privatizationObject: props.privatizationObject,
  privatCompetitionProtocol: props.privatCompetitionProtocol,
  applicationToPrivatization: props.applicationToPrivatization,
});

export const parseToFE = (props) => ({
  assessementReviewingCaseNum: props.arcNumber,
  assessementReviewingStartDate: getDate(props.arcStartDate),
  assessementReviewingEndPlanDate: getDate(props.arcEndPlanDate),
  assessementReviewingControlDate: getDate(props.controlDate),
  assessmentReasonType: props.assessmentReasonType,
  assessementReviewingState: props.arcState ? props.arcState.guid : null,
  assessementReviewingCategory: _get(props, ['arcCategory', 'guid']),
  docForReviewing: createDocumentValue(props.docForReviewing),
  assessementDate: getDate(props.assessmentDate),
  assessementReviewingConclusion: props.arcConclusion,
  assessementReviewingEndFactDate: getDate(props.arcEndFactDate),
  assessementReviewingConclusionDoc: createDocumentValue(props.assessmentReviewingConclusionDoc),
  reviewer: createCounterpartyValue(props.reviewer),
  balanceHolder: createCounterpartyValue(props.balanceHolder),
  appraiser: createCounterpartyValue(props.appraiser),
  assessementContract: createDocumentValue(props.assessmentContract),
  assessementReviewingNotes: props.assessmentReviewingNotes,
  buyer: createCounterpartyValue(props.buyer),
  privatCompetitionProtocol: createDocumentValue(props.privatCompetitionProtocol),
  applicationToPrivatization: createDocumentValue(props.applicationToPrivatization),

  evaluationObjectNumber: _get(props, ['privatizationObject', 'privatObjectNumber']),
  evaluationObjectName: _get(props, ['privatizationObject', 'privatObjectFullName']),
  evaluationObjectAddress: _get(props, ['privatizationObject', 'address', 'addressAsString'], ''),
  evaluationObjectTotalSpace: _get(props, ['privatizationObject', 'privatObjectTotalSpace']),
  evaluationObjectUsefullSpace: _get(props, ['privatizationObject', 'privatObjectUsefullSpace']),
  evaluationObjectCommonUsesSpace: _get(props, [
    'privatizationObject',
    'privatObjectCommonUseSpace',
  ]),
  // evaluationObjectTotalAssessmentPrice: props.totalAssessmentPrice,
  // oneSqMeterUsdPrice: props.oneSqMeterUsdPrice
});
