import moment from 'moment';

import * as formItemTypes from '../../../constants/FormItemTypes';

const DATE_FORMAT_BE = 'YYYY-MM-DD HH:mm:ss.SSS Z';
const getDate = (data) => (data ? moment(data, DATE_FORMAT_BE) : null);

export const leaseContractPaymentScheduleFields = {
  leaseContract: {
    field: 'leaseContract',
    name: 'Договір оренди',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
  periodYear: {
    field: 'periodYear',
    name: 'Звітний період: рік',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
  periodMonth: {
    field: 'periodMonth',
    name: 'Звітний період: місяць',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
  paymentDatePlan: {
    field: 'paymentDatePlan',
    name: 'Запланована дата платежу',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
  // leaseOperationMode: {
  //   field: 'leaseOperationMode',
  //   name: 'Режим оренди об\'єкту',
  //   type: formItemTypes.INPUT,
  //   readOnly: true
  // },
  // forecastMLTQuantityByPeriod: {
  //   field: 'forecastMLTQuantityByPeriod',
  //   name: 'Кількість МСО в ЗП ПРОГНОЗНА',
  //   type: formItemTypes.INPUT,
  //   readOnly: true
  // },
  forecastRental: {
    field: 'forecastRental',
    name: 'Орендна плата за прогнозним ІІ, грн',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
  forecastLeaseTotalAmount: {
    field: 'forecastLeaseTotalAmount',
    name: 'Прогнозна за ІІ сума до сплати, грн*',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
  contractRental: {
    field: 'contractRental',
    name: 'Договірна орендна плата',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
  contractLeaseTotalAmount: {
    field: 'contractLeaseTotalAmount',
    name: 'Договірна сума до сплати за оренду',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
  // factMLTQuantityByPeriod: {
  //   field: 'factMLTQuantityByPeriod',
  //   name: 'Фактична кількістіь МСО в ЗП',
  //   type: formItemTypes.INPUT,
  //   readOnly: true
  // },
  factRental: {
    field: 'factRental',
    name: 'Фактична орендна плата',
    type: formItemTypes.INPUT,
  },
  factLeaseTotalAmount: {
    field: 'factLeaseTotalAmount',
    name: 'Фактична сума до сплати за оренду',
    type: formItemTypes.INPUT,
  },
};

export const parseToFE = (props) => ({
  leaseContract: (props.leaseContract || {}).docNumber,
  periodYear: props.periodYear,
  periodMonth: props.periodMonth,
  paymentDatePlan: getDate(props.paymentDatePlan),
  // leaseOperationMode: props.leaseOperationMode,
  // forecastMLTQuantityByPeriod: props.forecastMLTQuantityByPeriod,
  forecastRental: props.forecastRental,
  forecastLeaseTotalAmount: props.forecastLeaseTotalAmount,
  contractRental: props.contractRental,
  contractLeaseTotalAmount: props.contractLeaseTotalAmount,
  // factMLTQuantityByPeriod: props.factMLTQuantityByPeriod,
  factRental: props.factRental,
  factLeaseTotalAmount: props.factLeaseTotalAmount,
});

export const parseToBE = (props) => ({
  factRental: props.factRental,
  factLeaseTotalAmount: props.factLeaseTotalAmount,
});
