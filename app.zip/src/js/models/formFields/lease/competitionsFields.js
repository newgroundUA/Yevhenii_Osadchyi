import moment from 'moment';
import _get from 'lodash/get';

import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';
import { createValueCreator } from '../../../helpers/formHelpers/dropdownValueCreators';

const DATE_FORMAT_BE = 'YYYY-MM-DD HH:mm:ss.SSS Z';
const getDate = (data) => (data ? moment(data, DATE_FORMAT_BE) : null);
const createValue = createValueCreator('counterparty');
const createDocumentValue = createValueCreator('document');

const defaultValuableFields = ['guid', 'versionId'];

export const competitionsFields = {
  // +
  leaseCompetitionsNumber: {
    field: 'leaseCompetitionsNumber',
    name: 'Реєстраційний номер конкурсу',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: "Обов'язково для вводу!" }],
  },
  leaseCompetitionsStatus: {
    // +
    field: 'leaseCompetitionsStatus',
    name: 'Операційни стан конкурсу',
    type: formItemTypes.SELECT,
    valuableFields: defaultValuableFields,
    classifier: classifiers.CL_LEASE_COMPETITION_STATUS,
    rules: [{ required: true, message: "Обов'язково для вводу!" }],
  },
  advertPaymentByBalansHolder: {
    // +
    field: 'advertPaymentByBalansHolder',
    name: 'Оплата оголошення балансоутримувачем',
    type: formItemTypes.RADIO,
    classifier: classifiers.YES_NO,
    rules: [{ required: true, message: "Обов'язково для вводу!" }],
  },
  leaseCases: {
    // +
    field: 'leaseCases',
    name: 'Орендна справа',
    type: formItemTypes.SELECT,
    valuableFields: defaultValuableFields,
    classifier: classifiers.LEASE_CASES,
    rules: [{ required: true, message: "Обов'язково для вводу!" }],
  },
  addDescription: {
    // +
    field: 'addDescription',
    name: "Додаткова інформація про об'єкт",
    type: formItemTypes.INPUT,
  },
  execDateTime: {
    // +
    field: 'execDateTime',
    name: 'Дата та час проведення',
    type: formItemTypes.DATE_TIME_PICKER,
  },
  addressNotes: {
    // +
    field: 'addressNotes',
    name: 'Місце проведення',
    type: formItemTypes.INPUT,
  },
  endRecievDate: {
    // +
    field: 'endRecievDate',
    name: 'Кінцева дата прийняття пропозицій',
    type: formItemTypes.DATEPICKER,
  },
  advancePaymentSize: {
    // +
    field: 'advancePaymentSize',
    name: 'Розмір авансової плати',
    type: formItemTypes.INPUT,
  },
  startCompetitionBet: {
    // +
    field: 'startCompetitionBet',
    name: 'Початкова орендна плата',
    type: formItemTypes.INPUT,
  },
  minAuctionStep: {
    // +
    field: 'minAuctionStep',
    name: 'Мінімальний крок аукціону, %',
    type: formItemTypes.INPUT,
  },
  leaseCompetitionsReasonDocs: {
    // +
    field: 'leaseCompetitionsReasonDocs',
    name: 'Документи що є підставою для конкурсу',
    type: formItemTypes.MULTISELECT,
    placeholder: 'Введіть номер документа для пошуку',
    valuableFields: defaultValuableFields,
    classifier: classifiers.DOCUMENTS,
    colSpan: 24,
  },
  competitiorsForDirectNotice: {
    // +
    field: 'competitiorsForDirectNotice',
    name: 'Контрагенти для повідомлення',
    type: formItemTypes.MULTISELECT,
    valuableFields: defaultValuableFields,
    classifier: classifiers.COUNTERPARTY,
  },
  leaseCompetition: {
    // +
    field: 'leaseCompetition',
    name: 'Первинний конкурс',
    type: formItemTypes.SELECT,
    valuableFields: defaultValuableFields,
    classifier: classifiers.LEASE_COMPETITIONS,
  },

  competitionCancelReasonType: {
    field: 'competitionCancelReasonType',
    name: 'Конкурс не відбувся з причини',
    type: formItemTypes.SELECT,
    valuableFields: defaultValuableFields.concat('type'),
    classifier: classifiers.COMPETITION_CANCEL_REASON_TYPE,
  },

  address: {
    field: 'address',
    name: 'Адреса проведення',
    type: formItemTypes.SELECT,
    valuableFields: defaultValuableFields,
    classifier: classifiers.OBJECT_ADDRESS,
    placeholder: 'Виберіть адресу розташування',
    customRendered: true,
  },

  phoneList: {
    field: 'phoneList',
    name: 'Телефони комісії',
    type: formItemTypes.MULTISELECT,
    valuableFields: defaultValuableFields,
    classifier: classifiers.PHONELIST,
  },
  emailList: {
    field: 'emailList',
    name: 'Електронна адреса',
    type: formItemTypes.MULTISELECT,
    valuableFields: defaultValuableFields,
    classifier: classifiers.EMAILLIST,
  },

  /* not implemented on BE
  bankDetails: {
    field: 'bankDetails',
    name: 'Банковськи реквізіти для авансу',
    type: formItemTypes.INPUT
  },
  */
};

export const parseToFE = (props) => ({
  leaseCompetitionsNumber: props.leaseCompetitionsNumber,
  addDescription: props.addDescription,

  endRecievDate: getDate(props.endRecievDate),
  execDateTime: getDate(props.execDateTime),

  addressNotes: props.addressNotes,
  advancePaymentSize: props.advancePaymentSize,
  advertPaymentByBalansHolder: props.advertPaymentByBalansHolder,
  startCompetitionBet: props.startCompetitionBet,
  minAuctionStep: props.minAuctionStep,

  address: props.address,
  phoneList: (props.phoneList || []).map((el) => el.guid),
  emailList: (props.emailList || []).map((el) => el.guid),

  leaseCompetitionsStatus: props.leaseCompetitionsStatus && props.leaseCompetitionsStatus.guid,

  competitionCancelReasonType: _get(props.competitionCancelReasonType, 'guid'),
  leaseCases: props.leaseCases && props.leaseCases.guid,
  leaseCompetition: props.leaseCompetition && props.leaseCompetition.guid,

  leaseCompetitionsReasonDocs: createDocumentValue(props.leaseCompetitionsReasonDocs),
  competitiorsForDirectNotice: createValue(props.competitiorsForDirectNotice),
});

export const parseToBE = (props) => ({
  leaseCompetitionsNumber: props.leaseCompetitionsNumber,
  addDescription: props.addDescription,
  execDateTime: props.execDateTime,

  addressNotes: props.addressNotes,
  endRecievDate: props.endRecievDate,
  advancePaymentSize: props.advancePaymentSize,
  advertPaymentByBalansHolder: props.advertPaymentByBalansHolder,
  startCompetitionBet: props.startCompetitionBet,
  minAuctionStep: props.minAuctionStep,

  address: props.address,
  phoneList: props.phoneList,
  emailList: props.emailList,

  competitionCancelReasonType: props.competitionCancelReasonType,
  leaseCompetitionsStatus: props.leaseCompetitionsStatus,
  leaseCases: props.leaseCases,
  leaseCompetition: props.leaseCompetition,

  leaseCompetitionsReasonDocs: props.leaseCompetitionsReasonDocs,
  competitiorsForDirectNotice: props.competitiorsForDirectNotice,

  // not implemented on BE
  bankDetails: undefined,
});

export const compReqListFields = {
  competitionRequrementType: {
    field: 'competitionRequrementType',
    name: 'Умова конкурсу',
    type: formItemTypes.SELECT,
    valuableFields: defaultValuableFields.concat('type'),
    classifier: classifiers.CL_COMPETION_REQUREMENT_TYPE,
  },
  compReqDescription: {
    field: 'compReqDescription',
    name: 'Опис вимог по умові',
    type: formItemTypes.INPUT,
  },
};

export const parseCompReqListToFE = (props) => ({
  competitionRequrementType: _get(props.competitionRequrementType, 'guid'),
  compReqDescription: props.compReqDescription,
});

export const parseCompReqListToBE = (props) => ({
  competitionRequrementType: props.competitionRequrementType,
  compReqDescription: props.compReqDescription,
});

export const competitionAdvertListsFields = {
  publicationResource: {
    field: 'publicationResource',
    name: 'Місце (ресурс) публікації',
    type: formItemTypes.MULTISELECT,
    valuableFields: defaultValuableFields,
    classifier: classifiers.REF_PUBLICATION_RESOURCE,
  },
  publicationResourcePeriodNumber: {
    field: 'publicationResourcePeriodNumber',
    name: 'Періодичний номер видання',
    type: formItemTypes.INPUT,
  },
  publicationDate: {
    field: 'publicationDate',
    name: 'Дата публікації',
    type: formItemTypes.DATEPICKER,
  },
  advertWebAddress: {
    field: 'advertWebAddress',
    name: 'Адреса оголошення',
    type: formItemTypes.INPUT,
  },
  // advertFile: { // TODO: add files
  //   field: 'advertFile',
  //   name: 'Файл з оголошенням',
  //   type: formItemTypes.FILE
  // },
};

export const parseCompetitionAdvertListsToFE = (props) => ({
  publicationResource: (props.publicationResource || []).map((el) => el.guid),
  publicationResourcePeriodNumber: props.publicationResourcePeriodNumber,
  publicationDate: getDate(props.publicationDate),
  advertWebAddress: props.advertWebAddress,
  // advertFile: // TODO: add files
});

export const parseCompetitionAdvertListsToBE = (props) => ({
  publicationResource: props.publicationResource,
  publicationResourcePeriodNumber: props.publicationResourcePeriodNumber,
  publicationDate: props.publicationDate,
  advertWebAddress: props.advertWebAddress,
  // advertFile: // TODO: add files
});

export const submitDocListFields = {
  documentType: {
    field: 'documentType',
    name: 'Назва документу',
    type: formItemTypes.MULTISELECT,
    valuableFields: defaultValuableFields.concat('type'),
    classifier: classifiers.DOCUMENT_TYPE,
  },
  docFilingForm: {
    field: 'docFilingForm',
    name: 'Форма подання',
    type: formItemTypes.SELECT,
    classifier: classifiers.DOC_FILLING_FORM,
  },
  docFilingPlace: {
    field: 'docFilingPlace',
    name: 'Місце подання',
    type: formItemTypes.INPUT,
  },
};

export const parseSubmitDocListToFE = (props) => ({
  documentType: (props.documentType || []).map((el) => el.guid),
  docFilingForm: props.docFilingForm,
  docFilingPlace: props.docFilingPlace,
});

export const parseSubmitDocListToBE = (props) => ({
  documentType: props.documentType,
  docFilingForm: props.docFilingForm,
  docFilingPlace: props.docFilingPlace,
});

export const memberOfCompCommissionFields = {
  counterpartyMember: {
    field: 'counterpartyMember',
    name: 'Контрагент член комісії',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    valuableFields: defaultValuableFields,
  },
  personMember: {
    field: 'personMember',
    name: 'Член комісії',
    type: formItemTypes.SELECT,
    counterpartyType: 'Person',
    classifier: classifiers.COUNTERPARTY,
    valuableFields: defaultValuableFields,
  },
  membersPosition: {
    field: 'membersPosition',
    name: 'Позиція члена комісії',
    type: formItemTypes.INPUT,
  },
};

export const parseMemberOfCompCommissionToFE = (props) => ({
  counterpartyMember: createValue(props.counterpartyMember),
  personMember: createValue(props.personMember),
  membersPosition: props.membersPosition,
});

export const parseMemberOfCompCommissionToBE = (props) => ({
  counterpartyMember: props.counterpartyMember,
  personMember: props.personMember,
  membersPosition: props.membersPosition,
});
