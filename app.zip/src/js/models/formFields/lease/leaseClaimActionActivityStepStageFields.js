import { message } from 'antd';
import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';
import { getDate } from '../../../helpers/formHelpers/formHelpers';
import { defaultFilterOption, getObjGuidAndVersionId } from '../../../helpers/commonUtils';

export const leaseClaimActionActivityStepStageFields = {
  stepStageDate: {
    field: 'stepStageDate',
    name: 'Дата етапу',
    type: formItemTypes.DATEPICKER,
    placeholder: 'дд.мм.рррр',
    rules: [{ required: true, message: 'Поле обов`язкове для вводу!' }],
  },
  claimActionActivityStepStage: {
    field: 'claimActionActivityStepStage',
    name: 'Етап заходу',
    type: formItemTypes.SELECT,
    classifier: classifiers.CLAIM_ACTION_ACTIVITY_STEP_STAGE,
    disabledOptionValue: 'INITIATION',
    placeholder: 'Оберіть тип етапу',
    rules: [{ required: true, message: 'Поле обов`язкове для вводу!' }],
  },
  generalInitialDebt: {
    field: 'generalInitialDebt',
    name: 'Загальна',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
  stepStageSumLease: {
    field: 'stepStageSumLease',
    name: 'По оренді',
    placeholder: '0',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вводу!' }],
  },
  stepStageSumFine: {
    field: 'stepStageSumFine',
    name: 'Штраф/Пеня',
    placeholder: '0',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вводу!' }],
  },
  sumOperation: {
    field: 'sumOperation',
    name: 'Операція з сумою по документу',
    placeholder: 'Оберіть тип операції',
    type: formItemTypes.SELECT,
    classifier: classifiers.CLAIM_ACTION_ACTIVITY_STEP_STAGE_SUM_OPERATION,
  },
  // reason: {
  //   field: 'reason',
  //   name: 'reason',
  //   placeholder: 'Введіть reason',
  //   type: formItemTypes.INPUT,
  // },
  periodYear: {
    field: 'periodYear',
    name: 'Рік',
    placeholder: 'Оберіть рік',
    type: formItemTypes.SELECT,
    classifier: classifiers.YEARS,
    filter: defaultFilterOption,
  },
  periodMonth: {
    field: 'periodMonth',
    placeholder: 'Оберіть місяць',
    name: 'Місяць',
    readOnly: true,
    type: formItemTypes.SELECT,
    classifier: classifiers.MONTH,
  },
};

export const parseToFe = (el) => ({
  stepStageDate: getDate(el.stepStageDate),
  generalInitialDebt: el.stepStageSumFine + el.stepStageSumLease,
  stepStageSumLease: el.stepStageSumLease,
  stepStageSumFine: el.stepStageSumFine,
  sumOperation: el.sumOperation,
  claimActionActivityStepStage: el.claimActionActivityStepStage,
  // reason: el.,
  periodYear: el.periodYear,
  periodMonth: el.periodMonth,
});

export const isBindedDocuments = (docArr) => {
  if (!Array.isArray(docArr) || docArr.length === 0) {
    message.error('Документи етапу є обов`язкові для вибору.');
    return { isBinded: false };
  }
  return {
    isBinded: true,
    documents: docArr.map((el) => getObjGuidAndVersionId(el.savedBEDto || el)),
  };
};
