import moment from 'moment';

import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';
import { createValueCreator } from '../../../helpers/formHelpers/dropdownValueCreators';
import { isRequired } from '../../../services/validator/rules';

const DATE_FORMAT_BE = 'YYYY-MM-DD HH:mm:ss.SSS Z';
const getDate = (data) => (data ? moment(data, DATE_FORMAT_BE) : null);
const createDocumentValue = createValueCreator('document');

const defaultValuableFields = ['guid', 'versionId'];

export const leaseCasesFields = {
  leaseCasesNumber: {
    field: 'leaseCasesNumber',
    name: 'Реєстраційний номер ОС',
    type: formItemTypes.INPUT,
    rules: [isRequired()],
  },
  // landlordObjectGuid: {
  //   field: 'landlordObjectGuid',
  //   name: 'Об\'єкт (поле будет удалено)',
  //   type: formItemTypes.SELECT,
  //   classifier: classifiers.LANDLORD_TO_OBJECTS,
  //   rules: [{ required: true, message: 'Обов\'язково для вводу!' }]
  // },
  caseDateFrom: {
    field: 'caseDateFrom',
    name: 'Дата відкриття справи',
    type: formItemTypes.DATEPICKER,
    rules: [isRequired()],
  },
  caseDateTo: {
    field: 'caseDateTo',
    name: 'Дата закриття справи',
    type: formItemTypes.DATEPICKER,
  },
  leaseCasesStatuses: {
    field: 'leaseCasesStatuses',
    name: 'Операційний стан справи',
    type: formItemTypes.MULTISELECT,
    valuableFields: defaultValuableFields.concat('type'),
    classifier: classifiers.LEASE_CASES_STATUS,
    rules: [isRequired()],
  },
  leaseObjectWoCompetDocs: {
    field: 'leaseObjectWoCompetDocs',
    name: 'Документи щодо передачі без конкурсу',
    type: formItemTypes.MULTISELECT,
    valuableFields: defaultValuableFields,
    classifier: classifiers.DOCUMENTS,
    colSpan: 24,
  },
  leaseObjectContractDocs: {
    field: 'leaseObjectContractDocs',
    name: 'Договорні документи щодо орендиу',
    type: formItemTypes.MULTISELECT,
    valuableFields: defaultValuableFields,
    classifier: classifiers.DOCUMENTS,
    colSpan: 24,
  },
  leaseObjectEvaluationDocs: {
    field: 'leaseObjectEvaluationDocs',
    name: "Документи про оцінку об'єкту оренди",
    type: formItemTypes.MULTISELECT,
    valuableFields: defaultValuableFields,
    classifier: classifiers.DOCUMENTS,
    colSpan: 24,
  },
  leaseObjectInsuranceDocs: {
    field: 'leaseObjectInsuranceDocs',
    name: "Документи про страхування об'єкту оренди",
    type: formItemTypes.MULTISELECT,
    valuableFields: defaultValuableFields,
    classifier: classifiers.DOCUMENTS,
    colSpan: 24,
  },
  leaseObjectSubLeaseDocs: {
    field: 'leaseObjectSubLeaseDocs',
    name: 'Документи щодо суборенди',
    type: formItemTypes.MULTISELECT,
    valuableFields: defaultValuableFields,
    classifier: classifiers.DOCUMENTS,
    colSpan: 24,
  },
  leaseObjectsImprovmentsDocs: {
    field: 'leaseObjectsImprovmentsDocs',
    name: "Документи щодо поліпшення об'єкту оренди",
    type: formItemTypes.MULTISELECT,
    valuableFields: defaultValuableFields,
    classifier: classifiers.DOCUMENTS,
    colSpan: 24,
  },
  leaseObjectControlDocs: {
    field: 'leaseObjectControlDocs',
    name: 'Документи щодо контролю процесу оренди',
    type: formItemTypes.MULTISELECT,
    valuableFields: defaultValuableFields,
    classifier: classifiers.DOCUMENTS,
    colSpan: 24,
  },
};

export const parseCasesToBE = (props) => ({
  caseDateTo: props.caseDateTo,
  caseDateFrom: props.caseDateFrom,
  leaseCasesNumber: props.leaseCasesNumber,
  leaseCasesStatuses: props.leaseCasesStatuses,

  leaseObjectWoCompetDocs: props.leaseObjectWoCompetDocs,
  leaseObjectContractDocs: props.leaseObjectContractDocs,
  leaseObjectEvaluationDocs: props.leaseObjectEvaluationDocs,
  leaseObjectInsuranceDocs: props.leaseObjectInsuranceDocs,
  leaseObjectSubLeaseDocs: props.leaseObjectSubLeaseDocs,
  leaseObjectsImprovmentsDocs: props.leaseObjectsImprovmentsDocs,
  leaseObjectControlDocs: props.leaseObjectControlDocs,
  // landlordObjectGuid: props.landlordObjectGuid
});

export const parseCasesToFE = (props) => ({
  caseDateTo: getDate(props.caseDateTo),
  caseDateFrom: getDate(props.caseDateFrom),
  leaseCasesNumber: props.leaseCasesNumber,

  leaseCasesStatuses: (props.leaseCasesStatuses || []).map(({ guid }) => guid),

  leaseObjectWoCompetDocs: createDocumentValue(props.leaseObjectWoCompetDocs),
  leaseObjectContractDocs: createDocumentValue(props.leaseObjectContractDocs),
  leaseObjectEvaluationDocs: createDocumentValue(props.leaseObjectEvaluationDocs),
  leaseObjectInsuranceDocs: createDocumentValue(props.leaseObjectInsuranceDocs),
  leaseObjectSubLeaseDocs: createDocumentValue(props.leaseObjectSubLeaseDocs),
  leaseObjectsImprovmentsDocs: createDocumentValue(props.leaseObjectsImprovmentsDocs),
  leaseObjectControlDocs: createDocumentValue(props.leaseObjectControlDocs),

  // landlordObjectGuid: props.landlordObjectGuid
});
