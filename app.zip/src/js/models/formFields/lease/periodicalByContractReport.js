import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';
import { createValueCreator } from '../../../helpers/formHelpers/dropdownValueCreators';
import { defaultFilterOption } from '../../../helpers/commonUtils';

const createDocumentValue = createValueCreator('document');
const createCounterpartyValue = createValueCreator('counterparty');
const required = { required: true, message: "Обов'язково для вводу!" };

const defaultValuableFields = ['guid', 'versionId'];

export const periodocialByContractReportFields = {
  balanceHolder: {
    field: 'balanceHolder',
    name: 'Балансоутримувач',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    valuableFields: defaultValuableFields,
    rules: [required],
  },
  leaseContract: {
    field: 'leaseContract',
    name: 'Договір оренди',
    type: formItemTypes.SELECT,
    classifier: classifiers.DOCUMENTS,
    valuableFields: defaultValuableFields,
    colSpan: 24,
    documentType: 'LeaseContract',
    rules: [required],
  },
  regNumber: {
    field: 'regNumber',
    name: 'Реєстраційний номер звіту',
    type: formItemTypes.INPUT,
    rules: [required],
  },
  periodYear: {
    field: 'periodYear',
    name: 'Звітний період: рік',
    type: formItemTypes.SELECT,
    classifier: classifiers.YEARS,
    filter: defaultFilterOption,
    rules: [required],
  },
  periodMonth: {
    field: 'periodMonth',
    name: 'Звітний період: місяць',
    type: formItemTypes.SELECT,
    classifier: classifiers.MONTH,
    rules: [required],
  },
  badDebtsValue: {
    field: 'badDebtsValue',
    name: 'Безнадійна заборгованість з ОП, без ПДВ, грн ',
    type: formItemTypes.INPUT,
    rules: [required],
  },
  potentialBadDebtsValue: {
    field: 'potentialBadDebtsValue',
    name: 'Потенційно-безнадійна заборгованість з ОП, без ПДВ, грн',
    type: formItemTypes.INPUT,
    rules: [required],
  },
  otherDebtsValue: {
    field: 'otherDebtsValue',
    name: 'Інша заборгованість з ОП, , без ПДВ, грн',
    type: formItemTypes.INPUT,
    rules: [required],
  },
  maintenanceCostDebtValue: {
    field: 'maintenanceCostDebtValue',
    name: 'Заборгованість в межах витрат на утримання, без ПДВ, гр',
    type: formItemTypes.INPUT,
    rules: [required],
  },
  debitedDebtsValue: {
    field: 'debitedDebtsValue',
    name: 'Списано забогованості з ОП, без ПДВ, грн',
    type: formItemTypes.INPUT,
    rules: [required],
  },
  courtAppealQuantity: {
    field: 'courtAppealQuantity',
    name: 'Кількість позовів до суду',
    type: formItemTypes.INPUT,
    rules: [required],
  },
  courtAppeals: {
    field: 'courtAppeals',
    name: 'Посилання на позови',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.DOCUMENTS,
    valuableFields: defaultValuableFields,
    colSpan: 24,
    rules: [{ required: false, message: '' }],
  },
  satisfactoryCourtAppealQuantity: {
    field: 'satisfactoryCourtAppealQuantity',
    name: 'Кількість задовільнених позовів до суду',
    type: formItemTypes.INPUT,
    rules: [required],
  },
  satisfactoryCourtAppeals: {
    field: 'satisfactoryCourtAppeals',
    name: 'Посилання на задовільнені позови',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.DOCUMENTS,
    valuableFields: defaultValuableFields,
    colSpan: 24,
    rules: [{ required: false, message: '' }],
  },
  enforcementQuantity: {
    field: 'enforcementQuantity',
    name: 'Кількість відкритих виконавчих впроваджень',
    type: formItemTypes.INPUT,
    rules: [required],
  },
  enforcements: {
    field: 'enforcements',
    name: 'Посилання на впровадження ',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.DOCUMENTS,
    valuableFields: defaultValuableFields,
    colSpan: 24,
    rules: [required],
  },
  enforcementRepaymentDebts: {
    field: 'enforcementRepaymentDebts',
    name: 'Погашено забогованості з викон. проваджень, без ПДВ, грн',
    type: formItemTypes.INPUT,
    rules: [required],
  },
  judicalProceedingTotalValue: {
    field: 'judicalProceedingTotalValue',
    name: 'Сума коштів - судове впровадження, без ПДВ, грн ',
    type: formItemTypes.INPUT,
    rules: [required],
  },
  enforcementTotalValue: {
    field: 'enforcementTotalValue',
    name: 'Сума коштів - виконавчі дії, без ПДВ, грн',
    type: formItemTypes.INPUT,
    rules: [required],
  },
  additionalInform: {
    field: 'additionalInform',
    name: 'Додаткова інформація',
    type: formItemTypes.TEXTAREA,
    rules: [required],
  },
};

export const parseToFE = (props) => ({
  balanceHolder: createCounterpartyValue(props.balanceHolder),
  leaseContract: createDocumentValue(props.leaseContract),
  regNumber: props.leasePeriodicalByContractlReportRegNum,
  periodYear: props.reportPeriodYear,
  periodMonth: props.reportPeriodMonth,
  badDebtsValue: props.badDebtsValue,
  potentialBadDebtsValue: props.potentialBadDebtsValue,
  otherDebtsValue: props.otherDebtsValue,
  maintenanceCostDebtValue: props.maintenanceCostDebtValue,
  debitedDebtsValue: props.debitedDebtsValue,
  courtAppealQuantity: props.courtAppealQuantity,
  courtAppeals: (props.courtAppeals || []).map((item) => createDocumentValue(item)),
  satisfactoryCourtAppealQuantity: props.satisfactoryCourtAppealQuantity,
  satisfactoryCourtAppeals: (props.satisfactoryCourtAppeals || []).map((item) =>
    createDocumentValue(item),
  ),
  enforcementQuantity: props.enforcementQuantity,
  enforcements: props.enforcements
    ? (props.enforcements || []).map((item) => createDocumentValue(item))
    : null,
  enforcementRepaymentDebts: props.enforcementRepaymentDebts,
  judicalProceedingTotalValue: props.judicalProceedingTotalValue,
  enforcementTotalValue: props.enforcementTotalValue,
  additionalInform: props.additionalInform,
});

export const parseToBE = (props) => ({
  balanceHolder: props.balanceHolder,
  leaseContract: props.leaseContract,
  leasePeriodicalByContractlReportRegNum: props.regNumber,
  reportPeriodYear: props.periodYear,
  reportPeriodMonth: props.periodMonth,
  badDebtsValue: props.badDebtsValue,
  potentialBadDebtsValue: props.potentialBadDebtsValue,
  otherDebtsValue: props.otherDebtsValue,
  maintenanceCostDebtValue: props.maintenanceCostDebtValue,
  debitedDebtsValue: props.debitedDebtsValue,
  courtAppealQuantity: props.courtAppealQuantity,
  courtAppeals: props.courtAppeals,
  satisfactoryCourtAppealQuantity: props.satisfactoryCourtAppealQuantity,
  satisfactoryCourtAppeals: props.satisfactoryCourtAppeals,
  enforcementQuantity: props.enforcementQuantity,
  enforcements: props.enforcements,
  enforcementRepaymentDebts: props.enforcementRepaymentDebts,
  judicalProceedingTotalValue: props.judicalProceedingTotalValue,
  enforcementTotalValue: props.enforcementTotalValue,
  additionalInform: props.additionalInform,
});
