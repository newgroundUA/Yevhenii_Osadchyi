import moment from 'moment';

import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';
import { createValueCreator } from '../../../helpers/formHelpers/dropdownValueCreators';
import { getGuidsArray } from '../../../helpers/formHelpers/formHelpers';
import { isRequired } from '../../../services/validator/rules';

const DATE_FORMAT_BE = 'YYYY-MM-DD HH:mm:ss.SSS Z';
const getDate = (data) => (data ? moment(data, DATE_FORMAT_BE) : null);
const createDocumentValue = createValueCreator('document');
const createCounterpatryValue = createValueCreator('counterparty');
const createObjectValue = createValueCreator('object');

const defaultValuableFields = ['guid', 'versionId'];

export const leaseObjectsFields = {
  leaseObjectNumber: {
    field: 'leaseObjectNumber',
    name: "Реєстровий номер об'єкту оренди",
    rules: [isRequired()],
    type: formItemTypes.INPUT,
    placeholder: "Введіть реєстровий номер об'єкту оренди",
  },
  leaseObjectFullName: {
    field: 'leaseObjectFullName',
    name: "Назва об'єкту оренди повна",
    rules: [isRequired()],
    type: formItemTypes.INPUT,
    placeholder: "Введіть повну назву об'єкту оренди",
  },
  leaseObjectShortName: {
    field: 'leaseObjectShortName',
    name: "Назва об'єкту оренди коротка",
    type: formItemTypes.INPUT,
    placeholder: "Введіть коротку назву об'єкту оренди",
  },
  leaseObjectTotalSpace: {
    field: 'leaseObjectTotalSpace',
    name: 'Загальна площа, кв. м.',
    type: formItemTypes.INPUT,
    placeholder: 'Введіть загальну площу, кв. м.',
  },
  leaseObjectUsefullSpace: {
    field: 'leaseObjectUsefullSpace',
    name: 'Загальна корисна площа, кв. м.',
    type: formItemTypes.INPUT,
    placeholder: 'Введіть загальну корисну площу, кв. м.',
  },
  leaseObjectCommonUsesSpace: {
    field: 'leaseObjectCommonUsesSpace',
    name: 'Площа приміщень загального користування, кв.м.',
    type: formItemTypes.INPUT,
    placeholder: 'Введіть площу приміщень загального користування, кв.м.',
  },
  objectInLeaseObject: {
    field: 'objectInLeaseObject',
    name: "Майновий об'єкт в складі об'єкту оренди",
    rules: [isRequired()],
    type: formItemTypes.MULTISELECT,
    valuableFields: defaultValuableFields,
    classifier: classifiers.OBJECTS,
    colSpan: 12,
  },
  leaseObjectAddress: {
    field: 'leaseObjectAddress',
    name: 'Адреса розташування',
    type: formItemTypes.SELECT,
    classifier: classifiers.OBJECT_ADDRESS,
    placeholder: 'Виберіть адресу розташування',
    valuableFields: defaultValuableFields,
    customRendered: true,
  },
};

export const parseLeaseObjectToBE = (props) => ({
  groupedObjectsType: 'LeaseObjects',
  leaseObjectNumber: props.leaseObjectNumber,
  leaseObjectCommonUsesSpace: props.leaseObjectCommonUsesSpace,
  leaseObjectFullName: props.leaseObjectFullName,
  leaseObjectShortName: props.leaseObjectShortName,
  leaseObjectTotalSpace: props.leaseObjectTotalSpace,
  leaseObjectUsefullSpace: props.leaseObjectUsefullSpace,
  leaseObjectAddress: props.leaseObjectAddress,
  objectInLeaseObject: props.objectInLeaseObject,
});

export const parseLeaseObjectToFE = (props) => ({
  leaseObjectNumber: props.leaseObjectNumber,
  leaseObjectCommonUsesSpace: props.leaseObjectCommonUsesSpace,
  leaseObjectFullName: props.leaseObjectFullName,
  leaseObjectShortName: props.leaseObjectShortName,
  leaseObjectTotalSpace: props.leaseObjectTotalSpace,
  leaseObjectUsefullSpace: props.leaseObjectUsefullSpace,
  leaseObjectAddress: props.leaseObjectAddress,
  objectInLeaseObject: createObjectValue(props.objectInLeaseObject),
});

export const landlordToObjectsFields = {
  landlord: {
    field: 'landlord',
    name: 'Орендодавець',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    valuableFields: defaultValuableFields,
    rules: [isRequired()],
    placeholder: 'Виберіть орендодавеця',
  },
  landlordLegalType: {
    field: 'landlordLegalType',
    name: 'Тип орендодавця',
    type: formItemTypes.SELECT,
    classifier: classifiers.LANDLORD_LEGAL_TYPE,
    valuableFields: defaultValuableFields.concat('type'),
    rules: [isRequired()],
    placeholder: 'Виберіть тип орендодавця',
  },
  leaseObjectType: {
    field: 'leaseObjectType',
    name: "Тип об'єкта оренди",
    type: formItemTypes.SELECT,
    classifier: classifiers.OBJECT_TYPE,
    valuableFields: defaultValuableFields.concat('type'),
    rules: [isRequired()],
    placeholder: "Виберіть тип об'єкту оренди",
  },
  dValidFrom: {
    field: 'dValidFrom',
    name: 'Діє з',
    rules: [isRequired()],
    type: formItemTypes.DATEPICKER,
  },
  dValidTill: {
    field: 'dValidTill',
    name: 'Діє по',
    type: formItemTypes.DATEPICKER,
  },
  reasonDocs: {
    field: 'reasonDocs',
    name: 'Документ підстава про включення до реєстру',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.DOCUMENTS,
    valuableFields: defaultValuableFields,
    rules: [isRequired()],
    colSpan: 24,
    placeholder: 'Виберіть документ підставу про включення до реєстру',
  },
  // plannedleasepurposeGUID: {
  //   field: 'plannedleasepurposeGUID',
  //   name: 'Планові призначення оренди',
  //   type: formItemTypes.SELECT,
  //   classifier: classifiers.LEASE_RATE_DIRECTORY,
  //   placeholder: 'Виберіть планові призначення оренди'
  // }
  leaseCases: {
    field: 'leaseCases',
    name: "Орендні справи по об'єкту",
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.LEASE_CASES,
    valuableFields: defaultValuableFields.concat([
      'landlordObject',
      'leaseCasesNumber',
      'caseDateFrom',
      'leaseCasesStatuses',
    ]),
    rules: [],
    placeholder: "Виберіть орендні справи по об'єкту",
  },
};

export const parseLandlordToBE = (props) => ({
  dValidFrom: props.dValidFrom,
  dValidTill: props.dValidTill,
  landlord: props.landlord,
  landlordLegalType: props.landlordLegalType,
  leaseObjectType: props.leaseObjectType,
  reasonDocs: props.reasonDocs,
  leaseCases: props.leaseCases,
});

export const parseLandlordToFE = (props) => ({
  dValidFrom: getDate(props.dValidFrom),
  dValidTill: getDate(props.dValidTill),

  reasonDocs: createDocumentValue(props.reasonDocs),
  landlord: createCounterpatryValue(props.landlord),

  leaseCases: getGuidsArray(props.leaseCases),
  leaseObjectType: (props.leaseObjectType || {}).guid,
  landlordLegalType: (props.landlordLegalType || {}).guid,
});
