import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';
import { createValueCreator } from '../../../helpers/formHelpers/dropdownValueCreators';
import { defaultFilterOption } from '../../../helpers/commonUtils';

const createDocumentValue = createValueCreator('document');
const createCounterpartyValue = createValueCreator('counterparty');
const required = { required: true, message: "Обов'язково для вводу!" };

const defaultValuableFields = ['guid', 'versionId'];

export const periodocialByBalanceHolderReportFields = {
  balanceHolder: {
    field: 'balanceHolder',
    name: 'Балансоутримувач',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    valuableFields: defaultValuableFields,
    rules: [required],
  },
  leasePeriodicalByBalanceHolderReportRegNum: {
    field: 'leasePeriodicalByBalanceHolderReportRegNum',
    name: 'Реєстраційний номер звіту',
    type: formItemTypes.INPUT,
    rules: [required],
  },
  reportPeriodYear: {
    field: 'reportPeriodYear',
    name: 'Звітний період: рік',
    type: formItemTypes.SELECT,
    classifier: classifiers.YEARS,
    filter: defaultFilterOption,
    rules: [required],
  },
  reportPeriodMonth: {
    field: 'reportPeriodMonth',
    name: 'Звітний період: місяць',
    type: formItemTypes.SELECT,
    classifier: classifiers.MONTH,
    rules: [required],
  },
  nopaymentReasons: {
    field: 'nopaymentReasons',
    name: 'Причини неперерахування коштів до бюджету',
    type: formItemTypes.TEXTAREA,
    rules: [{ required: false, message: '' }],
  },
  budgetDebtReasons: {
    field: 'budgetDebtReasons',
    name: 'Причини виникнення заборгованності перед бюджетом',
    type: formItemTypes.TEXTAREA,
    rules: [{ required: false, message: '' }],
  },
  measuresForDebtRepayment: {
    field: 'measuresForDebtRepayment',
    name: 'Вжиті заходи щодо погашення заборгованності ',
    type: formItemTypes.TEXTAREA,
    rules: [{ required: false, message: '' }],
  },
  reportsDocuments: {
    field: 'reportsDocuments',
    name: 'Звітні документи за період',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.DOCUMENTS,
    valuableFields: defaultValuableFields,
    colSpan: 24,
    rules: [{ required: false, message: '' }],
  },
  leaseToSubleasePaymentDifference: {
    field: 'leaseToSubleasePaymentDifference',
    name: 'Сплачена різниця між суборендою та орендною платою',
    type: formItemTypes.INPUT,
    rules: [{ required: false, message: '' }],
  },
};

export const parseToFE = (props) => ({
  balanceHolder: createCounterpartyValue(props.balanceHolder),
  leasePeriodicalByBalanceHolderReportRegNum: props.leasePeriodicalByBalanceHolderReportRegNum,
  reportPeriodYear: props.reportPeriodYear,
  reportPeriodMonth: props.reportPeriodMonth,
  nopaymentReasons: props.nopaymentReasons,
  budgetDebtReasons: props.budgetDebtReasons,
  measuresForDebtRepayment: props.measuresForDebtRepayment,
  reportsDocuments: (props.reportsDocuments || []).map((item) => createDocumentValue(item)),
  leaseToSubleasePaymentDifference: props.leaseToSubleasePaymentDifference,
});

export const parseToBE = (props) => ({
  balanceHolder: props.balanceHolder,
  leasePeriodicalByBalanceHolderReportRegNum: props.leasePeriodicalByBalanceHolderReportRegNum,
  reportPeriodYear: props.reportPeriodYear,
  reportPeriodMonth: props.reportPeriodMonth,
  nopaymentReasons: props.nopaymentReasons,
  budgetDebtReasons: props.budgetDebtReasons,
  measuresForDebtRepayment: props.measuresForDebtRepayment,
  reportsDocuments: props.reportsDocuments,
  leaseToSubleasePaymentDifference: props.leaseToSubleasePaymentDifference,
});
