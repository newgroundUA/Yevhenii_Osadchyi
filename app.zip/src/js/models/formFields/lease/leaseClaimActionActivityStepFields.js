import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';
import { selectFilter, getDate } from '../../../helpers/formHelpers/formHelpers';

const defaultValuableFields = ['guid', 'versionId'];

export const leaseClaimActionActivityStepFields = {
  claimActionActivityStepType: {
    field: 'claimActionActivityStepType',
    name: 'Тип заходу',
    type: formItemTypes.SELECT,
    classifier: classifiers.CL_CLAIM_ACTION_ACTIVITY_STEP_TYPE,
    readOnly: true,
  },
  stepStartDate: {
    field: 'stepStartDate',
    name: 'Дата початку заходу',
    type: formItemTypes.DATEPICKER,
    placeholder: 'дд.мм.рррр',
    rules: [{ required: true, message: 'Поле обов`язкове для вводу!' }],
  },
  legalAffairs: {
    field: 'legalAffairs',
    name: 'Посилання на юридичну справу',
    type: formItemTypes.SELECT,
    classifier: classifiers.LEGAL_AFFAIRS,
    filter: selectFilter,
    valuableFields: defaultValuableFields,
    readOnly: true,
  },
};

export const parseStepToFE = (el) => ({
  claimActionActivityStepType: '', // TODO: add mapping this field
  stepStartDate: getDate(el.stepStartDate),
  legalAffairs: (el.legalAffairs || {}).guid,
});

export const parseStepToBE = () => ({});
