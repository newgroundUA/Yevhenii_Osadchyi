import moment from 'moment';
import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';
import { createValueCreator } from '../../../helpers/formHelpers/dropdownValueCreators';
import { getDate } from '../../../helpers/formHelpers/formHelpers';

const createCounterpartyValue = createValueCreator('counterparty');

export const leaseClaimActionActivityCardGeneralFields = {
  regNum: {
    field: 'regNum',
    name: 'Реєстраційний номер картки',
    type: formItemTypes.SELECT,
  },
  serialAndNumber: {
    field: 'serialAndNumber',
    name: 'Серія та номер Договору оренди',
    type: formItemTypes.INPUT,
  },
  landlordRepresenter: {
    field: 'landlordRepresenter',
    name: 'Орендодавець',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
  },
  createdDate: {
    field: 'createdDate',
    name: 'Дата створення картки',
    type: formItemTypes.DATEPICKER,
  },
  docDate: {
    field: 'docDate',
    name: 'Дата Договору оренди',
    type: formItemTypes.DATEPICKER,
  },
  renter: {
    field: 'renter',
    name: 'Орендар',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
  },
  updatedDate: {
    field: 'updatedDate',
    name: 'Дата оновлення картки',
    type: formItemTypes.DATEPICKER,
  },
  statusType: {
    field: 'statusType',
    name: 'Стан ППД',
    defaultValue: 'NEW',
    type: formItemTypes.SELECT,
    classifier: classifiers.CLAIM_ACTION_ACTIVITY_STATUS,
  },
  balanceKeeperRepresenter: {
    field: 'balanceKeeperRepresenter',
    name: 'Балансоутримувач',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
  },
};

export const leaseClaimActionActivityCardInitialSumFields = {
  generalInitialDebt: {
    field: 'generalInitialDebt',
    name: 'Загальна',
    type: formItemTypes.INPUT,
  },
  initialDebtByLease: {
    field: 'initialDebtByLease',
    name: 'По оренді',
    type: formItemTypes.INPUT,
  },
  initialDebtByFine: {
    field: 'initialDebtByFine',
    name: 'Штраф/Пеня',
    type: formItemTypes.INPUT,
  },
};

export const leaseClaimActionActivityCardCurrentSumFields = {
  generalCurrentDebt: {
    field: 'generalCurrentDebt',
    name: 'Загальна',
    type: formItemTypes.INPUT,
  },
  currentDebtByLease: {
    field: 'currentDebtByLease',
    name: 'По оренді',
    type: formItemTypes.INPUT,
  },
  currentDebtByFine: {
    field: 'currentDebtByFine',
    name: 'Штраф/Пеня',
    type: formItemTypes.INPUT,
  },
};

export const parseCardToFE = ({
  regNum,
  statusType,
  leaseContract,
  initialDebtByLease,
  initialDebtByFine,
  currentDebtByLease,
  currentDebtByFine,
  createdDate,
  updatedDate,
}) => ({
  regNum,
  serialAndNumber: `${leaseContract.docSerialNumber} ${leaseContract.docNumber}`,
  landlordRepresenter: createCounterpartyValue(leaseContract.landlordRepresenter),
  createdDate: getDate(createdDate),
  docDate: getDate(leaseContract.dateFrom),
  renter: createCounterpartyValue(leaseContract.renter),
  updatedDate: moment(updatedDate),
  statusType,
  balanceKeeperRepresenter: createCounterpartyValue(leaseContract.balanceKeeper),
  generalInitialDebt: (initialDebtByLease + initialDebtByFine).toFixed(2),
  initialDebtByLease,
  initialDebtByFine,
  generalCurrentDebt: (currentDebtByLease + currentDebtByFine).toFixed(2),
  currentDebtByLease,
  currentDebtByFine,
});

export const claimActionActivityClassifiersFields = {
  classifierStep: {
    classifier: classifiers.CLAIM_ACTION_ACTIVITY_STEP,
  },
  classifierYears: {
    classifier: classifiers.YEARS, // Added for initial stepStage form step
  },
  classifierMonth: {
    classifier: classifiers.MONTH,
  },
  classifierStepStage: {
    classifier: classifiers.CLAIM_ACTION_ACTIVITY_STEP_STAGE,
  },
  classifierStepStageSumOperation: {
    classifier: classifiers.CLAIM_ACTION_ACTIVITY_STEP_STAGE_SUM_OPERATION,
  },
};
