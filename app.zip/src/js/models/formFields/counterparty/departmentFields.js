import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';

// const getGuidsArray = (arr) => (arr ? arr.map((item) => item.guid) : []);
const defaultValuableFields = ['guid', 'versionId'];

export const fields = {
  depfullname: {
    field: 'depfullname',
    name: 'Повна назва підрозділу',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  depshortname: {
    field: 'depshortname',
    name: 'Коротка назва підрозділу',
    type: formItemTypes.INPUT,
  },
  departmenttype: {
    field: 'departmenttype',
    name: 'Тип підрозділу',
    type: formItemTypes.SELECT,
    classifier: classifiers.DEPARTMENT_TYPE,
    valuableFields: [...defaultValuableFields, 'type'],
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  notes: {
    field: 'notes',
    name: 'Примітка',
    type: formItemTypes.TEXTAREA,
  },
  parentcontractor: {
    field: 'parentcontractor',
    name: 'Організація',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
  parentdep: {
    field: 'parentdep',
    name: 'Батьківський підрозділ',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
  phoneNumbers: {
    field: 'phoneNumbers',
    name: 'Номери телефонів',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.PHONELIST,
    valuableFields: defaultValuableFields,
    placeholder: 'Нічого не вибрано',
    rules: [{ required: false, message: '' }],
  },
  addresses: {
    field: 'addresses',
    customRendered: true,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
};

export const getMappedForm = (props) => ({
  name: props.depfullname,
  notes: props.notes,
  shortName: props.depshortname,
  refDepartmentType: props.departmenttype,
  phones: props.phoneNumbers || [],
  addresses: props.addresses || [],
});

export const getParsedForm = (props) => ({
  depfullname: props.name,
  notes: props.notes,
  depshortname: props.shortName,
  departmenttype: (props.refDepartmentType || {}).guid,
  phoneNumbers: props.phones ? props.phones.map((el) => el.guid) : [],
  addresses: props.addresses,
});
