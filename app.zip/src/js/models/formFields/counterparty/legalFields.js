import moment from 'moment';
import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';
import { EDRPOU } from '../../../constants/ValidationClasses';
import { selectFilter, getGuidsArray } from '../../../helpers/formHelpers/formHelpers';
import { createValueCreator } from '../../../helpers/formHelpers/dropdownValueCreators';
import { isRequired } from '../../../services/validator/rules';

const DATE_FORMAT_BE = 'YYYY-MM-DD HH:mm:ss.SSS Z';
const getDate = (data) => (data ? moment(data, DATE_FORMAT_BE) : null);
const createCounterpartyValue = createValueCreator('counterparty');

const defaultValuableFields = ['guid', 'versionId'];

const baseKved = {
  type: formItemTypes.KVED_LIVE_SEARCH_SELECT,
  placeholder: 'Введіть код або вид діяльності для пошуку',
  rules: [isRequired({ message: 'Виберіть вид діяльності за КВЕД!' })],
  valuableFields: [...defaultValuableFields, 'type'],
  colSpan: 12,
};

export const ownerShip = {
  field: 'ownerShip',
  name: 'Форма власності',
  type: formItemTypes.SELECT,
  classifier: classifiers.KFV,
  placeholder: 'Не вибрано',
  rules: [{ required: true, message: 'Виберіть форму власності!' }],
  valuableFields: defaultValuableFields,
};

export const formOfFunding = {
  field: 'formOfFunding',
  name: 'Форма фінансування',
  type: formItemTypes.SELECT,
  classifier: classifiers.FIN_SOURSE_TYPE,
  placeholder: 'Не вибрано',
  rules: [{ required: true, message: 'Виберіть форму фінансування!' }],
  valuableFields: defaultValuableFields,
};

export const legalFastFields = {
  edrpoy: {
    field: 'edrpoy',
    name: '№ ЄДРПОУ',
    type: formItemTypes.INPUT,
    rules: [
      { required: true, message: 'Поле обов`язкове для вибору!' },
      { len: 8, message: 'Повинно бути 8 цифр' },
    ],
    validations: [{ className: EDRPOU, instance: null }],
  },
  kopfg: {
    field: 'kopfg',
    name: 'Організаційно-правова форма господарювання (за КОПФГ)',
    type: formItemTypes.SELECT,
    classifier: classifiers.KOPFG,
    placeholder: 'Виберіть форму господарювання',
    rules: [{ required: true, message: 'Виберіть форму господарювання!' }],
    filter: selectFilter,
    valuableFields: [...defaultValuableFields, 'type'],
  },
  username: {
    field: 'username',
    name: 'Повна назва ЮО',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Назва повинна буди вказана!' }],
  },
};

export const formSubjectOfEconomy = {
  field: 'formSubjectOfEconomy',
  name: "Форма суб'єкту економіки",
  type: formItemTypes.SELECT,
  classifier: classifiers.SKOF,
  placeholder: 'Введіть код або вид діяльності для пошуку',
  rules: [],
  filter: selectFilter,
  valuableFields: defaultValuableFields,
};

export const typeBySKODY = {
  field: 'typeBySKODY',
  name: 'Орган державного управління',
  type: formItemTypes.SELECT,
  classifier: classifiers.SKODY,
  placeholder: 'Введіть код або назву органу управління для пошуку',
  valuableFields: defaultValuableFields,
};

export const legalEntityStatus = {
  field: 'legalEntityStatus',
  name: 'Статус юридичної особи',
  type: formItemTypes.RADIO,
  classifier: classifiers.YES_NO,
  rules: [{ required: true, message: 'Виберіть статус юридичної особи!' }],
};

export const syPablicGroup = {
  field: 'syPablicGroup',
  name: 'СУ громадського формування',
  type: formItemTypes.RADIO,
  classifier: classifiers.YES_NO,
  rules: [{ required: true, message: 'Виберіть СУ громадського формування!' }],
};

export const rateToBudget = {
  field: 'rateToBudget',
  name: 'Ставка відрахувань по бюджету (%)',
  type: formItemTypes.INPUT,
};

export const isModelStatut = {
  field: 'isModelStatut',
  name: 'Модельний статут',
  type: formItemTypes.RADIO,
  classifier: classifiers.YES_NO,
  rules: [{ required: true, message: 'Виберіть стан реєстрації ЮО!' }],
};

export const regRecNumber = {
  field: 'regRecNumber',
  name: 'Номер запису про реєстрацію',
  type: formItemTypes.INPUT,
};

export const stateTypeGUID = {
  field: 'stateTypeGUID',
  name: 'Стан реєстрації ЮО',
  type: formItemTypes.SELECT,
  classifier: classifiers.REGISTRATION_STATE,
  placeholder: 'Введіть стан реєстрації ЮО',
  rules: [{ required: true, message: 'Виберіть стан реєстрації ЮО!' }],
};

export const legalDataFields = {
  shortName: {
    field: 'shortName',
    name: 'Коротка назва організації',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Назва повинна буди вказана!' }],
  },
  formSubjectOfEconomy,
  rateToBudget,
  syPablicGroup,
  SY_PablicFormation: {
    field: 'SY_PablicFormation',
    name: 'СУ політичної партії',
    type: formItemTypes.RADIO,
    classifier: classifiers.YES_NO,
    rules: [{ required: true, message: 'Виберіть СУ політичної партії!' }],
  },
  legalEntityStatus,
  formOfFunding,
  ownerShip,
  typeBySKODY,
  controlEconomicManagement: {
    field: 'controlEconomicManagement',
    name: 'Орган господарського управління',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    valuableFields: defaultValuableFields,
  },
  areaManagement: {
    field: 'areaManagement',
    name: 'Сфера управління',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    valuableFields: defaultValuableFields,
  },
  headOrganization: {
    // ????
    field: 'headOrganization',
    name: 'Головуюча організація',
    type: formItemTypes.SELECT,
    counterpartyType: 'LegalEntity',
    classifier: classifiers.COUNTERPARTY,
    valuableFields: defaultValuableFields,
    placeholder: 'Почніть вписувати назву',
  },
  mainKved: {
    // same data source
    ...baseKved,
    field: 'mainKved',
    multiple: false,
    treeCheckable: false,
    name: 'Основний вид дільності (КВЕД)',
  },
  kveds: {
    // same data source
    ...baseKved,
    field: 'kveds',
    multiple: true,
    treeCheckable: true,
    name: 'Види діяльності (КВЕД)',
  },
};

export const legalRegistrationFields = {
  regDate: {
    // legalentityregdate
    field: 'regDate',
    name: 'Дата державної реєстрації',
    type: formItemTypes.DATEPICKER,
    rules: [{ required: false, message: 'Виберіть дату державної реєстрації!' }],
  },
  regRecDate: {
    field: 'regRecDate',
    name: 'Дата запису про реєстрацію',
    type: formItemTypes.DATEPICKER,
  },
  regRecNumber,
  statutCapital: {
    field: 'statutCapital',
    name: 'Розмір статутного капіталу (грн)',
    type: formItemTypes.INPUT,
  },
  closeDate: {
    field: 'closeDate',
    name: 'Дата ліквідації',
    type: formItemTypes.DATEPICKER,
  },
  isModelStatut,
  stateTypeGUID,

  statutCapitalFinishDate: {
    field: 'statutCapitalFinishDate',
    name: 'Дата закінчення формування статутного капіталу',
    type: formItemTypes.DATEPICKER,
  },
  controlDescription: {
    field: 'controlDescription',
    name: 'Відомості про органи управління',
    type: formItemTypes.TEXTAREA,
  },
};

export const getLegalShort = (props) => {
  const { edrpoy, kopfg, username } = props;
  return {
    edrpou: edrpoy,
    fullName: username,
    clKopfg: kopfg,
  };
};

export const getLegalFull = (props) => ({
  edrpou: props.edrpoy,
  fullName: props.username,
  clKopfg: props.kopfg,

  shortName: props.shortName,
  clFinSource: [props.formOfFunding],
  clSkof: props.formSubjectOfEconomy,

  entityLegalStatus: props.legalEntityStatus,
  clKfv: props.ownerShip,
  budgetDeductionRate: props.rateToBudget,
  partOfCivilFormation: props.SY_PablicFormation,
  partOfParty: props.syPablicGroup,
  mainKved: JSON.parse(props.mainKved.value),
  kveds: props.kveds.map((kved) => JSON.parse(kved.value)),
  clSkodu: props.typeBySKODY,
  controlEconomicManagement: props.controlEconomicManagement,
  areaManagement: props.areaManagement,
  parentLegalEntity: props.headOrganization, // [DKV-1579]
  dateFrom: props.regDate, // dateFrom or regDate
  dateTo: props.closeDate, // dateTo or closeDate
  regRecDate: props.regRecDate,
  regRecNumber: props.regRecNumber,
  controlDescription: props.controlDescription,
  isModelStatut: props.isModelStatut,
  statutCapital: props.statutCapital,
  statutCapitalFinishDate: props.statutCapitalFinishDate,
  statusOfStateRegistration: props.stateTypeGUID,
  phones: props.phoneNumbers || [],
  emailes: props.emailList || [],
  addresses: props.addresses || [],
  webSites: props.webSiteList || [],
});

export const getKvedLevelIds = (internalId) => {
  const [second, thirdAndForth = ''] = internalId.split('.');
  const third = thirdAndForth.length >= 1 ? thirdAndForth.split('')[0] : '';
  const forth = thirdAndForth.length === 2 ? thirdAndForth.split('')[1] : '';

  return { second, third, forth };
};

export const toKvedValueAndLabel = (kved) => ({
  value: JSON.stringify({
    guid: kved.guid,
    type: kved.type,
    versionId: kved.versionId,
  }),
  label: `${kved.internalId} ${kved.name}`,
});

export const mapTreeKvedsToArray = (kveds, result = []) => {
  kveds.forEach((kved) => {
    if (getKvedLevelIds(kved.internalId).third) {
      result.push(toKvedValueAndLabel(kved));
    }
    if (kved.childKveds) {
      mapTreeKvedsToArray(kved.childKveds, result);
    }
  });
  return result;
};
// to FE
export const parseLegal = (props) => ({
  username: props.fullName,
  edrpoy: props.edrpou,
  kopfg: props.clKopfg && props.clKopfg.guid,

  shortName: props.shortName,
  mainKved: props.mainKved && {
    value: JSON.stringify({
      guid: props.mainKved.guid,
      versionId: props.mainKved.versionId,
      type: props.mainKved.type,
    }),
    label: `${props.mainKved.internalId} ${props.mainKved.name}`,
  },
  kveds: mapTreeKvedsToArray(props.kveds),
  formSubjectOfEconomy: props.clSkof && props.clSkof.guid,
  typeBySKODY: props.clSkodu && props.clSkodu.guid,
  controlEconomicManagement: createCounterpartyValue(props.controlEconomicManagement),
  areaManagement: createCounterpartyValue(props.areaManagement),
  ownerShip: props.clKfv && props.clKfv.guid,
  rateToBudget: props.budgetDeductionRate,
  syPablicGroup: props.partOfParty,
  SY_PablicFormation: props.partOfCivilFormation,
  legalEntityStatus: props.entityLegalStatus,
  formOfFunding: props.clFinSource && props.clFinSource.length ? props.clFinSource[0].guid : null, // TODO: why? Because the BE is so pretty
  // homeOrganization: { value: undefined }
  headOrganization: createCounterpartyValue(props.parentLegalEntity),
  regDate: getDate(props.dateFrom),
  regRecDate: getDate(props.regRecDate),
  regRecNumber: props.regRecNumber,
  stateTypeGUID: props.statusOfStateRegistration,
  statutCapital: props.statutCapital,
  statutCapitalFinishDate: getDate(props.statutCapitalFinishDate),
  closeDate: getDate(props.dateTo),
  isModelStatut: props.isModelStatut,
  controlDescription: props.controlDescription,

  phoneNumbers: getGuidsArray(props.phones),
  addresses: props.addresses,
  emailList: getGuidsArray(props.emailes),
  webSiteList: getGuidsArray(props.webSites),
});
