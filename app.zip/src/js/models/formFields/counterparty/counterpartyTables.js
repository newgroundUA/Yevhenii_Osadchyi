export const organizationParent = [
  {
    title: 'Організація',
    dataIndex: 'name',
    key: 'name',
  },
  {
    title: 'Телефони',
    dataIndex: 'phones',
    key: 'phones',
  },
];

export const divisionParent = [
  {
    title: 'Назва',
    dataIndex: 'name',
    key: 'name',
  },
  {
    title: 'Коротка назва',
    dataIndex: 'shortName',
    key: 'shortName',
  },
  {
    title: 'Тип підрозділу',
    dataIndex: 'divisionType',
    key: 'divisionType',
  },
  {
    title: 'Батьківський підрозділ:',
    dataIndex: 'parentDepartment',
    key: 'parentDepartment',
  },
  {
    title: 'Телефони:',
    dataIndex: 'phones',
    key: 'phones',
  },
  {
    title: 'Адреси:',
    dataIndex: 'addresses',
    key: 'addresses',
  },
  {
    title: 'Примітка',
    dataIndex: 'notes',
    key: 'notes',
  },
];

export const divisionChildren = [
  {
    title: 'Назва',
    dataIndex: 'name',
    key: 'name',
  },
  {
    title: 'Коротка назва',
    dataIndex: 'shortName',
    key: 'shortName',
  },
  {
    title: 'Тип підрозділу',
    dataIndex: 'divisionType',
    key: 'divisionType',
  },
  {
    title: 'Батьківський підрозділ:',
    dataIndex: 'parentDepartment',
    key: 'parentDepartment',
  },
  {
    title: 'Телефони:',
    dataIndex: 'phones',
    key: 'phones',
  },
  {
    title: 'Адреси:',
    dataIndex: 'addresses',
    key: 'addresses',
  },
  {
    title: 'Примітка',
    dataIndex: 'notes',
    key: 'notes',
  },
];

export const positionParent = [
  {
    title: 'Тип посади',
    dataIndex: 'positionType',
    key: 'positionType',
  },
  {
    title: 'Повна назва посади',
    dataIndex: 'fullName',
    key: 'fullName',
  },
  {
    title: 'Коротка назва посади',
    dataIndex: 'shortName',
    key: 'shortName',
  },
  {
    title: 'Повна назва департаменту',
    dataIndex: 'departmentFullName',
    key: 'departmentFullName',
  },
  {
    title: 'Коротка назва департаменту',
    dataIndex: 'departmentShortName',
    key: 'departmentShortName',
  },
];

export const positionChildren = [
  {
    title: 'Тип посади',
    dataIndex: 'positionType',
    key: 'positionType',
  },
  {
    title: 'Повна назва посади',
    dataIndex: 'fullName',
    key: 'fullName',
  },
  {
    title: 'Коротка назва посади',
    dataIndex: 'shortName',
    key: 'shortName',
  },
  {
    title: 'Прізвище, ім’я, по-батькові',
    dataIndex: 'personName',
    key: 'personName',
  },
  {
    title: 'Телефони:',
    dataIndex: 'phones',
    key: 'phones',
  },
  {
    title: 'Адреса електронної пошти',
    dataIndex: 'email',
    key: 'email',
  },
  {
    title: 'Чи є користувачем ЄІС',
    dataIndex: 'eis',
    key: 'eis',
  },
  // {
  //   title: 'Перелік ролей, які має в ЄІС',
  //   dataIndex: 'eisRoles',
  //   key: 'eisRoles',
  // },
];

export const employeeChildren = [
  {
    title: 'Прізвище, ім’я, по-батькові',
    dataIndex: 'name',
    key: 'name',
  },
  {
    title: 'Номер телефону',
    dataIndex: 'phones',
    key: 'phones',
  },
  {
    title: 'Адреса електронної пошти',
    dataIndex: 'email',
    key: 'email',
  },
  {
    title: 'Чи є користувачем ЄІС',
    dataIndex: 'eis',
    key: 'eis',
  },
  {
    title: 'Перелік ролей, які має в ЄІС',
    dataIndex: 'eisRoles',
    key: 'eisRoles',
  },
];

export const employeeParent = [
  {
    title: 'Назва підрозділу',
    dataIndex: 'departmentFullName',
    key: 'departmentFullName',
  },
  {
    title: 'Тип посади',
    dataIndex: 'positionType',
    key: 'positionType',
  },
  {
    title: 'Повна назва посади',
    dataIndex: 'positionFullName',
    key: 'positionFullName',
  },
  {
    title: 'ПІБ працівника',
    dataIndex: 'name',
    key: 'name',
  },
  {
    title: 'Телефони',
    dataIndex: 'phones',
    key: 'phones',
  },
  {
    title: 'Адреса електронної пошти',
    dataIndex: 'email',
    key: 'email',
  },
];
