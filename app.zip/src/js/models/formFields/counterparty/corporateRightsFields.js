import moment from 'moment';
import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';
import { createValueCreator } from '../../../helpers/formHelpers/dropdownValueCreators';
import { isNumberWithTwoDecimal, isRequired } from '../../../services/validator/rules';
import { getCounterpartyString } from '../../../helpers/geters';

const DATE_FORMAT_BE = 'YYYY-MM-DD HH:mm:ss.SSS Z';
const getDate = (data) => (data ? moment(data, DATE_FORMAT_BE) : null);
const createValue = createValueCreator('counterparty');
const createDocumentsValue = createValueCreator('document');

export const structureFields = {
  shareCapital: {
    field: 'shareCapital',
    name: 'Статутний капітал, грн.',
    type: formItemTypes.INPUT,
  },
  shareParValue: {
    field: 'shareParValue',
    name: 'Номінальна вартість акції, грн.',
    type: formItemTypes.INPUT,
  },
  totalNumberOfShares: {
    field: 'totalNumberOfShares',
    name: 'Загальна кількість акцій, шт.',
    type: formItemTypes.INPUT,
  },
  shareMarketValue: {
    field: 'shareMarketValue',
    name: 'Ринкова вартість акції, грн.',
    type: formItemTypes.INPUT,
    rules: [isNumberWithTwoDecimal()],
  },
  sharesFormType: {
    field: 'sharesFormType',
    name: 'Форма існування акцій',
    type: formItemTypes.SELECT,
    classifier: classifiers.SHARES_FORM_TYPE,
    placeholder: 'Не вибрано',
    rules: [isRequired()],
  },
  totalEnterprisePrice: {
    field: 'totalEnterprisePrice',
    name: 'Ринкова вартість підприємства, грн.',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
};

export const ownersFields = {
  participant: {
    field: 'participant',
    name: 'Учасник підприємства',
    type: formItemTypes.SELECT,
    rules: [isRequired()],
    customRendered: true,
  },
  stocksQuantity: {
    field: 'stocksQuantity',
    name: 'Кількість акцій учасника, шт.',
    type: formItemTypes.INPUT,
  },
  percentOfShare: {
    field: 'percentOfShare',
    name: 'Частка учасника, %',
    type: formItemTypes.INPUT,
  },
  shareSize: {
    field: 'shareSize',
    name: 'Вартість частки учасника, грн.',
    type: formItemTypes.INPUT,
  },
  shareCapital: {
    field: 'shareCapital',
    name: "Статутний капітал об'єкту корпоративної власності",
    type: formItemTypes.INPUT,
  },
  isFounder: {
    field: 'isFounder',
    name: 'Є засновником',
    type: formItemTypes.INPUT,
  },
  shareParValue: {
    field: 'shareParValue',
    name: "Номінальна вартість акцій об'єкту корпоративної власності, грн.",
    type: formItemTypes.INPUT,
  },
  // sharesFormType: {
  //   field: 'sharesFormType',
  //   name: "Форма існування акцій об'єкту корпоративної власності",
  //   type: formItemTypes.SELECT,
  //   classifier: classifiers.SHARES_FORM_TYPE,
  //   placeholder: 'Не вибрано',
  //   rules: [isRequired()],
  // },
  statusOfStateRegistration: {
    field: 'statusOfStateRegistration',
    name: "Стан реєстрації об'єкту корп власності",
    type: formItemTypes.SELECT,
    classifier: classifiers.REGISTRATION_STATE,
    placeholder: 'Не вибрано',
    rules: [isRequired()],
  },
  mainKved: {
    field: 'mainKved',
    name: "Основний КВЕД об'єкту корпоративної власності",
    type: formItemTypes.INPUT,
  },
};

export const movementsFields = {
  corporateRightsMovementDate: {
    field: 'corporateRightsMovementDate',
    name: 'Дата операції',
    type: formItemTypes.DATEPICKER,
    rules: [isRequired()],
  },
  corporateRightsMovementRegNumber: {
    field: 'corporateRightsMovementRegNumber',
    name: 'Реєстровий номер операції',
    type: formItemTypes.INPUT,
    rules: [isRequired()],
  },
  shareReceiver: {
    field: 'shareReceiver',
    name: 'Учасник отримувач',
    type: formItemTypes.SELECT,
    rules: [isRequired()],
    customRendered: true,
  },
  shareSender: {
    field: 'shareSender',
    name: 'Учасник передавач',
    type: formItemTypes.MULTISELECT,
    customRendered: true,
  },
  corporateRightsOperationType: {
    field: 'corporateRightsOperationType',
    name: 'Тип правової операції',
    type: formItemTypes.SELECT,
    classifier: classifiers.CORPORATE_RIGHTS_OPERATION_TYPE,
    rules: [isRequired()],
  },
  stocksQuantity: {
    field: 'stocksQuantity',
    name: 'Кількість акцій, шт.',
    type: formItemTypes.INPUT,
  },
  stocksPrice: {
    field: 'stocksPrice',
    name: 'Вартість акції, грн.',
    type: formItemTypes.INPUT,
  },
  stocksType: {
    field: 'stocksType',
    name: 'Тип акцій',
    type: formItemTypes.SELECT,
    classifier: classifiers.STOCKS_TYPE,
  },
  shareSizeInOperationFact: {
    field: 'shareSizeInOperationFact',
    name: 'Розмір частки у СК фактичний, грн.',
    type: formItemTypes.INPUT,
    rules: [isRequired()],
  },
  shareSizeInOperationPlan: {
    field: 'shareSizeInOperationPlan',
    name: 'Розмір частки у СК за планом, грн.',
    type: formItemTypes.INPUT,
  },
  operationMethodType: {
    field: 'operationMethodType',
    name: 'Метод проведення операції',
    type: formItemTypes.SELECT,
    classifier: classifiers.OPERATION_METHOD_TYPE,
  },
  corporateRightsMovementDocs: {
    field: 'corporateRightsMovementDocs',
    name: 'Документ щодо операції',
    type: formItemTypes.MULTISELECT,
    customRendered: true,
  },
  moneySendersInOperation: {
    field: 'moneySendersInOperation',
    name: 'Платник коштів по операції',
    type: formItemTypes.MULTISELECT,
    customRendered: true,
  },
  moneyReceiversInOperation: {
    field: 'moneyReceiversInOperation',
    name: 'Одержувач коштів по операції',
    type: formItemTypes.MULTISELECT,
    customRendered: true,
  },
  paymentDocs: {
    field: 'paymentDocs',
    name: 'Документ про оплату по операції',
    type: formItemTypes.MULTISELECT,
    customRendered: true,
  },
};

// structure
export const getMappedStructure = ({ totalEnterprisePrice, ...other }) => other;

export const getParsedStructure = (props) => {
  const totalEnterprisePrice = Number(props.totalNumberOfShares) * Number(props.shareMarketValue);
  return {
    ...props,
    totalEnterprisePrice: totalEnterprisePrice || undefined,
  };
};

// owners
export const getParsedOwners = (props) => ({
  participant: `${getCounterpartyString(props.corporateRightsOwner)}, ${props.corporateRightsOwner
    .itn ||
    props.corporateRightsOwner.edrpou ||
    ''}`,
  isFounder: props.isFounder ? 'Так' : 'Ні',
  shareSize: props.shareSize,
  percentOfShare: props.percentShareSize ? Math.round(props.percentShareSize * 100) / 100 : '',
  shareCapital: props.shareCapital,
  shareParValue: props.shareParValue,
  stocksQuantity: props.stocksQuantity,
  // sharesFormType: props.sharesFormType,
  statusOfStateRegistration: props.statusOfStateRegistration,
  mainKved: props.mainKvedActivity && props.mainKvedActivity.name,
});

// movements
export const getMappedMovements = (props) => {
  const getGuidAndVersionId = (key) => {
    try {
      const parsed = JSON.parse(key);
      return { guid: parsed.guid, versionId: parsed.versionId };
    } catch (e) {
      return { guid: key };
    }
  };
  return {
    corporateRightsMovementRegNumber: props.corporateRightsMovementRegNumber,
    corporateRightsOperationType: props.corporateRightsOperationType,
    corporateRightsMovementDate: props.corporateRightsMovementDate,
    moneyReceiversInOperation: props.moneyReceiversInOperation
      ? (props.moneyReceiversInOperation || []).map((c) => getGuidAndVersionId(c.key))
      : undefined,
    moneySendersInOperation: props.moneySendersInOperation
      ? (props.moneySendersInOperation || []).map((c) => getGuidAndVersionId(c.key))
      : undefined,
    operationMethodType: props.operationMethodType,
    shareReceiver: props.shareReceiver && getGuidAndVersionId(props.shareReceiver.key),
    shareSender: props.shareSender && getGuidAndVersionId(props.shareSender.key),
    shareSizeInOperationFact: props.shareSizeInOperationFact
      ? Number(props.shareSizeInOperationFact)
      : undefined,
    shareSizeInOperationPlan: props.shareSizeInOperationPlan
      ? Number(props.shareSizeInOperationPlan)
      : undefined,
    paymentDocs: props.paymentDocs
      ? (props.paymentDocs || []).map((c) => getGuidAndVersionId(c.key))
      : undefined,
    stocksType: props.stocksType,
    stocksQuantity: props.stocksQuantity ? Number(props.stocksQuantity) : undefined,
    stocksPrice: props.stocksPrice ? Number(props.stocksPrice) : undefined,
    corporateRightsMovementDocs: props.corporateRightsMovementDocs
      ? (props.corporateRightsMovementDocs || []).map((c) => getGuidAndVersionId(c.key))
      : undefined,
  };
};

export const getParsedMovements = (props) => ({
  corporateRightsMovementRegNumber: props.corporateRightsMovementRegNumber,
  corporateRightsOperationType: props.corporateRightsOperationType,
  corporateRightsMovementDate:
    props.corporateRightsMovementDate && getDate(props.corporateRightsMovementDate),
  moneyReceiversInOperation: createValue(props.moneyReceiversInOperation),
  moneySendersInOperation: createValue(props.moneySendersInOperation),
  operationMethodType: props.operationMethodType,
  shareReceiver: createValue(props.shareReceiver || props.shareReceiver),
  shareSender: createValue(props.shareSender || props.shareSender),
  shareSizeInOperationFact: props.shareSizeInOperationFact,
  stocksType: props.stocksType,
  stocksQuantity: props.stocksQuantity,
  stocksPrice: props.stocksPrice,
  shareSizeInOperationPlan: props.shareSizeInOperationPlan,
  corporateRightsMovementDocs: createDocumentsValue(props.corporateRightsMovementDocs),
});
