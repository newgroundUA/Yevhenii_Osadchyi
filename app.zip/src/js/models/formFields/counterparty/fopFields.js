import moment from 'moment';
import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';
import { isRequired } from '../../../services/validator/rules';
import { mapTreeKvedsToArray } from './legalFields';

const DATE_FORMAT_BE = 'YYYY-MM-DD HH:mm:ss.SSS Z';
const getDate = (data) => (data ? moment(data, DATE_FORMAT_BE) : null);
// const getGuidsArray = (arr) => (arr ? arr.map((item) => item.guid) : []);

const defaultValuableFields = ['guid', 'versionId'];

export const kopfg = {
  field: 'kopfg',
  name: 'Форма господарювання',
  type: formItemTypes.SELECT,
  classifier: classifiers.KOPFG,
  placeholder: 'Нічого не вибрано',
  rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  valuableFields: defaultValuableFields,
};

const baseKved = {
  type: formItemTypes.KVED_LIVE_SEARCH_SELECT,
  placeholder: 'Введіть код або вид діяльності для пошуку',
  rules: [
    isRequired({
      message: 'Виберіть вид діяльності за КВЕД!',
    }),
  ],
  valuableFields: [...defaultValuableFields, 'type'],
  colSpan: 12,
};

export const mainKved = {
  // same data source
  ...baseKved,
  field: 'mainKved',
  multiple: false,
  treeCheckable: false,
  name: 'Основний вид дільності (КВЕД)',
};

export const fopDataFOPFields = {
  mainKved,
  kveds: {
    // same data source
    ...baseKved,
    field: 'kveds',
    multiple: true,
    treeCheckable: true,
    name: 'Види діяльності (КВЕД)',
  },
  economic: {
    field: 'economic',
    name: "Форма суб'єкту економіки",
    type: formItemTypes.SELECT,
    classifier: classifiers.SKOF,
    placeholder: 'Нічого не вибрано',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
    valuableFields: defaultValuableFields,
  },
  kopfg,
  fin: {
    field: 'fin',
    name: 'Форма фінансування',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.FIN_SOURSE_TYPE,
    placeholder: 'Нічого не вибрано',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
    valuableFields: defaultValuableFields,
  },
};

export const fopRegistrationDataFields = {
  registrationDate: {
    field: 'registrationDate',
    name: 'Дата державної реєстрації',
    type: formItemTypes.DATEPICKER,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  closeDate: {
    field: 'closeDate',
    name: 'Дата ліквідації',
    type: formItemTypes.DATEPICKER,
    rules: [{ required: false, message: '' }],
  },
  registrationNoteDate: {
    field: 'registrationNoteDate',
    name: 'Дата запису про реєстрацію',
    type: formItemTypes.DATEPICKER,
    rules: [{ required: false, message: '' }],
  },
  registrationNoteNumber: {
    field: 'registrationNoteNumber',
    name: 'Номер запису про реєстрацію',
    type: formItemTypes.INPUT,
    rules: [{ required: false, message: '' }],
  },
  legalState: {
    field: 'legalState',
    name: 'Стан реєстрації ЮО',
    type: formItemTypes.SELECT,
    classifier: classifiers.REGISTRATION_STATE,
    placeholder: 'Нічого не вибрано',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  isModelStatut: {
    field: 'isModelStatut',
    name: 'Модельний статут',
    type: formItemTypes.RADIO,
    classifier: classifiers.IS_MODEL_STATUT,
    placeholder: 'Нічого не вибрано',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  managementNotes: {
    field: 'managementNotes',
    name: 'Відомості про органи управління',
    type: formItemTypes.TEXTAREA,
    // classifier: classifiers.MODEL_STATUT,
    // placeholder: 'Нічого не вибрано',
    rules: [{ required: false, message: '' }],
  },
};

export const getFopBEFields = (props) => ({
  addresses: props.foData.addresses,
  emailes: props.foData.emailes,
  phones: props.foData.phones,
  webSites: props.foData.webSites,
  documents: props.foData.documents,
  files: props.foData.files,
  mainKved: JSON.parse(props.mainKved.value),
  kveds: props.kveds.map((kved) => JSON.parse(kved.value)),
  clSkof: props.economic,
  clKopfg: props.kopfg,
  clFinSources: props.fin,

  personDto: props.foData,
  isModelStatut: props.isModelStatut,
  controlDescription: props.managementNotes,
  regRecordNumber: props.registrationNoteNumber,
  regRecordDate: props.registrationNoteDate,
  dateFrom: props.registrationDate,
  dateTo: props.closeDate,
  statusOfStateRegistration: props.legalState,
});

export const parseFop = (props) => ({
  mainKved: props.mainKved && {
    value: JSON.stringify({
      guid: props.mainKved.guid,
      versionId: props.mainKved.versionId,
      type: props.mainKved.type,
    }),
    label: `${props.mainKved.internalId} ${props.mainKved.name}`,
  },
  kveds: mapTreeKvedsToArray(props.kveds),
  economic: props.clSkof && props.clSkof.guid,
  kopfg: props.clKopfg && props.clKopfg.guid,
  fin: (props.clFinSources || []).map((item) => item.guid),
  registrationDate: getDate(props.dateFrom),
  closeDate: getDate(props.dateTo),
  registrationNoteDate: getDate(props.regRecordDate),
  registrationNoteNumber: props.regRecordNumber,
  legalState: props.statusOfStateRegistration,
  isModelStatut: props.isModelStatut,
  managementNotes: props.controlDescription,
});
