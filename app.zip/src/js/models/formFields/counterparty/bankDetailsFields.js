import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';
import { isRequired, isNumberLengthBetween } from '../../../services/validator/rules';
import { selectFilter } from '../../../helpers/formHelpers/formHelpers';

export const bankDetailsFields = {
  action: {
    title: 'Дія',
    dataIndex: '',
  },
  mfo: {
    field: 'mfo',
    title: 'МФО',
    dataIndex: 'mfo',
    type: formItemTypes.SELECT,
    classifier: classifiers.BANKS,
    filter: selectFilter,
    rules: [isRequired()],
  },
  bankName: {
    title: 'Назва банку',
    dataIndex: 'bankName',
  },
  account: {
    field: 'account',
    title: 'Номер рахунку',
    dataIndex: 'account',
    type: formItemTypes.INPUT,
    rules: [isRequired(), isNumberLengthBetween(5, 30)],
  },
  name: {
    field: 'name',
    title: 'Назва/ПІБ контрагента',
    dataIndex: 'name',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
  edrpou: {
    field: 'edrpou',
    title: 'ЄДРПОУ/ІПН',
    dataIndex: 'edrpou',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
  notes: {
    field: 'notes',
    title: 'Примітки',
    dataIndex: 'notes',
    type: formItemTypes.TEXTAREA,
  },
};
