import moment from 'moment';

import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';

const DATE_FORMAT_BE = 'YYYY-MM-DD HH:mm:ss.SSS Z';
const getDate = (data) => (data ? moment(data, DATE_FORMAT_BE) : null);
const defaultValuableFields = ['guid', 'versionId'];

export const fields = {
  fullname: {
    field: 'fullname',
    name: 'Назва посади повна',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  shortname: {
    field: 'shortname',
    name: 'Назва посади коротка',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  positionType: {
    field: 'positionType',
    name: 'Тип посади',
    type: formItemTypes.SELECT,
    classifier: classifiers.POST,
    valuableFields: defaultValuableFields.concat('type'),
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  positionqty: {
    field: 'positionqty',
    name: 'Кількість посад',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  validFrom: {
    field: 'validFrom',
    name: 'Діє з',
    type: formItemTypes.DATEPICKER,
  },
  validTill: {
    field: 'validTill',
    name: 'Діє по',
    type: formItemTypes.DATEPICKER,
  },
  notes: {
    field: 'notes',
    name: 'Примітка',
    type: formItemTypes.TEXTAREA,
  },
  parentdep: {
    field: 'parentdep',
    name: 'Підрозділ',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
};

export const getMappedForm = (props) => ({
  positionName: props.fullname,
  positionShortName: props.shortname,
  validFrom: props.validFrom,
  validTill: props.validTill,
  positionType: props.positionType,
  notes: props.notes,
  positionQty: props.positionqty || 1,
});

export const getParsedForm = (props) => ({
  fullname: props.positionName,
  shortname: props.positionShortName,
  validFrom: getDate(props.validFrom),
  validTill: getDate(props.validTill),
  positionType: (props.positionType || {}).guid,
  notes: props.notes,
  positionqty: props.positionQty,
});
