import * as formItemTypes from '../../../constants/FormItemTypes';
import { createValueCreator } from '../../../helpers/formHelpers/dropdownValueCreators';
import * as classifiers from '../../../constants/ClassifiersNames';

const createValue = createValueCreator('counterparty');

const defaultValuableFields = ['guid', 'versionId'];

export const fields = {
  position: {
    field: 'position',
    name: 'Посада',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
  contractor: {
    field: 'contractor',
    name: 'Персона',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    counterpartyType: 'Person',
    valuableFields: defaultValuableFields,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
};

export const getMappedForm = (props) => ({
  person: props.contractor,
});

export const getParsedForm = (props) => ({
  contractor: createValue(props.person),
});
