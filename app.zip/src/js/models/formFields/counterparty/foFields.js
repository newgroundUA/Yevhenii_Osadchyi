import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';
import { IPN } from '../../../constants/ValidationClasses';
import { getGuidsArray, getDate } from '../../../helpers/formHelpers/formHelpers';

const defaultValuableFields = ['guid', 'versionId'];

export const foMainFields = {
  lastName: {
    field: 'lastName',
    name: 'Прізвище',
    type: formItemTypes.SEARCH_BOX,
    mode: 'combobox',
    optionFilterProp: 'children',
    rules: [{ required: true, message: 'Поле обов`язкове для заповнення!' }],
  },
  firstName: {
    field: 'firstName',
    name: "Ім'я",
    type: formItemTypes.SEARCH_BOX,
    optionFilterProp: 'children',
    mode: 'combobox',
    rules: [{ required: true, message: 'Поле обов`язкове для заповнення!' }],
  },
  middleName: {
    field: 'middleName',
    name: 'По-батькові',
    type: formItemTypes.SEARCH_BOX,
    optionFilterProp: 'children',
    mode: 'combobox',
    rules: [{ required: false, message: '' }],
  },
  shortName: {
    field: 'shortName',
    name: 'П.І.Б. скорочено',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Назва повинна буди вказана!' }],
  },
  formOfAddresses: {
    field: 'formOfAddresses',
    name: 'Звернення',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.PERSON_ADDRESSING,
    valuableFields: defaultValuableFields.concat('type'),
    rules: [{ required: false, message: '' }],
  },
  personType: {
    field: 'personType',
    name: 'Тип особи',
    type: formItemTypes.RADIO,
    classifier: classifiers.PERSON_TYPE_ENUM_ON_FE,
    defaultValue: 'REGULAR',
    rules: [{ required: false, message: 'Назва повинна буди вказана!' }],
  },
  IPN: {
    field: 'IPN',
    name: 'ІПН',
    type: formItemTypes.INPUT,
    readOnly: false,
    rules: [
      { len: 10, message: 'Повинно бути 10 цифр' },
      { required: true, message: 'Поле обов`язкове для вибору!' },
    ],
    validations: [{ className: IPN, instance: null }],
  },
  birthDate: {
    field: 'birthDate',
    name: 'Дата народження',
    type: formItemTypes.DATEPICKER,
    rules: [{ required: false, message: '' }],
  },
  deathDate: {
    field: 'deathDate',
    name: 'Дата смерті',
    type: formItemTypes.DATEPICKER,
    rules: [{ required: false, message: '' }],
  },
};

export const foContactFields = {
  phoneNumbers: {
    field: 'phoneNumbers',
    name: 'Номери телефонів',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.PHONELIST,
    placeholder: 'Нічого не вибрано',
    rules: [{ required: false, message: '' }],
    valuableFields: defaultValuableFields,
  },
  emailList: {
    field: 'emailList',
    name: 'Електронні адреси',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.EMAILLIST,
    placeholder: 'Нічого не вибрано',
    rules: [{ required: false, message: '' }],
    valuableFields: defaultValuableFields,
  },
  webSiteList: {
    field: 'webSiteList',
    name: 'Сайти',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.WEBSITELIST,
    placeholder: 'Нічого не вибрано',
    rules: [{ required: false, message: '' }],
    valuableFields: defaultValuableFields,
  },
  addresses: {
    field: 'addresses',
    customRendered: true,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
};

// INFO: Work for post or put to server side
export const getFoShort = (props) => ({
  addresses: props.addresses || [],
  passports: [],
  fistName: props.firstName,
  lastName: props.lastName,
  middleName: props.middleName,
  shortOfficeName: props.shortName,
  dateFrom: props.birthDate,
  dateTo: props.deathDate,
  formOfAddresses: props.formOfAddresses,
  // look at https://ucplatform.atlassian.net/browse/DKV-1465
  personType: props.personType,
  itn: props.personType === 'REGULAR' ? props.IPN : null,
});

export const getFoFull = (props) => ({
  passports: [],
  fistName: props.firstName,
  lastName: props.lastName,
  middleName: props.middleName,
  shortOfficeName: props.shortName,
  dateFrom: props.birthDate,
  dateTo: props.deathDate,
  // look at https://ucplatform.atlassian.net/browse/DKV-1465
  personType: props.personType,
  itn: props.personType === 'REGULAR' ? props.IPN : null,
  formOfAddresses: props.formOfAddresses,
  phones: props.phoneNumbers || [],
  emailes: props.emailList || [],
  addresses: props.addresses || [],
  webSites: props.webSiteList || [],
});

export const parseFo = (props) => ({
  lastName: props.lastName,
  firstName: props.fistName,
  middleName: props.middleName,
  shortName: props.shortOfficeName,
  IPN: props.itn,
  formOfAddresses: (props.formOfAddresses || []).map((item) => item.guid),
  personType: props.personType,
  birthDate: getDate(props.dateFrom),
  deathDate: getDate(props.dateTo),
  phoneNumbers: getGuidsArray(props.phones),
  addresses: props.addresses,
  emailList: getGuidsArray(props.emailes),
  webSiteList: getGuidsArray(props.webSites),
});
