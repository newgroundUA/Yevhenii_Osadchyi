import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';

import {
  getMappedForm as getMappedGeneral,
  getParsedForm as getParsedGeneral,
} from './generalFields';

export const electricityFields = {
  // eslint-disable-line import/prefer-default-export
  cableElectricityPurpose: {
    field: 'cableElectricityPurpose',
    name: 'Призначення електрокомунікації',
    type: formItemTypes.SELECT,
    classifier: classifiers.CL_CABLE_ELECTRICITY_PURPOSE,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  cableVoltage: {
    field: 'cableVoltage',
    name: 'Робоча напруга, В"',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для заповнення!' }],
  },
  cableLenght: {
    field: 'cableLenght',
    name: 'Довжина, м',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для заповнення!' }],
  },
  cableDiameter: {
    field: 'cableDiameter',
    name: 'Діаметр носія, м',
    type: formItemTypes.INPUT,
    rules: [{ required: false, message: '' }],
  },
  cableClassifier: {
    field: 'cableClassifier',
    name: 'Марка проводу',
    type: formItemTypes.SELECT,
    classifier: classifiers.CL_CABLE_CLASSIFIER,
    rules: [{ required: false, message: '' }],
  },
  cableHeight: {
    field: 'cableHeight',
    name: 'Висота зовнішнього монтажу, м',
    type: formItemTypes.INPUT,
    rules: [{ required: false, message: '' }],
  },
  cablePillarQty: {
    field: 'cablePillarQty',
    name: 'К   ількість опор',
    type: formItemTypes.INPUT,
    rules: [{ required: false, message: '' }],
  },
  cablePillarMaterial: {
    field: 'cablePillarMaterial',
    name: 'Матеріал опор',
    type: formItemTypes.SELECT,
    classifier: classifiers.CL_CABLE_PILLAR_MATERIAL,
    rules: [{ required: false, message: '' }],
  },
  cableDepth: {
    field: 'cableDepth',
    name: 'Глибина закладання, м',
    type: formItemTypes.INPUT,
    rules: [{ required: false, message: '' }],
  },
  cableWellQty: {
    field: 'cableWellQty',
    name: 'Кількість колодязів',
    type: formItemTypes.INPUT,
    rules: [{ required: false, message: '' }],
  },
  cableTechnology: {
    field: 'cableTechnology',
    name: 'Технологія прокладки',
    type: formItemTypes.SELECT,
    classifier: classifiers.CL_CABLE_TECHNOLOGY,
    rules: [{ required: false, message: '' }],
  },
};

export const getMappedForm = (props) => ({
  ...getMappedGeneral(props),
  cableElectricityPurpose: { guid: props.cableElectricityPurpose },
  cableVoltage: props.cableVoltage,
  cableLenght: props.cableLenght,
  cableDiameter: props.cableDiameter,
  cableClassifier: { guid: props.cableClassifier },
  cableHeight: props.cableHeight,
  cablePillarQty: props.cablePillarQty,
  cablePillarMaterial: { guid: props.cablePillarMaterial },
  cableDepth: props.cableDepth,
  cableWellQty: props.cableWellQty,
  cableTechnology: { guid: props.cableTechnology },
});

export const getParsedForm = (props) => ({
  ...getParsedGeneral(props),
  cableElectricityPurpose: props.cableElectricityPurpose.guid,
  cableVoltage: props.cableVoltage,
  cableLenght: props.cableLenght,
  cableDiameter: props.cableDiameter,
  cableClassifier: props.cableClassifier.guid,
  cableHeight: props.cableHeight,
  cablePillarQty: props.cablePillarQty,
  cablePillarMaterial: props.cablePillarMaterial.guid,
  cableDepth: props.cableDepth,
  cableWellQty: props.cableWellQty,
  cableTechnology: props.cableTechnology.guid,
});
