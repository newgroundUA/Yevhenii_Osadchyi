import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';

import {
  getMappedForm as getMappedGeneral,
  getParsedForm as getParsedGeneral,
} from './generalFields';

export const whTransportFields = {
  whtransportType: {
    field: 'whtransportType',
    name: 'Транспортний засіб',
    type: formItemTypes.SELECT,
    classifier: classifiers.REF_WH_TRANSPORT_TYPE,
    placeholder: 'Введіть дані для пошуку',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  whtransportVincode: {
    field: 'whtransportVincode',
    name: 'Ідентифікаційний номер',
    type: formItemTypes.INPUT,
  },
  whtransportStateNumber: {
    field: 'whtransportStateNumber',
    name: 'Державний номер',
    type: formItemTypes.INPUT,
  },
  whtransportEngineNumber: {
    field: 'whtransportEngineNumber',
    name: 'Номер двигуна',
    type: formItemTypes.INPUT,
  },
  whtransportChasisNumber: {
    field: 'whtransportChasisNumber',
    name: 'Номер шасси',
    type: formItemTypes.INPUT,
  },
  whtransportBodyNumber: {
    field: 'whtransportBodyNumber',
    name: 'Номер кузова',
    type: formItemTypes.INPUT,
  },
  whtransportColorType: {
    field: 'whtransportColorType',
    name: 'Колір кузова',
    type: formItemTypes.SELECT,
    classifier: classifiers.REF_WH_TRANSPORT_COLOR_TYPE,
    placeholder: 'Введіть дані для пошуку',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  whtransportBearingCapacity: {
    field: 'whtransportBearingCapacity',
    name: "Дозволена вантажопід'ємність, кг",
    type: formItemTypes.INPUT,
  },
  whtransportNetWeight: {
    field: 'whtransportNetWeight',
    name: 'Маса без навантаження, кг',
    type: formItemTypes.INPUT,
  },
};

export const getMappedForm = (props) => ({
  ...getMappedGeneral(props),

  whtransportType: { guid: props.whtransportType },
  whtransportVincode: props.whtransportVincode,
  whtransportStateNumber: props.whtransportStateNumber,
  whtransportChasisNumber: props.whtransportChasisNumber,
  whtransportBodyNumber: props.whtransportBodyNumber,
  steadTotalSpace: props.steadTotalSpace,
  whtransportColorType: { guid: props.whtransportColorType },
  whtransportBearingCapacity: props.whtransportBearingCapacity,
  whtransportNetWeight: props.whtransportNetWeight,
});

export const getParsedForm = (props) => ({
  ...getParsedGeneral(props),

  whtransportType: props.whtransportType.guid,
  whtransportVincode: props.whtransportVincode,
  whtransportStateNumber: props.whtransportStateNumber,
  whtransportChasisNumber: props.whtransportChasisNumber,
  whtransportBodyNumber: props.whtransportBodyNumber,
  steadTotalSpace: props.steadTotalSpace,
  whtransportColorType: props.whtransportColorType.guid,
  whtransportBearingCapacity: props.whtransportBearingCapacity,
  whtransportNetWeight: props.whtransportNetWeight,
});
