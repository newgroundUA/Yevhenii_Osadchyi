import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';

import {
  getMappedForm as getMappedGeneral,
  getParsedForm as getParsedGeneral,
} from './generalFields';
import { isNumberWithTwoDecimal } from '../../../services/validator/rules';

const getObjectGuid = (obj) => (obj ? obj.guid : null);
const getArr = (fields = []) => (fields || []).map((el) => getObjectGuid(el));
const defaultValuableFields = ['guid', 'versionId'];

export const specificationFields1 = {
  cadastreNumber: {
    field: 'cadastreNumber',
    name: 'Кадастровий номер будівлі',
    type: formItemTypes.INPUT,
  },
  buildingBTILetter: {
    field: 'buildingBTILetter',
    name: 'Літера за тех. планом БТІ',
    type: formItemTypes.INPUT,
  },
  floorAmount: {
    field: 'floorAmount',
    name: 'Загальна кількість поверхів',
    type: formItemTypes.INPUT,
    rules: [
      {
        required: true,
        message: 'Поле обов`язкове для вибору!',
      },
    ],
  },
  hasFacade: {
    field: 'hasFacade',
    name: 'Фасадність',
    type: formItemTypes.RADIO,
    placeholder: 'Введіть дані для пошуку',
    classifier: classifiers.YES_NO,
    rules: [
      {
        required: true,
        message: 'Поле обов`язкове для вибору!',
      },
    ],
  },
  historyValue: {
    field: 'historyValue',
    name: 'Є історичною цінністю',
    type: formItemTypes.RADIO,
    placeholder: 'Введіть дані для пошуку',
    classifier: classifiers.YES_NO,
    rules: [
      {
        required: true,
        message: 'Поле обов`язкове для вибору!',
      },
    ],
  },
  inputTotalSpace: {
    field: 'inputTotalSpace',
    name: 'Загальна площа',
    type: formItemTypes.INPUT,
    rules: [isNumberWithTwoDecimal()],
  },
  inputUnLivingSpace: {
    field: 'inputUnLivingSpace',
    name: 'Площа нежилих приміщень',
    type: formItemTypes.INPUT,
    rules: [isNumberWithTwoDecimal()],
  },
  inputUsefullUnLivingSpace: {
    field: 'inputUsefullUnLivingSpace',
    name: 'Корисна площа нежилих приміщень',
    type: formItemTypes.INPUT,
    rules: [isNumberWithTwoDecimal()],
  },
  differenceTotalSpace: {
    field: 'differenceTotalSpace',
    name: 'Загальна площа - площа приміщень (м. кв.)',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
};

export const specificationFields2 = {
  lengthBuilding: {
    field: 'lengthBuilding',
    name: 'Довжина (м)',
    type: formItemTypes.INPUT,
  },
  widthBuilding: {
    field: 'widthBuilding',
    name: 'Ширина (м)',
    type: formItemTypes.INPUT,
  },
  heightBuilding: {
    field: 'heightBuilding',
    name: 'Висота (м)',
    type: formItemTypes.INPUT,
  },
  volumeBuilding: {
    field: 'volumeBuilding',
    name: "Будівельний об'єм (м.куб.)",
    type: formItemTypes.INPUT,
  },
  usefullVolumeBuilding: {
    field: 'usefullVolumeBuilding',
    name: "Корисний об'єм (м.куб.)",
    type: formItemTypes.INPUT,
  },
  premiseAmount: {
    field: 'premiseAmount',
    name: 'Загальна кількість приміщень',
    type: formItemTypes.INPUT,
  },
  subStructureMaterial: {
    field: 'subStructureMaterial',
    name: 'Матеріал фундаменту',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.CL_BUILDING_MATERIAL,
    placeholder: 'Введіть дані для пошуку',
    valuableFields: [...defaultValuableFields, 'type'],
  },
  extWallMaterial: {
    field: 'extWallMaterial',
    name: 'Матеріал зовнішніх стін',
    type: formItemTypes.MULTISELECT,
    placeholder: 'Введіть дані для пошуку',
    classifier: classifiers.CL_BUILDING_MATERIAL,
    valuableFields: [...defaultValuableFields, 'type'],
  },
  intWallMaterial: {
    field: 'intWallMaterial',
    name: 'Матеріал внутрішніх стін',
    type: formItemTypes.MULTISELECT,
    placeholder: 'Введіть дані для пошуку',
    classifier: classifiers.CL_BUILDING_MATERIAL,
    valuableFields: [...defaultValuableFields, 'type'],
  },
  roofMaterial: {
    field: 'roofMaterial',
    name: 'Матеріал покрівлі',
    type: formItemTypes.MULTISELECT,
    placeholder: 'Введіть дані для пошуку',
    classifier: classifiers.CL_BUILDING_MATERIAL,
    valuableFields: [...defaultValuableFields, 'type'],
  },
  overLapMaterial: {
    field: 'overLapMaterial',
    name: 'Матеріал перекриття',
    type: formItemTypes.MULTISELECT,
    placeholder: 'Введіть дані для пошуку',
    classifier: classifiers.CL_BUILDING_MATERIAL,
    valuableFields: [...defaultValuableFields, 'type'],
  },
  stairMaterial: {
    field: 'stairMaterial',
    name: 'Матеріал сходин',
    type: formItemTypes.MULTISELECT,
    placeholder: 'Введіть дані для пошуку',
    classifier: classifiers.CL_BUILDING_MATERIAL,
    valuableFields: [...defaultValuableFields, 'type'],
  },
  electroSupply: {
    field: 'electroSupply',
    name: 'Електропостачання',
    type: formItemTypes.MULTISELECT,
    placeholder: 'Введіть дані для пошуку',
    classifier: classifiers.CL_ELECTRO_SUPPLY,
    valuableFields: [...defaultValuableFields, 'type'],
  },
  coldWaterSupply: {
    field: 'coldWaterSupply',
    name: 'Холодне водопостачання',
    type: formItemTypes.SELECT,
    placeholder: 'Введіть дані для пошуку',
    classifier: classifiers.CL_COLD_WATER_SUPPLY,
    valuableFields: [...defaultValuableFields, 'type'],
  },
  hotWaterSupply: {
    field: 'hotWaterSupply',
    name: 'Гаряче водопостачання',
    type: formItemTypes.SELECT,
    placeholder: 'Введіть дані для пошуку',
    classifier: classifiers.CL_HOT_WATER_SUPPLY,
    valuableFields: [...defaultValuableFields, 'type'],
  },
  sewerageSupply: {
    field: 'sewerageSupply',
    name: 'Каналізація',
    type: formItemTypes.SELECT,
    placeholder: 'Введіть дані для пошуку',
    classifier: classifiers.CL_SEWERAGE_SUPPLY,
    valuableFields: [...defaultValuableFields, 'type'],
  },
  gasSupply: {
    field: 'gasSupply',
    name: 'Газопостачання',
    type: formItemTypes.SELECT,
    placeholder: 'Введіть дані для пошуку',
    classifier: classifiers.CL_GAS_SUPPLY,
    valuableFields: [...defaultValuableFields, 'type'],
  },
  lift: {
    field: 'lift',
    name: 'Ліфт',
    type: formItemTypes.MULTISELECT,
    placeholder: 'Введіть дані для пошуку',
    classifier: classifiers.CL_LIFT,
    valuableFields: [...defaultValuableFields, 'type'],
  },
  heatingSupply: {
    field: 'heatingSupply',
    name: 'Опалення',
    type: formItemTypes.MULTISELECT,
    placeholder: 'Введіть дані для пошуку',
    classifier: classifiers.CL_HEATING_SUPPLY,
    valuableFields: [...defaultValuableFields, 'type'],
  },
  rubbishSupply: {
    field: 'rubbishSupply',
    name: 'Сміттєпровід',
    type: formItemTypes.SELECT,
    placeholder: 'Введіть дані для пошуку',
    classifier: classifiers.CL_RUBBISH_SUPPLY,
    valuableFields: [...defaultValuableFields, 'type'],
  },
  addressNote: {
    field: 'addressNote',
    name: 'Додатковий адресний опис',
    type: formItemTypes.TEXTAREA,
  },
  documentType: {
    // need to be removed
    field: 'documentType',
    name: 'Тип документа',
    type: formItemTypes.SELECT,
    classifier: classifiers.DOCUMENT_TYPE,
    customRendered: true,
    valuableFields: defaultValuableFields,
  },
};

export const readOnlySpecFields = {
  floorsEntered: {
    field: 'floorsEntered',
    name: 'Введена кількість поверхів',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
  premisesEntered: {
    field: 'premisesEntered',
    name: 'Введена кількість приміщень',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
  totalBuildingSpace: {
    field: 'totalBuildingSpace',
    name: 'Загальна площа будівлі (м.кв.)',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
  buildingLivingSpace: {
    field: 'buildingLivingSpace',
    name: 'Загальна житлова площа (м.кв.)',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
  buildingUnLivingSpace: {
    field: 'buildingUnLivingSpace',
    name: 'Загальна нежитлова площа (м.кв.)',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
  buildingUsefullUnLivingSpace: {
    field: 'buildingUsefullUnLivingSpace',
    name: 'Загальна корисна нежитлова площа (м.кв.)',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
  buildingTechnicalSpace: {
    field: 'buildingTechnicalSpace',
    name: 'Загальна технічна площа (м.кв.)',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
  buildingCommonSpace: {
    field: 'buildingCommonSpace',
    name: 'Загальна площа загального користування (м.кв.)',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
  buildingSocleSpace: {
    field: 'buildingSocleSpace',
    name: 'Загальна площа цоколю (м.кв.)',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
  buildingBasementSpace: {
    field: 'buildingBasementSpace',
    name: 'Загальна площа підвалів (м.кв.)',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
  buildingLoftSpace: {
    field: 'buildingLoftSpace',
    name: 'Загальна площа горища (м.кв.)',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
};

export const getMappedForm = (props) => ({
  ...getMappedGeneral(props),

  cadastreNumber: props.cadastreNumber,
  buildingBTILetter: props.buildingBTILetter,
  lengthBuilding: props.lengthBuilding,
  widthBuilding: props.widthBuilding,
  heightBuilding: props.heightBuilding,
  volumeBuilding: props.volumeBuilding,
  usefullVolumeBuilding: props.usefullVolumeBuilding,
  inputTotalSpace: props.inputTotalSpace,
  inputUnLivingSpace: props.inputUnLivingSpace,
  inputUsefullUnLivingSpace: props.inputUsefullUnLivingSpace,

  subStructureMaterial: props.subStructureMaterial,
  extWallMaterial: props.extWallMaterial,
  intWallMaterial: props.intWallMaterial,
  roofMaterial: props.roofMaterial,
  overLapMaterial: props.overLapMaterial,
  stairMaterial: props.stairMaterial,
  electroSupply: props.electroSupply,
  coldWaterSupply: props.coldWaterSupply,
  hotWaterSupply: props.hotWaterSupply,
  sewerageSupply: props.sewerageSupply,
  gasSupply: props.gasSupply,
  lift: props.lift,
  heatingSupply: props.heatingSupply,
  rubbishSupply: props.rubbishSupply,

  hasFacade: props.hasFacade,
  historyValue: props.historyValue,
  addressNote: props.addressNote,
  totalBuildingSpace: props.totalBuildingSpace,
  floorAmount: props.floorAmount,
  premiseAmount: props.premiseAmount,
  buildingLivingSpace: props.buildingLivingSpace,
  buildingUnLivingSpace: props.buildingUnLivingSpace,
  buildingUsefullUnLivingSpace: props.buildingUsefullUnLivingSpace,
  buildingTechnicalSpace: props.buildingTechnicalSpace,
  buildingCommonSpace: props.buildingCommonSpace,
  buildingBasementSpace: props.buildingBasementSpace,
  buildingLoftSpace: props.buildingLoftSpace,
});

const countPremises = (floors) => {
  let premises = 0;
  floors.filter((f) => f.premises !== null).forEach((floor) => {
    premises = (floor.premises || []).length + premises;
  });

  return premises;
};

export const getParsedForm = (props) => ({
  ...getParsedGeneral(props),

  cadastreNumber: props.cadastreNumber,
  buildingBTILetter: props.buildingBTILetter,
  lengthBuilding: props.lengthBuilding,
  widthBuilding: props.widthBuilding,
  heightBuilding: props.heightBuilding,
  volumeBuilding: props.volumeBuilding,
  usefullVolumeBuilding: props.usefullVolumeBuilding,
  inputTotalSpace: props.inputTotalSpace,
  inputUnLivingSpace: props.inputUnLivingSpace,
  inputUsefullUnLivingSpace: props.inputUsefullUnLivingSpace,
  differenceTotalSpace: ((props.inputTotalSpace || 0) - (props.totalBuildingSpace || 0)).toFixed(2),

  subStructureMaterial: getArr(props.subStructureMaterial),
  extWallMaterial: getArr(props.extWallMaterial),
  intWallMaterial: getArr(props.intWallMaterial),
  roofMaterial: getArr(props.roofMaterial),
  overLapMaterial: getArr(props.overLapMaterial),
  stairMaterial: getArr(props.stairMaterial),
  coldWaterSupply: getObjectGuid(props.coldWaterSupply),
  electroSupply: getArr(props.electroSupply),
  hotWaterSupply: getObjectGuid(props.hotWaterSupply),
  sewerageSupply: getObjectGuid(props.sewerageSupply),
  gasSupply: getObjectGuid(props.gasSupply),
  lift: getArr(props.lift),
  heatingSupply: getArr(props.heatingSupply),
  rubbishSupply: getObjectGuid(props.rubbishSupply),

  hasFacade: props.hasFacade,
  historyValue: props.historyValue,
  addressNote: props.addressNote,
  floorAmount: props.floorAmount,
  premiseAmount: props.premiseAmount,

  // view fields, disabled
  floorsEntered: (props.floors || []).length,
  premisesEntered: props.floors ? countPremises(props.floors) : 0,
  totalBuildingSpace: props.totalBuildingSpace,
  buildingLivingSpace: props.buildingLivingSpace,
  buildingUnLivingSpace: props.buildingUnLivingSpace,
  buildingUsefullUnLivingSpace: props.buildingUsefullUnLivingSpace,
  buildingTechnicalSpace: props.buildingTechnicalSpace,
  buildingCommonSpace: props.buildingCommonSpace,
  buildingSocleSpace: props.buildingSocleSpace,
  buildingBasementSpace: props.buildingBasementSpace,
  buildingLoftSpace: props.buildingLoftSpace,
});
