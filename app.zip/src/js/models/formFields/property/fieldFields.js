import * as formItemTypes from '../../../constants/FormItemTypes';

import {
  getMappedForm as getMappedGeneral,
  getParsedForm as getParsedGeneral,
} from './generalFields';

export const fieldFields = {
  // eslint-disable-line import/prefer-default-export
  coordinateX: {
    field: 'coordinateX',
    name: 'Координата Х опорної точки',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для заповнення!' }],
  },
  coordinateY: {
    field: 'coordinateY',
    name: 'Координата Y опорної точки',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для заповнення!' }],
  },
  fieldLength: {
    field: 'fieldLength',
    name: 'Довжина, м',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для заповнення!' }],
  },
  fieldWidth: {
    field: 'fieldWidth',
    name: 'Ширина, м',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для заповнення!' }],
  },
  commonFieldSpace: {
    field: 'commonFieldSpace',
    name: 'Загальна площа частини приміщення, м2',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для заповнення!' }],
  },
  premise: {
    field: 'premise',
    name: 'Приміщення',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
};

export const getMappedForm = (props) => ({
  ...getMappedGeneral(props),

  coordinateX: props.coordinateX,
  coordinateY: props.coordinateY,
  fieldLength: props.fieldLength,
  fieldWidth: props.fieldWidth,
  commonFieldSpace: props.commonFieldSpace,
});

export const getParsedForm = (props) => ({
  ...getParsedGeneral(props),

  premise: props.premiseName,
  coordinateX: props.coordinateX,
  coordinateY: props.coordinateY,
  fieldLength: props.fieldLength,
  fieldWidth: props.fieldWidth,
  commonFieldSpace: props.commonFieldSpace,
});
