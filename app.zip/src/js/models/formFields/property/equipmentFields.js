import moment from 'moment';
import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';

import {
  getMappedForm as getMappedGeneral,
  getParsedForm as getParsedGeneral,
} from './generalFields';

const DATE_FORMAT_BE = 'YYYY-MM-DD HH:mm:ss.SSS Z';
const getDate = (data) => (data ? moment(data, DATE_FORMAT_BE) : null);

export const equipmentFields = {
  equipmentManufacClassifier: {
    field: 'equipmentManufacClassifier',
    name: 'Виробник',
    type: formItemTypes.SELECT,
    classifier: classifiers.CL_MANUFACTURER,
    placeholder: 'Введіть дані для пошуку',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  equipmentType: {
    field: 'equipmentType',
    name: 'Тип обладнання',
    type: formItemTypes.SELECT,
    classifier: classifiers.EQUIPMENT_TYPE,
    placeholder: 'Введіть дані для пошуку',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },

  equipmentManufacDate: {
    field: 'equipmentManufacDate',
    name: 'Дата виробництва',
    type: formItemTypes.DATEPICKER,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
    disabledDate: (currDate) => currDate && currDate.valueOf() > moment().valueOf(),
  },
  equipmentWarrantyPeriod: {
    field: 'equipmentWarrantyPeriod',
    name: 'Гарантійний термін, м',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  equipmentTechnicalNote: {
    field: 'equipmentTechnicalNote',
    name: 'Технічний опис',
    type: formItemTypes.TEXTAREA,
  },
};

export const getMappedForm = (props) => ({
  ...getMappedGeneral(props),

  equipmentManufacClassifier: { guid: props.equipmentManufacClassifier },
  equipmentType: { guid: props.equipmentType },
  equipmentManufacDate: props.equipmentManufacDate,
  equipmentWarrantyPeriod: props.equipmentWarrantyPeriod,
  equipmentTechnicalNote: props.equipmentTechnicalNote,
});

export const getParsedForm = (props) => ({
  ...getParsedGeneral(props),

  equipmentManufacClassifier: props.equipmentManufacClassifier.guid,
  equipmentType: props.equipmentType.guid,
  equipmentManufacDate: getDate(props.equipmentManufacDate),
  equipmentWarrantyPeriod: props.equipmentWarrantyPeriod,
  equipmentTechnicalNote: props.equipmentTechnicalNote,
});
