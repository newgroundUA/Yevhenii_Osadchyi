import moment from 'moment';
import * as formItemTypes from '../../../../constants/FormItemTypes';
import * as classifiers from '../../../../constants/ClassifiersNames';
import { createValueCreator } from '../../../../helpers/formHelpers/dropdownValueCreators';

const createValue = createValueCreator('counterparty');
const createDocumentsValue = createValueCreator('document');

const DATE_FORMAT_BE = 'YYYY-MM-DD HH:mm:ss.SSS Z';
const getDate = (data) => (data ? moment(data, DATE_FORMAT_BE) : null);
const defaultValuableFields = ['guid', 'versionId'];

export const ownersOfPrimaryPRFields = {
  primaryOwner: {
    field: 'primaryOwner',
    name: 'Первинний власник',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    placeholder: 'Введіть дані для пошуку',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
    valuableFields: defaultValuableFields,
  },
  propertyRegistrRecNum: {
    field: 'propertyRegistrRecNum',
    name: 'Номер запису про право власності в ДРП',
    type: formItemTypes.INPUT,
  },
  propertyRightFactStartDate: {
    field: 'propertyRightFactStartDate',
    name: 'Дата фактичного виникнення права власності',
    type: formItemTypes.DATEPICKER,
  },
  propertyRightsRegConfirmationDocs: {
    field: 'propertyRightsRegConfirmationDocs',
    name: 'Підтвердження (документ) реєстрації права власноті',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.DOCUMENTS,
    placeholder: 'Введіть дані для пошуку',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
    colSpan: 24,
    valuableFields: defaultValuableFields,
  },
  propertyRightsBaseStartDate: {
    field: 'propertyRightsBaseStartDate',
    name: 'Дата виникнення підстави на право власності',
    type: formItemTypes.DATEPICKER,
  },
  propertyRightsGroundsOfOccurrenceDocs: {
    field: 'propertyRightsGroundsOfOccurrenceDocs',
    name: 'Підстава (документ) виникнення права власності',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.DOCUMENTS,
    placeholder: 'Введіть дані для пошуку',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
    colSpan: 24,
    valuableFields: defaultValuableFields,
  },
  propertyRightFactEndDate: {
    field: 'propertyRightFactEndDate',
    name: 'Дата скасування права власності',
    type: formItemTypes.DATEPICKER,
  },
  propertyRightsCancelDocs: {
    field: 'propertyRightsCancelDocs',
    name: 'Документи про скасування права власності',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.DOCUMENTS,
    colSpan: 24,
    placeholder: 'Введіть дані для пошуку',
    rules: [],
    valuableFields: defaultValuableFields,
  },
  shareSize: {
    field: 'shareSize',
    name: 'Розмір частки',
    type: formItemTypes.INPUT,
  },
  primaryAdditionalDocs: {
    field: 'primaryAdditionalDocs',
    name: 'Додаткові документи',
    colSpan: 24,
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.DOCUMENTS,
    placeholder: 'Введіть дані для пошуку',
    rules: [],
    valuableFields: defaultValuableFields,
  },
};

export const getMappedForm = (props) => ({
  primaryOwner: props.primaryOwner,
  propertyRegistrRecNum: props.propertyRegistrRecNum,
  propertyRightFactStartDate: props.propertyRightFactStartDate,
  propertyRightsRegConfirmationDocs: props.propertyRightsRegConfirmationDocs,
  propertyRightsBaseStartDate: props.propertyRightsBaseStartDate,
  propertyRightsGroundsOfOccurrenceDocs: props.propertyRightsGroundsOfOccurrenceDocs,
  propertyRightFactEndDate: props.propertyRightFactEndDate,
  propertyRightsCancelDocs: props.propertyRightsCancelDocs,
  shareSize: props.shareSize,
  additionalDocs: props.primaryAdditionalDocs,

  // ownersRegistryGuid
});

// TODO: fix during refactoring proccess
export const getParsedForm = (props) => ({
  primaryOwner: props.primaryOwner
    ? { ...createValue(props.primaryOwner), ...props.primaryOwner }
    : undefined,
  propertyRegistrRecNum: props.propertyRegistrRecNum,
  propertyRightFactStartDate: getDate(props.propertyRightFactStartDate),
  propertyRightsRegConfirmationDocs: (props.propertyRightsRegConfirmationDocs || []).map((el) => ({
    ...el,
    ...createDocumentsValue(el),
  })),
  propertyRightsBaseStartDate: getDate(props.propertyRightsBaseStartDate),
  propertyRightsGroundsOfOccurrenceDocs: props.propertyRightsGroundsOfOccurrenceDocs.map(
    createDocumentsValue,
  ),
  propertyRightFactEndDate: getDate(props.propertyRightFactEndDate),
  propertyRightsCancelDocs: (props.propertyRightsCancelDocs || []).map((el) => ({
    ...el,
    ...createDocumentsValue(el),
  })),
  shareSize: props.shareSize,
  primaryAdditionalDocs: (props.additionalDocs || []).map((el) => ({
    ...el,
    ...createDocumentsValue(el),
  })),
});

export const getMappedLocal = (props) => ({
  primaryOwner: props.primaryOwner,
  propertyRegistrRecNum: props.propertyRegistrRecNum,
  propertyRightFactStartDate: props.propertyRightFactStartDate,
  propertyRightsRegConfirmationDocs: props.propertyRightsRegConfirmationDocs,
  propertyRightsBaseStartDate: props.propertyRightsBaseStartDate,
  propertyRightsGroundsOfOccurrenceDocs: props.propertyRightsGroundsOfOccurrenceDocs,
  propertyRightFactEndDate: props.propertyRightFactEndDate,
  propertyRightsCancelDocs: props.propertyRightsCancelDocs,
  shareSize: props.shareSize,
  additionalDocs: props.primaryAdditionalDocs,
});
