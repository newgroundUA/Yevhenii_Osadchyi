import moment from 'moment';
import * as formItemTypes from '../../../../constants/FormItemTypes';
import * as classifiers from '../../../../constants/ClassifiersNames';
import { createValueCreator } from '../../../../helpers/formHelpers/dropdownValueCreators';

const createCounterpartyValue = createValueCreator('counterparty');
const createDocumentValue = createValueCreator('document');

const DATE_FORMAT_BE = 'YYYY-MM-DD HH:mm:ss.SSS Z';
const getDate = (data) => (data ? moment(data, DATE_FORMAT_BE) : null);
const defaultValuableFields = ['guid', 'versionId'];

export const ownersOfDerivativePRFields = {
  derivativeOwner: {
    field: 'derivativeOwner',
    name: "Суб'єкт речового права",
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    placeholder: 'Введіть дані для пошуку',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
    valuableFields: defaultValuableFields,
  },
  derivativePropertyRegistrRecNum: {
    field: 'derivativePropertyRegistrRecNum',
    name: 'Номер запису про інше майнове право в ДРП',
    type: formItemTypes.INPUT,
  },
  derivativeRightFactStartDate: {
    field: 'derivativeRightFactStartDate',
    name: 'Дата фактичного виникнення іншого майнового права',
    type: formItemTypes.DATEPICKER,
  },
  derivativeRightsRegConfirmationDocs: {
    field: 'derivativeRightsRegConfirmationDocs',
    name: 'Підтвердження реєстрації іншого права власноті',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.DOCUMENTS,
    placeholder: 'Введіть дані для пошуку',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
    colSpan: 24,
    valuableFields: defaultValuableFields,
  },
  derivativeRightsBaseStartDate: {
    field: 'derivativeRightsBaseStartDate',
    name: 'Дата виникнення підстави іншого майнового права',
    type: formItemTypes.DATEPICKER,
  },
  derivativeRightsGroundsOfOccurrenceDocs: {
    field: 'derivativeRightsGroundsOfOccurrenceDocs',
    name: 'Підстава виникнення іншого речового права',
    type: formItemTypes.SELECT,
    classifier: classifiers.DOCUMENTS,
    placeholder: 'Введіть дані для пошуку',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
    colSpan: 24,
    valuableFields: defaultValuableFields,
  },
  derivativePropertyRightsType: {
    field: 'derivativePropertyRightsType',
    name: 'Вид речового права',
    type: formItemTypes.SELECT,
    classifier: classifiers.CL_PROPERTY_RIGHTS_TYPE,
    placeholder: 'Введіть дані для пошуку',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
    valuableFields: [...defaultValuableFields, 'type'],
  },
  derivativeAdditionalDocs: {
    field: 'derivativeAdditionalDocs',
    name: 'Додаткові документи',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.DOCUMENTS,
    placeholder: 'Введіть дані для пошуку',
    rules: [],
    colSpan: 24,
    valuableFields: defaultValuableFields,
  },
  derivativeRightFactEndDate: {
    field: 'derivativeRightFactEndDate',
    name: 'Дата скасування права речового права',
    type: formItemTypes.DATEPICKER,
  },
  derivativeRightsCancelDocs: {
    field: 'derivativeRightsCancelDocs',
    name: 'Документи про скасування речового права',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.DOCUMENTS,
    placeholder: 'Введіть дані для пошуку',
    rules: [],
    colSpan: 24,
    valuableFields: defaultValuableFields,
  },
};

export const getMappedForm = (props) => ({
  derivativeOwner: props.derivativeOwner,
  propertyRegistrRecNum: props.derivativePropertyRegistrRecNum,
  derivativeRightFactStartDate: props.derivativeRightFactStartDate,
  derivativeRightsRegConfirmationDocs: props.derivativeRightsRegConfirmationDocs,
  derivativeRightsBaseStartDate: props.derivativeRightsBaseStartDate,
  derivativeRightsGroundsOfOccurrenceDocs: Array.isArray(
    props.derivativeRightsGroundsOfOccurrenceDocs,
  ) // eslint-disable-line
    ? props.derivativeRightsGroundsOfOccurrenceDocs
    : [props.derivativeRightsGroundsOfOccurrenceDocs],
  derivativeRightFactEndDate: props.derivativeRightFactEndDate,
  derivativeRightsCancelDocs: props.derivativeRightsCancelDocs,
  derivativePropertyRightsType: props.derivativePropertyRightsType,
  additionalDocs: props.derivativeAdditionalDocs,
});

export const getParsedForm = (props) => ({
  derivativeOwner: props.derivativeOwner
    ? { ...createCounterpartyValue(props.derivativeOwner), ...props.derivativeOwner }
    : undefined,
  derivativePropertyRegistrRecNum: props.propertyRegistrRecNum,
  derivativeRightFactStartDate: getDate(props.derivativeRightFactStartDate),
  derivativeRightsRegConfirmationDocs: (props.derivativeRightsRegConfirmationDocs || []).map(
    (el) => ({ ...createDocumentValue(el), ...el }),
  ),
  derivativeRightsBaseStartDate: getDate(props.derivativeRightsBaseStartDate),
  derivativeRightsGroundsOfOccurrenceDocs: createDocumentValue(
    props.derivativeRightsGroundsOfOccurrenceDocs[0],
  ),
  derivativeRightFactEndDate: getDate(props.derivativeRightFactEndDate),
  derivativeRightsCancelDocs: (props.derivativeRightsCancelDocs || []).map((el) => ({
    ...createDocumentValue(el),
    ...el,
  })),
  derivativePropertyRightsType: props.derivativePropertyRightsType.guid,
  derivativeAdditionalDocs: (props.additionalDocs || []).map((el) => ({
    ...createDocumentValue(el),
    ...el,
  })),
});

export const getMappedLocal = (props, propertyRightsTypes) => ({
  derivativeOwner: props.derivativeOwner,
  propertyRegistrRecNum: props.derivativePropertyRegistrRecNum,
  derivativeRightFactStartDate: props.derivativeRightFactStartDate,
  derivativeRightsRegConfirmationDocs: props.derivativeRightsRegConfirmationDocs,
  derivativeRightsBaseStartDate: props.derivativeRightsBaseStartDate,
  derivativeRightsGroundsOfOccurrenceDocs: [props.derivativeRightsGroundsOfOccurrenceDocs], // eslint-disable-line
  derivativeRightFactEndDate: props.derivativeRightFactEndDate,
  derivativeRightsCancelDocs: props.derivativeRightsCancelDocs,
  derivativePropertyRightsType: propertyRightsTypes.find(
    (el) => el.guid === props.derivativePropertyRightsType,
  ),
  additionalDocs: props.derivativeRightsCancelDocs,
});
