import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';

import {
  getMappedForm as getMappedGeneral,
  getParsedForm as getParsedGeneral,
} from './generalFields';

const getArr = (fields = []) => fields.map((el) => el.guid);
const isObject = (obj) => (obj ? obj.guid : null);

export const steadFields = {
  cadastreNumber: {
    field: 'cadastreNumber',
    name: 'Кадастровий номер',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  steadTotalSpace: {
    field: 'steadTotalSpace',
    name: 'Загальна площа ділянки',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  landCategory: {
    field: 'landCategory',
    name: 'Категорія земель',
    type: formItemTypes.SELECT,
    classifier: classifiers.CL_LAND_CATEGORY,
    placeholder: 'Введіть дані для пошуку',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  landPurpose: {
    field: 'landPurpose',
    name: 'Призначення земель',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.CL_LAND_PURPOSE,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
};

export const getMappedForm = (props) => ({
  ...getMappedGeneral(props),

  cadastreNumber: props.cadastreNumber,
  steadTotalSpace: props.steadTotalSpace,
  landCategory: props.landCategory ? { guid: props.landCategory } : null,
  landPurpose: (props.landPurpose || []).map((lp) => ({ guid: lp })),
});

export const getParsedForm = (props) => ({
  ...getParsedGeneral(props),

  cadastreNumber: props.cadastreNumber,
  steadTotalSpace: props.steadTotalSpace,
  landCategory: isObject(props.landCategory),
  landPurpose: getArr(props.landPurpose),
});
