import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';
import { createValueCreator } from '../../../helpers/formHelpers/dropdownValueCreators';

import {
  getMappedForm as getMappedGeneral,
  getParsedForm as getParsedGeneral,
} from './generalFields';

const createValue = createValueCreator('counterparty');

export const intellRightFields = {
  intelCreationType: {
    field: 'intelCreationType',
    name: 'Тип твору за класифікатором',
    type: formItemTypes.SELECT,
    classifier: classifiers.CL_INTELL_CREATION_TYPE,
    placeholder: 'Введіть дані для пошуку',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  intelLicenseType: {
    field: 'intelLicenseType',
    name: 'Тип ліцензії',
    type: formItemTypes.SELECT,
    classifier: classifiers.CL_INTELL_LICENSE_TYPE,
    placeholder: 'Введіть дані для пошуку',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  intelManufacturer: {
    field: 'intelManufacturer',
    name: 'Виробник',
    type: formItemTypes.SELECT,
    placeholder: 'Введіть дані для пошуку',
    customRendered: true,
  },
  intelAuthors: {
    field: 'intelAuthors',
    name: 'Автори',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  intelPatentData: {
    field: 'intelPatentData',
    name: 'Номер та дата свідотства',
    type: formItemTypes.SELECT,
    classifier: classifiers.CL_INTELL_PATENT_DATA,
    placeholder: 'Введіть дані для пошуку',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
};

export const getMappedForm = (props) => ({
  ...getMappedGeneral(props),

  intelCreationType: { guid: props.intelCreationType },
  intelLicenseType: { guid: props.intelLicenseType },
  intelManufacturer: { guid: props.intelManufacturer.key },
  intelAuthors: props.intelAuthors,
  intelPatentData: { guid: props.intelPatentData },
});

export const getParsedForm = (props) => ({
  ...getParsedGeneral(props),

  intelCreationType: props.intelCreationType.guid,
  intelLicenseType: props.intelLicenseType.guid,
  intelManufacturer: createValue(props.intelManufacturer),
  intelAuthors: props.intelAuthors,
  intelPatentData: props.intelPatentData.guid,
});
