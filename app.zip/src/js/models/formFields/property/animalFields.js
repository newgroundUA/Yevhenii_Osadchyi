import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';

import {
  getMappedForm as getMappedGeneral,
  getParsedForm as getParsedGeneral,
} from './generalFields';

export const animalFields = {
  animalClassifier: {
    field: 'animalClassifier',
    name: 'Клас та порода за довідником',
    type: formItemTypes.SELECT,
    classifier: classifiers.REF_ANIMAL_CLASSIFIER,
    placeholder: 'Введіть дані для пошуку',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  animalPurpose: {
    field: 'animalPurpose',
    name: 'Призначення',
    type: formItemTypes.SELECT,
    classifier: classifiers.CL_ANIMAL_PURPOSE,
    placeholder: 'Введіть дані для пошуку',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
};

export const getMappedForm = (props) => ({
  ...getMappedGeneral(props),

  animalClassifier: { guid: props.animalClassifier },
  animalPurpose: { guid: props.animalPurpose },
});

export const getParsedForm = (props) => ({
  ...getParsedGeneral(props),

  animalClassifier: props.animalClassifier.guid,
  animalPurpose: props.animalPurpose.guid,
});
