import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';

import {
  getMappedForm as getMappedGeneral,
  getParsedForm as getParsedGeneral,
} from './generalFields';

export const roadFields = {
  roadLength: {
    field: 'roadLength',
    name: 'Довжина, м',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  roadMaxWidth: {
    field: 'roadMaxWidth',
    name: 'Максимальна ширина, м',
    type: formItemTypes.INPUT,
  },
  roadMinWidth: {
    field: 'roadMinWidth',
    name: 'Мінімальна ширина, м',
    type: formItemTypes.INPUT,
  },
  roadAverageWidth: {
    field: 'roadAverageWidth',
    name: 'Середня ширина, м',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  roadFullSpace: {
    field: 'roadFullSpace',
    name: 'Загальна площа, м.кв',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  roadHeight: {
    field: 'roadHeight',
    name: 'Висота (для мостів), м',
    type: formItemTypes.INPUT,
  },
  roadDepth: {
    field: 'roadDepth',
    name: 'Глибина (для тунелів), м',
    type: formItemTypes.INPUT,
  },
  roadTunnelDiameter: {
    field: 'roadTunnelDiameter',
    name: 'Діаметр (для тунелів), м',
    type: formItemTypes.INPUT,
  },
  roadTunnelVolume: {
    field: 'roadTunnelVolume',
    name: "Об'єм (для тунелів), м",
    type: formItemTypes.INPUT,
  },
  roadWeight: {
    field: 'roadWeight',
    name: 'Маса (для споруд), т',
    type: formItemTypes.INPUT,
  },
  roadMoveLine: {
    field: 'roadMoveLine',
    name: 'Кількість полос для руху (в усіх напр)',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  roadClMoveLine: {
    field: 'roadClMoveLine',
    name: 'Типи полоси для руху',
    type: formItemTypes.SELECT,
    classifier: classifiers.CL_ROAD_MOVE_LINE,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  roadCrossQty: {
    field: 'roadCrossQty',
    name: 'Кількість перетинів',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  roadClBuildingMaterial: {
    field: 'roadClBuildingMaterial',
    name: 'Матеріал',
    type: formItemTypes.SELECT,
    classifier: classifiers.CL_BUILDING_MATERIAL,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  roadClRoadTechnology: {
    field: 'roadClRoadTechnology',
    name: 'Технологія',
    type: formItemTypes.SELECT,
    classifier: classifiers.CL_ROAD_TECHNOLOGY,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
};

export const getMappedForm = (props) => ({
  ...getMappedGeneral(props),

  roadLength: props.roadLength,
  roadMaxWidth: props.roadMaxWidth,
  roadMinWidth: props.roadMinWidth,
  roadAverageWidth: props.roadAverageWidth,
  roadFullSpace: props.roadFullSpace,
  roadHeight: props.roadHeight,
  roadDepth: props.roadDepth,
  roadTunnelDiameter: props.roadTunnelDiameter,
  roadTunnelVolume: props.roadTunnelVolume,
  roadWeight: props.roadWeight,
  roadMoveLine: props.roadMoveLine,
  roadClMoveLine: { guid: props.roadClMoveLine },
  roadCrossQty: props.roadCrossQty,
  roadClBuildingMaterial: { guid: props.roadClBuildingMaterial },
  roadClRoadTechnology: { guid: props.roadClRoadTechnology },
});

export const getParsedForm = (props) => ({
  ...getParsedGeneral(props),

  roadLength: props.roadLength,
  roadMaxWidth: props.roadMaxWidth,
  roadMinWidth: props.roadMinWidth,
  roadAverageWidth: props.roadAverageWidth,
  roadFullSpace: props.roadFullSpace,
  roadHeight: props.roadHeight,
  roadDepth: props.roadDepth,
  roadTunnelDiameter: props.roadTunnelDiameter,
  roadTunnelVolume: props.roadTunnelVolume,
  roadWeight: props.roadWeight,
  roadMoveLine: props.roadMoveLine,
  roadClMoveLine: props.roadClMoveLine.guid,
  roadCrossQty: props.roadCrossQty,
  roadClBuildingMaterial: props.roadClBuildingMaterial.guid,
  roadClRoadTechnology: props.roadClRoadTechnology.guid,
});
