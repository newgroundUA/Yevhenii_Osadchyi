import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';

import {
  getMappedForm as getMappedGeneral,
  getParsedForm as getParsedGeneral,
} from './generalFields';

export const plantFields = {
  plantClassifier: {
    field: 'plantClassifier',
    name: 'Клас та різновид рослини',
    type: formItemTypes.SELECT,
    classifier: classifiers.CL_PLANT,
    placeholder: 'Введіть дані для пошуку',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  plantPurpose: {
    field: 'plantPurpose',
    name: 'Призначення',
    type: formItemTypes.SELECT,
    classifier: classifiers.CL_PLANT_PURPOSE,
    placeholder: 'Введіть дані для пошуку',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
};

export const getMappedForm = (props) => ({
  ...getMappedGeneral(props),

  plantClassifier: { guid: props.plantClassifier },
  plantPurpose: { guid: props.plantPurpose },
});

export const getParsedForm = (props) => ({
  ...getParsedGeneral(props),

  plantClassifier: props.plantClassifier.guid,
  plantPurpose: props.plantPurpose.guid,
});
