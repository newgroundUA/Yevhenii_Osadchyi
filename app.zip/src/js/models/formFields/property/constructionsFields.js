// import moment from 'moment';
import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';
import {
  getMappedForm as getMappedGeneral,
  getParsedForm as getParsedGeneral,
} from './generalFields';

// const DATE_FORMAT_BE = 'YYYY-MM-DD HH:mm:ss.SSS Z';
// const getDate = (data) => (data ? moment(data, DATE_FORMAT_BE) : null);
const getGuidsArray = (arr) => (arr ? arr.map((item) => item.guid) : []);

export const constructionsFields = {
  cadastreNumber: {
    field: 'cadastreNumber',
    name: 'Кадастровий номер будівлі',
    type: formItemTypes.INPUT,
    // classifier: classifiers.KVED,
    placeholder: 'Введіть кадастровий номер будівлі',
    rules: [{ required: false, message: '' }],
  },
  buildingBTILetter: {
    field: 'buildingBTILetter',
    name: 'Литера за БТІ',
    type: formItemTypes.INPUT,
    // classifier: classifiers.KVED,
    placeholder: 'Введіть литеру за БТІ',
    rules: [{ required: false, message: '' }],
  },
  buildingDMALetter: {
    field: 'buildingDMALetter',
    name: 'Литера за ДМА',
    type: formItemTypes.INPUT,
    // classifier: classifiers.KVED,
    placeholder: 'Введіть литеру за ДМА',
    rules: [{ required: false, message: '' }],
  },
  lengthConstruction: {
    field: 'lengthConstruction',
    name: 'Довжина (м)',
    type: formItemTypes.INPUT, // <- InputNumber
    // classifier: classifiers.KVED,
    placeholder: 'Введіть довжину',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  widthConstruction: {
    field: 'widthConstruction',
    name: 'Ширина (м)',
    type: formItemTypes.INPUT, // <- InputNumber
    // classifier: classifiers.KVED,
    placeholder: 'Введіть ширину',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  heightConstruction: {
    field: 'heightConstruction',
    name: 'Висота будівлі (м)',
    type: formItemTypes.INPUT, // <- InputNumber
    // classifier: classifiers.KVED,
    placeholder: 'Введіть висоту будівлі',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  diameterConstruction: {
    field: 'diameterConstruction',
    name: 'Діаметр (м)',
    type: formItemTypes.INPUT, // <- InputNumber
    // classifier: classifiers.KVED,
    placeholder: 'Введіть діаметр',
    rules: [{ required: false, message: '' }],
  },
  weightConstruction: {
    field: 'weightConstruction',
    name: 'Маса споруди, т',
    type: formItemTypes.INPUT, // <- InputNumber
    // classifier: classifiers.KVED,
    placeholder: 'Введіть масу споруди',
    rules: [{ required: false, message: '' }],
  },
  volumeConstruction: {
    field: 'volumeConstruction',
    name: "Будівельний об'єм будівлі, м.куб.",
    type: formItemTypes.INPUT, // <- InputNumber
    // classifier: classifiers.KVED,
    placeholder: "Введіть будівельний об'єм",
    rules: [{ required: false, message: '' }],
  },
  usefullVolumeConstruction: {
    field: 'usefullVolumeConstruction',
    name: "Корисний об'єм, м. куб.",
    type: formItemTypes.INPUT, // <- InputNumber
    // classifier: classifiers.KVED,
    placeholder: "Введіть корисний об'єм",
    rules: [{ required: false, message: '' }],
  },
  totalConstructionSpace: {
    field: 'totalConstructionSpace',
    name: 'Загальна площа',
    type: formItemTypes.INPUT, // <- InputNumber
    // classifier: classifiers.KVED,
    placeholder: 'Введіть загальну площу',
    rules: [{ required: false, message: '' }],
  },
  constructionMaterial: {
    field: 'constructionMaterial',
    name: 'Матеріали споруди',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.CL_BUILDING_MATERIAL,
    placeholder: 'Введіть дані для пошуку',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  constructionAddressNote: {
    field: 'constructionAddressNote',
    name: 'Додатковий адресний опис',
    type: formItemTypes.TEXTAREA,
    // classifier: classifiers.KVED,
    placeholder: 'Введіть загальну площу',
    rules: [{ required: false, message: '' }],
  },
};

export const getConstructionsBEFields = (props) => ({
  ...getMappedGeneral(props),

  cadastreNumber: props.cadastreNumber,
  buildingBTILetter: props.buildingBTILetter,
  buildingDMALetter: props.buildingDMALetter,
  lengthConstruction: props.lengthConstruction,
  widthConstruction: props.widthConstruction,
  heightConstruction: props.heightConstruction,
  diameterConstruction: props.diameterConstruction,
  weightConstruction: props.weightConstruction,
  volumeConstruction: props.volumeConstruction,
  usefullVolumeConstruction: props.usefullVolumeConstruction,
  totalConstructionSpace: props.totalConstructionSpace,
  constructionMaterial: (props.constructionMaterial || []).map((m) => ({ guid: m })),
  constructionAddressNote: props.constructionAddressNote,
});

export const parseConstruction = (props) => ({
  ...getParsedGeneral(props),

  cadastreNumber: props.cadastreNumber,
  buildingBTILetter: props.buildingBTILetter,
  buildingDMALetter: props.buildingDMALetter,
  lengthConstruction: props.lengthConstruction,
  widthConstruction: props.widthConstruction,
  heightConstruction: props.heightConstruction,
  diameterConstruction: props.diameterConstruction,
  weightConstruction: props.weightConstruction,
  volumeConstruction: props.volumeConstruction,
  usefullVolumeConstruction: props.usefullVolumeConstruction,
  totalConstructionSpace: props.totalConstructionSpace,
  constructionMaterial: getGuidsArray(props.constructionMaterial),
  constructionAddressNote: props.constructionAddressNote, // мне кажется этого поля нету на BE
});
