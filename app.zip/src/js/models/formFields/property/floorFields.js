import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';
import { isRequired, isPositiveInteger } from '../../../services/validator/rules';

const defaultValuableFields = ['guid', 'versionId'];
const getObjectGuid = (obj) => (obj ? obj.guid : null);

export const floorFields = {
  floorNumber: {
    field: 'floorNumber',
    name: 'Номер поверху',
    type: formItemTypes.INPUT,
    rules: [isRequired(), isPositiveInteger()],
  },
  // floorName: {
  //   field: 'floorName',
  //   name: 'Назва поверху',
  //   type: formItemTypes.INPUT,
  // },
  floorType: {
    field: 'floorType',
    name: 'Тип поверху за класифікатором',
    type: formItemTypes.SELECT,
    classifier: classifiers.CL_FLOOR,
    rules: [isRequired()],
    placeholder: 'Введіть тип поверху',
    valuableFields: [...defaultValuableFields, 'type'],
  },
  // Это костыль который придумали Паша и Андрей 29.11.2017
  // floorControl: {
  //   field: 'floorControl',
  //   name: 'Контроль поверху по приміщеннях',
  //   rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  //   type: formItemTypes.RADIO,
  //   classifier: classifiers.YES_NO
  // },
  floorLivingSpace: {
    field: 'floorLivingSpace',
    name: 'Загальна житлова площа, м.кв.',
    type: formItemTypes.INPUT,
    readOnly: true,
    rules: [],
  },
  floorUnlivingSpace: {
    field: 'floorUnlivingSpace',
    name: 'Загальна нежитлова площа, м.кв.',
    type: formItemTypes.INPUT,
    readOnly: true,
    rules: [],
  },
  floorTechSpace: {
    field: 'floorTechSpace',
    name: 'Загальна технічна площа, м.кв.',
    type: formItemTypes.INPUT,
    readOnly: true,
    rules: [],
  },
  floorCommonUseSpace: {
    field: 'floorCommonUseSpace',
    name: 'noName',
    type: formItemTypes.INPUT,
    rules: [],
    customRendered: true,
  },
  floorCommonSpace: {
    field: 'floorCommonSpace',
    name: 'Загальна площа загального кристування, м.кв.',
    type: formItemTypes.INPUT,
    readOnly: true,
    rules: [],
  },
};

export const getMappedForm = (props) => ({
  floorNumber: props.floorNumber,
  floorName: props.floorName,
  floorType: props.floorType,
  // true это костыль который придумали Паша и Андрей 29.11.2017
  floorControl: true, // props.floorControl
  floorLivingSpace: props.floorLivingSpace || 0,
  floorUnlivingSpace: props.floorUnlivingSpace || 0,
  floorTechSpace: props.floorTechSpace || 0,
  floorCommonUseSpace: props.floorCommonUseSpace || 0,
  floorCommonSpace: props.floorCommonSpace || 0,
});

export const getParsedForm = (props) => ({
  floorNumber: props.floorNumber,
  floorName: props.floorName,
  floorType: getObjectGuid(props.floorType),
  // это костыль который придумали Паша и Андрей 29.11.2017
  // floorControl: props.floorControl,
  floorLivingSpace: props.floorLivingSpace,
  floorUnlivingSpace: props.floorUnlivingSpace,
  floorTechSpace: props.floorTechSpace,
  floorCommonUseSpace: props.floorCommonUseSpace,
  floorCommonSpace: props.floorCommonSpace,
});
