import moment from 'moment';

import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';
import { createValueCreator } from '../../../helpers/formHelpers/dropdownValueCreators';
import { getObjGuid, getFEDate, defaultFilterOption } from '../../../helpers/commonUtils';
import {
  isRequired,
  isNumberWithTwoDecimal,
  isYearBetween,
} from '../../../services/validator/rules';

const createCounterpartyValue = createValueCreator('counterparty');
const createDocumentValue = createValueCreator('document');
const createObjectValue = createValueCreator('object');
const defaultValuableFields = ['guid', 'versionId'];

export const clStateProperty = {
  field: 'clStateProperty',
  name: "Тип об'єкту за КДМ",
  type: formItemTypes.SELECT,
  classifier: classifiers.STATE_PROPERTY_OF_ACCOUNTING_ITEM,
  placeholder: "Введіть тип об'єкту  за КДМ для пошуку",
  readOnly: true,
  valuableFields: [...defaultValuableFields, 'type'],
};

export const technicalState = {
  field: 'technicalState',
  name: 'Технічний стан',
  type: formItemTypes.SELECT,
  classifier: classifiers.CL_PHYSICAL_STATE,
  valuableFields: defaultValuableFields.concat('type'),
};

export const generalInfoFields = {
  clStateProperty,
  clPropertyStruct: {
    field: 'clPropertyStruct',
    name: "Тип об'єкту за КСК",
    type: formItemTypes.SELECT,
    classifier: classifiers.CL_PROPERTY_STRUCT,
    placeholder: "Введіть тип об'єкту  за КСК для пошуку",
    rules: [{ required: false, message: '' }],
    valuableFields: [...defaultValuableFields, 'type'],
    filter: defaultFilterOption,
  },
  fullName: {
    field: 'fullName',
    name: 'Повна назва',
    placeholder: "напр. 'Нежитлова будівля'",
    rules: [{ required: true, message: 'Поле обов`язкове для заповнення!' }],
    type: formItemTypes.INPUT,
  },
  address: {
    field: 'address',
    customRendered: true,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  dateFrom: {
    field: 'dateFrom',
    name: 'Дата побудови',
    type: formItemTypes.DATEPICKER,
    rules: [],
    disabledDate: (currDate) => currDate && currDate.valueOf() > moment().valueOf(),
  },
  shortName: {
    field: 'shortName',
    name: 'Коротка назва',
    placeholder: "напр. 'Неж. буд.'",
    type: formItemTypes.INPUT,
  },
  parentAccountingItem: {
    field: 'parentAccountingItem',
    name: "Батьківський об'єкт",
    type: formItemTypes.SELECT,
    classifier: classifiers.OBJECTS,
    colSpan: 12,
    readOnly: true,
    placeholder: "Введіть батьківський об'єкт для пошуку",
    valuableFields: defaultValuableFields,
  },
  dateTo: {
    field: 'dateTo',
    name: 'Дата ліквідації',
    type: formItemTypes.DATEPICKER,
    disabledDate: (currDate) => currDate && currDate.valueOf() > moment().valueOf(),
  },
  accountingItemId: {
    field: 'accountingItemId',
    name: 'Обліковий номер ООМ',
    placeholder: "напр. 'Нежитлова будівля'",
    type: formItemTypes.INPUT,
  },
  totalPeriodOfUsage: {
    field: 'totalPeriodOfUsage',
    name: 'Загальний строк корисного використання (років)',
    type: formItemTypes.INPUT,
  },
  clWriteOff: {
    field: 'clWriteOff',
    name: 'Шлях списання',
    type: formItemTypes.SELECT,
    classifier: classifiers.CL_WRITE_OFF,
    placeholder: 'Введіть шлях списання для пошуку',
    valuableFields: [...defaultValuableFields, 'type'],
  },
  notes: {
    field: 'notes',
    name: "Додатковий коментар щодо об'єкту",
    type: formItemTypes.TEXTAREA,
  },
  extraFeatureDescription: {
    field: 'extraFeatureDescription',
    name: 'Додатковий опис властивостей',
    type: formItemTypes.TEXTAREA,
  },
  // execStartDate: {
  //   field: 'execStartDate',
  //   name: 'Дата введення в експлуатацію',
  //   type: formItemTypes.DATEPICKER,
  //   readOnly: true
  // },
  // assetSpecialisation: {
  //   field: 'assetSpecialisation',
  //   name: 'Спеціалізація активу',
  //   type: formItemTypes.SELECT,
  //   classifier: classifiers.DOCUMENTS,
  //   colSpan: 24,
  //   valuableFields: defaultValuableFields,
  // },
  // physicalState: {
  //   field: 'physicalState',
  //   name: "Фізичний стан об'єкта",
  //   type: formItemTypes.SELECT,
  //   classifier: classifiers.DOCUMENTS,
  //   colSpan: 24,
  //   valuableFields: defaultValuableFields,
  // },
  // funkAccordance: {
  //   field: 'funkAccordance',
  //   name: "Функціональна відповідність об'єкта",
  //   type: formItemTypes.SELECT,
  //   classifier: classifiers.DOCUMENTS,
  //   colSpan: 24,
  //   valuableFields: defaultValuableFields,
  // },
  yearValidFrom: {
    field: 'yearValidFrom',
    name: 'Рік побудови',
    type: formItemTypes.SELECT,
    classifier: classifiers.YEARS,
    rules: [isYearBetween(1700, moment().year())],
    filter: defaultFilterOption,
  },
  assetSpecializationInput: {
    field: 'assetSpecializationInput',
    name: 'Призначення',
    type: formItemTypes.INPUT,
  },
  inventNumber: {
    field: 'inventNumber',
    name: 'Інвентарний номер',
    type: formItemTypes.INPUT,
    rules: [isRequired()],
  },
  firstCost: {
    field: 'firstCost',
    name: 'Первісна вартість (грн.)',
    type: formItemTypes.INPUT,
    rules: [isNumberWithTwoDecimal()],
  },
  endCost: {
    field: 'endCost',
    name: 'Залишкова вартість (грн.)',
    type: formItemTypes.INPUT,
    rules: [isNumberWithTwoDecimal()],
  },
  endCostDate: {
    field: 'endCostDate',
    name: 'Дата розрахунку залишкової вартості',
    type: formItemTypes.DATEPICKER,
  },
  execStartDate: {
    field: 'execStartDate',
    name: 'Дата введення в єксплуатацію',
    type: formItemTypes.DATEPICKER,
  },
  technicalState,
  funcAccordanceInput: {
    field: 'funcAccordanceInput',
    name: 'Функціональна відповідність',
    type: formItemTypes.INPUT,
  },
  decisionDocuments: {
    field: 'decisionDocuments',
    name: 'Рішення',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.DOCUMENTS,
    valuableFields: defaultValuableFields,
    colSpan: 24,
  },
  orderDocuments: {
    field: 'orderDocuments',
    name: 'Розпорядження/Наказ департаменту',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.DOCUMENTS,
    valuableFields: defaultValuableFields,
    colSpan: 24,
  },
  actDocuments: {
    field: 'actDocuments',
    name: 'Акт прийому',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.DOCUMENTS,
    valuableFields: defaultValuableFields,
    colSpan: 24,
  },
};

export const operationFields = {
  propertyObject: {
    field: 'propertyObject',
    name: "Майновий об'єкт",
    placeholder: "Введіть майновий об'єкт",
    rules: [{ required: true, message: "Поле обов'язкове для вибору" }],
    type: formItemTypes.SELECT,
    classifier: classifiers.OBJECTS,
    valuableFields: defaultValuableFields,
  },
  responsiblePerson: {
    field: 'responsiblePerson',
    name: 'Відповідальна особа',
    placeholder: 'Введіть відповідальну особу',
    rules: [{ required: false, message: '' }],
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.COUNTERPARTY,
    valuableFields: defaultValuableFields,
    counterpartyType: 'Person',
  },
  dateFrom: {
    field: 'dateFrom',
    name: 'Дата початку дії стану',
    type: formItemTypes.DATEPICKER,
    rules: [],
    disabledDate: (currDate) => currDate && currDate.valueOf() > moment().valueOf(),
  },
  dateTo: {
    field: 'dateTo',
    name: 'Дата закінчення дії стану',
    type: formItemTypes.DATEPICKER,
    rules: [{ required: false, message: '' }],
    disabledDate: (currDate) => currDate && currDate.valueOf() > moment().valueOf(),
  },
  reasonDocs: {
    field: 'reasonDocs',
    name: 'Підстава (документ)',
    placeholder: 'Введіть підставу',
    rules: [{ required: false, message: '' }],
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.DOCUMENTS,
    colSpan: 24,
    valuableFields: defaultValuableFields,
  },
  operationState: {
    field: 'operationState',
    name: 'Операціний стан',
    placeholder: 'Ввиберіть операційний стан',
    rules: [{ required: true, message: "Поле обов'язкове для вибору" }],
    type: formItemTypes.SELECT,
    classifier: classifiers.CL_OBJECTS_OPERATION_STATUS_TYPE,
    valuableFields: [...defaultValuableFields, 'type'],
  },
};
// 'clPropertyStruct'
// 'fullName'
// 'address'
// 'dateFrom'
// 'shortName'
// 'parentAccountingItem'
// 'dateTo'
// 'accountingItemId'
// 'totalPeriodOfUsage'
// 'clWriteOff'
// 'notes'
// 'extraFeatureDescription'
// 'clStateProperty'
// 'execStartDate'
// 'assetSpecialisation'
// 'physicalState'
// 'funkAccordance'
// 'propertyObject' ?????
// 'responsiblePerson'
// 'dateFrom'
// 'dateTo'
// 'reasonDocs'
// 'operationState'

export const getMappedForm = (props) => ({
  clPropertyStruct: props.clPropertyStruct,
  fullName: props.fullName,
  address: props.address || null,
  dateFrom: props.dateFrom,
  shortName: props.shortName,
  parentAccountingItem: props.parentAccountingItem,
  dateTo: props.dateTo,
  accountingItemId: props.accountingItemId,
  totalPeriodOfUsage: props.totalPeriodOfUsage,
  clWriteOff: props.clWriteOff,
  notes: props.notes,
  extraFeatureDescription: props.extraFeatureDescription,
  clStateProperty: props.clStateProperty,
  // execStartDate: props.execStartDate, BE expexcted to get document? but not date
  assetSpecialisation: props.assetSpecialisation,
  physicalState: props.physicalState,
  funkAccordance: props.funkAccordance,

  yearValidFrom: props.yearValidFrom,
  assetSpecializationInput: props.assetSpecializationInput,
  inventNumber: props.inventNumber,
  firstCost: props.firstCost,
  endCost: props.endCost,
  endCostDate: props.endCostDate,
  execStartDate: props.execStartDate,
  technicalState: props.technicalState,
  funcAccordanceInput: props.funcAccordanceInput,
  decisionDocuments: props.decisionDocuments,
  orderDocuments: props.orderDocuments,
  actDocuments: props.actDocuments,
});

export const getParsedForm = (props) => ({
  clStateProperty: getObjGuid(props.clStateProperty),
  clPropertyStruct: getObjGuid(props.clPropertyStruct),
  fullName: props.fullName,
  shortName: props.shortName,
  totalPeriodOfUsage: props.totalPeriodOfUsage,
  // execStartDate: undefined, // ???
  dateFrom: getFEDate(props.dateFrom),
  dateTo: getFEDate(props.dateTo),
  clWriteOff: getObjGuid(props.clWriteOff),
  notes: props.notes,
  extraFeatureDescription: props.extraFeatureDescription,
  parentAccountingItem: createObjectValue(props.parentAccountingItem), // батьківський об'єкт
  address: props.address,
  accountingItemId: props.accountingItemId,
  assetSpecialisation: createDocumentValue(props.assetSpecialisation),
  physicalState: createDocumentValue(props.physicalState),
  funkAccordance: createDocumentValue(props.physicalState),
  // curInvNumber: '64657' // ???

  yearValidFrom: props.yearValidFrom,
  assetSpecializationInput: props.assetSpecializationInput,
  inventNumber: props.inventNumber,
  firstCost: props.firstCost,
  endCost: props.endCost,
  endCostDate: getFEDate(props.endCostDate),
  execStartDate: getFEDate(props.execStartDate),
  technicalState: (props.technicalState || {}).guid,
  funcAccordanceInput: props.funcAccordanceInput,
  decisionDocuments: (props.decisionDocuments || []).map((el) => createDocumentValue(el)),
  orderDocuments: (props.orderDocuments || []).map((el) => createDocumentValue(el)),
  actDocuments: (props.actDocuments || []).map((el) => createDocumentValue(el)),
});

// not done
export const getMappedFormForOperations = (props) => ({
  objects: props.propertyObject,
  people: props.responsiblePerson || [],
  dateFrom: props.dateFrom,
  dateTo: props.dateTo,
  reasonDocs: props.reasonDocs || [],
  objectOperationStatusType: props.operationState,
});

export const getParsedFormForOperations = (props) => ({
  propertyObject: createObjectValue(props.objects),
  responsiblePerson: (props.people || []).map((el) => createCounterpartyValue(el)),
  dateFrom: typeof props.dateFrom === 'string' ? getFEDate(props.dateFrom) : props.dateFrom,
  dateTo: typeof props.dateTo === 'string' ? getFEDate(props.dateTo) : props.dateTo,
  reasonDocs: createDocumentValue(props.reasonDocs),
  operationState: getObjGuid(props.objectOperationStatusType),
});
