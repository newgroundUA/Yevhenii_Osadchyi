export const BUILDING_COLUMNS = [
  {
    title: 'Назва',
    dataIndex: 'name',
    key: 'name',
  },
  {
    title: 'Обліковий №',
    dataIndex: 'num',
    key: 'num',
  },
  {
    title: 'Літера БТІ',
    dataIndex: 'letterBTI',
    key: 'letterBTI',
  },
  {
    title: 'Поверхів',
    dataIndex: 'amountFloors',
    key: 'amountFloors',
  },
  {
    title: 'Груп приміщень',
    dataIndex: 'premiseGroup',
    key: 'premiseGroup',
  },
  {
    title: 'Приміщень',
    dataIndex: 'premises',
    key: 'premises',
  },
  {
    title: 'Ділянок',
    dataIndex: 'fields',
    key: 'fields',
  },
];

export const GENERAL_FLOORS_COLUMNS = [
  {
    title: '#',
    dataIndex: 'number',
    key: 'number',
  },
  // {
  //   title: 'Назва',
  //   dataIndex: 'name',
  //   key: 'name',
  // },
  {
    title: 'Тип',
    dataIndex: 'type',
    key: 'type',
  },
  {
    title: 'Житлова пл. (м.кв.)',
    dataIndex: 'livingSpace',
    key: 'livingSpace',
  },
  {
    title: 'Нежитлова пл. (м.кв.)',
    dataIndex: 'unLivingSpace',
    key: 'unLivingSpace',
  },
  {
    title: 'Корисна нежитлова пл. (м.кв.)',
    dataIndex: 'usefulUnLivingSpace',
    key: 'usefulUnLivingSpace',
  },
  {
    title: 'Технічна пл. (м.кв.)',
    dataIndex: 'technicalSpace',
    key: 'technicalSpace',
  },
  {
    title: 'Загального використання (м.кв.)',
    dataIndex: 'floorCommonSpace',
    key: 'floorCommonSpace',
  },
  {
    title: 'Груп приміщень',
    dataIndex: 'groupOfPremise',
    key: 'groupOfPremise',
  },
  {
    title: 'Приміщень',
    dataIndex: 'premises',
    key: 'premises',
  },
];

export const FLOOR_COLUMNS = [
  {
    title: 'Номер/Назва',
    dataIndex: 'number',
    key: 'number',
  },
  {
    title: 'К-сть груп',
    dataIndex: 'groupCount',
    key: 'groupCount',
  },
  {
    title: 'К-сть приміщень',
    dataIndex: 'premisesCount',
    key: 'premisesCount',
  },
  {
    title: 'Житлова пл. (м.кв.)',
    dataIndex: 'livingSpace',
    key: 'livingSpace',
  },
  {
    title: 'Нежитлова пл. (м.кв.)',
    dataIndex: 'unLivingSpace',
    key: 'unLivingSpace',
  },
  {
    title: 'Корисна нежитлова пл. (м.кв.)',
    dataIndex: 'usefulUnLivingSpace',
    key: 'usefulUnLivingSpace',
  },
  {
    title: 'Технічна пл. (м.кв.)',
    dataIndex: 'technicalSpace',
    key: 'technicalSpace',
  },
  {
    title: 'Загального використання (м.кв.)',
    dataIndex: 'socialUseSpace',
    key: 'socialUseSpace',
  },
];

export const GENERAL_PREMISE_COLUMNS = [
  {
    title: 'Код',
    dataIndex: 'code',
    key: 'code',
  },
  {
    title: 'Назва',
    dataIndex: 'name',
    key: 'name',
  },
  {
    title: 'Тип',
    dataIndex: 'type',
    key: 'type',
  },
  {
    title: 'Площа (м.кв.)',
    dataIndex: 'area',
    key: 'area',
  },
  {
    title: 'Корисна нежитлова пл. (м.кв.)',
    dataIndex: 'usefulUnLivingSpace',
    key: 'usefulUnLivingSpace',
  },
  {
    title: 'Загального використання (м.кв.)',
    dataIndex: 'socialUseSpace',
    key: 'socialUseSpace',
  },
  {
    title: 'Оздоблення',
    dataIndex: 'decoration',
    key: 'decoration',
  },
];

export const GROUP_OF_PREMISES = [
  {
    title: 'Номер/Назва',
    dataIndex: 'num',
    key: 'num',
  },
  {
    title: 'К-сть приміщень',
    dataIndex: 'premisesCount',
    key: 'premisesCount',
  },
  {
    title: 'Житлова пл. (м.кв.)',
    dataIndex: 'livingSpace',
    key: 'livingSpace',
  },
  {
    title: 'Нежитлова пл. (м.кв.)',
    dataIndex: 'unLivingSpace',
    key: 'unLivingSpace',
  },
  {
    title: 'Корисна нежитлова пл. (м.кв.)',
    dataIndex: 'usefulUnLivingSpace',
    key: 'usefulUnLivingSpace',
  },
];

export const GENERAL_PREMISES = [
  {
    title: 'Код',
    dataIndex: 'code',
    key: 'code',
  },
  {
    title: 'Назва',
    dataIndex: 'name',
    key: 'name',
  },
  {
    title: 'Тип',
    dataIndex: 'type',
    key: 'type',
  },
  {
    title: 'Площа (м.кв.)',
    dataIndex: 'area',
    key: 'area',
  },
  {
    title: 'Корисна нежитлова пл. (м.кв.)',
    dataIndex: 'usefulUnLivingSpace',
    key: 'usefulUnLivingSpace',
  },
  {
    title: 'Загального використання (м.кв.)',
    dataIndex: 'socialUseSpace',
    key: 'socialUseSpace',
  },
  {
    title: 'Оздоблення',
    dataIndex: 'decoration',
    key: 'decoration',
  },
];

export const PREMISES = [
  {
    title: 'Номер/Назва',
    dataIndex: 'num',
    key: 'num',
  },
  {
    title: 'Тип',
    dataIndex: 'type',
    key: 'type',
  },
  {
    title: 'Група',
    dataIndex: 'group',
    key: 'group',
  },
  {
    title: 'Площа (м.кв.)',
    dataIndex: 'area',
    key: 'area',
  },
  {
    title: 'Загального використання',
    dataIndex: 'socialUseSpaceBool',
    key: 'socialUseSpaceBool',
  },
  {
    title: 'Нежитлова пл. (м.кв.)',
    dataIndex: 'unLivingSpace',
    key: 'unLivingSpace',
  },
  {
    title: 'Загального використання (м.кв.)',
    dataIndex: 'socialUseSpace',
    key: 'socialUseSpace',
  },
  {
    title: 'Тип за призначенням',
    dataIndex: 'premisePurpose',
    key: 'premisePurpose',
  },
];

export const FIELDS = [
  {
    title: '№ частини приміщення',
    dataIndex: 'num',
    key: 'num',
  },
  {
    title: 'Назва частини приміщення',
    dataIndex: 'name',
    key: 'name',
  },
  {
    title: 'Площа (м.кв.)',
    dataIndex: 'area',
    key: 'area',
  },
  {
    title: 'Довжина',
    dataIndex: 'length',
    key: 'length',
  },
  {
    title: 'Ширина',
    dataIndex: 'width',
    key: 'width',
  },
  {
    title: 'Інфо щодо',
    dataIndex: 'info',
    key: 'info',
  },
];

export const FIELD = [
  {
    title: 'Назва',
    dataIndex: 'name',
    key: 'name',
  },
  {
    title: 'Обл.номер в ЕІС',
    dataIndex: 'num',
    key: 'num',
  },
  {
    title: 'Довжина (м.)',
    dataIndex: 'length',
    key: 'length',
  },
  {
    title: 'Ширина (м.)',
    dataIndex: 'width',
    key: 'width',
  },
  {
    title: 'Площа (м.кв.)',
    dataIndex: 'area',
    key: 'area',
  },
];
