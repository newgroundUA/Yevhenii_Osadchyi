import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';

import {
  getMappedForm as getMappedGeneral,
  getParsedForm as getParsedGeneral,
} from './generalFields';

const isObject = (obj) => (obj ? obj.guid : null);

export const pipelineFields = {
  // eslint-disable-line import/prefer-default-export
  pipelineLength: {
    field: 'pipelineLength',
    name: 'Довжина, м',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для заповнення!' }],
  },
  pipelineDiameter: {
    field: 'pipelineDiameter',
    name: 'Діаметр, м',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для заповнення!' }],
  },
  pipelineTubeClassifier: {
    field: 'pipelineTubeClassifier',
    name: 'Марка труб',
    type: formItemTypes.SELECT,
    classifier: classifiers.CL_PROPERTY_TUBE_CLASSIFIER,
    placeholder: 'Введіть дані для пошуку',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  pipelineHeight: {
    field: 'pipelineHeight',
    name: 'Висота зовнішнього монтажу, м',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для заповнення!' }],
  },
  pipelineDepth: {
    field: 'pipelineDepth',
    name: 'Глибина закладання, м',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для заповнення!' }],
  },
  pipelineTunnelDiameter: {
    field: 'pipelineTunnelDiameter',
    name: 'Діаметр тунеля, м',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для заповнення!' }],
  },
  pipelineTunnelVolume: {
    field: 'pipelineTunnelVolume',
    name: "Об'єм тунелю, м",
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для заповнення!' }],
  },
  pipelineWeight: {
    field: 'pipelineWeight',
    name: 'Маса опори, т',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для заповнення!' }],
  },
  pipelineTubeBaseMaterial: {
    field: 'pipelineTubeBaseMaterial',
    name: 'Матеріал опори',
    type: formItemTypes.SELECT,
    classifier: classifiers.CL_PROPERTY_TUBE_BASE_MATERIAL,
    placeholder: 'Введіть дані для пошуку',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  pipelineTubeTechnology: {
    field: 'pipelineTubeTechnology',
    name: 'Технологія прокладки труб',
    type: formItemTypes.SELECT,
    classifier: classifiers.CL_PROPERTY_TUBE_TEHNOLOGY,
    placeholder: 'Введіть дані для пошуку',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
};

export const getMappedForm = (props) => ({
  ...getMappedGeneral(props),
  pipelineLength: props.pipelineLength,
  pipelineDiameter: props.pipelineDiameter,
  pipelineTubeClassifier: props.pipelineTubeClassifier
    ? { guid: props.pipelineTubeClassifier }
    : null,
  pipelineHeight: props.pipelineHeight,
  pipelineDepth: props.pipelineDepth,
  pipelineTunnelDiameter: props.pipelineTunnelDiameter,
  pipelineTunnelVolume: props.pipelineTunnelVolume,
  pipelineWeight: props.pipelineWeight,
  pipelineTubeBaseMaterial: props.pipelineTubeBaseMaterial
    ? { guid: props.pipelineTubeBaseMaterial }
    : null,
  pipelineTubeTechnology: props.pipelineTubeTechnology
    ? { guid: props.pipelineTubeTechnology }
    : null,
});

export const getParsedForm = (props) => ({
  ...getParsedGeneral(props),
  pipelineLength: props.pipelineLength,
  pipelineDiameter: props.pipelineDiameter,
  pipelineTubeClassifier: isObject(props.pipelineTubeClassifier),
  pipelineHeight: props.pipelineHeight,
  pipelineDepth: props.pipelineDepth,
  pipelineTunnelDiameter: props.pipelineTunnelDiameter,
  pipelineTunnelVolume: props.pipelineTunnelVolume,
  pipelineWeight: props.pipelineWeight,
  pipelineTubeBaseMaterial: isObject(props.pipelineTubeBaseMaterial),
  pipelineTubeTechnology: props.pipelineTubeTechnology.guid,
});
