import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';
import { isRequired } from '../../../services/validator/rules';

const defaultValuableFields = ['guid', 'versionId'];

export const premiseGroupFields = {
  groupNumber: {
    field: 'groupNumber',
    name: 'Номер групи приміщень',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  groupName: {
    field: 'groupName',
    name: 'Назва групи приміщень',
    type: formItemTypes.INPUT,
  },
  premises: {
    field: 'premises',
    name: 'Приміщення в группі',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.PREMISE,
    rules: [isRequired()],
    valuableFields: defaultValuableFields,
  },
  groupControl: {
    field: 'groupControl',
    name: 'Контроль групи по приміщеннях',
    type: formItemTypes.RADIO,
    classifier: classifiers.YES_NO,
  },
  groupLivingSpace: {
    field: 'groupLivingSpace',
    name: 'Загальна житлова площа, м.кв.',
    type: formItemTypes.INPUT,
    rules: [{ required: false, message: 'Поле обов`язкове для вибору!' }],
  },
  groupUnlivingSpace: {
    field: 'groupUnlivingSpace',
    name: 'Загальна нежитлова площа, м.кв.',
    rules: [{ required: false, message: 'Поле обов`язкове для вибору!' }],
    type: formItemTypes.INPUT,
  },
  groupUsefullUnlivingSpace: {
    field: 'groupUsefullUnlivingSpace',
    name: 'Загальна корисна нежитлова площа, м.кв.',
    rules: [{ required: false, message: 'Поле обов`язкове для вибору!' }],
    type: formItemTypes.INPUT,
  },
  groupTechSpace: {
    field: 'groupTechSpace',
    name: 'Загальна технічна площа, м.кв.',
    type: formItemTypes.INPUT,
    rules: [{ required: false, message: 'Поле обов`язкове для вибору!' }],
  },
  groupCommonSpace: {
    field: 'groupCommonSpace',
    name: 'Загальна площа загального кристування, м.кв.',
    type: formItemTypes.INPUT,
  },
  floor: {
    field: 'floor',
    name: 'Поверх групи',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
};

export const getMappedForm = (props) => ({
  groupNumber: props.groupNumber,
  groupName: props.groupName,
  premises: props.premises,
  groupControl: props.groupControl,
  groupLivingSpace: props.groupLivingSpace || 0,
  groupUnlivingSpace: props.groupUnlivingSpace || 0,
  groupUsefullUnlivingSpace: props.groupUsefullUnlivingSpace || 0,
  groupTechSpace: props.groupTechSpace || 0,
  groupCommonSpace: props.groupCommonSpace || 0,
});

export const getParsedForm = (props) => ({
  groupNumber: props.groupNumber,
  groupName: props.groupName,
  premises: (props.premises || []).map((p) => p.guid),
  groupControl: props.groupControl,
  groupLivingSpace: props.groupLivingSpace,
  groupUnlivingSpace: props.groupUnlivingSpace,
  groupUsefullUnlivingSpace: props.groupUsefullUnlivingSpace,
  groupTechSpace: props.groupTechSpace,
  groupCommonSpace: props.groupCommonSpace,
});
