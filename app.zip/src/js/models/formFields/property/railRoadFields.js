import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';

import {
  getMappedForm as getMappedGeneral,
  getParsedForm as getParsedGeneral,
} from './generalFields';

export const railRoadFields = {
  railRoadLength: {
    field: 'railRoadLength',
    name: 'Довжина, м',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для заповнення!' }],
  },
  railRoadWidth: {
    field: 'railRoadWidth',
    name: 'Ширина колії, м',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для заповнення!' }],
  },
  railRoadHeight: {
    field: 'railRoadHeight',
    name: 'Висота (для мостів), м',
    type: formItemTypes.INPUT,
  },
  railRoadDept: {
    field: 'railRoadDept',
    name: 'Глибина (для тунелів), м',
    type: formItemTypes.INPUT,
  },
  railRoadTunnelDiameter: {
    field: 'railRoadTunnelDiameter',
    name: 'Діаметр (для тунелів), м',
    type: formItemTypes.INPUT,
  },
  railRoadTunnelVolume: {
    field: 'railRoadTunnelVolume',
    name: "Об'єм (для тунелів), м",
    type: formItemTypes.INPUT,
  },
  railRoadWeight: {
    field: 'railRoadWeight',
    name: 'Маса (для споруд), т',
    type: formItemTypes.INPUT,
  },
  railRoadTrackQty: {
    field: 'railRoadTrackQty',
    name: 'Кількість колій',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для заповнення!' }],
  },
  railRoadCrossQty: {
    field: 'railRoadCrossQty',
    name: 'Кількість переїздів',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для заповнення!' }],
  },
  railRoadTrackCrossQty: {
    field: 'railRoadTrackCrossQty',
    name: 'Кількість залізничних стрілок',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для заповнення!' }],
  },
  railRoadMaterial: {
    field: 'railRoadMaterial',
    name: 'Матеріал рейки',
    type: formItemTypes.SELECT,
    classifier: classifiers.REF_RAIL_ROAD_MATERIAL,
    placeholder: 'Введіть дані для пошуку',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  railRoadBalastMaterial: {
    field: 'railRoadBalastMaterial',
    name: 'Матеріал баластного шару',
    type: formItemTypes.SELECT,
    classifier: classifiers.REF_RAIL_ROAD_BALAST_MATERIAL,
    placeholder: 'Введіть дані для пошуку',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  railRoadSleepersMaterial: {
    field: 'railRoadSleepersMaterial',
    name: 'Матеріал шпал',
    type: formItemTypes.SELECT,
    classifier: classifiers.REF_RAIL_ROAD_SLEEPERS_MATERIAL,
    placeholder: 'Введіть дані для пошуку',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  railRoadTechnology: {
    field: 'railRoadTechnology',
    name: 'Технологія будівництва',
    type: formItemTypes.SELECT,
    classifier: classifiers.REF_RAIL_ROAD_TECHNOLOGY,
    placeholder: 'Введіть дані для пошуку',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
};

export const getMappedForm = (props) => ({
  ...getMappedGeneral(props),

  railRoadLength: props.railRoadLength,
  railRoadWidth: props.railRoadWidth,
  railRoadHeight: props.railRoadHeight,
  railRoadDept: props.railRoadDept,
  railRoadTunnelDiameter: props.railRoadTunnelDiameter,
  railRoadTunnelVolume: props.railRoadTunnelVolume,
  railRoadWeight: props.railRoadWeight,
  railRoadTrackQty: props.railRoadTrackQty,
  railRoadCrossQty: props.railRoadCrossQty,
  railRoadTrackCrossQty: props.railRoadTrackCrossQty,
  railRoadMaterial: { guid: props.railRoadMaterial },
  railRoadBalastMaterial: { guid: props.railRoadBalastMaterial },
  railRoadSleepersMaterial: { guid: props.railRoadSleepersMaterial },
  railRoadTechnology: { guid: props.railRoadTechnology },
});

export const getParsedForm = (props) => ({
  ...getParsedGeneral(props),

  railRoadLength: props.cadastreNumber,
  railRoadWidth: props.steadTotalSpace,
  railRoadHeight: props.steadTotalSpace,
  railRoadDept: props.steadTotalSpace,
  railRoadTunnelDiameter: props.steadTotalSpace,
  railRoadTunnelVolume: props.steadTotalSpace,
  railRoadWeight: props.steadTotalSpace,
  railRoadTrackQty: props.steadTotalSpace,
  railRoadCrossQty: props.steadTotalSpace,
  railRoadTrackCrossQty: props.steadTotalSpace,
  railRoadMaterial: props.railRoadMaterial.guid,
  railRoadBalastMaterial: props.railRoadBalastMaterial.guid,
  railRoadSleepersMaterial: props.railRoadSleepersMaterial.guid,
  railRoadTechnology: props.railRoadTechnology.guid,
});
