import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';

import {
  getMappedForm as getMappedGeneral,
  getParsedForm as getParsedGeneral,
} from './generalFields';

const getObjectGuid = (obj) => (obj ? obj.guid : null);
const defaultValuableFields = ['guid', 'versionId'];

export const premiseFields = {
  floor: {
    field: 'floor',
    name: 'Поверх',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
  groupOfPremise: {
    field: 'groupOfPremise',
    name: 'Група приміщень',
    type: formItemTypes.SELECT,
    classifier: classifiers.GROUP_OF_PREMISE,
    rules: [{ required: false, message: '' }],
    valuableFields: defaultValuableFields,
  },
  premiseSpace: {
    field: 'premiseSpace',
    name: 'Загальна площа приміщення, кв.м.',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  premisePurpose: {
    field: 'premisePurpose',
    name: 'Тип за призначенням',
    type: formItemTypes.SELECT,
    placeholder: 'Введіть дані для пошуку',
    classifier: classifiers.CL_PREMISE_PURPOSE,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
    valuableFields: [...defaultValuableFields, 'type'],
  },
  premiseConstruction: {
    field: 'premiseConstruction',
    name: 'Тип побудови',
    type: formItemTypes.SELECT,
    placeholder: 'Введіть дані для пошуку',
    classifier: classifiers.CL_PREMISE_CONSTRUCTION,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
    valuableFields: [...defaultValuableFields, 'type'],
  },
  usefullSpace: {
    field: 'usefullSpace',
    name: 'Корисна площа нежитлового приміщення, м.кв.',
    type: formItemTypes.INPUT,
    rules: [{ required: false, message: '' }],
  },
  commonUse: {
    field: 'commonUse',
    name: 'Приміщення загального користування',
    type: formItemTypes.RADIO,
    classifier: classifiers.YES_NO,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  premiseEquip: {
    field: 'premiseEquip',
    name: 'Оздоблення приміщення',
    type: formItemTypes.SELECT,
    placeholder: 'Введіть дані для пошуку',
    classifier: classifiers.CL_PREMISE_EQUIP,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
    valuableFields: [...defaultValuableFields, 'type'],
  },
};

export const getMappedForm = (props) => ({
  ...getMappedGeneral(props),
  groupOfPremise: props.groupOfPremise,
  premiseSpace: props.premiseSpace,
  premisePurpose: props.premisePurpose,
  premiseConstruction: props.premiseConstruction,
  usefullSpace: props.usefullSpace,
  commonUse: props.commonUse,
  premiseEquip: props.premiseEquip,
});

export const getParsedForm = (props) => ({
  ...getParsedGeneral(props),

  floor: props.floorName, // need to be renamed in container
  groupOfPremise: props.groupOfPremise && props.groupOfPremise.guid,
  premiseSpace: props.premiseSpace,
  premisePurpose: getObjectGuid(props.premisePurpose),
  premiseConstruction: getObjectGuid(props.premiseConstruction),
  usefullSpace: props.usefullSpace,
  commonUse: props.commonUse,
  premiseEquip: getObjectGuid(props.premiseEquip),
});
