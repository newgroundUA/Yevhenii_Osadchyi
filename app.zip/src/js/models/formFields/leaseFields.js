import * as formItemTypes from '../../constants/FormItemTypes';
import * as classifiers from '../../constants/ClassifiersNames';

export const objectsFields = {
  name: {
    field: 'name',
    name: 'Назва',
    type: formItemTypes.INPUT,
  },
  type: {
    field: 'type',
    name: 'Тип',
    type: formItemTypes.SELECT,
    classifier: classifiers.OBJECT_TYPE,
  },
  pm: {
    field: 'pm',
    name: 'ПМ',
    type: formItemTypes.INPUT,
  },
};

export default objectsFields;
