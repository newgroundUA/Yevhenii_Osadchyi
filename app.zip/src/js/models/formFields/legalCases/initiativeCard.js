import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';

export const generalInfoFields = {
  // eslint-disable-line import/prefer-default-export
  objectAddress: {
    field: 'objectAddress',
    name: "Адреса об'єкту",
    type: formItemTypes.SELECT,
    classifier: classifiers.OBJECT_ADDRESS,
    placeholder: 'Введіть адресу для пошуку',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  initiator: {
    field: 'initiator',
    name: 'Ініціатор',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    placeholder: 'Ініціатор',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  caseClasification: {
    field: 'caseClasification',
    name: 'Ініціатор',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    placeholder: 'Введіть назву для пошуку',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
};
