import moment from 'moment';
import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';
import { createValueCreator } from '../../../helpers/formHelpers/dropdownValueCreators';
import { createRequestForLegalProsessingDropDownValue } from '../../../helpers/entities/legalAffairs';
import { getFEDate } from '../../../helpers/commonUtils';

const createValue = createValueCreator('counterparty');
const createObjectValue = createValueCreator('object');
const DATE_FORMAT_BE = 'YYYY-MM-DD HH:mm:ss.SSS Z';
const DATE_FORMAT_FE = 'DD.MM.YYYY';
const DATE_TIME_FORMAT_FE = 'DD.MM.YYYY HH:mm:ss';
const isFeDate = (str) => /(0[1-9]|[12][0-9]|3[01])\.(0[1-9]|1[012])\.(19|20)\d\d/.test(str);
const getDate = (data) =>
  data ? moment(data, isFeDate(data) ? DATE_FORMAT_FE : DATE_FORMAT_BE) : null;
const getDateTime = (data) =>
  data ? moment(data, isFeDate(data) ? DATE_TIME_FORMAT_FE : DATE_FORMAT_BE) : null;
// const getObjGuidsArray = (arr) => (arr ? arr.map((guid) => ({ guid })) : undefined);
// const tansfToBEArr = (arr) => (arr ? arr.map((el) => ({ guid: el.key })) : undefined);

const defaultValuableFields = ['guid', 'versionId'];

const required = {
  required: true,
  message: 'Поле обов`язкове для вибору!',
};
// Параметри справи (на BE это LegalAffairs)
export const caseParameters = {
  legalAffairRegNumber: {
    field: 'legalAffairRegNumber',
    name: 'Реєстраційний номер справи',
    type: formItemTypes.INPUT,
    readOnly: true,
    placeholder: '',
    rules: [], // На создании - пустое, присваивается при удачном сохрании.
  },
  legalAffairCourtNumber: {
    field: 'legalAffairCourtNumber',
    name: 'Судовий номер справи',
    type: formItemTypes.INPUT,
    placeholder: 'Введіть cудовий номер справи',
    rules: [], // добавить валидацию на макс 10 символов!!!
  },
  legalAffairsStartDate: {
    field: 'legalAffairsStartDate',
    name: 'Дата відкриття справи',
    type: formItemTypes.DATEPICKER,
    placeholder: '',
    rules: [required],
  },
  legalAffairsEndDate: {
    field: 'legalAffairsEndDate',
    name: 'Дата закриття справи',
    type: formItemTypes.DATEPICKER,
    placeholder: '',
    rules: [],
  },
  startRequest: {
    field: 'startRequest',
    name: 'Запит на юр. провадження',
    type: formItemTypes.SELECT, // live search
    classifier: classifiers.REQUEST_FOR_LEGAL_PROCESSING,
    valuableFields: defaultValuableFields,
    placeholder: 'Введіть номер для пошуку',
    rules: [],
    processingStatuses: ['New', 'Analyzed', 'AfterTreatment'],
  },
  bailsman: {
    field: 'bailsman',
    name: 'Орган, який представляємо',
    type: formItemTypes.MULTISELECT, // live search
    classifier: classifiers.COUNTERPARTY,
    valuableFields: defaultValuableFields,
    placeholder: 'Виберіть документ',
    rules: [],
  },
  responsibleLawyer: {
    field: 'responsibleLawyer',
    name: 'Відповідальний юрист по справі',
    type: formItemTypes.SELECT, // live search
    classifier: classifiers.COUNTERPARTY,
    valuableFields: defaultValuableFields,
    counterpartyType: 'Person',
    placeholder: 'Виберіть документ',
    rules: [required],
  },
  legalAffairsType: {
    field: 'legalAffairsType',
    name: 'Класифікація справи',
    type: formItemTypes.SELECT,
    classifier: classifiers.CL_LEGAL_AFFAIRS_TYPE,
    valuableFields: defaultValuableFields.concat('type'),
    placeholder: 'Виберіть документ',
    rules: [required],
  },
  legalAffairPoints: {
    field: 'legalAffairPoints',
    name: 'Параметри справи: cуть справи (спору)',
    type: formItemTypes.TEXTAREA,
    placeholder: 'Виберіть документ',
    rules: [],
  },
};

export const parserCaseParametersToFE = (props) => ({
  guid: props.guid,
  legalAffairRegNumber: props.regNumber,
  legalAffairCourtNumber: props.courtNumber,
  legalAffairsStartDate: getFEDate(props.legalAffairsStartDate),
  legalAffairsEndDate: getFEDate(props.legalAffairsEndDate),
  startRequest:
    props.startRequest && createRequestForLegalProsessingDropDownValue(props.startRequest),
  bailsman: props.bailsman && createValue(props.bailsman),
  responsibleLawyer: props.responsibleLawyer && createValue(props.responsibleLawyer),
  legalAffairsType: props.legalAffairsType ? props.legalAffairsType.guid : null,
  legalAffairPoints: props.legalAffairPoints,
});

export const parserCaseParametersToBE = (props) => ({
  regNumber: props.legalAffairRegNumber,
  courtNumber: props.legalAffairCourtNumber,
  legalAffairsStartDate: props.legalAffairsStartDate,
  legalAffairsEndDate: props.legalAffairsEndDate,
  startRequest: props.startRequest,
  bailsman: props.bailsman,
  responsibleLawyer: props.responsibleLawyer,
  legalAffairsType: props.legalAffairsType,
  legalAffairPoints: props.legalAffairPoints,
});

// Сторони справи  (на BE это ___)
export const caseParties = {
  complainants: {
    field: 'complainants',
    name: 'Позивачі',
    type: formItemTypes.MULTISELECT, // live search
    classifier: classifiers.COUNTERPARTY,
    valuableFields: defaultValuableFields,
    // customRendered: true,
    placeholder: 'Виберіть контрагента',
    rules: [],
  },
  defendants: {
    field: 'defendants',
    name: 'Відповідачі',
    type: formItemTypes.MULTISELECT, // live search
    classifier: classifiers.COUNTERPARTY,
    valuableFields: defaultValuableFields,
    placeholder: 'Виберіть контрагента',
    rules: [],
  },
  thirdPartys: {
    field: 'thirdPartys',
    name: 'Третя сторона',
    type: formItemTypes.MULTISELECT, // live search
    classifier: classifiers.COUNTERPARTY,
    valuableFields: defaultValuableFields,
    // customRendered: true,
    placeholder: 'Виберіть контрагента',
    rules: [],
  },
  prosecutor: {
    field: 'prosecutor',
    name: 'Прокурор по справі',
    type: formItemTypes.SELECT, // live search
    classifier: classifiers.COUNTERPARTY, // Person only
    counterpartyType: 'Person',
    valuableFields: defaultValuableFields,
    placeholder: 'Виберіть контрагента',
    rules: [],
  },
};

export const parserCasePartiesToFE = (props) => ({
  guid: props.guid,
  complainants: createValue(props.complainants),
  defendants: createValue(props.defendants),
  thirdPartys: createValue(props.thirdPartys),
  prosecutor: createValue(props.prosecutor),
});

export const parserCasePartiesToBE = (props) => ({
  complainants: props.complainants,
  defendants: props.defendants,
  thirdPartys: props.thirdPartys,
  prosecutor: props.prosecutor,
});

export const caseObject = {
  accountingItems: {
    field: 'accountingItems',
    name: "Об'єкти запиту",
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.OBJECTS,
    valuableFields: defaultValuableFields,
    rules: [],
  },
};

export const parserCaseObjectToFE = (props) => ({
  guid: props.guid,
  accountingItems: createObjectValue(props.accountingItems),
});

export const parserCaseObjectToBE = (props) => ({
  accountingItems: props.accountingItems || [],
});

// Суди по справі  (на BE это ProceedingCourt)
export const caseCourt = {
  court1: {
    field: 'court1',
    name: 'Суд що розглядає справу',
    type: formItemTypes.SELECT, // live Search
    classifier: classifiers.COUNTERPARTY,
    placeholder: 'Виберіть контрагента',
    valuableFields: defaultValuableFields,
    // customRendered: true,
    rules: [required],
  },
  judges: {
    field: 'judges',
    name: 'Судді, що розглядають справу',
    type: formItemTypes.MULTISELECT, // live Search
    classifier: classifiers.COUNTERPARTY, // ФО
    counterpartyType: 'Person',
    valuableFields: defaultValuableFields,
    placeholder: 'Виберіть фіз. особу',
    // customRendered: true,
    rules: [],
  },
  courtInstanceLevel: {
    field: 'courtInstanceLevel',
    name: 'Рівень інстанції суду',
    type: formItemTypes.SELECT,
    classifier: classifiers.COURT_INSTANCE_LEVEL_ENUM,
    placeholder: 'Виберіть рівень інстанції',
    rules: [required],
  },
  proceedingStartDate: {
    field: 'proceedingStartDate',
    name: 'Дата початку розглядання',
    type: formItemTypes.DATEPICKER,
    rules: [required],
  },
  proceedingEndDate: {
    field: 'proceedingEndDate',
    name: 'Дата закінчення розглядання',
    type: formItemTypes.DATEPICKER,
    rules: [],
  },
};

export const parserCaseCourtToFE = (props) => ({
  guid: props.guid,
  court1: props.court ? createValue(props.court) : props.court1,
  judges: props.judges
    ? props.judges.map((el) => {
        if (el.label) return el;
        return { label: el.shortName, key: el.guid };
      })
    : [],
  courtInstanceLevel: props.courtInstanceLevel,
  proceedingStartDate: getDate(props.proceedingStartDate),
  proceedingEndDate: getDate(props.proceedingEndDate),
});

export const parserCaseCourtToBE = (props) => ({
  court: props.court1,
  judges: props.judges,
  courtInstanceLevel: props.courtInstanceLevel,
  proceedingStartDate: props.proceedingStartDate,
  proceedingEndDate: props.proceedingEndDate,
});

// Засідання суду  (на BE это CourtSessionPlanning)
export const courtHearing = {
  courtSessionDate: {
    field: 'courtSessionDate',
    name: 'Дата засідання',
    type: formItemTypes.DATE_TIME_PICKER,
    rules: [required],
  },
  // courtSessionTime: {
  //   field: 'courtSessionTime',
  //   name: 'Час засідання',
  //   type: formItemTypes.TIMEPICKER,
  //   rules: [required]
  // },
  courtSessionRoomNumber: {
    field: 'courtSessionRoomNumber',
    name: 'Номер кімнати (залу)',
    type: formItemTypes.INPUT,
    rules: [],
  },
  courtSessionStatus: {
    field: 'courtSessionStatus',
    name: 'Стасус засідання',
    type: formItemTypes.SELECT,
    classifier: classifiers.COURT_SESSION_STATUS_ENUM,
    rules: [],
  },
  court: {
    field: 'court',
    name: 'Суд',
    type: formItemTypes.SELECT, // live Search
    classifier: classifiers.COUNTERPARTY,
    placeholder: 'Виберіть контрагента',
    valuableFields: defaultValuableFields,
    // customRendered: true,
    rules: [required],
  },
  judjes: {
    field: 'judjes',
    name: 'Судді',
    type: formItemTypes.MULTISELECT, // live Search
    classifier: classifiers.COUNTERPARTY, // FO
    placeholder: 'Виберіть фіз. особу',
    counterpartyType: 'Person',
    valuableFields: defaultValuableFields,
    // customRendered: true,
    rules: [],
  },
  courtSessionNotes: {
    field: 'courtSessionNotes',
    name: 'Приміткі до засідання',
    type: formItemTypes.INPUT, // SELECT, // live Search
    rules: [],
  },
  representers: {
    field: 'representers',
    name: 'Наш представник на засіданні',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.COUNTERPARTY,
    placeholder: 'Виберіть фіз. особу',
    counterpartyType: 'Person',
    valuableFields: defaultValuableFields,
    // customRendered: true,
    rules: [],
  },
};

export const parserCourtHearingToFE = (props) => ({
  guid: props.guid,
  courtSessionDate: getDateTime(props.courtSessionDate),
  // courtSessionTime: getDate(props.courtSessionDate),
  courtSessionRoomNumber: props.courtSessionRoomNumber,
  courtSessionStatus: props.courtSessionStatus,
  court: props.court // eslint-disable-line
    ? props.court.label
      ? props.court
      : { label: props.court.fullName, key: props.court.guid }
    : null,
  judjes: props.judjes
    ? props.judjes.map((el) => {
        if (el.label) return el;
        return { label: el.shortName, key: el.guid };
      })
    : [],
  courtSessionNotes: props.courtSessionNotes,
  representers: props.representers
    ? props.representers.map((el) => {
        if (el.label) return el;
        return { label: el.shortName, key: el.guid };
      })
    : [],
});

export const parserCourtHearingToBE = (props) => ({
  courtSessionDate: props.courtSessionDate,
  // courtSessionDate: props.courtSessionTime,
  courtSessionRoomNumber: props.courtSessionRoomNumber,
  courtSessionStatus: props.courtSessionStatus,
  court: props.court,
  judjes: props.judjes,
  courtSessionNotes: props.courtSessionNotes,
  representers: props.representers,
});

// Об'єкти запиту  (на BE это AccountingItem)
export const objectsOfTheRequest = {
  accountingItemId: {
    readOnly: true,
    field: 'accountingItemId',
    name: 'Обліковий номер ООМ',
    type: formItemTypes.INPUT,
    rules: [],
  },
  clStateProperty: {
    readOnly: true,
    field: 'clStateProperty',
    name: 'Тип ООМ за КДМ',
    type: formItemTypes.INPUT,
    rules: [],
  },
  fullName: {
    readOnly: true,
    field: 'fullName',
    name: 'Повна назва ООМ',
    type: formItemTypes.INPUT,
    rules: [],
  },
  address: {
    readOnly: true,
    field: 'address',
    name: 'Адреса розташування',
    type: formItemTypes.INPUT,
    rules: [],
  },
};

export const parserObjectsOfTheRequestToFE = (props) => ({
  guid: props.guid,
  accountingItemId: props.accountingItemId || '', // должен быть какойто номер
  clStateProperty: props.stateProperty // clStatePropertyOfAccountingItem,
    ? props.stateProperty.name
    : null,
  fullName: props.fullName || props.fullname,
  adressGUID: props.address ? props.address.addressAsString : null,
});

// export const parserObjectsOfTheRequestToBE = (props) => ({
//   guid: props.accountingItemId,
//   clStatePropertyOfAccountingItem: props.statepropertytypeGUID,
//   fullName: props.fullName,
//   address: props.adressGUID
// });

// Этапи та документи  (на BE это LegalAffairsStages)
export const stagesAndDocuments = {
  stagesDoc: {
    field: 'stagesDoc',
    name: 'Документи по етапу',
    type: formItemTypes.MULTISELECT, // live search
    placeholder: 'Введіть назву документа',
    classifier: classifiers.DOCUMENTS,
    valuableFields: defaultValuableFields,
    colSpan: 24,
    rules: [required],
  },
  regDate: {
    field: 'regDate',
    name: 'Дата реєстрації',
    type: formItemTypes.DATEPICKER,
    rules: [required],
  },
  clLegalAffairsStagesType: {
    field: 'clLegalAffairsStagesType',
    name: 'Этап справи',
    type: formItemTypes.SELECT, // live search
    classifier: classifiers.CL_LEGAL_AFFAIRS_STAGES_TYPE,
    valuableFields: defaultValuableFields.concat('type'),
    placeholder: 'Введіть тип юр. справи',
    rules: [required],
  },
};

export const parserStagesAndDocumentsToFE = (props) => ({
  guid: props.guid,
  regDate: getDate(props.regDate),
  clLegalAffairsStagesType: props.clLegalAffairsStagesType
    ? props.clLegalAffairsStagesType.guid
    : null,
  stagesDoc: props.stagesDoc
    ? props.stagesDoc.map((el) => {
        if (el.label) return el;
        return { ...el, label: el.docNumber, key: el.guid };
      })
    : [],
});

export const parserStagesAndDocumentsToBE = (props) => ({
  regDate: props.regDate,
  clLegalAffairsStagesType: props.clLegalAffairsStagesType,
  stagesDoc: props.stagesDoc,
});

export const generalInfoFields = {
  objectAddress: {
    field: 'objectAddress',
    name: "Адреса об'єкту",
    type: formItemTypes.SELECT,
    classifier: classifiers.OBJECT_ADDRESS,
    placeholder: 'Введіть адресу для пошуку',
    rules: [required],
  },
  plaintiff: {
    field: 'plaintiff',
    name: 'Позивач',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    placeholder: 'Введіть назву контрагента для пошуку',
    rules: [required],
  },
  defendant: {
    field: 'defendant',
    name: 'Відповідач',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    placeholder: 'Введіть назву контрагента для пошуку',
    rules: [required],
  },
  thirdPerson: {
    field: 'thirdPerson',
    name: 'Третя особа',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    placeholder: 'Введіть назву контрагента для пошуку',
    rules: [required],
  },
  process: {
    field: 'process',
    name: 'Процес',
    type: formItemTypes.SELECT, // watta this
    classifier: classifiers.PROCESS,
    rules: [required],
  },
  state: {
    field: 'state',
    name: 'Етап',
    type: formItemTypes.SELECT, // watta this
    classifier: classifiers.STATE,
    rules: [required],
  },
  caseClasification: {
    field: 'caseClasification',
    name: 'Класифікація справи',
    type: formItemTypes.SELECT, // watta this
    classifier: classifiers.CASE_CLASIFICATION,
    rules: [required],
  },
  dateOfNextMeeting: {
    field: 'dateOfNextMeeting',
    name: 'Дата наступного засідання',
    type: formItemTypes.DATEPICKER,
    rules: [required],
  },
  timeOfNextMeeting: {
    field: 'timeOfNextMeeting',
    name: 'Час наступного засідання',
    type: formItemTypes.TIMEPICKER,
    rules: [required],
  },
  court: {
    field: 'court',
    name: 'Суд',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    rules: [required],
  },
  judge: {
    field: 'judge',
    name: 'Суддя',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    placeholder: 'Введіть назву контрагента для пошуку',
    rules: [required],
  },
  comments: {
    field: 'comments',
    name: 'Коментарі і пояснення',
    type: formItemTypes.TEXTAREA,
  },
  caseNumber: {
    field: 'caseNumber',
    name: 'Номер справи',
    type: formItemTypes.INPUT,
    rules: [required],
  },
  caseDate: {
    field: 'caseDate',
    name: 'Дата справи',
    type: formItemTypes.DATEPICKER,
    rules: [required],
  },
  processStartDate: {
    field: 'processStartDate',
    name: 'Початок процесу',
    type: formItemTypes.DATEPICKER,
    rules: [required],
  },
  processEndDate: {
    field: 'processEndDate',
    name: 'Закінчення процесу',
    type: formItemTypes.DATEPICKER,
    rules: [required],
  },
  bodiesInCourtCases: {
    field: 'bodiesInCourtCases',
    name: 'Органи, представництво інтересів яких у судових справах здійснюється',
    type: formItemTypes.MULTISELECT, // watta this
    classifier: classifiers.BODIES,
  },
  controlDate: {
    field: 'controlDate',
    name: 'Контрольна дата',
    type: formItemTypes.DATEPICKER,
    rules: [required],
  },
};
// процеси - описана форма для додавання нового рядка таблиці
export const processesTableFields = {
  plaintiff: {
    field: 'plaintiff',
    name: 'Позивач',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    placeholder: 'Введіть назву контрагента для пошуку',
    rules: [required],
  },
  defendant: {
    field: 'defendant',
    name: 'Відповідач',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    placeholder: 'Введіть назву контрагента для пошуку',
    rules: [required],
  },
  thirdPerson: {
    field: 'thirdPerson',
    name: 'Третя особа',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    placeholder: 'Введіть назву контрагента для пошуку',
    rules: [required],
  },
  claimRegDate: {
    field: 'claimRegDate',
    name: 'Дата реєстрації позову/ухвали судом',
    type: formItemTypes.DATEPICKER,
    rules: [required],
  },
  claimDate: {
    field: 'claimDate',
    name: 'Дата позову/ухвали',
    type: formItemTypes.DATEPICKER,
    rules: [required],
  },
  claimPrice: {
    field: 'claimPrice',
    name: 'Ціна позову (грн.)',
    type: formItemTypes.INPUT,
    rules: [required],
  },
  court: {
    field: 'court',
    name: 'Суд',
    type: formItemTypes.SELECT, // watta this
    classifier: classifiers.COUNTERPARTY,
  },
  judge: {
    field: 'judge',
    name: 'Суддя',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    placeholder: 'Введіть назву контрагента для пошуку',
  },
  changeDate: {
    field: 'changeDate',
    name: 'Дата зміни',
    type: formItemTypes.DATEPICKER,
    rules: [required],
  },
  claimSubject: {
    field: 'claimSubject',
    name: 'Предмет позову',
    type: formItemTypes.INPUT,
    rules: [required],
  },
  comment: {
    field: 'comment',
    name: 'Коментар',
    type: formItemTypes.TEXTAREA,
  },
};

export const stagesFields = {
  // UX not done yet
};

export const documentsFields = {
  incomingDocument: {
    field: 'incomingDocument',
    name: 'Вхідний документ',
    type: formItemTypes.SELECT,
    classifier: classifiers.DOCUMENTS,
    placeholder: 'Введіть назву документа для пошуку',
    rules: [],
  },
  outgoingDocument: {
    field: 'outgoingDocument',
    name: 'Вихідний документ',
    type: formItemTypes.SELECT,
    classifier: classifiers.DOCUMENTS,
    placeholder: 'Введіть назву документа для пошуку',
    rules: [],
  },
  statement: {
    field: 'statement',
    name: 'Заява',
    type: formItemTypes.SELECT,
    classifier: classifiers.DOCUMENTS,
    placeholder: 'Введіть назву документа для пошуку',
    rules: [],
  },
  inventory: {
    field: 'inventory',
    name: 'Інвентаризація',
    type: formItemTypes.SELECT,
    classifier: classifiers.INVENTORY,
    placeholder: 'Введіть назву документа для пошуку',
    rules: [],
  },
  contractWithSubjectOfValuationActivity: {
    field: 'contractWithSubjectOfValuationActivity',
    name: "Договір з суб'єктом оціночної діяльності",
    type: formItemTypes.SELECT,
    classifier: classifiers.DOCUMENTS,
    placeholder: 'Введіть назву документа для пошуку',
    rules: [],
  },
};
