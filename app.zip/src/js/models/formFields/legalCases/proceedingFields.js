import moment from 'moment';

import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';
import { createValueCreator } from '../../../helpers/formHelpers/dropdownValueCreators';

const DATE_FORMAT_BE = 'YYYY-MM-DD HH:mm:ss.SSS Z';
const getDate = (data) => (data ? moment(data, DATE_FORMAT_BE) : null);
const createValue = createValueCreator('counterparty');
const createDocumentValue = createValueCreator('document');
const createObjectValue = createValueCreator('object');
const defaultValuableFields = ['guid', 'versionId'];

export const formsFields = {
  requestStartDate: {
    field: 'requestStartDate',
    name: 'Дата запиту',
    type: formItemTypes.DATEPICKER,
    rules: [{ required: true, message: "Обов'язково для вводу!" }],
  },
  requestEndDate: {
    field: 'requestEndDate',
    name: 'Дата прийняття рішення',
    type: formItemTypes.DATEPICKER,
  },
  requestStatus: {
    field: 'requestStatus',
    name: 'Стан обробки запиту',
    type: formItemTypes.SELECT,
    classifier: classifiers.LEGAL_PROCESSING_STATUS_ENUM,
    rules: [{ required: true, message: "Обов'язково для вводу!" }],
  },
  requestInitiator: {
    field: 'requestInitiator',
    name: 'Контрагент ініціатор',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    valuableFields: defaultValuableFields,
  },
  requestAuthor: {
    field: 'requestAuthor',
    name: 'Автор запиту',
    type: formItemTypes.SELECT,
    rules: [{ required: true, message: "Обов'язково для вводу!" }],
    classifier: classifiers.COUNTERPARTY,
    counterpartyType: 'Person',
    valuableFields: defaultValuableFields,
  },
  requestResponsibleLawyer: {
    field: 'requestResponsibleLawyer',
    name: 'Відповідальний юрист по запиту',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    counterpartyType: 'Person',
    valuableFields: defaultValuableFields,
  },
  clLegalAffairsType: {
    field: 'clLegalAffairsType',
    name: 'Класифікація запиту',
    classifier: classifiers.CL_LEGAL_AFFAIRS_TYPE,
    type: formItemTypes.SELECT,
    valuableFields: defaultValuableFields.concat('type'),
  },
  requestDocuments: {
    field: 'requestDocuments',
    name: 'Документи до запиту',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.DOCUMENTS,
    valuableFields: defaultValuableFields,
    colSpan: 24,
  },
  requestNumber: {
    field: 'requestNumber',
    name: 'Номер запиту',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
  object: {
    field: 'object',
    name: "Об'єкт запиту",
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.OBJECTS,
    valuableFields: defaultValuableFields,
    // rules: [{ required: true, message: 'Об\'єкт повинен бути вказан!' }]
  },
};

export const tableFields = {
  object: {
    field: 'object',
    name: "Об'єкт запиту",
    type: formItemTypes.SELECT,
    classifier: classifiers.OBJECTS,
    // rules: [{ required: true, message: 'Об\'єкт повинен бути вказан!' }]
  },
};

export const getMappedForm = (props) => ({
  requestNumber: props.requestNumber,
  requestStartDate: props.requestStartDate,
  requestEndDate: props.requestEndDate,
  requestStatus: props.requestStatus,
  requestInitiator: props.requestInitiator,
  requestAuthor: props.requestAuthor,
  requestResponsibleLawyer: props.requestResponsibleLawyer,
  clLegalAffairs: props.clLegalAffairsType,
  requestDocuments: props.requestDocuments || [],
  accountingItems: props.object || [],
});

export const getParsedForm = (props) => ({
  requestNumber: props.requestNumber,
  requestStartDate: getDate(props.requestStartDate),
  requestEndDate: getDate(props.requestEndDate),
  requestStatus: props.requestStatus,
  requestInitiator: createValue(props.requestInitiator),
  requestAuthor: createValue(props.requestAuthor),
  requestResponsibleLawyer: createValue(props.requestResponsibleLawyer),
  clLegalAffairsType: (props.clLegalAffairs || {}).guid,
  requestDocuments: createDocumentValue(props.requestDocuments),
  object: createObjectValue(props.accountingItems),
});
