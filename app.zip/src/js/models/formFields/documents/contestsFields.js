import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';
import {
  getMappedForm as getMappedGeneral,
  getParsedForm as getParsedGeneral,
} from './generalFields';
import { createValueCreator } from '../../../helpers/formHelpers/dropdownValueCreators';

const createValue = createValueCreator('counterparty');
const createDocumentValue = createValueCreator('document');

const defaultValuableFields = ['guid', 'versionId'];

export const contestsFields = {
  leaseCompetition: {
    field: 'leaseCompetition',
    name: 'Протокол до конкурсу',
    type: formItemTypes.SELECT,
    placeholder: 'Виберіть протокол до конкурсу',
    classifier: classifiers.LEASE_UNUSED_COMPETITIONS,
    valuableFields: defaultValuableFields,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  observersList: {
    field: 'observersList',
    name: 'Перелік зацікавлених осіб',
    type: formItemTypes.INPUT,
    // classifier: classifiers.COUNTERPARTY,
    // valuableFields: defaultValuableFields.concat('counterpartyType'),
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  compresult: {
    field: 'compresult',
    name: 'Результат конкурсу',
    type: formItemTypes.INPUT,
  },
};

export const contestsTableFields = {
  compmembercardnumber: {
    field: 'compmembercardnumber',
    name: 'Номер картки учасника',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  startmembersbet: {
    field: 'startmembersbet',
    name: 'Стартова пропозиція учасника в пропозиції',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  maxmembersbet: {
    field: 'maxmembersbet',
    name: 'Максимальна пропозиція учасника на аукціоні',
    type: formItemTypes.INPUT,
  },
  contractqueuenumber: {
    field: 'contractqueuenumber',
    name: 'Черга укладання договору',
    type: formItemTypes.INPUT,
  },
  memberauctionstate: {
    field: 'memberauctionstate',
    name: 'Стан участі в торгах',
    type: formItemTypes.SELECT,
    classifier: classifiers.MEMBER_AUCTION_STATE,
    placeholder: 'Виберіть стан участі в торгах',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  memberauctionstatenotes: {
    field: 'memberauctionstatenotes',
    name: 'Примітка щодо стану',
    type: formItemTypes.INPUT,
  },
  compmember: {
    field: 'compmember',
    name: 'Контрагент учасник',
    type: formItemTypes.SELECT,
    placeholder: 'Виберіть контрагента учасника',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
    classifier: classifiers.COUNTERPARTY,
    counterpartyType: 'Person',
    valuableFields: defaultValuableFields,
  },
  compmemberrepresenter: {
    field: 'compmemberrepresenter',
    name: 'Представник контрагента учасника',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    valuableFields: defaultValuableFields,
    counterpartyType: 'Person',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
    placeholder: 'Виберіть представника контрагента учасника',
  },
  membercomppropositiondocs: {
    field: 'membercomppropositiondocs',
    name: 'Документи до пропозиції',
    type: formItemTypes.MULTISELECT,
    placeholder: 'Виберіть документи до пропозиції',
    classifier: classifiers.REF_DOCUMENT_TYPE_GENERAL_DOC_CLASSNAME,
    valuableFields: defaultValuableFields,
    colSpan: 24,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
};

export const parseContestMembers = (props) => ({
  compmembercardnumber: props.compMemberCardNumber,
  startmembersbet: props.startMembersBet,
  maxmembersbet: props.maxMembersBet,
  contractqueuenumber: props.contractQueueNumber,
  memberauctionstate: props.memberAuctionState, // TODO: it's enum or wtf?
  memberauctionstatenotes: props.memberAuctionStateNotes,
  compmember: createValue(props.compMember),
  compmemberrepresenter: createValue(props.compMemberRepresenter),
  membercomppropositiondocs: createDocumentValue(props.memberCompPropositionDocs),
});

export const mapContestMembers = (props) => ({
  compMemberCardNumber: props.compmembercardnumber,
  startMembersBet: props.startmembersbet,
  maxMembersBet: props.maxmembersbet,
  contractQueueNumber: props.contractqueuenumber,
  memberAuctionState: props.memberauctionstate,
  memberAuctionStateNotes: props.memberauctionstatenotes,
  compMember: props.compmember,
  compMemberRepresenter: props.compmemberrepresenter,
  memberCompPropositionDocs: props.membercomppropositiondocs,
});

export const getMappedForm = (props) => ({
  ...getMappedGeneral(props),
  observersList: props.observersList,
  compResult: props.compresult,
  leaseCompetition: props.leaseCompetition,
});

export const getParsedForm = (props) => ({
  ...getParsedGeneral(props),
  observersList: props.observersList,
  compresult: props.compResult,
  leaseCompetition: props.leaseCompetition && props.leaseCompetition.guid,
});
