import _get from 'lodash/get';
import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';
import { getFeDate, getCounterpartyString } from '../../../helpers/geters';
import EnumToLabelsMap from '../../../constants/EnumToLabelsMap';

const searchPlaceholder = 'Введіть мін. 3 символи для пошуку';

export const bindingByFoCounterpartyFields = {
  lastNameFo: {
    field: 'lastNameFo',
    name: 'Прізвище',
    type: formItemTypes.INPUT,
    placeholder: searchPlaceholder,
    colSpan: 6,
    className: 'labelOneRow',
  },
  fistNameFo: {
    field: 'fistNameFo',
    name: "Ім'я",
    type: formItemTypes.INPUT,
    placeholder: searchPlaceholder,
    colSpan: 6,
    className: 'labelOneRow',
  },
  middleNameFo: {
    field: 'middleNameFo',
    name: 'По-батькові',
    type: formItemTypes.INPUT,
    placeholder: searchPlaceholder,
    colSpan: 6,
    className: 'labelOneRow',
  },
  itnFo: {
    field: 'itnFo',
    name: 'ІПН',
    type: formItemTypes.INPUT,
    placeholder: searchPlaceholder,
    colSpan: 6,
    className: 'labelOneRow',
  },
};

export const bindingByFopCounterpartyFields = {
  lastNameFOP: {
    field: 'lastNameFOP',
    name: 'Прізвище',
    type: formItemTypes.INPUT,
    placeholder: searchPlaceholder,
    colSpan: 6,
    className: 'labelOneRow',
  },
  fistNameFop: {
    field: 'fistNameFop',
    name: "Ім'я",
    type: formItemTypes.INPUT,
    placeholder: searchPlaceholder,
    colSpan: 6,
    className: 'labelOneRow',
  },
  middleNameFop: {
    field: 'middleNameFop',
    name: 'По-батькові',
    type: formItemTypes.INPUT,
    placeholder: searchPlaceholder,
    colSpan: 6,
    className: 'labelOneRow',
  },
  itnFop: {
    field: 'itnFop',
    name: 'ІПН',
    type: formItemTypes.INPUT,
    placeholder: searchPlaceholder,
    colSpan: 6,
    className: 'labelOneRow',
  },
};

export const bindingByLegalCounterpartyFields = {
  fullName: {
    field: 'fullName',
    name: 'Назва',
    type: formItemTypes.INPUT,
    placeholder: searchPlaceholder,
    colSpan: 12,
    className: 'labelOneRow',
  },
  edrpou: {
    field: 'edrpou',
    name: 'ЄДРПОУ',
    type: formItemTypes.INPUT,
    placeholder: searchPlaceholder,
    colSpan: 12,
    className: 'labelOneRow',
  },
};

export const bindingByDocumentInfoFields = {
  docDescription: {
    field: 'docDescription',
    name: 'Опис',
    type: formItemTypes.INPUT,
    placeholder: searchPlaceholder,
    colSpan: 24,
    className: 'labelOneRow',
  },
  docSerialNumber: {
    field: 'docSerialNumber',
    name: 'Серія',
    type: formItemTypes.INPUT,
    placeholder: 'Введіть серію документа ',
    colSpan: 3,
    className: 'labelOneRow',
  },
  docNumber: {
    field: 'docNumber',
    name: 'Номер',
    type: formItemTypes.INPUT,
    placeholder: 'Введіть номер документа',
    colSpan: 3,
    className: 'labelOneRow',
  },
  validityStatus: {
    field: 'validityStatus',
    name: 'Чинність',
    type: formItemTypes.SELECT,
    placeholder: 'Всі',
    classifier: classifiers.DOCUMENT_VALIDITY_STATUS_ENUM,
    colSpan: 6,
    className: 'labelOneRow',
  },
  docDateFrom: {
    field: 'docDateFrom',
    name: 'Дата документа',
    type: formItemTypes.DATEPICKER,
    colSpan: 3,
    placeholder: 'дд.мм.рррр',
    className: 'labelOneRow',
  },
  docDateTo: {
    field: 'docDateTo',
    name: ' ',
    type: formItemTypes.DATEPICKER,
    placeholder: 'дд.мм.рррр',
    colSpan: 3,
    className: 'labelOneRow',
  },
};

export const liveSearchColumns = [
  {
    title: 'Тип документа',
    dataIndex: 'documentType',
  },
  {
    title: 'Серія та номер',
    dataIndex: 'docNumber',
  },
  {
    title: 'Чинність',
    dataIndex: 'validityStatus',
  },
  {
    title: 'Опис',
    dataIndex: 'docDescription',
    width: 300,
  },
  {
    title: 'Видавач',
    dataIndex: 'publisher',
  },
  {
    title: 'Дата',
    dataIndex: 'docDate',
  },
];

export const expandableColumns = [
  {
    title: "Тип зв'язку",
    dataIndex: 'header',
  },
];

export const getLiveSearchedDocumentToFE = (el) => ({
  ...el,
  savedBEDto: el, // for map this el in getBoundDocumentToFE
  documentType:
    el.documentType === 'Document'
      ? 'Загальний'
      : EnumToLabelsMap[classifiers.DOCUMENT_TYPE][el.documentType],
  docNumber: `${el.docSerialNumber || ''} ${el.docNumber || ''}`,
  validityStatus: EnumToLabelsMap[classifiers.DOCUMENT_VALIDITY_STATUS_ENUM][el.validityStatus],
  publisher: _get(el.publishers, ['0', 'fullName']),
  docDate: getFeDate(el.docDate),
});

export const getBoundDocumentToFE = (el, relationshipType) => ({
  ...el,
  docDate: getFeDate(el.docDate),
  docNumber: `${el.docSerialNumber || ''} ${el.docNumber || ''}`,
  documentType:
    el.documentType === 'Document'
      ? 'Загальний'
      : EnumToLabelsMap[classifiers.DOCUMENT_TYPE][el.documentType],
  relationshipType: EnumToLabelsMap[relationshipType.toUpperCase()],
  publisher:
    _get(el.publishers, ['0', 'fullName']) || getCounterpartyString(_get(el.publishers, ['0'])),
  validityStatus: EnumToLabelsMap[classifiers.DOCUMENT_VALIDITY_STATUS_ENUM][el.validityStatus],
  dataForActions: {
    guid: el.guid,
    documentType: el.documentType,
    relationshipType,
  },
});

export const getBoundToPropertyDocumentToFE = (documentData) => ({
  docDate: getFeDate(documentData.docDate),
  docNumber: `${documentData.docSerialNumber || ''} ${documentData.docNumber || ''}`,
  documentType:
    documentData.documentType === 'Document'
      ? 'Загальний'
      : EnumToLabelsMap[documentData.documentType],
  docDescription: documentData.docDescription,
  validityStatus:
    EnumToLabelsMap[classifiers.DOCUMENT_VALIDITY_STATUS_ENUM][documentData.validityStatus],
  dataForActions: {
    guid: documentData.guid,
    documentType: documentData.documentType,
  },
});
