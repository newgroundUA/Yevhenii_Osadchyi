import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';
import { createValueCreator } from '../../../helpers/formHelpers/dropdownValueCreators';

import {
  getMappedForm as getMappedGeneral,
  getParsedForm as getParsedGeneral,
} from './generalFields';

export const planLeaseBasePeriodStringMap = {
  HOURLY: 'Година',
  DAILY: 'День',
  MONTHLY: 'Місяць',
};

const createValue = createValueCreator('counterparty');
const createDocumentValue = createValueCreator('document');
const createObjectValue = createValueCreator('object');

const getArr = (fields = []) => fields.map((el) => el.guid);

const defaultValuableFields = ['guid', 'versionId'];

export const rentStatementFields = {
  applicant: {
    field: 'applicant',
    name: 'Заявник',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
    valuableFields: defaultValuableFields,
    customRendered: true,
  },
  applicantRepresenter: {
    field: 'applicantRepresenter',
    name: 'Керівник заявника',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
    valuableFields: defaultValuableFields,
    customRendered: true,
  },
  landLord: {
    field: 'landLord',
    name: 'Орендодавець',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
    valuableFields: defaultValuableFields,
    customRendered: true,
  },
  docsToApplication: {
    field: 'docsToApplication',
    name: 'Документи, що додаються',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.DOCUMENTS,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
    valuableFields: defaultValuableFields,
    colSpan: 24,
  },
};

export const rentStatementFieldsTableProperty = {
  planLeaseRateDirectory: {
    field: 'planLeaseRateDirectory',
    name: 'Цільове призначення',
    type: formItemTypes.MULTISELECT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
    valuableFields: defaultValuableFields.concat('type'),
    classifier: classifiers.LEASE_RATE_DIRECTORY,
  },
  planLeaseBasePeriod: {
    field: 'planLeaseBasePeriod',
    name: 'Режим оренди',
    type: formItemTypes.SELECT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
    classifier: classifiers.BASE_LEASE_PERIODS,
  },
  planLeaseBasePeriodString: {
    field: 'planLeaseBasePeriodString',
    name: 'Період',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
  planLeaseBasePeriodQuantity: {
    field: 'planLeaseBasePeriodQuantity',
    name: 'Кількість періодів',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
    type: formItemTypes.INPUT,
  },
  planLeaseTerm: {
    field: 'planLeaseTerm',
    name: 'Термін оренди',
    rules: [],
    type: formItemTypes.INPUT,
  },
  objectsInApplication: {
    field: 'objectsInApplication',
    name: "Майновий об'єкт в оренду",
    type: formItemTypes.SELECT,
    classifier: classifiers.OBJECTS,
    valuableFields: defaultValuableFields,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
};

export const rentStatementFieldsTableRent = {
  leaseObjects: {
    field: 'leaseObjects',
    name: "Об'єкт оренди в оренду",
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.LAND_LORDS_TO_LEASE_OBJECTS,
    valuableFields: defaultValuableFields,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  planLeaseRateDirectory: {
    field: 'planLeaseRateDirectory',
    name: 'Цільове призначення',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.LEASE_RATE_DIRECTORY,
    valuableFields: defaultValuableFields.concat('type'),
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  planLeaseBasePeriod: {
    field: 'planLeaseBasePeriod',
    name: 'Режим оренди',
    type: formItemTypes.SELECT,
    classifier: classifiers.BASE_LEASE_PERIODS,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  planLeaseBasePeriodString: {
    field: 'planLeaseBasePeriodString',
    name: 'Період',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
  planLeaseBasePeriodQuantity: {
    field: 'planLeaseBasePeriodQuantity',
    name: 'Кількість періодів',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  planLeaseTerm: {
    field: 'planLeaseTerm',
    name: 'Термін оренди',
    type: formItemTypes.INPUT,
    rules: [],
  },
  mainRenter: {
    field: 'mainRenter',
    name: 'Орендар по основному договору',
    type: formItemTypes.SELECT,
    rules: [],
    classifier: classifiers.COUNTERPARTY,
    valuableFields: defaultValuableFields,
  },
};

// FE to BE
export const getMappedForm = (props) => ({
  ...getMappedGeneral(props),

  applicant: props.applicant,
  applicantRepresenter: props.applicantRepresenter,
  landlord: props.landLord,
  docsToApplication: props.docsToApplication || [],

  objectsInApplicationToLeaseList: [],
  leaseObjectsInAppToLeaseList: [],
});

// BE to FE
export const getParsedForm = (props) => ({
  ...getParsedGeneral(props),

  applicant: createValue(props.applicant),
  applicantRepresenter: createValue(props.applicantRepresenter),
  landLord: createValue(props.landlord),
  docsToApplication: createDocumentValue(props.docsToApplication),
});

// FE to BE
export const getMappedFormForPropertyObjects = (props) => ({
  objectInApplication: props.objectsInApplication,
  leaseRateDirectory: props.planLeaseRateDirectory,
  planLeaseBasePeriod: props.planLeaseBasePeriod,
  planLeaseBasePeriodQuantity: props.planLeaseBasePeriodQuantity,
  planLeaseTerm: props.planLeaseTerm,
});

// BE to FE
export const getParsedFormForPropertyObjects = (props) => ({
  objectsInApplication: createObjectValue(props.objectInApplication),
  planLeaseRateDirectory: props.leaseRateDirectory ? getArr(props.leaseRateDirectory) : [],
  planLeaseBasePeriod: props.planLeaseBasePeriod,
  planLeaseBasePeriodString: planLeaseBasePeriodStringMap[props.planLeaseBasePeriod],
  planLeaseBasePeriodQuantity: props.planLeaseBasePeriodQuantity,
  planLeaseTerm: props.planLeaseTerm,
});

// FE to BE
export const getMappedFormForLeaseObjects = (props) => ({
  leaseObjects: props.leaseObjects,
  leaseRateDirectory: props.planLeaseRateDirectory,
  planLeaseBasePeriod: props.planLeaseBasePeriod,
  planLeaseBasePeriodQuantity: props.planLeaseBasePeriodQuantity,
  planLeaseTerm: props.planLeaseTerm,
  mainRenter: props.mainRenter,
});

// BE to FE
export const getParsedFormForLeaseObjects = (props) => ({
  leaseObjects: props.leaseObjects ? getArr(props.leaseObjects) : [],
  planLeaseRateDirectory: props.leaseRateDirectory ? getArr(props.leaseRateDirectory) : [],
  planLeaseBasePeriod: props.planLeaseBasePeriod,
  planLeaseBasePeriodString: planLeaseBasePeriodStringMap[props.planLeaseBasePeriod],
  planLeaseBasePeriodQuantity: props.planLeaseBasePeriodQuantity,
  planLeaseTerm: props.planLeaseTerm,
  ...(props.mainRenter ? { mainRenter: createValue(props.mainRenter) } : {}),
});
