import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';
import {
  getMappedForm as getMappedGeneral,
  getParsedForm as getParsedGeneral,
} from './generalFields';
import { createValueCreator } from '../../../helpers/formHelpers/dropdownValueCreators';
import { isRequired } from '../../../services/validator/rules';
import {
  LEASE_OBJECTS,
  PRIVATIZATION_OBJECTS,
} from '../../../constants/actionTypes/documents/DocumentsConstants';

const createCounterpartyValue = createValueCreator('counterparty');
const createDocumentValue = createValueCreator('document');
const createAccountingItemValue = createValueCreator('object');

const defaultValuableFields = ['guid', 'versionId'];

const getTotalSpace = (fieldName, obj) => (obj[fieldName] ? `(${obj[fieldName]} м. кв.)` : '');

export const getLeaseObjectName = (obj) =>
  `${obj.leaseObjectShortName || obj.leaseObjectFullName}, ${
    obj.leaseObjectAddress ? obj.leaseObjectAddress.addressAsString : ''
  } ${getTotalSpace('leaseObjectTotalSpace', obj)}`;

export const getPrivatizationObjectName = (obj) =>
  `${obj.privatObjectShortName || obj.privatObjectFullName}, ${
    obj.address ? obj.address.addressAsString : ''
  } ${getTotalSpace('privatObjectTotalSpace', obj)}`;

const getAssessObjectLabel = (obj) => {
  switch (obj.groupedObjectsType) {
    case LEASE_OBJECTS:
      return getLeaseObjectName(obj);
    case PRIVATIZATION_OBJECTS:
      return getPrivatizationObjectName(obj);
    default:
      return '';
  }
};

const getAssessObject = (obj) => ({
  key: obj.guid,
  label: getAssessObjectLabel(obj),
});

export const marketValueInformationFields = {
  counterpartyOwner: {
    field: 'counterpartyOwner',
    classifier: classifiers.COUNTERPARTY,
    name: 'Контрагент-власник',
    type: formItemTypes.SELECT,
    valuableFields: defaultValuableFields,
    rules: [],
  },
  counterpartyCharterer: {
    field: 'counterpartyCharterer',
    classifier: classifiers.COUNTERPARTY,
    name: 'Контрагент-замовник',
    type: formItemTypes.SELECT,
    valuableFields: defaultValuableFields,
    rules: [isRequired()],
  },
  counterpartyAppraiser: {
    field: 'counterpartyAppraiser',
    classifier: classifiers.COUNTERPARTY,
    name: 'Контрагент-оцінювач',
    type: formItemTypes.SELECT,
    valuableFields: defaultValuableFields,
    rules: [isRequired()],
  },
  counterpartyControllers: {
    field: 'counterpartyControllers',
    classifier: classifiers.COUNTERPARTY,
    name: 'Контрагент-контролер',
    type: formItemTypes.MULTISELECT,
    valuableFields: defaultValuableFields,
    rules: [isRequired()],
  },
  sertPriceDetect: {
    field: 'sertPriceDetect',
    name: "Сертіфікат суб'єкту оціночної діяльності",
    type: formItemTypes.SELECT,
    classifier: classifiers.DOCUMENTS,
    colSpan: 24,
    valuableFields: defaultValuableFields,
    rules: [],
  },
  evaluationAgreement: {
    field: 'evaluationAgreement',
    name: 'Договір про здійснення оцінки',
    type: formItemTypes.SELECT,
    classifier: classifiers.DOCUMENTS,
    colSpan: 24,
    valuableFields: defaultValuableFields,
    rules: [],
  },
  marketPriceDetectMethods: {
    field: 'marketPriceDetectMethods',
    name: 'Використані методичні підходи',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.MARKET_PRICE_DETECT_METHOD,
    valuableFields: defaultValuableFields.concat('type'),
    rules: [isRequired()],
  },
  groupedObjectsType: {
    field: 'groupedObjectsType',
    name: "Тип об'єкту",
    type: formItemTypes.RADIO,
    classifier: classifiers.GROUPED_OBJECTS_TYPE,
    defaultValue: LEASE_OBJECTS,
    colSpan: 24,
    rules: [isRequired()],
  },
  assessObject: {
    field: 'assessObject',
    name: "Об'єкт оцінки",
    type: formItemTypes.SEARCH_BOX,
    showSearch: true,
    optionFilterProp: false,
    labelInValue: true,
    mode: 'default',
    valuableFields: defaultValuableFields,
    rules: [isRequired()],
  },
  marketPriceDetectReasonDocs: {
    // document
    field: 'marketPriceDetectReasonDocs',
    name: 'Документ-підстава для визначення ринкової вартості',
    type: formItemTypes.SELECT,
    classifier: classifiers.DOCUMENTS,
    valuableFields: defaultValuableFields,
    colSpan: 24,
    rules: [isRequired()],
  },
  estimatedCostUAH: {
    field: 'estimatedCostUAH',
    name: 'Оціночна Вартість ФМО без ПДВ грн',
    type: formItemTypes.INPUT,
    rules: [isRequired()],
  },
  estimatedCostUSD: {
    field: 'estimatedCostUSD',
    name: 'Оціночна Вартість 1 квм ФМО без ПДВ, дл. США',
    type: formItemTypes.INPUT,
    rules: [],
  },
  goOLeaseRateDirectory: {
    // goOLeaseRateDirectory - this field BE name
    field: 'goOLeaseRateDirectory',
    name: 'Найбільш ефективне використання ФМО',
    type: formItemTypes.SELECT,
    classifier: classifiers.LEASE_RATE_DIRECTORY,
    valuableFields: defaultValuableFields.concat('type'),
    rules: [],
  },
};

export const marketValueOOMTableFields = {
  propertyObject: {
    field: 'propertyObject',
    name: "Фізичний майновий об'єкт",
    type: formItemTypes.SELECT,
    classifier: classifiers.OBJECTS,
    rules: [],
    valuableFields: defaultValuableFields,
  },
  objectEstimatedCostUAH: {
    field: 'objectEstimatedCostUAH',
    name: 'Оціночна Вартість ФМО без ПДВ грн',
    type: formItemTypes.INPUT,
    rules: [isRequired()],
  },
  objectEstimatedCostUSD: {
    field: 'objectEstimatedCostUSD',
    name: 'Оціночна Вартість 1 квм ФМО без ПДВ, дл. США',
    type: formItemTypes.INPUT,
    rules: [isRequired()],
  },
  objectMostEffectiveUse: {
    field: 'objectMostEffectiveUse',
    name: 'Найбільш ефективне використання ФМО',
    type: formItemTypes.SELECT,
    classifier: classifiers.LEASE_RATE_DIRECTORY,
    valuableFields: defaultValuableFields.concat('type'),
    rules: [],
  },
  objectNotes: {
    field: 'objectNotes',
    name: "Додатковий коментар щодо об'єкту",
    type: formItemTypes.TEXTAREA,
    rules: [isRequired()],
  },
};

export const parseAcountingItemWithMarketPriceListToBE = (props) => ({
  accountingItem: props.propertyObject,
  accountingItemMarketPrice: props.objectEstimatedCostUAH,
  accountItemMarketPriceForOneSqm: props.objectEstimatedCostUSD,
  mostEffectiveUse: props.objectMostEffectiveUse,
  notes: props.objectNotes,
});

export const parseAcountingItemWithMarketPriceListToFE = (props) => ({
  propertyObject: createAccountingItemValue(props.accountingItem),
  objectEstimatedCostUAH: props.accountingItemMarketPrice,
  objectEstimatedCostUSD: props.accountItemMarketPriceForOneSqm,
  objectMostEffectiveUse: props.mostEffectiveUse ? props.mostEffectiveUse.guid : null,
  objectNotes: props.notes,
});

// map to BE
export const getMappedForm = (props) => ({
  ...getMappedGeneral(props),
  counterpartyOwner: props.counterpartyOwner,
  counterpartyCharterer: props.counterpartyCharterer,
  counterpartyAppraiser: props.counterpartyAppraiser,
  counterpartyControllers: props.counterpartyControllers,
  // sertPriceDetect: props.sertPriceDetect,
  // evaluationAgreement: props.evaluationAgreement,
  marketPriceDetectMethods: props.marketPriceDetectMethods,
  goOAssessmentCost: props.estimatedCostUAH,
  marketPriceDetectReasonDocs: [props.marketPriceDetectReasonDocs],
  // estimatedCostUSD: props.estimatedCostUSD,
  goOLeaseRateDirectory: props.goOLeaseRateDirectory,
});

// parse to FE
export const getParsedForm = (props) => ({
  ...getParsedGeneral(props),
  counterpartyOwner: createCounterpartyValue(props.counterpartyOwner),
  counterpartyCharterer: createCounterpartyValue(props.counterpartyCharterer),
  counterpartyAppraiser: createCounterpartyValue(props.counterpartyAppraiser),
  counterpartyControllers: createCounterpartyValue(props.counterpartyControllers),
  // sertPriceDetect: createDocumentValue(props.sertPriceDetect),
  // evaluationAgreement: createDocumentValue(props.evaluationAgreement),
  assessObject: props.assessObject && getAssessObject(props.assessObject),
  groupedObjectsType: props.assessObject && props.assessObject.groupedObjectsType,
  marketPriceDetectMethods: props.marketPriceDetectMethods
    ? props.marketPriceDetectMethods.map((el) => el.guid)
    : [],
  marketPriceDetectReasonDocs: createDocumentValue(props.marketPriceDetectReasonDocs[0]),
  estimatedCostUAH: props.goOAssessmentCost,
  // estimatedCostUSD: props.estimatedCostUSD,
  goOLeaseRateDirectory: props.goOLeaseRateDirectory ? props.goOLeaseRateDirectory.guid : null,
});
