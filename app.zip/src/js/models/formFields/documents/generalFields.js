import moment from 'moment';
// import _get from 'lodash/get'

import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';
import { createValueCreator } from '../../../helpers/formHelpers/dropdownValueCreators';
// import {
// getGuidsArray,
// makeGuidVersionStr
// } from '../../../helpers/formHelpers/formHelpers';

const DATE_FORMAT_BE = 'YYYY-MM-DD HH:mm:ss.SSS Z';
export const getDate = (data) => (data ? moment(data, DATE_FORMAT_BE) : null);
// const getObject = (value) => (value ? { guid: value } : null);
const createValue = createValueCreator('counterparty');
// const createDocumentValue = createValueCreator('document');

const defaultValuableFields = ['guid', 'versionId'];

// [DKV-1860]
export const generalFields = {
  refDocumentType: {
    //   field: 'refDocumentType',
    //   name: 'Тип документа',
    //   type: formItemTypes.SELECT,
    //   rules: [{ required: true, message: 'Виберіть тип документа!' }],
    classifier: classifiers.REF_DOCUMENT_TYPE_GENERAL_DOC_CLASSNAME,
    valuableFields: defaultValuableFields.concat('type'),
  },
  docRegNumber: {
    field: 'docRegNumber',
    name: 'Внутрішній реєстраційний номер',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вводу!' }],
  },
  docRegDate: {
    field: 'docRegDate',
    name: 'Дата реєстрації',
    type: formItemTypes.DATEPICKER,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
    disabledDate: (currDate) => currDate && currDate.valueOf() > moment().valueOf(),
  },
  docdescription: {
    field: 'docdescription',
    name: 'Опис',
    type: formItemTypes.INPUT,
    colSpan: 12,
    rules: [{ required: true, message: 'Поле обов`язкове для вводу!' }],
  },
  validityStatus: {
    field: 'validityStatus',
    name: 'Чинність',
    type: formItemTypes.SELECT,
    defaultValue: 'Valid',
    readOnly: true,
    classifier: classifiers.DOCUMENT_VALIDITY_STATUS_ENUM,
  },
  counterpartyRecipients: {
    field: 'counterpartyRecipients',
    name: 'Отримувач',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.COUNTERPARTY,
    valuableFields: defaultValuableFields.concat('counterpartyType'),
  },
  docReceptionist: {
    field: 'docReceptionist',
    name: 'Реєстратор',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    valuableFields: defaultValuableFields.concat('counterpartyType'),
  },
  counterpartyPublishers: {
    field: 'counterpartyPublishers',
    name: 'Видавач',
    type: formItemTypes.MULTISELECT,
    rules: [
      {
        required: true,
        message: 'Поле обов`язкове для вибору!',
      },
    ],
    classifier: classifiers.COUNTERPARTY,
    valuableFields: defaultValuableFields.concat('counterpartyType'),
  },
  docNumber: {
    field: 'docNumber',
    name: 'Номер',
    type: formItemTypes.INPUT,
    rules: [
      {
        required: true,
        message: 'Поле обов`язкове для вибору!',
      },
    ],
  },
  docSerialNumber: {
    field: 'docSerialNumber',
    name: 'Серія',
    type: formItemTypes.INPUT,
  },
  docWwwPage: {
    field: 'docWwwPage',
    name: 'Веб-посилання',
    type: formItemTypes.INPUT,
  },
  docCreator: {
    field: 'docCreator',
    name: 'Автор',
    // readOnly: true,
    type: formItemTypes.SELECT,
    rules: [
      {
        required: true,
        message: 'Поле обов`язкове для вибору!',
      },
    ],
    classifier: classifiers.COUNTERPARTY,
    valuableFields: defaultValuableFields.concat('counterpartyType'),
  },
  dvalidfrom: {
    field: 'dvalidfrom',
    name: 'Дійсний з',
    type: formItemTypes.DATEPICKER,
    rules: [
      {
        required: true,
        message: 'Поле обов`язкове для вибору!',
      },
    ],
    disabledDate: (currDate) => currDate && currDate.valueOf() > moment().valueOf(),
  },
  dvalidtill: {
    field: 'dvalidtill',
    name: 'Дійсний по',
    type: formItemTypes.DATEPICKER,
    readOnly: true,
    disabledDate: (currDate) => currDate && currDate.valueOf() < moment().valueOf(),
  },
  docDate: {
    field: 'docDate',
    name: 'Дата документа',
    type: formItemTypes.DATEPICKER,
    rules: [
      {
        required: true,
        message: 'Поле обов`язкове для вибору!',
      },
    ],
    disabledDate: (currDate) => currDate && currDate.valueOf() > moment().valueOf(),
  },
  reason: {
    field: 'reason',
    name: 'Причина блокування',
    type: formItemTypes.INPUT,
    readOnly: true,
  },
  // counterpartyOwner: {
  //   field: 'counterpartyOwner',
  //   name: 'Контрагент-власник документа',
  //   type: formItemTypes.SELECT,
  //   classifier: classifiers.COUNTERPARTY,
  //   valuableFields: defaultValuableFields.concat('counterpartyType')
  // },

  // docfileaddres: {
  //   field: 'docfileaddres',
  //   name: 'Посилання на файл',
  //   type: formItemTypes.SELECT,
  //   classifier: classifiers.WEBSITELIST
  // },
};

export const generalFieldsForComponentDocuments = {
  refDocumentType: {
    field: 'refDocumentType',
    name: 'Тип документа',
    type: formItemTypes.SELECT,
    rules: [{ required: true, message: 'Виберіть тип документа!' }],
    classifier: classifiers.REF_DOCUMENT_TYPE_GENERAL_DOC_CLASSNAME,
  },
  docRegNumber: {
    field: 'docRegNumber',
    name: 'Внутрішній реєстраційний номер',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вводу!' }],
  },
  docSerialNumber: {
    field: 'docSerialNumber',
    name: 'Серія',
    type: formItemTypes.INPUT,
  },
  docNumber: {
    field: 'docNumber',
    name: 'Номер документа',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  docDate: {
    field: 'docDate',
    name: 'Дата документа',
    type: formItemTypes.DATEPICKER,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
    disabledDate: (currDate) => currDate && currDate.valueOf() > moment().valueOf(),
  },
  counterpartyPublisherGUID: {
    field: 'counterpartyPublisherGUID',
    name: 'Контрагент-видавач документа',
    type: formItemTypes.INPUT,
    customRendered: true,
  },
  docWWWPage: {
    field: 'docWWWPage',
    name: 'Веб-посилання',
    type: formItemTypes.INPUT, // был SELECT
    // classifier: classifiers.WEBSITELIST
  },
  // docfileaddres: {
  //   field: 'docfileaddres',
  //   name: 'Посилання на файл',
  //   type: formItemTypes.SELECT,
  //   classifier: classifiers.WEBSITELIST
  // },
  dvalidfrom: {
    field: 'dvalidfrom',
    name: 'Дійсний з',
    type: formItemTypes.DATEPICKER,
  },
  dvalidtill: {
    field: 'dvalidtill',
    name: 'Дійсний по',
    type: formItemTypes.DATEPICKER,
  },
};

export const getParsedForComponentDocuments = (props) => ({
  refDocumentType: props.refDocumentType ? props.refDocumentType.guid : '',
  docRegNumber: props.docRegNumber,
  docSerialNumber: props.docSerialNumber,
  docNumber: props.docNumber,
  docDate: getDate(props.docDate),
  counterpartyPublisherGUID: props.counterpartyPublishers.reduce(
    (prev, curr, index, arr) => `
    ${prev}${curr}${index !== arr.length - 1 ? ', ' : '.'}`,
    '',
  ),
  docWWWPage: props.docWWWPage,
  // docfileaddres: props.fileStorage, // неточно
  dvalidfrom: getDate(props.dateFrom),
  dvalidtill: getDate(props.dateTo),
});

export const getMappedForm = (props) => ({
  // refDocumentType: props.refDocumentType,
  docRegNumber: props.docRegNumber,
  docRegDate: props.docRegDate,
  docSerialNumber: props.docSerialNumber,
  docNumber: props.docNumber,
  docDate: props.docDate,
  docCreator: props.docCreator,
  docReceptionist: props.docReceptionist,
  counterpartyPublishers: props.counterpartyPublishers || [],
  // counterpartyOwner: props.counterpartyOwner,
  counterpartyRecipients: props.counterpartyRecipients || undefined,
  docDescription: props.docdescription,
  docWWWPage: props.docWWWPage || undefined,
  // docfileaddres: props.docfileaddres,
  reason: props.reason,
  validityStatus: props.validityStatus, // array of strings here
  // parentDocument: props.parentdocumentGUID, TODO take from redux
  // childrenDocuments: props.childrendocumentGUID || [],
  // linkedDocuments: props.linkeddocumentsGUID || [],
  dateFrom: props.dvalidfrom,
  dateTo: props.dvalidtill,
  // fileStorage: props.fileStorage || []
  // position creator
  // positionReceptionist
});

export const getParsedForm = (props) => ({
  // refDocumentType: makeGuidVersionStr(props.refDocumentType),
  docRegNumber: props.docRegNumber,
  docRegDate: getDate(props.docRegDate),
  docSerialNumber: props.docSerialNumber,
  docNumber: props.docNumber,
  docDate: getDate(props.docDate),
  docCreator: createValue(props.docCreator),
  docReceptionist: createValue(props.docReceptionist),
  counterpartyPublishers: createValue(props.counterpartyPublishers) || [],
  // counterpartyOwner: createValue(props.counterpartyOwner),
  counterpartyRecipients: createValue(props.counterpartyRecipients) || [],
  docdescription: props.docDescription,
  docWWWPage: props.docWWWPage || undefined,
  // docfileaddres: (props.docfileaddres || {}).guid,
  validityStatus: props.validityStatus,
  dvalidfrom: getDate(props.dateFrom),
  reason: props.reason,
  dvalidtill: getDate(props.dateTo),
  // position creator
  // positionReceptionist
  // fileStorage
});
