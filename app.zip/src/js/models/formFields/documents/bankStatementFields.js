import moment from 'moment';

import {
  getMappedForm as getMappedGeneral,
  getParsedForm as getParsedGeneral,
} from './generalFields';

import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';
import { createValueCreator } from '../../../helpers/formHelpers/dropdownValueCreators';
import { isRequired, isNumberWithTwoDecimal } from '../../../services/validator/rules';
import { defaultFilterOption } from '../../../helpers/commonUtils';

const DATE_FORMAT_BE = 'YYYY-MM-DD HH:mm:ss.SSS Z';
const getDate = (data) => (data ? moment(data, DATE_FORMAT_BE) : null);
const createValue = createValueCreator('counterparty');
const createDocumentValue = createValueCreator('document');

export const parseBankStatementToFE = (props) => ({
  ...getParsedGeneral(props),
});

export const parseBankStatementToBE = (props) => getMappedGeneral(props);

const defaultValuableFields = ['guid', 'versionId'];

export const receivedMoneyFields = {
  incomingPaymentOrderNum: {
    field: 'incomingPaymentOrderNum',
    name: 'Номер платіжного доручення',
    type: formItemTypes.INPUT,
    placeholder: 'Введіть номер платіжного доручення',
    rules: [isRequired()],
  },
  paymentDescription: {
    field: 'paymentDescription',
    name: 'Призначення платежу',
    type: formItemTypes.TEXTAREA,
    placeholder: 'Введіть призначення платежу',
    rules: [isRequired()],
  },
  moneyAmountReceived: {
    field: 'moneyAmountReceived',
    name: 'Сума отриманих коштів',
    type: formItemTypes.INPUT,
    placeholder: 'Введіть суму отриманих коштів',
    rules: [isRequired(), isNumberWithTwoDecimal()],
  },
  pdv: {
    field: 'pdv',
    name: 'З ПДВ',
    defaultValue: true,
    checkedChildren: 'Так',
    unCheckedChildren: 'Hі',
    colSpan: 2,
    type: formItemTypes.SWITCH,
  },
  pdvSum: {
    field: 'pdvSum',
    name: 'Сума ПДВ',
    colSpan: 4,
    type: formItemTypes.INPUT,
    defaultValue: 0,
    readOnly: true,
  },
  incomingPaymentOrderDate: {
    field: 'incomingPaymentOrderDate',
    name: 'Дата платіжного доручення',
    type: formItemTypes.DATEPICKER,
    disabledDate: (currDate) => currDate && currDate.valueOf() > moment().valueOf(),
    rules: [isRequired()],
  },
  moneyEnlistmentDate: {
    field: 'moneyEnlistmentDate',
    name: 'Дата зарахування коштів',
    type: formItemTypes.DATEPICKER,
    rules: [isRequired()],
  },
  incomingPaymentOrderBankReceivedDate: {
    field: 'incomingPaymentOrderBankReceivedDate',
    name: 'Дата надходження платіжного доручення',
    type: formItemTypes.DATEPICKER,
  },
  incomingPaymentBankOperationNum: {
    field: 'incomingPaymentBankOperationNum',
    name: 'Номер операційного платежу',
    type: formItemTypes.INPUT,
  },
  moneyReceiverGuid: {
    field: 'moneyReceiverGuid',
    name: 'Контрагент-отримувач платежів в документі',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    valuableFields: defaultValuableFields,
    rules: [isRequired()],
    customRendered: true,
  },
  moneySenderGuid: {
    field: 'moneySenderGuid',
    name: 'Контрагент-платник',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    valuableFields: defaultValuableFields,
    rules: [isRequired()],
    customRendered: true,
  },
  paymentState: {
    field: 'paymentState',
    name: 'Стан',
    type: formItemTypes.SELECT,
    classifier: classifiers.PAYMENT_STATE,
    readOnly: true,
  },
};

export const parseReceivedMoneyToBE = (props) => ({
  incomingPaymentOrderNum: props.incomingPaymentOrderNum,
  incomingPaymentBankOperationNum: props.incomingPaymentBankOperationNum,
  paymentDescription: props.paymentDescription,
  moneyAmountReceived: props.moneyAmountReceived,

  incomingPaymentOrderBankReceivedDate: props.incomingPaymentOrderBankReceivedDate,
  incomingPaymentOrderDate: props.incomingPaymentOrderDate,
  moneyEnlistmentDate: props.moneyEnlistmentDate,

  moneyReceiver: props.moneyReceiverGuid,
  moneySender: props.moneySenderGuid,

  pdv: props.pdv,
  pdvSum: props.pdvSum,
});

export const parseReceivedMoneyToFE = (props) => ({
  guid: props.guid,
  versionId: props.versionId,
  incomingPaymentOrderNum: props.incomingPaymentOrderNum,
  incomingPaymentBankOperationNum: props.incomingPaymentBankOperationNum,
  paymentDescription: props.paymentDescription,
  moneyAmountReceived: props.moneyAmountReceived,

  incomingPaymentOrderBankReceivedDate: getDate(props.incomingPaymentOrderBankReceivedDate),
  incomingPaymentOrderDate: getDate(props.incomingPaymentOrderDate),
  moneyEnlistmentDate: getDate(props.moneyEnlistmentDate),

  moneyReceiverGuid: createValue(props.moneyReceiver), // empty fields, should be moneyReceiver
  moneySenderGuid: createValue(props.moneySender),

  paymentState: props.paymentState,
  pdv: props.pdv,
  pdvSum: props.pdvSum,
});

// ReceivedPaymentToPurposeList

export const receivedPaymentFields = {
  paymentToReportingPeriodYear: {
    field: 'paymentToReportingPeriodYear',
    name: 'Сплата за період по Договору "рік"',
    type: formItemTypes.SELECT,
    classifier: classifiers.YEARS,
    filter: defaultFilterOption,
    rules: [isRequired()],
  },
  paymentToReportingPeriodMonth: {
    field: 'paymentToReportingPeriodMonth',
    name: 'Сплата за період по Договору "місяць"',
    type: formItemTypes.SELECT,
    classifier: classifiers.MONTH,
    rules: [isRequired()],
  },
  nominatedPaymentAmount: {
    field: 'nominatedPaymentAmount',
    name: 'Рознесена сума',
    type: formItemTypes.INPUT,
    placeholder: 'Введіть рознесена суму',
    rules: [isRequired(), isNumberWithTwoDecimal()],
  },
  paymentPurposeType: {
    field: 'paymentPurposeType',
    name: 'Призначення платежу за класифікатором',
    type: formItemTypes.SELECT,
    classifier: classifiers.PAYMENT_PURPOSE_TYPE,
    valuableFields: defaultValuableFields.concat('type'),
    rules: [isRequired()],
  },
  paymentToContract: {
    field: 'paymentToContract',
    name: 'Плата по договору',
    type: formItemTypes.SELECT,
    classifier: classifiers.DOCUMENTS,
    documentType: 'LeaseContract',
    valuableFields: defaultValuableFields,
    rules: [isRequired()],
  },
  paymentState: {
    field: 'paymentState',
    name: 'Стан',
    type: formItemTypes.SELECT,
    classifier: classifiers.PAYMENT_STATE,
    readOnly: true,
  },
};

export const parseReceivedPaymentToBE = (props) => ({
  paymentToContract: props.paymentToContract,
  paymentToReportingPeriodYear: props.paymentToReportingPeriodYear,
  paymentToReportingPeriodMonth: props.paymentToReportingPeriodMonth,
  nominatedPaymentAmount: props.nominatedPaymentAmount,
  paymentPurposeType: props.paymentPurposeType,
});

export const parseReceivedPaymentToFE = (props) => ({
  paymentToContract: createDocumentValue(props.paymentToContract),
  paymentToReportingPeriodYear: props.paymentToReportingPeriodYear,
  paymentToReportingPeriodMonth: props.paymentToReportingPeriodMonth,
  nominatedPaymentAmount: props.nominatedPaymentAmount,
  paymentPurposeType: (props.paymentPurposeType || {}).guid,
  paymentState: props.paymentState,
});

// SentMoney

export const sentMoneyFields = {
  outcomingPaymentOrderNum: {
    field: 'outcomingPaymentOrderNum',
    name: 'Номер платіжного доручення',
    type: formItemTypes.INPUT,
    placeholder: 'Введіть номер платіжного доручення',
    rules: [isRequired()],
  },
  paymentDescription: {
    field: 'paymentDescription',
    name: 'Призначення платежу',
    type: formItemTypes.TEXTAREA,
    placeholder: 'Введіть призначення платежу',
    rules: [isRequired()],
  },
  moneyAmountSent: {
    field: 'moneyAmountSent',
    name: 'Сума відправлених коштів',
    type: formItemTypes.INPUT,
    placeholder: 'Введіть суму відправлених коштів',
    rules: [isRequired()],
  },
  outcomingPaymentOrderDate: {
    field: 'outcomingPaymentOrderDate',
    name: 'Дата платіжного доручення',
    type: formItemTypes.DATEPICKER,
    rules: [isRequired()],
  },
  outcomingPaymentOrderBankReceivedDate: {
    field: 'outcomingPaymentOrderBankReceivedDate',
    name: 'Дата надходження платіжного доручення',
    type: formItemTypes.DATEPICKER,
  },
  paymentOperationNumber: {
    field: 'paymentOperationNumber',
    name: 'Номер операційного платежу',
    type: formItemTypes.INPUT,
  },
  moneySenderGuid: {
    field: 'moneySenderGuid',
    name: 'Контрагент-платник по документу',
    type: formItemTypes.SELECT,
    valuableFields: defaultValuableFields,
    classifier: classifiers.COUNTERPARTY,
    rules: [isRequired()],
    customRendered: true,
  },
  moneyReceiverGuid: {
    field: 'moneyReceiverGuid',
    name: 'Контрагент-отримувач',
    type: formItemTypes.SELECT,
    valuableFields: defaultValuableFields,
    classifier: classifiers.COUNTERPARTY,
    rules: [isRequired()],
    customRendered: true,
  },
};

export const parseSentMoneyToBE = (props) => ({
  outcomingPaymentOrderNum: props.outcomingPaymentOrderNum,
  paymentOperationNumber: props.paymentOperationNumber,
  paymentDescription: props.paymentDescription,
  moneyAmountSent: props.moneyAmountSent,

  outcomingPaymentOrderBankReceivedDate: props.outcomingPaymentOrderBankReceivedDate,
  outcomingPaymentOrderDate: props.outcomingPaymentOrderDate,

  moneyReceiver: props.moneyReceiverGuid,
  moneySender: props.moneySenderGuid,
});

export const parseSentMoneyToFE = (props) => ({
  guid: props.guid,
  versionId: props.versionId,
  outcomingPaymentOrderNum: props.outcomingPaymentOrderNum,
  paymentOperationNumber: props.paymentOperationNumber,
  paymentDescription: props.paymentDescription,
  moneyAmountSent: props.moneyAmountSent,

  outcomingPaymentOrderBankReceivedDate: getDate(props.outcomingPaymentOrderBankReceivedDate),
  outcomingPaymentOrderDate: getDate(props.outcomingPaymentOrderDate),

  moneyReceiverGuid: createValue(props.moneyReceiver),
  moneySenderGuid: createValue(props.moneySender),
});

// SentPaymentToPurposeList

export const sentPaymentFields = {
  paymentToReportingPeriodYear: {
    field: 'paymentToReportingPeriodYear',
    name: 'Сплата за період "рік"',
    type: formItemTypes.SELECT,
    classifier: classifiers.YEARS,
    filter: defaultFilterOption,
    rules: [isRequired()],
  },
  paymentToReportingPeriodMonth: {
    field: 'paymentToReportingPeriodMonth',
    name: 'Сплата за період "місяць"',
    type: formItemTypes.INPUT,
    rules: [isRequired()],
  },
  nominatedPaymentAmount: {
    field: 'nominatedPaymentAmount',
    name: 'Рознесена сума',
    type: formItemTypes.INPUT,
    placeholder: 'Введіть рознесена суму',
    rules: [isRequired()],
  },
  paymentPurposeType: {
    field: 'paymentPurposeType',
    name: 'Призначення платежу за класифікатором',
    type: formItemTypes.SELECT,
    classifier: classifiers.PAYMENT_PURPOSE_TYPE,
    valuableFields: defaultValuableFields.concat('type'),
    rules: [isRequired()],
  },
  paymentToDoctGuid: {
    field: 'paymentToDoctGuid',
    name: 'Плата по документу',
    // type: formItemTypes.SELECT,
    type: formItemTypes.INPUT,
    // valuableFields: defaultValuableFields,
    // classifier: classifiers.DOCUMENTS,
    // documentType: 'LeaseContract',
    customRendered: true,
  },
};

export const parseSentPaymentToBE = (props) => ({
  paymentToDoctGuid: props.paymentToDoctGuid,
  paymentToReportingPeriodYear: props.paymentToReportingPeriodYear,
  paymentToReportingPeriodMonth: props.paymentToReportingPeriodMonth,
  nominatedPaymentAmount: props.nominatedPaymentAmount,
  paymentPurposeType: props.paymentPurposeType,
});

export const parseSentPaymentToFE = (props) => ({
  paymentToDoctGuid: createDocumentValue(props.paymentToDoctGuid),
  paymentToReportingPeriodYear: props.paymentToReportingPeriodYear,
  paymentToReportingPeriodMonth: props.paymentToReportingPeriodMonth,
  nominatedPaymentAmount: props.nominatedPaymentAmount,
  paymentPurposeType: (props.paymentPurposeType || {}).guid,
});
