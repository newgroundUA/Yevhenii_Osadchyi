import moment from 'moment';
import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';

import { createValueCreator } from '../../../helpers/formHelpers/dropdownValueCreators';

import {
  getMappedForm as getMappedGeneral,
  getParsedForm as getParsedGeneral,
} from './generalFields';
import {
  isNumber,
  isNumberBetween,
  isPositiveInteger,
  isRequired,
} from '../../../services/validator/rules';
import { defaultFilterOption } from '../../../helpers/commonUtils';

const createCounterpartyFEValue = createValueCreator('counterparty');
const createDocumentFEValue = createValueCreator('document');
const createObjectFEValue = createValueCreator('object');
const createClassifierFEValue = (val = {}) => val.guid;

const DATE_FORMAT_BE = 'YYYY-MM-DD HH:mm:ss.SSS Z';
const getDate = (data) => (data ? moment(data, DATE_FORMAT_BE) : null);

const defaultValuableFields = ['guid', 'versionId'];

export const typicalContractFields = {
  landlord: {
    field: 'landlord',
    name: 'Орендодавець',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    placeholder: 'Виберіть орендодавця',
    rules: [isRequired()],
    valuableFields: defaultValuableFields,
    customRendered: true,
  }, // 2
  landlordrepresenter: {
    field: 'landlordrepresenter',
    name: 'Представник орендодавця',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    counterpartyType: 'Person',
    placeholder: 'Виберіть представника орендодавця',
    customRendered: true,
    valuableFields: defaultValuableFields,
    rules: [isRequired()],
  }, // 3
  landlordrepresenterreasondoc: {
    field: 'landlordrepresenterreasondoc',
    name: 'Підстава дії представника орендодавця',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.DOCUMENTS,
    colSpan: 24,
    placeholder: 'Виберіть підставу дії представника орендодавця',
    valuableFields: defaultValuableFields,
    rules: [isRequired()],
  }, // 4
  landlordbankdetail: {
    field: 'landlordbankdetail',
    name: 'Банківські реквізіти Орендодавця по Договору',
    type: formItemTypes.SELECT,
    classifier: classifiers.BANKDETAILS,
    placeholder: 'Виберіть банківські реквізіти Орендодавця по Договору',
  }, // 5
  renter: {
    field: 'renter',
    name: 'Орендар',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    placeholder: 'Виберіть орендаря',
    valuableFields: defaultValuableFields,
    rules: [isRequired()],
  }, // 6
  renterrepresenter: {
    field: 'renterrepresenter',
    name: 'Представник орендаря',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    counterpartyType: 'Person',
    placeholder: 'Виберіть представника орендаря',
    valuableFields: defaultValuableFields,
    rules: [isRequired()],
  }, // 7
  renterrepresenterreasondoc: {
    field: 'renterrepresenterreasondoc',
    name: 'Підстава дії представника орендаря',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.DOCUMENTS,
    colSpan: 24,
    placeholder: 'Виберіть підставу дії представника орендаря',
    valuableFields: defaultValuableFields,
    rules: [isRequired()],
  }, // 8
  renterbankdetail: {
    field: 'renterbankdetail',
    name: 'Банківські реквізіти Орендаря по Договору',
    type: formItemTypes.SELECT,
    classifier: classifiers.BANKDETAILS,
    placeholder: 'Виберіть банківські реквізіти Орендаря по Договору',
  }, // 9
  balancekeeper: {
    field: 'balancekeeper',
    name: 'Балансоутримувач',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    placeholder: 'Виберіть балансоутримувача',
    valuableFields: defaultValuableFields,
    rules: [isRequired()],
  }, // 10
  balancekeeperrepresenter: {
    field: 'balancekeeperrepresenter',
    name: 'Представник балансоутримувача',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    counterpartyType: 'Person',
    placeholder: 'Виберіть представника балансоутримувача',
    valuableFields: defaultValuableFields,
    rules: [isRequired()],
  }, // 11
  balancekeepebankdetail: {
    field: 'balancekeepebankdetail',
    name: 'Банківські реквізіти балансоутримувача по Договору',
    type: formItemTypes.SELECT,
    classifier: classifiers.BANKDETAILS,
    placeholder: 'Виберіть банківські реквізіти балансоутримувача по Договору',
  }, // 12
  balancekeeperrepresenterreasondoc: {
    field: 'balancekeeperrepresenterreasondoc',
    name: 'Підстава дії представника балансоутримувача',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.DOCUMENTS,
    colSpan: 24,
    placeholder: 'Виберіть підставу дії представника балансоутримувача',
    valuableFields: defaultValuableFields,
    rules: [isRequired()],
  }, // 13
  basementcontractdocs: {
    field: 'basementcontractdocs',
    name: 'Документальні підстави укладання договору',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.DOCUMENTS,
    colSpan: 24,
    placeholder: 'Виберіть документальні підстави укладання договору',
    valuableFields: defaultValuableFields,
    rules: [isRequired()],
  }, // 14
  objectOfLeaseContractList: {
    field: 'objectOfLeaseContractList',
    name: "Об'єкти що надаються в оренду",
    type: formItemTypes.SELECT,
    classifier: classifiers.OBJECTS,
    placeholder: "Виберіть об'єкти що надаються в оренду",
    valuableFields: defaultValuableFields,
    rules: [isRequired()],
  }, // 15
  cuObjectsleaserate: {
    field: 'cuObjectsleaserate',
    name: 'Ставка за користування приміщеннями ЗК',
    defaultValue: 20,
    type: formItemTypes.INPUT,
    rules: [isRequired(), isNumber()],
  }, // 17
  signdate: {
    field: 'signdate',
    name: 'Дата підписання договору',
    type: formItemTypes.DATEPICKER,
    defaultValue: moment(),
    rules: [isRequired()],
  }, // 18
  contracadditionalregistration: {
    field: 'contracadditionalregistration',
    name: 'Потребує додаткову реєстрацію',
    type: formItemTypes.SELECT,
    defaultValue: 'No',
    classifier: classifiers.CONTRACT_ADDITIONAL_REGISTRATION_ENUM,
    placeholder: 'Тип додаткової реєстрації?',
    rules: [isRequired()],
  }, // 19
  stateregistrdate: {
    field: 'stateregistrdate',
    name: 'Дата державної реєстрації',
    type: formItemTypes.DATEPICKER,
  }, // 20
  autoprolongation: {
    field: 'autoprolongation',
    name: 'Автоматична пролонгація',
    type: formItemTypes.RADIO,
    classifier: classifiers.YES_NO,
    rules: [isRequired()],
  }, // 21
  monthenumlist: {
    field: 'monthenumlist',
    name: 'Базовий місяць розрахунку',
    type: formItemTypes.SELECT,
    classifier: classifiers.MONTH,
  }, // 22
  yearenumlist: {
    field: 'yearenumlist',
    name: 'Базовий рік розрахунку',
    type: formItemTypes.SELECT,
    classifier: classifiers.YEARS,
    filter: defaultFilterOption,
  }, // 23
  leaseratecorrectivefactor: {
    field: 'leaseratecorrectivefactor',
    name: 'Корегуючий коефіціент до орендної ставки',
    defaultValue: 1,
    type: formItemTypes.INPUT,
    rules: [isNumberBetween(0, 1)],
  }, // 24
  rentPriseCalcReasonDoc: {
    field: 'rentPriseCalcReasonDoc',
    name: 'Документ підстава визначення орендної плати',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.DOCUMENTS,
    colSpan: 24,
    valuableFields: defaultValuableFields,
    placeholder: 'Виберіть документ підстава визначення орендної плати',
  }, // 25
  shortpenaltypaymentrate: {
    field: 'shortpenaltypaymentrate',
    name: 'Пеня за несвоєчасну сплату, розмір %',
    defaultValue: 0.5,
    type: formItemTypes.INPUT,
    rules: [isRequired(), isNumber()],
  }, // 26
  shortpenaltypaymentratemax: {
    field: 'shortpenaltypaymentratemax',
    name: 'Макс. пеня за несвоєчасну сплату, розмір %',
    defaultValue: 2,
    type: formItemTypes.INPUT,
    rules: [isRequired(), isNumberBetween(0, 100)],
  }, // 27
  shortpenaltypaymentperiod: {
    field: 'shortpenaltypaymentperiod',
    name: 'Пеня за несвоєчасну сплату, період, днів',
    defaultValue: 1,
    type: formItemTypes.INPUT,
    rules: [isRequired(), isNumber()],
  }, // 28
  longpenaltypaymentrate: {
    field: 'longpenaltypaymentrate',
    name: 'Штраф за довгострокову несплату, розмір %',
    defaultValue: 3,
    type: formItemTypes.INPUT,
    rules: [isRequired(), isNumber()],
  }, // 29
  longpenaltypaymentratemax: {
    field: 'longpenaltypaymentratemax',
    name: 'Макс. пеня за довгострокову несплату, розмір %',
    defaultValue: 3,
    type: formItemTypes.INPUT,
    rules: [isRequired(), isNumberBetween(0, 100)],
  }, // 30
  longpenaltypaymentperiod: {
    field: 'longpenaltypaymentperiod',
    name: 'Штраф за довгострокову несплату, період, днів',
    defaultValue: 90,
    type: formItemTypes.INPUT,
    rules: [isRequired(), isNumber()],
  }, // 31
  committalperiod: {
    field: 'committalperiod',
    name: "Період на передачу об'єкта, днів",
    defaultValue: 30,
    type: formItemTypes.INPUT,
    rules: [isRequired(), isNumber()],
  }, // 32
  stopusingperiod: {
    field: 'stopusingperiod',
    name: 'Термін на попередж. про закінчення викор., днів',
    defaultValue: 60,
    type: formItemTypes.INPUT,
    rules: [isRequired(), isNumber()],
  }, // 33
  createterminsurancepolice: {
    field: 'createterminsurancepolice',
    name: 'Термін укладання страхдоговору, днів',
    defaultValue: 60,
    type: formItemTypes.INPUT,
    rules: [isRequired(), isNumber()],
  }, // 34
  insurancedocs: {
    field: 'insurancedocs',
    name: 'Страхові договори та платежі',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.DOCUMENTS,
    valuableFields: defaultValuableFields,
    colSpan: 24,
  }, // 35
  endcontractreturnterm: {
    field: 'endcontractreturnterm',
    name: "Термін повернення об'єкта по закін. договору, днів",
    defaultValue: 3,
    type: formItemTypes.INPUT,
    rules: [isRequired(), isNumber()],
  }, // 36
  newinsurancepolicegiveterm: {
    field: 'newinsurancepolicegiveterm',
    name: 'Термін подання нового оціночного документа, днів',
    defaultValue: 90,
    type: formItemTypes.INPUT,
    rules: [isRequired(), isNumber()],
  }, // 37
  rentpaymentallowedterm: {
    field: 'rentpaymentallowedterm',
    name: 'Стандартний термін на сплату, днів',
    defaultValue: 15,
    type: formItemTypes.INPUT,
    rules: [isRequired(), isNumber()],
  }, // 38
  advancepaymentterm: {
    field: 'advancepaymentterm',
    name: 'Термін на сплату авансу, днів',
    defaultValue: 10,
    type: formItemTypes.INPUT,
    rules: [isRequired(), isNumber()],
  }, // 39
  baserentperiod: {
    field: 'baserentperiod',
    name: 'Базовий період оренди',
    type: formItemTypes.SELECT,
    defaultValue: 'MONTHLY',
    classifier: classifiers.BASE_LEASE_PERIODS,
    placeholder: 'Виберіть базовий період оренди',
    rules: [isRequired()],
  }, // 40
  baserentperiodforadvance: {
    field: 'baserentperiodforadvance',
    name: 'Кількість базових періодов для авансу',
    defaultValue: 2,
    type: formItemTypes.INPUT,
    rules: [isRequired(), isNumber()],
  }, // 41
  leasestartusingterm: {
    field: 'leasestartusingterm',
    name: 'Термін вступу Орендаря в користування',
    type: formItemTypes.SELECT,
    classifier: classifiers.LEASE_START_USING_TERM,
    placeholder: 'Виберіть термін вступу Орендаря в користування',
    rules: [isRequired()],
  }, // 42
};

export const objectOfLeaseContractListFields = {
  objectInLease: {
    field: 'objectInLease',
    name: "Об'єкт що надається в оренду за Договором(ОВОД)",
    type: formItemTypes.SELECT,
    classifier: classifiers.OBJECTS,
    rules: [isRequired()],
    valuableFields: defaultValuableFields,
  },
  objectListRecordStatus: {
    field: 'objectListRecordStatus',
    name: 'Операційний стан запису',
    type: formItemTypes.SELECT,
    defaultValue: 'ApprovedInTheContract',
    classifier: classifiers.OBJECT_LIST_RECORD_STATUS_ENUM,
    rules: [],
  },
  objectListRecordStatusDate: {
    field: 'objectListRecordStatusDate',
    name: 'Дата операційного стану',
    type: formItemTypes.DATEPICKER,
    rules: [],
  },
  objectInLeaseStartDate: {
    field: 'objectInLeaseStartDate',
    name: 'Надається в оренду З',
    type: formItemTypes.DATEPICKER,
    rules: [isRequired()],
  },
  objectInLeaseEndDate: {
    field: 'objectInLeaseEndDate',
    name: 'Надається в оренду ПО',
    type: formItemTypes.DATEPICKER,
    rules: [isRequired()],
  },
  leaseRateDetectMethod: {
    field: 'leaseRateDetectMethod',
    name: 'Метод визначення орендної ставки (платні)',
    type: formItemTypes.SELECT,
    classifier: classifiers.BASE_LEASE_RATE_DETECT_METHOD_ENUM,
    rules: [isRequired()],
  },
  leaseRateDiscountBaseType: {
    field: 'leaseRateDiscountBaseType',
    name: 'Підстава льготної орендної ставки',
    type: formItemTypes.SELECT,
    valuableFields: defaultValuableFields.concat('type'),
    rules: [],
    classifier: classifiers.LEASE_RATE_DISCOUNTBASE_TYPE,
  },
  leaseRateDirectory: {
    field: 'leaseRateDirectory',
    name: 'Цільове призначення ОВОД за класифікатором',
    type: formItemTypes.SELECT,
    valuableFields: defaultValuableFields.concat('type'),
    classifier: classifiers.LEASE_RATE_DIRECTORY,
    rules: [isRequired()],
  },
  objectMarketValueDocs: {
    field: 'objectMarketValueDocs',
    name: "Документ про вартість об'єкта",
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.DOCUMENTS,
    colSpan: 24,
    valuableFields: defaultValuableFields,
    rules: [isRequired()],
  },
  leaseOperationMode: {
    field: 'leaseOperationMode',
    name: 'Режим оренди',
    type: formItemTypes.SELECT,
    defaultValue: 'MONTHLY',
    classifier: classifiers.LEASE_OPERATION_MODE,
    rules: [isRequired()],
  },
  leaseRateByFact: {
    field: 'leaseRateByFact',
    name: 'Орендна ставка фактична',
    type: formItemTypes.INPUT,
    rules: [isRequired()],
  },
  legalYearRental: {
    field: 'legalYearRental',
    name: 'Річна Орендна плата за Методикою',
    type: formItemTypes.INPUT,
    rules: [],
  },
  factYearRental: {
    field: 'factYearRental',
    name: 'Річна Орендна плата Фактична',
    type: formItemTypes.INPUT,
    rules: [],
  },
  baseRental: {
    field: 'baseRental',
    name: 'Базова орендна плата',
    type: formItemTypes.INPUT,
    rules: [isRequired(), isNumber()],
  },
  objectInLeaseStartDateFact: {
    field: 'objectInLeaseStartDateFact',
    name: 'Фактична дата початку оренди',
    type: formItemTypes.DATEPICKER,
  },
  objectInLeaseEndDateFact: {
    field: 'objectInLeaseEndDateFact',
    name: 'Фактична дата закінчення оренди',
    type: formItemTypes.DATEPICKER,
  },
  leaseObjectRecieptDocs: {
    field: 'leaseObjectRecieptDocs',
    name: "Посилання на акт приймання передачі об'єкта",
    type: formItemTypes.MULTISELECT,
    valuableFields: defaultValuableFields,
    classifier: classifiers.DOCUMENTS,
    colSpan: 24,
  },
  leaseObjectReturnDocs: {
    field: 'leaseObjectReturnDocs',
    name: "Посилання на акт повернення об'єкта",
    type: formItemTypes.MULTISELECT,
    valuableFields: defaultValuableFields,
    classifier: classifiers.DOCUMENTS,
    colSpan: 24,
  },
};

export const leaseBasePeriodinReportingPeriodFields = {
  planReportingYear: {
    field: 'planReportingYear',
    name: 'Рік звітного періоду Договору',
    type: formItemTypes.SELECT,
    classifier: classifiers.YEARS,
    filter: defaultFilterOption,
    rules: [isRequired()],
  },
  planReportingMonth: {
    field: 'planReportingMonth',
    name: 'Місяць звітного періоду Договору',
    type: formItemTypes.SELECT,
    classifier: classifiers.MONTH,
    rules: [isRequired()],
  },
  mltQuantityByPeriodPlanned: {
    field: 'mltQuantityByPeriodPlanned',
    name: 'Запланована кількість МСО в ЗП',
    type: formItemTypes.INPUT,
    rules: [isRequired(), isPositiveInteger()],
  },
  mltQuantityByPeriodFact: {
    field: 'mltQuantityByPeriodFact',
    name: 'Фактична кількість МСО в ЗП',
    type: formItemTypes.INPUT,
    rules: [isRequired(), isPositiveInteger()],
  },
};

export const leaseObjectsLinkFields = {
  leaseObjectNumber: {
    field: 'leaseObjectNumber',
    name: 'Реєстровий номер',
  },
  leaseObjectFullName: {
    field: 'leaseObjectFullName',
    name: "Назва об'єкта оренди повна",
  },
  leaseObjectShortName: {
    field: 'leaseObjectShortName',
    name: "Назва об'єкта оренди коротка",
  },
  leaseObjectAddress: {
    field: 'leaseObjectAddress',
    name: 'Адреса розташування',
  },
  leaseObjectTotalSpace: {
    field: 'leaseObjectTotalSpace',
    name: 'Загальна площа, кв. м',
  },
  leaseObjectUsefullSpace: {
    field: 'leaseObjectUsefullSpace',
    name: 'Загальна корисна площа, кв. м',
  },
  leaseObjectCommonUsesSpace: {
    field: 'leaseObjectCommonUsesSpace',
    name: 'Площа приміщень загального користування, кв. м',
  },
};

export const getMappedForm = (props) => ({
  ...getMappedGeneral(props),
  landlord: props.landlord,
  landlordRepresenter: props.landlordrepresenter,
  landlordRepresenterReasonDocs: props.landlordrepresenterreasondoc,
  landlordBankDetail: props.landlordbankdetail,
  renter: props.renter,
  renterRepresenter: props.renterrepresenter,
  renterRepresenterReasonDocs: props.renterrepresenterreasondoc,
  renterBankDetail: props.renterbankdetail,
  balanceKeeper: props.balancekeeper,
  balanceKeeperRepresenter: props.balancekeeperrepresenter,
  balanceKeeperRepresenterReasonDocs: props.balancekeeperrepresenterreasondoc,
  balanceKeeperBankDetail: props.balancekeepebankdetail,
  basementContractDocs: props.basementcontractdocs,
  // objectOfLeaseContractList: null, // easy
  cuObjectsLeaserate: props.cuObjectsleaserate,
  signDate: props.signdate,
  contractAdditionalRegistration: props.contracadditionalregistration,
  stateRegistrDate: props.stateregistrdate,
  autoProlongation: props.autoprolongation,
  baseMonth: props.monthenumlist,
  baseYear: props.yearenumlist,
  leaseRateCorrectiveFactor: props.leaseratecorrectivefactor,
  rentPriseCalcReasonDocs: props.rentPriseCalcReasonDoc,
  shortPenaltyPaymentRate: props.shortpenaltypaymentrate,
  shortPenaltyPaymentRateMax: props.shortpenaltypaymentratemax,
  shortPenaltyPaymentPeriod: props.shortpenaltypaymentperiod,
  longPenaltyPaymentRate: props.longpenaltypaymentrate,
  longPenaltyPaymentRateMax: props.longpenaltypaymentratemax,
  longPenaltyPaymentPeriod: props.longpenaltypaymentperiod,
  committalPeriod: props.committalperiod,
  stopUsingPeriod: props.stopusingperiod,
  createTerminInsurancePolice: props.createterminsurancepolice,
  insuranceDocs: props.insurancedocs,
  endContractReturnTerm: props.endcontractreturnterm,
  newInsurancePoliceGiveTerm: props.newinsurancepolicegiveterm,
  rentPaymentAllowedTerm: props.rentpaymentallowedterm,
  advancePaymentTerm: props.advancepaymentterm,
  baseRentPeriod: props.baserentperiod,
  baseRentPeriodForAdvance: props.baserentperiodforadvance,
  leaseStartUsingTerm: props.leasestartusingterm,
});

export const getParsedForm = (props) => ({
  ...getParsedGeneral(props),

  documentType: props.refDocumentType && props.refDocumentType.guid,
  // docvaliditystatusGUID: (props.docValidityStatus || []).map(({ guid }) => guid),

  landlord: createCounterpartyFEValue(props.landlord),
  landlordrepresenter: createCounterpartyFEValue(props.landlordRepresenter),
  landlordrepresenterreasondoc: createDocumentFEValue(props.landlordRepresenterReasonDocs),
  landlordbankdetail: createClassifierFEValue(props.landlordBankDetail),
  renter: createCounterpartyFEValue(props.renter),
  renterrepresenter: createCounterpartyFEValue(props.renterRepresenter),
  renterrepresenterreasondoc: createDocumentFEValue(props.renterRepresenterReasonDocs),
  renterbankdetail: createClassifierFEValue(props.renterBankDetail),
  balancekeeper: createCounterpartyFEValue(props.balanceKeeper),
  balancekeeperrepresenter: createCounterpartyFEValue(props.balanceKeeperRepresenter),
  balancekeeperrepresenterreasondoc: createDocumentFEValue(
    props.balanceKeeperRepresenterReasonDocs,
  ),
  balancekeepebankdetail: createClassifierFEValue(props.balanceKeeperBankDetail),
  basementcontractdocs: createDocumentFEValue(props.basementContractDocs),
  cuObjectsleaserate: props.cuObjectsLeaserate,
  signdate: getDate(props.signDate),
  contracadditionalregistration: props.contractAdditionalRegistration,
  stateregistrdate: getDate(props.stateRegistrDate),
  autoprolongation: props.autoProlongation,
  monthenumlist: props.baseMonth,
  yearenumlist: props.baseYear,
  leaseratecorrectivefactor: props.leaseRateCorrectiveFactor,
  rentPriseCalcReasonDoc: createDocumentFEValue(props.rentPriseCalcReasonDocs),
  shortpenaltypaymentrate: props.shortPenaltyPaymentRate,
  shortpenaltypaymentratemax: props.shortPenaltyPaymentRateMax,
  shortpenaltypaymentperiod: props.shortPenaltyPaymentPeriod,
  longpenaltypaymentrate: props.longPenaltyPaymentRate,
  longpenaltypaymentratemax: props.longPenaltyPaymentRateMax,
  longpenaltypaymentperiod: props.longPenaltyPaymentPeriod,
  committalperiod: props.committalPeriod,
  stopusingperiod: props.stopUsingPeriod,
  createterminsurancepolice: props.createTerminInsurancePolice,
  insurancedocs: createDocumentFEValue(props.insuranceDocs),
  endcontractreturnterm: props.endContractReturnTerm,
  newinsurancepolicegiveterm: props.newInsurancePoliceGiveTerm,
  rentpaymentallowedterm: props.rentPaymentAllowedTerm,
  advancepaymentterm: props.advancePaymentTerm,
  baserentperiod: props.baseRentPeriod,
  baserentperiodforadvance: props.baseRentPeriodForAdvance,
  leasestartusingterm: props.leaseStartUsingTerm,
});

export const getMappedForObjects = (props) => ({
  objectInLease: props.objectInLease,
  objectListRecordStatus: props.objectListRecordStatus,
  objectListRecordStatusDate: props.objectListRecordStatusDate,
  objectInLeaseStartDate: props.objectInLeaseStartDate,
  objectInLeaseEndDate: props.objectInLeaseEndDate,
  leaseRateDetectMethod: props.leaseRateDetectMethod,
  leaseRateDiscountBaseType: props.leaseRateDiscountBaseType,
  leaseRateDirectory: props.leaseRateDirectory,
  objectMarketValueDocs: props.objectMarketValueDocs,
  leaseOperationMode: props.leaseOperationMode,
  leaseRateByFact: props.leaseRateByFact,
  legalYearRental: props.legalYearRental,
  factYearRental: props.factYearRental,
  baseRental: props.baseRental,
  objectInLeaseStartDateFact: props.objectInLeaseStartDateFact,
  objectInLeaseEndDateFact: props.objectInLeaseEndDateFact,
  leaseObjectRecieptDocs: props.leaseObjectRecieptDocs,
  leaseObjectReturnDocs: props.leaseObjectReturnDocs,
});

export const getParsedForObjects = (props) => ({
  guid: props.guid,
  versionId: props.versionId,
  objectInLease: createObjectFEValue(props.objectInLease),
  objectListRecordStatus: props.objectListRecordStatus,
  objectListRecordStatusDate: getDate(props.objectListRecordStatusDate),
  objectInLeaseStartDate: getDate(props.objectInLeaseStartDate),
  objectInLeaseEndDate: getDate(props.objectInLeaseEndDate),
  leaseRateDetectMethod: props.leaseRateDetectMethod,
  leaseRateDiscountBaseType: createClassifierFEValue(props.leaseRateDiscountBaseType),
  leaseRateDirectory: createClassifierFEValue(props.leaseRateDirectory),
  objectMarketValueDocs: createDocumentFEValue(props.objectMarketValueDocs),
  leaseOperationMode: props.leaseOperationMode,
  leaseRateByFact: props.leaseRateByFact,
  legalYearRental: props.legalYearRental,
  factYearRental: props.factYearRental,
  baseRental: props.baseRental,
  objectInLeaseStartDateFact: getDate(props.objectInLeaseStartDateFact),
  objectInLeaseEndDateFact: getDate(props.objectInLeaseEndDateFact),
  leaseObjectRecieptDocs: createDocumentFEValue(props.leaseObjectRecieptDocs),
  leaseObjectReturnDocs: createDocumentFEValue(props.leaseObjectReturnDocs),
});

export const getLeaseBasePeriodsToBe = (props) => ({
  planReportingYear: props.planReportingYear,
  planReportingMonth: props.planReportingMonth,
  mltQuantityByPeriodPlanned: +props.mltQuantityByPeriodPlanned,
  mltQuantityByPeriodFact: +props.mltQuantityByPeriodFact,
});

export const getLeaseBasePeriodsToFe = (props) => ({
  planReportingYear: props.planReportingYear,
  planReportingMonth: props.planReportingMonth,
  mltQuantityByPeriodPlanned: props.mltQuantityByPeriodPlanned,
  mltQuantityByPeriodFact: props.mltQuantityByPeriodFact,
});

export const getParsedForLeaseObjects = (props) => ({
  leaseObjectNumber: props.leaseObjectNumber,
  leaseObjectFullName: props.leaseObjectFullName,
  leaseObjectShortName: props.leaseObjectShortName,
  leaseObjectAddress: '',
  leaseObjectTotalSpace: props.leaseObjectTotalSpace,
  leaseObjectUsefullSpace: props.leaseObjectUsefullSpace,
  leaseObjectCommonUsesSpace: props.leaseObjectCommonUsesSpace,
});
