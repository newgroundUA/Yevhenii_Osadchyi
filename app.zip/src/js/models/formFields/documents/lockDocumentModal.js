import * as formItemTypes from '../../../constants/FormItemTypes';
import EnumToLabelsMap from '../../../constants/EnumToLabelsMap';
import { getFeDate } from '../../../helpers/geters';
import * as classifiers from '../../../constants/ClassifiersNames';

export const lockDocumentFields = {
  dateTo: {
    field: 'dateTo',
    name: 'Дійсний до',
    type: formItemTypes.DATEPICKER,
    rules: [{ required: true, message: 'Оберіть період блокування!' }],
    className: 'labelOneRow',
    placeholder: 'дд.мм.рррр',
    colSpan: 6,
  },
  reason: {
    field: 'reason',
    name: 'Причина блокування',
    type: formItemTypes.INPUT,
    className: 'labelOneRow',
    placeholder: 'Вкажіть причину блокування документів',
    rules: [{ required: true, message: 'Введіть причину блокування!' }],
    colSpan: 18,
  },
};

export const lockDocumentColumns = [
  {
    title: 'Тип документа',
    dataIndex: 'documentType',
  },
  {
    title: 'Серія та номер',
    dataIndex: 'docNumber',
  },
  {
    title: 'Чинність',
    dataIndex: 'validityStatus',
  },
  {
    title: 'Короткий опис',
    dataIndex: 'docDescription',
  },
  {
    title: 'Видавач',
    dataIndex: 'publisher', // TODO
  },
  {
    title: 'Дата',
    dataIndex: 'docDate',
  },
];

export const lockDocumentParseToFE = (el) => ({
  ...el,
  documentType:
    el.documentType === 'Document'
      ? 'Загальний'
      : EnumToLabelsMap[classifiers.DOCUMENT_TYPE][el.documentType],
  docDate: getFeDate(el.docDate),
  validityStatus: EnumToLabelsMap[classifiers.CL_DOC_VALIDITY_STATUS][el.validityStatus],
});
