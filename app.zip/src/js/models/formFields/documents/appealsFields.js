import moment from 'moment';

import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';
import { createValueCreator } from '../../../helpers/formHelpers/dropdownValueCreators';

const DATE_FORMAT_BE = 'YYYY-MM-DD HH:mm:ss.SSS Z';
const getDate = (data) => (data ? moment(data, DATE_FORMAT_BE) : null);
// const getObject = (value) => (value ? { guid: value } : null);
// const getArr = (fields = []) => fields.map((el) => el.guid);
const createValue = createValueCreator('counterparty');
// const createDocumentValue = createValueCreator('document');

const defaultValuableFields = ['guid', 'versionId'];

export const appealsFields = {
  appealInitType: {
    field: 'appealInitType',
    name: 'Ініціатор позову або скарги',
    type: formItemTypes.SELECT,
    rules: [{ required: true, message: 'Виберіть тип документа!' }],
    classifier: classifiers.APPEAL_INIT_TYPE, // ????
  },
  court: {
    field: 'court',
    name: 'Суд, до якого направлено',
    type: formItemTypes.SELECT,
    rules: [{ required: true, message: 'Поле обов`язкове для вводу!' }],
    valuableFields: defaultValuableFields,
    classifier: classifiers.COUNTERPARTY,
  },
  sendingDate: {
    field: 'sendingDate',
    name: 'Дата відправлення',
    type: formItemTypes.DATEPICKER,
    rules: [{ required: false, message: 'Поле обов`язкове для вибору!' }],
    disabledDate: (currDate) => currDate && currDate.valueOf() > moment().valueOf(),
  },
  courtRegistrationDate: {
    field: 'courtRegistrationDate',
    name: 'Дата реєстраціїї в канцелярії суду',
    type: formItemTypes.DATEPICKER,
    rules: [{ required: false, message: 'Поле обов`язкове для вибору!' }],
    disabledDate: (currDate) => currDate && currDate.valueOf() > moment().valueOf(),
  },
  complainant: {
    field: 'complainant',
    name: 'Позивачі',
    type: formItemTypes.MULTISELECT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
    classifier: classifiers.COUNTERPARTY,
    valuableFields: defaultValuableFields,
    counterpartyType: 'Person',
  },
  appealPrice: {
    field: 'appealPrice',
    name: 'Ціна позову (скарги)',
    type: formItemTypes.INPUT,
  },
  defendant: {
    field: 'defendant',
    name: 'Відповідачі',
    type: formItemTypes.MULTISELECT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
    classifier: classifiers.COUNTERPARTY,
    valuableFields: defaultValuableFields,
    counterpartyType: 'Person',
  },
  thirdParty: {
    field: 'thirdParty',
    name: 'Третя сторона',
    type: formItemTypes.MULTISELECT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
    classifier: classifiers.COUNTERPARTY,
    valuableFields: defaultValuableFields,
    counterpartyType: 'Person',
  },
  appealClaims: {
    field: 'appealClaims',
    name: 'Позовні вимоги',
    type: formItemTypes.TEXTAREA,
  },
  conditionsOfClaims: {
    field: 'conditionsOfClaims',
    name: 'Перелік обставин',
    type: formItemTypes.TEXTAREA,
  },
  proofsOfClaims: {
    field: 'proofsOfClaims',
    name: 'Зазначення доказів',
    type: formItemTypes.TEXTAREA,
  },
  additionalInfo: {
    field: 'additionalInfo',
    name: 'Додаткова інформація',
    type: formItemTypes.TEXTAREA,
  },
};

export const getMappedForm = (props) => ({
  appealInitType: props.appealInitType,
  court: props.court,
  sendingDate: props.sendingDate,
  courtRegistrationDate: props.courtRegistrationDate,
  complainants: props.complainant,
  defendants: props.defendant,
  thirdParties: props.thirdParty,
  appealPrice: props.appealPrice,
  appealClaims: props.appealClaims,
  conditionsOfClaims: props.conditionsOfClaims,
  proofsOfClaims: props.proofsOfClaims,
  additionalInfo: props.additionalInfo,
});

export const getParsedForm = (props) => ({
  appealInitType: props.appealInitType,
  court: createValue(props.court),
  sendingDate: getDate(props.sendingDate),
  courtRegistrationDate: getDate(props.courtRegistrationDate),
  complainant: createValue(props.complainants),
  defendant: createValue(props.defendants),
  thirdParty: createValue(props.thirdParties),
  appealPrice: props.appealPrice,
  appealClaims: props.appealClaims,
  conditionsOfClaims: props.conditionsOfClaims,
  proofsOfClaims: props.proofsOfClaims,
  additionalInfo: props.additionalInfo,
});
