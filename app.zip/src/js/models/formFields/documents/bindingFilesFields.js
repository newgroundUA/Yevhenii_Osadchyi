import * as formItemTypes from '../../../constants/FormItemTypes';
import { getFeDate } from '../../../helpers/geters';
import { parseFileSizeToFE } from '../../../helpers/commonUtils';

export const bindingFilesLiveSerchFields = {
  fileName: {
    field: 'fileName',
    name: "Ім'я",
    type: formItemTypes.INPUT,
    placeholder: 'Напр.pdf',
    className: 'labelOneRow',
  },
  fileAlias: {
    field: 'fileAlias',
    name: 'Назва',
    type: formItemTypes.INPUT,
    placeholder: 'Введіть назву документу',
    className: 'labelOneRow',
  },
  tag: {
    field: 'tag',
    name: 'Теги',
    type: formItemTypes.INPUT,
    placeholder: 'Напр. "наказ", "положення" тощо',
    className: 'labelOneRow',
  },
  fileNotes: {
    field: 'fileNotes',
    name: 'Опис',
    type: formItemTypes.INPUT,
    colSpan: 18,
    placeholder: 'Введіть інформацію про файл',
    className: 'labelOneRow',
  },
};

export const getLiveSearchedFileToFE = (el) => ({
  ...el,
  date: getFeDate(el.createdOn),
  docUser: `${el.creator.fistName.slice(0, 1)}. ${el.creator.lastName}`,
  fileSize: parseFileSizeToFE(el.fileSize),
  dataForActions: {
    fileLink: el.fileLink,
    fileName: `${el.fileName}.${el.fileExtension}`,
  },
});

export const getBoundFileToFE = (Array) =>
  Array.map((el) => ({
    ...el,
    date: getFeDate(el.createdOn),
    docUser: `${el.creator && el.creator.fistName.slice(0, 1)}. ${el.creator &&
      el.creator.lastName}`,
    fileSize: parseFileSizeToFE(el.fileSize),
    dataForActions: {
      fileLink: el.fileLink,
      fileName: `${el.fileName}.${el.fileExtension}`,
      guid: el.guid,
    },
  }));
