import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';

import {
  getMappedForm as getMappedGeneral,
  getParsedForm as getParsedGeneral,
} from './generalFields';
import { createValueCreator } from '../../../helpers/formHelpers/dropdownValueCreators';
// import { getGuidsArray } from '../../../helpers/formHelpers/formHelpers';

const createValue = createValueCreator('counterparty');

const defaultValuableFields = ['guid', 'versionId'];

export const judicialDecisionFields = {
  complainants: {
    field: 'complainants',
    name: 'Позивачі',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.COUNTERPARTY,
    valuableFields: defaultValuableFields,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  complainantReps: {
    field: 'complainantReps',
    name: 'Представник позивача',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.COUNTERPARTY,
    valuableFields: defaultValuableFields,
    counterpartyType: 'Person',
  },
  defendants: {
    field: 'defendants',
    name: 'Відповідачі',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.COUNTERPARTY,
    valuableFields: defaultValuableFields,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  defendantReps: {
    field: 'defendantReps',
    name: 'Представник відповідача',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.COUNTERPARTY,
    valuableFields: defaultValuableFields,
    counterpartyType: 'Person',
  },
  thirdParties: {
    field: 'thirdParties',
    name: 'Третя сторона',
    type: formItemTypes.MULTISELECT,
    valuableFields: defaultValuableFields,
    classifier: classifiers.COUNTERPARTY,
  },
  thirdPartyReps: {
    field: 'thirdPartyReps',
    name: 'Представник третьої сторони',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.COUNTERPARTY,
    valuableFields: defaultValuableFields,
    counterpartyType: 'Person',
  },
  judges: {
    field: 'judges',
    name: 'Судді',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.COUNTERPARTY,
    valuableFields: defaultValuableFields,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
    counterpartyType: 'Person',
  },
  shortResult: {
    field: 'shortResult',
    name: 'Результат скорочено',
    type: formItemTypes.SELECT,
    classifier: classifiers.ENUM_JUDICIAL_SHOT_RESULT,
  },
  decisionPrice: {
    field: 'decisionPrice',
    name: 'Сумма рішення',
    type: formItemTypes.INPUT,
  },
  descriptivePart: {
    field: 'descriptivePart',
    name: 'Описова частина',
    type: formItemTypes.INPUT,
  },
  motivatedPart: {
    field: 'motivatedPart',
    name: 'Мотивувальна частина',
    type: formItemTypes.INPUT,
  },
  conclusion: {
    field: 'conclusion',
    name: 'Висновок',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
    type: formItemTypes.INPUT,
  },
};

export const getMappedForm = (props) => ({
  ...getMappedGeneral(props),

  complainants: props.complainants || [],
  complainantReps: props.complainantReps || [],
  defendants: props.defendants || [],
  defendantReps: props.defendantReps || [],
  thirdParties: props.thirdParties || [],
  thirdPartyReps: props.thirdPartyReps || [],
  judges: props.judges || [],
  decisionPrice: props.decisionPrice,
  shortResult: props.shortResult,
  descriptivePart: props.descriptivePart,
  motivatedPart: props.motivatedPart,
  conclusion: props.conclusion,
});

export const getParsedForm = (props) => ({
  ...getParsedGeneral(props),
  complainants: createValue(props.complainants),
  complainantReps: createValue(props.complainantReps),
  defendants: createValue(props.defendants),
  defendantReps: createValue(props.defendantReps),
  thirdParties: createValue(props.thirdParties),
  thirdPartyReps: createValue(props.thirdPartyReps),
  judges: createValue(props.judges),
  decisionPrice: props.decisionPrice,
  shortResult: props.shortResult,
  descriptivePart: props.descriptivePart,
  motivatedPart: props.motivatedPart,
  conclusion: props.conclusion,
});
