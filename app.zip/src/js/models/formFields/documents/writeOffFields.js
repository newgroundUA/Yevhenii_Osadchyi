import * as formItemTypes from '../../../constants/FormItemTypes';

export const writeOffOOMTableFields = {
  object: {
    field: 'object',
    name: "Об'єкт",
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  writingOffCost: {
    field: 'writingOffCost',
    name: 'Вартість списання, грн',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  additionalCommentForObject: {
    field: 'additionalCommentForObject',
    name: "Додатковий коментар щодо об'єкту",
    type: formItemTypes.TEXTAREA,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
};

export const writeOffInformationFields = {
  counterpartyOwner: {
    field: 'counterpartyOwner',
    name: 'Контрагент-власник',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  counterpartyController: {
    field: 'counterpartyController',
    name: 'Контрагент-контролер',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  propertyObjects: {
    field: 'propertyObjects',
    name: "Майнові об'єкти",
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  writeOffReson: {
    field: 'writeOffReson',
    name: 'Підстава для списання',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
};
