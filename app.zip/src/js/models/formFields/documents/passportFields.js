import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';
import {
  getMappedForm as getMappedGeneral,
  getParsedForm as getParsedGeneral,
} from './generalFields';

export const passportFields = {
  citizenship: {
    field: 'citizenship',
    name: 'Громадянство',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTRIES_LIST,
    rules: [{ required: true, message: 'Поле обов`язкове для заповнення!' }],
  },
  unicode_eddr: {
    field: 'unicode_eddr',
    name: 'УНЗР',
    type: formItemTypes.INPUT,
  },
  sex: {
    field: 'sex',
    name: 'Стать',
    type: formItemTypes.RADIO,
    classifier: classifiers.APPEAL,
    rules: [{ required: true, message: 'Поле обов`язкове для заповнення!' }],
  },
  passppublishercode: {
    field: 'passppublishercode',
    name: 'Код видавача',
    type: formItemTypes.INPUT,
  },
};

export const getMappedForm = (props) => ({
  ...getMappedGeneral(props),
  citizenship: props.citizenship,
  unicodeEddr: props.unicode_eddr,
  sex: props.sex,
  passPublisherCode: props.passppublishercode,
});

export const getParsedForm = (props) => ({
  ...getParsedGeneral(props),
  citizenship: props.citizenship,
  unicode_eddr: props.unicodeEddr,
  sex: props.sex,
  passppublishercode: props.passPublisherCode,
});
