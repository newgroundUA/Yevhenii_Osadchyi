import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';
import { createValueCreator } from '../../../helpers/formHelpers/dropdownValueCreators';
import { getDate, getParsedForm, getMappedForm } from './generalFields';

const createValue = createValueCreator('counterparty');
const createObjectValue = createValueCreator('object');

const defaultValuableFields = ['guid', 'versionId'];

export const balanceFields = {
  counterpartysender: {
    field: 'counterpartysender',
    name: 'Контрагент-здавач',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
    valuableFields: defaultValuableFields,
    placeholder: 'Виберіть контрагента-здавача',
  },
  counterpartyrecipient: {
    field: 'counterpartyrecipient',
    name: 'Контрагент-приймальник',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
    valuableFields: defaultValuableFields,
    placeholder: 'Виберіть контрагента-приймальника',
  },
  counterpartycontroller: {
    field: 'counterpartycontroller',
    name: 'Контрагент-контролер',
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.COUNTERPARTY,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
    valuableFields: defaultValuableFields,
    placeholder: 'Виберіть контрагента-контролера',
  },
  amortisationtype: {
    field: 'amortisationtype',
    name: 'Метод нарахування амортизації',
    type: formItemTypes.SELECT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
    placeholder: 'Виберіть метод нарахування амортизації',
    valuableFields: defaultValuableFields.concat('type'),
    classifier: classifiers.CL_AMORTIZATION,
  },
  writeofftype: {
    field: 'writeofftype',
    name: 'Шлях списання',
    type: formItemTypes.SELECT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
    placeholder: 'Виберіть шлях списання',
    valuableFields: defaultValuableFields.concat('type'),
    classifier: classifiers.CL_WRITE_OFF,
  },
};

export const balanceTableFields = {
  objectReceived: {
    field: 'objectReceived',
    name: "Об'єкт що прииймається",
    type: formItemTypes.SELECT,
    valuableFields: defaultValuableFields,
    classifier: classifiers.OBJECTS,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  curInvNumber: {
    field: 'curInvNumber',
    name: 'Призначено інвентарний номер',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  execStartDate: {
    field: 'execStartDate',
    name: 'Дата введення в експлуатацію',
    type: formItemTypes.DATEPICKER,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  startPrice: {
    field: 'startPrice',
    name: 'Первисна вартість',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  recalcPrice: {
    field: 'recalcPrice',
    name: 'Переоцінена вартість',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  wearoutPrice: {
    field: 'wearoutPrice',
    name: 'Вартість зносу',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  endPrice: {
    field: 'endPrice',
    name: 'Залишкова вартість',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  endPriceDate: {
    field: 'endPriceDate',
    name: 'Дата розрахунку залишкової та зносу',
    type: formItemTypes.DATEPICKER,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  physicalState: {
    field: 'physicalState',
    name: "Фізичний стан об'єкту",
    type: formItemTypes.SELECT,
    classifier: classifiers.CL_PHYSICAL_STATE,
    valuableFields: defaultValuableFields.concat('type'),
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  funcAccordance: {
    field: 'funcAccordance',
    name: "Функціональна відповідність об'єкта",
    type: formItemTypes.SELECT,
    classifier: classifiers.CL_FUNK_ACCORDANCE,
    valuableFields: defaultValuableFields.concat('type'),
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  assetSpecialisation: {
    field: 'assetSpecialisation',
    name: 'Спеціалізація актива',
    type: formItemTypes.SELECT,
    classifier: classifiers.CL_ASSET_SPECIALISATION,
    valuableFields: defaultValuableFields.concat('type'),
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  objectsTypeByAccounting: {
    field: 'objectsTypeByAccounting',
    name: 'Тип майна за бухобліком',
    type: formItemTypes.SELECT,
    classifier: classifiers.OBJECTS_TYPE_BY_ACCOUNTING,
    valuableFields: defaultValuableFields.concat('type'),
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  notes: {
    field: 'notes',
    name: "Додатковий коментар щодо об'єкту",
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
};

export const getMappedBalanceForm = (props) => ({
  ...getMappedForm(props),
  counterpartySender: props.counterpartysender,
  counterpartyRecipient: props.counterpartyrecipient,
  counterpartyControllers: props.counterpartycontroller,
  amortizationType: props.amortisationtype,
  writeOffType: props.writeofftype,
});

export const getParsedBalanceForm = (props) => ({
  ...getParsedForm(props),
  counterpartysender: createValue(props.counterpartySender),
  counterpartyrecipient: createValue(props.counterpartyRecipient),
  counterpartycontroller: createValue(props.counterpartyControllers),
  amortisationtype: props.amortizationType.guid,
  writeofftype: props.writeOffType.guid,
});

export const getMappedBalaceDetailForm = (props) => ({
  objectReceived: props.objectReceived,
  curInvNumber: props.curInvNumber,
  execStartDate: props.execStartDate,
  startPrice: props.startPrice,
  recalcPrice: props.recalcPrice,
  wearoutPrice: props.wearoutPrice,
  endPrice: props.endPrice,
  endPriceDate: props.endPriceDate,
  physicalState: props.physicalState,
  funcAccordance: props.funcAccordance,
  assetSpecialisation: props.assetSpecialisation,
  objectsTypeByAccounting: props.objectsTypeByAccounting,
  notes: props.notes,
});

export const getParsedBalanceDetailForm = (props) => ({
  assetSpecialisation: (props.assetSpecialisation || {}).guid,
  curInvNumber: props.curInvNumber,
  endPrice: props.endPrice,
  endPriceDate: getDate(props.endPriceDate),
  execStartDate: getDate(props.execStartDate),
  funcAccordance: (props.funcAccordance || {}).guid,
  notes: props.notes,
  objectReceived: createObjectValue(props.objectReceived),
  objectsTypeByAccounting: (props.objectsTypeByAccounting || {}).guid,
  physicalState: (props.physicalState || {}).guid,
  recalcPrice: props.recalcPrice,
  startPrice: props.startPrice,
  wearoutPrice: props.wearoutPrice,
});
