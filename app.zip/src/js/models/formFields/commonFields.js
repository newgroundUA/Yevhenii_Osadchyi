import * as formItemTypes from '../../constants/FormItemTypes';
import * as classifiers from '../../constants/ClassifiersNames';

export const SubjectsEvaluationFields = {
  subjectEvaluationActivity: {
    field: 'subjectEvaluationActivity',
    name: "Суб'єкт оціночної діяльності",
    type: formItemTypes.SELECT,
    classifier: classifiers.SUBJECT_EVALUATION_ACTIVITY,
    placeholder: 'Виберіть поле',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  balanceHolder: {
    field: 'balanceHolder',
    name: 'Балансоутримувач',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    placeholder: 'Виберіть поле',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  renter: {
    field: 'renter',
    name: 'Орендар',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    placeholder: 'Виберіть поле',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
};

export const SubjectsEvaluationTableFields = {
  contestsDate: {
    field: 'contestsDate',
    name: 'Дата конкурсу',
    type: formItemTypes.DATEPICKER,
    placeholder: 'Виберіть поле',
    rules: [{ required: false, message: 'Поле обов`язкове для вибору!' }],
  },
  contestsNumber: {
    field: 'contestsNumber',
    name: '№ конкурсу',
    type: formItemTypes.INPUT,
    placeholder: 'Введіть поле',
    rules: [{ required: false, message: 'Поле обов`язкове для вибору!' }],
  },
  comment: {
    field: 'comment',
    name: 'Коментар',
    type: formItemTypes.INPUT,
    placeholder: 'Введіть поле',
    rules: [{ required: false, message: 'Поле обов`язкове для вибору!' }],
  },
};

export const DocumentsFields = {
  incomingDocument: {
    field: 'incomingDocument',
    name: 'Вхідний документ',
    type: formItemTypes.SELECT,
    classifier: classifiers.INCOMING_DOCUMENT,
    placeholder: 'Виберіть поле',
    rules: [{ required: false, message: 'Поле обов`язкове для вибору!' }],
  },
  inventory: {
    field: 'inventory',
    name: 'Інвентаризація',
    type: formItemTypes.SELECT,
    classifier: classifiers.INVENTORY,
    placeholder: 'Виберіть поле',
    rules: [{ required: false, message: 'Поле обов`язкове для вибору!' }],
  },
  outgoingDocument: {
    field: 'outgoingDocument',
    name: 'Вихідний документ',
    type: formItemTypes.SELECT,
    classifier: classifiers.OUTGOING_DOCUMENT,
    placeholder: 'Виберіть поле',
    rules: [{ required: false, message: 'Поле обов`язкове для вибору!' }],
  },
  contractSubjectEvaluationActivity: {
    field: 'contractSubjectEvaluationActivity',
    name: "Договір з суб'єктом оціночної діяльності",
    type: formItemTypes.SELECT,
    classifier: classifiers.CONTRACT_SUBJECT_EVALUATION_ACTIVITY,
    placeholder: 'Виберіть поле',
    rules: [{ required: false, message: 'Поле обов`язкове для вибору!' }],
  },
  statement: {
    field: 'statement',
    name: 'Заява',
    type: formItemTypes.SELECT,
    classifier: classifiers.STATEMENT,
    placeholder: 'Виберіть поле',
    rules: [{ required: false, message: 'Поле обов`язкове для вибору!' }],
  },
};
