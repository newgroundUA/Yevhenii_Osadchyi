import moment from 'moment';

import * as formItemTypes from '../../constants/FormItemTypes';
import * as classifiers from '../../constants/ClassifiersNames';

import { createValueCreator } from '../../helpers/formHelpers/dropdownValueCreators';
import { isRequired } from '../../services/validator/rules';
import { PRIVATIZATION_OBJECTS } from '../../constants/actionTypes/documents/DocumentsConstants';

const DATE_FORMAT_BE = 'YYYY-MM-DD HH:mm:ss.SSS Z';
const getDate = (data) => (data ? moment(data, DATE_FORMAT_BE) : null);
const createDocumentValue = createValueCreator('document');
const createCounterpatryValue = createValueCreator('counterparty');
const createObjectValue = createValueCreator('object');
const defaultValuableFields = ['guid', 'versionId'];

// privatisationProgram PrivatisationProgram

export const privatisationProgramFields = {
  privatisationObjectStatus: {
    field: 'privatisationObjectStatus',
    name: "Стан приватизації об'єкту",
    type: formItemTypes.SELECT,
    classifier: classifiers.PRIVAT_OBJECT_STATUS,
    rules: [isRequired()],
  },
  privatisationOrganisation: {
    field: 'privatisationOrganisation',
    name: 'Орган приватизації',
    type: formItemTypes.SELECT,
    valuableFields: defaultValuableFields,
    classifier: classifiers.COUNTERPARTY,
  },
  privatisationOrganisationType: {
    field: 'privatisationOrganisationType',
    name: 'Вид органу приватизаціїї',
    type: formItemTypes.SELECT,
    valuableFields: defaultValuableFields.concat('type'),
    classifier: classifiers.PRIVAT_ORGANISATION_TYPE,
    colSpan: 12,
  },
  privatisationStageType: {
    field: 'privatisationStageType',
    name: 'Етап приватизації',
    type: formItemTypes.SELECT,
    valuableFields: defaultValuableFields.concat('type'),
    classifier: classifiers.PRIVAT_STAGE_TYPE,
    rules: [isRequired()],
    colSpan: 24,
  },
  privatObjectGroupType: {
    field: 'privatObjectGroupType',
    name: "Тип об'єкту приватизації",
    type: formItemTypes.SELECT,
    classifier: classifiers.PRIVAT_OBJECT_GROUP_TYPE,
    valuableFields: defaultValuableFields.concat('type'),
    rules: [isRequired()],
    colSpan: 18,
  },
  privatisationMethodType: {
    field: 'privatisationMethodType',
    name: 'Спосіб приватизації',
    type: formItemTypes.SELECT,
    valuableFields: defaultValuableFields.concat('type'),
    classifier: classifiers.PRIVAT_METHOD_TYPE,
  },
  privatisationReasonDocs: {
    field: 'privatisationReasonDocs',
    name: 'Рішення київської міської ради',
    type: formItemTypes.MULTISELECT,
    valuableFields: defaultValuableFields,
    classifier: classifiers.DOCUMENTS,
    colSpan: 24,
  },
  privatisationProcStartDate: {
    field: 'privatisationProcStartDate',
    name: 'Дата початку процессу приватизації',
    type: formItemTypes.DATEPICKER,
    rules: [isRequired()],
  },
  privatisationProcEndDate: {
    field: 'privatisationProcEndDate',
    name: 'Дата закриття процессу приватизації',
    type: formItemTypes.DATEPICKER,
  },
  privatisationProcNextControlDate: {
    field: 'privatisationProcNextControlDate',
    name: 'Чергова контрольна дата',
    type: formItemTypes.DATEPICKER,
  },
  orderNumberInDoc: {
    field: 'orderNumberInDoc',
    name: 'Порядковий номер в рішенні',
    type: formItemTypes.INPUT,
  },
  recordNotes: {
    field: 'recordNotes',
    name: 'Примітки',
    type: formItemTypes.TEXTAREA,
    colSpan: 24,
  },
};

export const parsePrivatisationProgramToFE = (props) => ({
  privatisationObjectStatus: props.privatisationObjectStatus,

  privatisationStageType: (props.privatisationStageType || {}).guid,
  privatisationOrganisationType: (props.privatisationOrganisationType || {}).guid,
  privatObjectGroupType: (props.privatObjectGroupType || {}).guid,
  privatisationMethodType: (props.privatisationMethodType || {}).guid,

  privatisationProcStartDate: getDate(props.privatisationProcStartDate),
  privatisationProcEndDate: getDate(props.privatisationProcEndDate),
  privatisationProcNextControlDate: getDate(props.privatisationProcNextControlDate),

  privatisationOrganisation: createCounterpatryValue(props.privatisationOrganisation),

  privatisationReasonDocs: createDocumentValue(props.privatisationReasonDocs),
  docAboutPrivatisation: createDocumentValue(props.docAboutPrivatisation),
  privContract: createDocumentValue(props.privContract), // documents

  orderNumberInDoc: props.orderNumberInDoc,
  recordNotes: props.recordNotes,
});

export const parsePrivatisationProgramToBE = (props) => ({
  privatisationObjectStatus: props.privatisationObjectStatus, // enum

  privatisationStageType: props.privatisationStageType,
  privatisationOrganisationType: props.privatisationOrganisationType,
  privatObjectGroupType: props.privatObjectGroupType,
  privatisationMethodType: props.privatisationMethodType,

  privatisationProcStartDate: props.privatisationProcStartDate,
  privatisationProcEndDate: props.privatisationProcEndDate,
  privatisationProcNextControlDate: props.privatisationProcNextControlDate,

  privatisationOrganisation: props.privatisationOrganisation,

  privatisationReasonDocs: props.privatisationReasonDocs || [],
  docAboutPrivatisation: props.docAboutPrivatisation || [],
  privContract: props.privContract || [],

  orderNumberInDoc: props.orderNumberInDoc,
  recordNotes: props.recordNotes,
});

// privatisationObjects PrivatisationObjects

export const privatisationObjectsFields = {
  privatObjectNumber: {
    field: 'privatObjectNumber',
    name: "Реєстровий номер об'єкту приватизації",
    type: formItemTypes.INPUT,
    rules: [isRequired()],
  },
  privatObjectFullName: {
    field: 'privatObjectFullName',
    name: "Назва об'єкту приватизації повна",
    type: formItemTypes.INPUT,
    rules: [isRequired()],
  },
  privatObjectShortName: {
    field: 'privatObjectShortName',
    name: "Назва об'єкту приватизації коротка",
    type: formItemTypes.INPUT,
  },
  privatObjectTotalSpace: {
    field: 'privatObjectTotalSpace',
    name: 'Загальна площа, кв. м.',
    type: formItemTypes.INPUT,
  },
  privatObjectUsefullSpace: {
    field: 'privatObjectUsefullSpace',
    name: 'Загальна корисна площа, кв. м',
    type: formItemTypes.INPUT,
  },
  privatObjectCommonUseSpace: {
    field: 'privatObjectCommonUseSpace',
    name: 'Площа приміщень загального користування, кв.м.',
    type: formItemTypes.INPUT,
  },
  objectsForPrivat: {
    field: 'objectsForPrivat',
    name: "Майнові об'єкти в складі об'єкту приватизації",
    type: formItemTypes.MULTISELECT,
    classifier: classifiers.OBJECTS,
    valuableFields: defaultValuableFields.concat(['fullName', 'shortName']),
    rules: [isRequired()],
    colSpan: 24,
  },
  address: {
    field: 'address',
    name: 'Адреса розташування',
    customRendered: true,
    rules: [isRequired()],
  },
};

export const parsePrivatisationObjectsToFE = (props) => ({
  privatObjectNumber: props.privatObjectNumber,
  privatObjectFullName: props.privatObjectFullName,
  privatObjectShortName: props.privatObjectShortName,
  privatObjectTotalSpace: props.privatObjectTotalSpace,
  privatObjectUsefullSpace: props.privatObjectUsefullSpace,
  privatObjectCommonUseSpace: props.privatObjectCommonUseSpace,

  objectsForPrivat: createObjectValue(props.objectsForPrivat),
  address: props.address,
});

export const parsePrivatisationObjectsToBE = (props) => ({
  privatObjectNumber: props.privatObjectNumber,
  privatObjectFullName: props.privatObjectFullName,
  privatObjectShortName: props.privatObjectShortName,
  privatObjectTotalSpace: props.privatObjectTotalSpace,
  privatObjectUsefullSpace: props.privatObjectUsefullSpace,
  privatObjectCommonUseSpace: props.privatObjectCommonUseSpace,
  groupedObjectsType: PRIVATIZATION_OBJECTS,
  objectsForPrivat: props.objectsForPrivat || [],
  address: props.address,
});
