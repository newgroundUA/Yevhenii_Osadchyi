import * as formItemTypes from '../../constants/FormItemTypes';
import * as classifiers from '../../constants/ClassifiersNames';

export const applicationForEvaluationFields = {
  objectAddress: {
    field: 'objectAddress',
    name: "Адреса об'єкта",
    type: formItemTypes.SELECT,
    classifier: classifiers.OBJECT_ADDRESS,
    placeholder: 'Виберіть адресу для пошуку',
    rules: [],
  },
  initiator: {
    field: 'initiator',
    name: 'Ініціатор',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    rules: [],
    placeholder: 'Виберіть потрібного контрагента',
  },
  processClasification: {
    field: 'processClasification',
    name: 'Класифікація процесу',
    type: formItemTypes.SELECT,
    classifier: classifiers.CLASSIFICATION_PROCESS,
    rules: [],
  },
};

export const objectOfEvaluationFields = {
  objectOfEvaluation: {
    field: 'objectOfEvaluation',
    name: "Об'єкт оцінки",
    type: formItemTypes.SELECT,
    classifier: classifiers.OBJECTS,
    placeholder: 'Введіть назву ООМ для пошуку',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  objectCostWithoutVAT: {
    field: 'objectCostWithoutVAT',
    name: "Вартість об'єкта оцінки без ПДВ, для приватизації (грн.)",
    type: formItemTypes.INPUT,
    rules: [],
  },
  evaluationDate: {
    field: 'evaluationDate',
    name: 'Дата оцінки',
    type: formItemTypes.DATEPICKER,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  objectCostWithVAT: {
    field: 'objectCostWithVAT',
    name: "Вартість об'єкта оцінки з ПДВ (грн.)",
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  objectCostWithoutVATLocalCommunity: {
    field: 'objectCostWithoutVATLocalCommunity',
    name:
      "Вартість об'єкта оцінки без ПДВ (частка тер.громади, у разі приватизації з невід’ємними поліпшеннями) (грн.)",
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  objectCostWithVATLocalCommunity: {
    field: 'objectCostWithVATLocalCommunity',
    name:
      "Вартість об'єкта оцінки з ПДВ (частка тер.громади, у разі приватизації з невід’ємними поліпшеннями) (грн.)",
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  shareOfTerritorialCommunity: {
    field: 'shareOfTerritorialCommunity',
    name: 'Частка територіальної громади у разі приватизації з невід’ємними поліпшеннями (%)',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  costOfTerritorialCommunity: {
    field: 'costOfTerritorialCommunity',
    name: 'Вартість територіальної громади у разі приватизації з невід’ємними поліпшеннями (грн.)',
    type: formItemTypes.INPUT,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  oneSqMCostUSD: {
    field: 'oneSqMCostUSD',
    name: 'Вартість 1 кв.м. без ПДВ (дол. США.)',
    type: formItemTypes.INPUT,
    rules: [],
  },
  costOfFixedAssetsUAH: {
    field: 'costOfFixedAssetsUAH',
    name: 'Вартість основних засобів (грн.)',
    type: formItemTypes.INPUT,
    rules: [],
  },
  costOfIntangibleAssetsUAH: {
    field: 'costOfIntangibleAssetsUAH',
    name: 'Вартість нематеріальних активів (грн.)',
    type: formItemTypes.INPUT,
    rules: [],
  },
};

export const evaluationProcessFields = {
  evaluationStage: {
    field: 'evaluationStage',
    name: 'Етап оцінки',
    type: formItemTypes.SELECT,
    classifier: classifiers.EVALUATION_STAGE,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  reviewCategory: {
    field: 'reviewCategory',
    name: 'Категорія рецензії',
    type: formItemTypes.INPUT,
    classifier: classifiers.ASSESSMENT_REVIEWING_CATEGORY,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  comment: {
    field: 'comment',
    name: 'Коментар / пояснення',
    type: formItemTypes.TEXTAREA,
    rules: [],
  },
  reviewer: {
    field: 'reviewer',
    name: 'Рецензент',
    type: formItemTypes.SELECT,
    classifier: classifiers.COUNTERPARTY,
    placeholder: 'Введіть назву контрагента для пошуку',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  conclusion: {
    field: 'conclusion',
    name: 'Висновок про можливість застосування результату оцінки об’єкта оренди',
    type: formItemTypes.INPUT,
    placeholder: 'Коментар / пояснення',
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  processBeginning: {
    field: 'processBeginning',
    name: 'Початок процесу',
    type: formItemTypes.DATEPICKER,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  processEnd: {
    field: 'processEnd',
    name: 'Закінчення процесу',
    type: formItemTypes.DATEPICKER,
    rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
  },
  checkDate: {
    field: 'checkDate',
    name: 'Контрольна дата',
    type: formItemTypes.DATEPICKER,
  },
};
