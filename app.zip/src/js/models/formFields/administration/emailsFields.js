import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';

const defaultValuableFields = ['guid', 'versionId', 'type'];

export const emailName = {
  field: 'emailName',
  name: 'Електронна адреса',
  type: formItemTypes.INPUT,
  rules: [{ required: true, message: 'Адреса повинна бути вказана!' }],
};
export const emailTypes = {
  field: 'emailTypes',
  name: 'Тип електронної адреси',
  type: formItemTypes.MULTISELECT,
  classifier: classifiers.EMAIL_TYPE,
  valuableFields: defaultValuableFields,
  rules: [{ required: true, message: 'Тип повинен бути вказан!' }],
};
export const emailsFields = {
  emailName,
  emailTypes,
  notes: {
    field: 'notes',
    name: 'Додаткова інформація',
    type: formItemTypes.TEXTAREA,
  },
};

export const getMappedForm = (props) => ({
  emailName: props.emailName,
  notes: props.notes,
  emailTypes: props.emailTypes || [],
});

export const getParsedForm = () => ({});
