import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';

const defaultValuableFields = ['guid', 'versionId', 'type'];

export const wwwPage = {
  field: 'wwwPage',
  name: 'Сайт',
  type: formItemTypes.INPUT,
  rules: [{ required: true, message: 'Сайт повинен бути вказан!' }],
};
export const webSiteTypes = {
  field: 'webSiteTypes',
  name: 'Тип сайта',
  type: formItemTypes.MULTISELECT,
  classifier: classifiers.SITE_TYPE,
  valuableFields: defaultValuableFields,
  rules: [{ required: true, message: 'Тип сайта повинен бути вказан!' }],
};

export const sitesFields = {
  wwwPage,
  webSiteTypes,
  notes: {
    field: 'notes',
    name: 'Додаткова інформація',
    type: formItemTypes.TEXTAREA,
  },
};

export const getMappedForm = (props) => ({
  wwwPage: props.wwwPage,
  notes: props.notes,
  webSiteTypes: props.webSiteTypes || [],
});

export const getParsedForm = () => ({});
