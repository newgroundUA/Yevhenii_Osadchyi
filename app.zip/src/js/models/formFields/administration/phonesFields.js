import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';

const defaultValuableFields = ['guid', 'versionId', 'type'];
export const phoneNumber = {
  field: 'phoneNumber',
  name: 'Телефон',
  type: formItemTypes.INPUT,
  rules: [{ required: true, message: 'Телефон повинен бути вказан!' }],
};

export const phoneTypes = {
  field: 'phoneTypes',
  name: 'Тип телефону',
  type: formItemTypes.MULTISELECT,
  classifier: classifiers.PHONE_TYPE,
  valuableFields: defaultValuableFields,
  rules: [{ required: true, message: 'Тип телефона повинен бути вказан!' }],
};

export const phonesFields = {
  phoneNumber,
  phoneTypes,
  notes: {
    field: 'notes',
    name: 'Додаткова інформація',
    type: formItemTypes.TEXTAREA,
  },
};

export const getMappedForm = (props) => ({
  phoneNumber: props.phoneNumber,
  notes: props.notes,
  phoneTypes: props.phoneTypes || [],
});

export const getParsedForm = () => ({});
