export const STARTS_WITH = {
  value: 'starts_with',
  label: 'Починається з',
};
export const ENDS_WITH = {
  value: 'ends_with',
  label: 'Закінчується на',
};
export const CONTAINS = {
  value: 'contains',
  label: 'Містить',
};
export const NOT_CONTAINS = {
  value: 'not_contain',
  label: 'Не містить',
};
export const EQUALS = {
  value: 'equals',
  label: 'Дорівнює',
};
export const LESS_THEN = {
  value: 'less_then',
  label: 'Менше',
};
export const LESS_THEN_OR_EQUAL = {
  value: 'less_then_or_equal',
  label: 'Менше або дорівнює',
};
export const GREATER_THEN = {
  value: 'greater_then',
  label: 'Більше',
};
export const GREATER_THEN_OR_EQUAL = {
  value: 'greater_then_or_equal',
  label: 'Більше або дорівнює',
};
export const NOT_EQUALS = {
  value: 'not_equal',
  label: 'Не дорівнює',
};

export const defaultCriterias = [
  STARTS_WITH,
  ENDS_WITH,
  CONTAINS,
  NOT_CONTAINS,
  EQUALS,
  NOT_EQUALS,
];
export const equalityCriterias = [EQUALS, NOT_EQUALS];
export const containsCriterias = [CONTAINS, NOT_CONTAINS];
