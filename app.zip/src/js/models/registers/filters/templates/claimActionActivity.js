import { defaultCriterias, equalityCriterias } from '../criterias';
import {
  getDateFormField,
  getStrInputFormField,
} from '../../../../helpers/formHelpers/filedsBuilders';
import * as formItemTypes from '../../../../constants/FormItemTypes';
import * as classifiers from '../../../../constants/ClassifiersNames';
import { isRequired } from '../../../../services/validator/rules';

export const claimActionActivityFilters = {
  regNumber: {
    type: 'regNumber',
    label: 'Реєстраційний номер ',
    criterias: defaultCriterias,
    valueFormFieldModel: getStrInputFormField('regNumber'),
  },
  contractNumber: {
    type: 'contractNumber',
    label: 'Договір оренди: Номер',
    criterias: defaultCriterias,
    valueFormFieldModel: getStrInputFormField('contractNumber'),
  },
  contractRegDate: {
    type: 'contractRegDate',
    label: 'Договір оренди: Дата',
    criterias: equalityCriterias,
    valueFormFieldModel: getDateFormField('contractRegDate'),
  },
  landlordName: {
    type: 'landlordName',
    label: 'Орендодавець',
    criterias: defaultCriterias,
    valueFormFieldModel: getStrInputFormField('landlordName'),
  },
  renterName: {
    type: 'renterName',
    label: 'Орендар',
    criterias: defaultCriterias,
    valueFormFieldModel: getStrInputFormField('renterName'),
  },
  balanceKeeperName: {
    type: 'balanceKeeperName',
    label: 'Балансоутримувач',
    criterias: defaultCriterias,
    valueFormFieldModel: getStrInputFormField('balanceKeeperName'),
  },
  initialDebtTotal: {
    type: 'initialDebtTotal',
    label: 'Початкова сума заборгованості - загальна',
    criterias: equalityCriterias,
    valueFormFieldModel: getStrInputFormField('initialDebtTotal'),
  },
  initialDebtLease: {
    type: 'initialDebtLease',
    label: 'Початкова сума заборгованості - по оренді',
    criterias: equalityCriterias,
    valueFormFieldModel: getStrInputFormField('initialDebtLease'),
  },
  initialDebtFine: {
    type: 'initialDebtFine',
    label: 'Початкова сума заборгованості - штраф/пеня',
    criterias: equalityCriterias,
    valueFormFieldModel: getStrInputFormField('initialDebtFine'),
  },
  currentDebtTotal: {
    type: 'currentDebtTotal',
    label: 'Поточна сума заборгованості - загальна',
    criterias: equalityCriterias,
    valueFormFieldModel: getStrInputFormField('currentDebtTotal'),
  },
  currentDebtLease: {
    type: 'currentDebtLease',
    label: 'Поточна сума заборгованості - по оренді',
    criterias: equalityCriterias,
    valueFormFieldModel: getStrInputFormField('currentDebtLease'),
  },
  currentDebtFine: {
    type: 'currentDebtFine',
    label: 'Поточна сума заборгованості - штраф/пеня',
    criterias: equalityCriterias,
    valueFormFieldModel: getStrInputFormField('currentDebtFine'),
  },
  statusType: {
    type: 'statusType',
    label: 'Стан ППД',
    criterias: equalityCriterias,
    valueFormFieldModel: {
      field: 'statusType',
      type: formItemTypes.SELECT,
      classifier: classifiers.CLAIM_ACTION_ACTIVITY_STATUS,
      placeholder: 'Виберіть стан реєстрації',
      rules: [isRequired()],
      colSpan: 24,
    },
  },
  stepsCount: {
    type: 'stepsCount',
    label: 'Кількість заходів',
    criterias: equalityCriterias,
    valueFormFieldModel: getStrInputFormField('stepsCount'),
  },
  // legalAffair: {
  //   type: 'legalAffair',
  //   label: 'Юридична справа',
  //   criterias: defaultCriterias,
  //   valueFormFieldModel: getDocumentsLiveSearchFormField('legalAffair'),
  // }, TODO: revert after BE implemented filtering by this field
};
