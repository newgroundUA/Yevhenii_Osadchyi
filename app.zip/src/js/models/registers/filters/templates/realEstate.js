import {
  EQUALS,
  CONTAINS,
  NOT_CONTAINS,
  LESS_THEN,
  LESS_THEN_OR_EQUAL,
  GREATER_THEN,
  GREATER_THEN_OR_EQUAL,
} from '../criterias';
import {
  getDateFormField,
  getStrInputFormField,
  getFormField,
  getSelectFormField,
} from '../../../../helpers/formHelpers/filedsBuilders';
import * as formItemTypes from '../../../../constants/FormItemTypes';
import * as classifiers from '../../../../constants/ClassifiersNames';
import { isRequired } from '../../../../services/validator/rules';
import { clStateProperty, technicalState } from '../../../formFields/property/generalFields';

export const realEstateRegistryFiltersTemplate = {
  fullName: {
    type: 'fullName',
    label: 'Повна назва',
    criterias: [EQUALS, CONTAINS, NOT_CONTAINS],
    valueFormFieldModel: getStrInputFormField({ field: 'fullName' }),
  },
  statePropertyType: {
    // TODO: implement client-side search
    type: 'statePropertyType',
    label: "Тип об'єкту за КДМ",
    criterias: [EQUALS],
    valueFormFieldModel: getFormField({
      ...clStateProperty,
      colSpan: 24,
      rules: [isRequired()],
      readOnly: false,
    }),
  },
  derivativeOwner: {
    type: 'derivativeOwner',
    label: 'Повна назва балансоутримувача',
    criterias: [EQUALS, CONTAINS, NOT_CONTAINS],
    valueFormFieldModel: getStrInputFormField({ field: 'derivativeOwner' }),
  },
  derivativeOwnerEdrpou: {
    type: 'derivativeOwnerEdrpou',
    label: 'Код ЄДРПОУ балансоутримувача',
    criterias: [EQUALS, CONTAINS, NOT_CONTAINS],
    valueFormFieldModel: getStrInputFormField({ field: 'derivativeOwnerEdrpou' }),
  },
  inputTotalSpace: {
    type: 'inputTotalSpace',
    label: 'Загальна площа (кв.м.)',
    criterias: [EQUALS, LESS_THEN, LESS_THEN_OR_EQUAL, GREATER_THEN, GREATER_THEN_OR_EQUAL],
    valueFormFieldModel: getStrInputFormField({ field: 'inputTotalSpace' }),
  },
  primaryOwners: {
    type: 'primaryOwners',
    label: 'Повна назва/ЄДРПОУ власника майна',
    criterias: [CONTAINS, NOT_CONTAINS],
    valueFormFieldModel: getStrInputFormField({ field: 'primaryOwners' }),
  },
  propertyOwnershipType: {
    type: 'propertyOwnershipType',
    label: 'Форма власності майна',
    criterias: [EQUALS],
    valueFormFieldModel: {
      field: 'propertyOwnershipType',
      type: formItemTypes.SELECT,
      classifier: classifiers.CL_PROPERTY_OWNERSHIP_TYPE,
      placeholder: 'Виберіть форму власності майна',
      rules: [isRequired()],
      colSpan: 24,
    },
  },
  shortName: {
    type: 'shortName',
    label: 'Скорочена назва ООМ',
    criterias: [CONTAINS, EQUALS],
    valueFormFieldModel: getStrInputFormField({ field: 'shortName' }),
  },
  assetSpecializationInput: {
    type: 'assetSpecializationInput',
    label: 'Призначення',
    criterias: [CONTAINS, NOT_CONTAINS, EQUALS],
    valueFormFieldModel: getStrInputFormField({ field: 'assetSpecializationInput' }),
  },
  yearValidFrom: {
    type: 'yearValidFrom',
    label: 'Рік побудови',
    criterias: [EQUALS, GREATER_THEN, LESS_THEN],
    valueFormFieldModel: getSelectFormField({
      field: 'contractRegDate',
      classifier: classifiers.YEARS,
    }),
  },
  dateTo: {
    type: 'dateTo',
    label: 'Дата ліквідації',
    criterias: [EQUALS, LESS_THEN, LESS_THEN_OR_EQUAL, GREATER_THEN, GREATER_THEN_OR_EQUAL],
    valueFormFieldModel: getDateFormField({
      field: 'contractRegDate',
    }),
  },
  parentAccountingItemName: {
    type: 'parentAccountingItemName',
    label: "Батьківський об'єкт",
    criterias: [CONTAINS, NOT_CONTAINS, EQUALS],
    valueFormFieldModel: getStrInputFormField({ field: 'parentAccountingItemName' }),
  },
  technicalState: {
    type: 'technicalState',
    label: 'Технічний стан',
    valueFormFieldModel: getFormField({
      ...technicalState,
      colSpan: 24,
      rules: [isRequired()],
    }),
  },
  accountingItemId: {
    type: 'accountingItemId',
    label: 'Обліковий номер в ЄІС',
    criterias: [CONTAINS, NOT_CONTAINS, EQUALS],
    valueFormFieldModel: getStrInputFormField({ field: 'accountingItemId' }),
  },
  inventNumber: {
    type: 'inventNumber',
    label: 'Інвентарний номер',
    criterias: [CONTAINS, NOT_CONTAINS, EQUALS],
    valueFormFieldModel: getStrInputFormField({ field: 'inventNumber' }),
  },
  firstCost: {
    type: 'firstCost',
    label: 'Первісна вартість (грн.)',
    criterias: [EQUALS, LESS_THEN, LESS_THEN_OR_EQUAL, GREATER_THEN, GREATER_THEN_OR_EQUAL],
    valueFormFieldModel: getStrInputFormField({ field: 'firstCost' }),
  },
  endCost: {
    type: 'endCost',
    label: 'Залишкова вартість (грн.)',
    criterias: [EQUALS, LESS_THEN, LESS_THEN_OR_EQUAL, GREATER_THEN, GREATER_THEN_OR_EQUAL],
    valueFormFieldModel: getStrInputFormField({ field: 'endCost' }),
  },
  endCostDate: {
    type: 'endCostDate',
    label: 'Дата розрахунку залишкової вартості',
    criterias: [EQUALS, LESS_THEN, LESS_THEN_OR_EQUAL, GREATER_THEN, GREATER_THEN_OR_EQUAL],
    valueFormFieldModel: getDateFormField({
      field: 'endCostDate',
    }),
  },
  historyValue: {
    type: 'historyValue',
    label: 'Історича цінність',
    criterias: [EQUALS],
    valueFormFieldModel: {
      field: 'historyValue',
      type: formItemTypes.SELECT,
      classifier: classifiers.YES_NO,
      rules: [isRequired()],
      colSpan: 24,
    },
  },
  inPrivatizationProgram: {
    type: 'inPrivatizationProgram',
    label: 'В програмі приватизації',
    criterias: [EQUALS],
    valueFormFieldModel: {
      field: 'inPrivatizationProgram',
      type: formItemTypes.SELECT,
      classifier: classifiers.YES_NO,
      rules: [isRequired()],
      colSpan: 24,
    },
  },
};
