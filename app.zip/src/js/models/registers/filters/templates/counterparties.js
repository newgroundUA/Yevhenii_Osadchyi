import { phoneNumber } from '../../../formFields/administration/phonesFields';
import { emailName } from '../../../formFields/administration/emailsFields';
import { wwwPage } from '../../../formFields/administration/sitesFields';
import { kopfg, mainKved } from '../../../formFields/counterparty/fopFields';

import * as formItemTypes from '../../../../constants/FormItemTypes';
import * as classifiers from '../../../../constants/ClassifiersNames';
import {
  getStrInputFormField,
  getFormField,
  getDocTypeCascaderFormField,
} from '../../../../helpers/formHelpers/filedsBuilders';
import { defaultCriterias, equalityCriterias, containsCriterias } from '../criterias';

import {
  ownerShip,
  formOfFunding,
  formSubjectOfEconomy,
  typeBySKODY,
  legalEntityStatus,
  syPablicGroup,
  rateToBudget,
  isModelStatut,
  regRecNumber,
} from '../../../formFields/counterparty/legalFields';
import { isRequired } from '../../../../services/validator/rules';

export const counterpartyFilters = {
  fullName: {
    type: 'fullName',
    label: 'Назва коротко ЮО',
    criterias: defaultCriterias,
    valueFormFieldModel: getStrInputFormField({
      field: 'fullName',
    }),
  },
  shortName: {
    type: 'shortName',
    label: 'ПІБ коротко ФО/ФОП',
    criterias: defaultCriterias,
    valueFormFieldModel: getStrInputFormField({
      field: 'shortName',
    }),
  },
  itnEdrpou: {
    type: 'itnEdrpou',
    label: 'КОД ЄДРПОУ/ІПН',
    criterias: defaultCriterias,
    valueFormFieldModel: getStrInputFormField({
      field: 'itnEdrpou',
    }),
  },
  kopfg: {
    type: 'kopfg', // live_search
    label: 'Форма господарювання',
    criterias: equalityCriterias,
    valueFormFieldModel: getFormField({
      ...kopfg,
      colSpan: 24,
      rules: [isRequired()],
    }),
  },
  phoneNumber: {
    type: 'phoneNumber',
    label: 'Телефони',
    criterias: defaultCriterias,
    valueFormFieldModel: getFormField({
      ...phoneNumber,
      colSpan: 24,
      rules: [isRequired()],
    }),
  },
  email: {
    type: 'email',
    label: 'Електронні адреси',
    criterias: defaultCriterias,
    valueFormFieldModel: getFormField({
      ...emailName,
      colSpan: 24,
      rules: [isRequired()],
    }),
  },
  site: {
    type: 'site',
    label: 'Сайт',
    criterias: defaultCriterias,
    valueFormFieldModel: getFormField({
      ...wwwPage,
      colSpan: 24,
      rules: [isRequired()],
    }),
  },
  docType: {
    type: 'docType', // cascade_document_type_selection
    label: "Тип  прив'язаного документа",
    criterias: equalityCriterias,
    valueFormFieldModel: getDocTypeCascaderFormField({
      field: 'docType',
    }),
  },
  mainKved: {
    type: 'mainKved', // live_search
    label: 'Основний за КВЕД',
    criterias: equalityCriterias,
    valueFormFieldModel: getFormField({
      ...mainKved,
      colSpan: 24,
      rules: [isRequired()],
    }),
  },
  kvedInternal: {
    type: 'kvedInternal', // is it true type choosed?  live_search
    label: 'Види діяльності за КВЕД',
    criterias: containsCriterias,
    valueFormFieldModel: getFormField({
      ...mainKved,
      colSpan: 24,
      rules: [isRequired()],
    }),
  },
  kvedType: {
    type: 'kvedType', // live_search
    label: 'Форма власності',
    criterias: equalityCriterias,
    valueFormFieldModel: getFormField({
      ...ownerShip,
      colSpan: 24,
      rules: [isRequired()],
    }),
  },
  finSourceType: {
    type: 'finSourceType', // live_search
    label: 'Форма фінансування',
    criterias: containsCriterias,
    valueFormFieldModel: getFormField({
      ...formOfFunding,
      colSpan: 24,
      rules: [isRequired()],
    }),
  },
  skof: {
    type: 'skof',
    label: "Форма суб'єкту економіки", // live_search
    criterias: equalityCriterias,
    valueFormFieldModel: getFormField({
      ...formSubjectOfEconomy,
      colSpan: 24,
      rules: [isRequired()],
    }),
  },
  legalMainOrganization: {
    // text field
    type: 'legalMainOrganization',
    label: 'Головна організація, повна назва',
    criterias: defaultCriterias,
    valueFormFieldModel: getStrInputFormField({
      field: 'legalMainOrganization',
    }),
  },
  legalSkodu: {
    type: 'legalSkodu', // live search
    label: 'Тип за СКОДУ',
    criterias: equalityCriterias,
    valueFormFieldModel: getFormField({
      ...typeBySKODY,
      colSpan: 24,
      rules: [isRequired()],
    }),
  },
  legalStatus: {
    type: 'legalStatus', // yes_no classification
    label: 'Статус юридичної особи',
    criterias: equalityCriterias,
    valueFormFieldModel: getFormField({
      ...legalEntityStatus,
      colSpan: 24,
      rules: [isRequired()],
    }),
  },
  legalPartOfParty: {
    type: 'legalPartOfParty', // yes_no classification
    label: 'СУ громадської партії',
    criterias: equalityCriterias,
    valueFormFieldModel: getFormField({
      ...syPablicGroup,
      colSpan: 24,
      rules: [isRequired()],
    }),
  },
  legalPartOfCivilFormation: {
    type: 'legalPartOfCivilFormation', // yes_no classification
    label: 'СУ громадського формування',
    criterias: equalityCriterias,
    valueFormFieldModel: getFormField({
      ...syPablicGroup,
      colSpan: 24,
      rules: [isRequired()],
    }),
  },
  legalBudgetDeductionRate: {
    type: 'legalBudgetDeductionRate',
    label: 'Ставка відр. До бюдж.',
    criterias: equalityCriterias,
    valueFormFieldModel: getFormField({
      ...rateToBudget,
      colSpan: 24,
      rules: [isRequired()],
    }),
  },
  stateRegistration: {
    type: 'stateRegistration', // &
    label: 'Стан реєстрації',
    criterias: equalityCriterias,
    valueFormFieldModel: {
      field: 'stateRegistration',
      type: formItemTypes.SELECT,
      classifier: classifiers.LEGAL_ENTITY_STATE,
      placeholder: 'Виберіть стан реєстрації',
      rules: [isRequired()],
      colSpan: 24,
    },
  },
  isModelStatut: {
    type: 'isModelStatut', // yes_no classification
    label: 'Модельний статут',
    criterias: equalityCriterias,
    valueFormFieldModel: getFormField({
      ...isModelStatut,
      colSpan: 24,
      rules: [isRequired()],
    }),
  },
  regRecNumber: {
    type: 'regRecNumber',
    label: 'Номер запису про реєстрацію',
    criterias: defaultCriterias,
    valueFormFieldModel: getFormField({
      ...regRecNumber,
      colSpan: 24,
      rules: [isRequired()],
    }),
  },
  legalStatutCapital: {
    type: 'legalStatutCapital',
    label: 'Розмір Статут. Кап., грн',
    criterias: defaultCriterias,
    valueFormFieldModel: getStrInputFormField({
      field: 'legalStatutCapital',
    }),
  },
};
