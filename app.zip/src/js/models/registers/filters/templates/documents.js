import { equalityCriterias, defaultCriterias, containsCriterias } from '../criterias';
import {
  getStrInputFormField,
  getDocTypeCascaderFormField,
} from '../../../../helpers/formHelpers/filedsBuilders';
import * as formItemTypes from '../../../../constants/FormItemTypes';
import { isRequired } from '../../../../services/validator/rules';
import * as classifiers from '../../../../constants/ClassifiersNames';

export const documentsFilters = {
  refDocumentTypeName: {
    type: 'refDocumentTypeName',
    label: 'Тип документу',
    criterias: equalityCriterias,
    valueFormFieldModel: getDocTypeCascaderFormField({
      field: 'refDocumentTypeName',
    }),
  },
  docRegNumber: {
    type: 'docRegNumber',
    label: 'Внутрішній реєстраційний номер',
    criterias: defaultCriterias,
    valueFormFieldModel: getStrInputFormField({
      field: 'docRegNumber',
    }),
  },
  docSerialNumber: {
    type: 'docSerialNumber',
    label: 'Серія',
    criterias: defaultCriterias,
    valueFormFieldModel: getStrInputFormField({
      field: 'docSerialNumber',
    }),
  },
  docNumber: {
    type: 'docNumber',
    label: 'Номер',
    criterias: defaultCriterias,
    valueFormFieldModel: getStrInputFormField({
      field: 'docNumber',
    }),
  },
  publishers: {
    type: 'publishers',
    label: 'Видавач',
    criterias: defaultCriterias,
    valueFormFieldModel: getStrInputFormField({
      field: 'publishers',
    }),
  },
  recipients: {
    type: 'recipients',
    label: 'Отримувач',
    criterias: defaultCriterias,
    valueFormFieldModel: getStrInputFormField({
      field: 'recipients',
    }),
  },
  docDescription: {
    type: 'docDescription',
    label: 'Опис',
    criterias: defaultCriterias,
    valueFormFieldModel: getStrInputFormField({
      field: 'docDescription',
    }),
  },
  docWWWPage: {
    type: 'docWWWPage',
    label: 'Веб посилання',
    criterias: defaultCriterias,
    valueFormFieldModel: getStrInputFormField({
      field: 'docWWWPage',
    }),
  },
  validityStatus: {
    type: 'validityStatus',
    label: 'Чинність',
    criterias: defaultCriterias,
    valueFormFieldModel: {
      field: 'validityStatus',
      type: formItemTypes.SELECT,
      classifier: classifiers.CL_DOC_VALIDITY_STATUS,
      placeholder: 'Виберіть чинність документа',
      rules: [isRequired()],
      colSpan: 24,
    },
  },
  parentDocument: {
    type: 'parentDocument', // cascade_document_type_selection
    label: 'Головний документ',
    criterias: equalityCriterias,
    valueFormFieldModel: getDocTypeCascaderFormField({
      field: 'parentDocument',
    }),
  },
  childrenDocuments: {
    type: 'childrenDocuments', // cascade_document_type_selection
    label: 'Підпорядковані документи',
    criterias: containsCriterias,
    valueFormFieldModel: getDocTypeCascaderFormField({
      field: 'childrenDocuments',
    }),
  },
  linkedDocuments: {
    type: 'linkedDocuments', // cascade_document_type_selection
    label: "Пов'язані документи",
    criterias: containsCriterias,
    valueFormFieldModel: getDocTypeCascaderFormField({
      field: 'linkedDocuments',
    }),
  },
  creator: {
    type: 'creator',
    label: 'Автор',
    criterias: defaultCriterias,
    valueFormFieldModel: getStrInputFormField('creator'),
  },
  receptionist: {
    type: 'receptionist',
    label: 'Реєстратор',
    criterias: defaultCriterias,
    valueFormFieldModel: getStrInputFormField('receptionist'),
  },
};
