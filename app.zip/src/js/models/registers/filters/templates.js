import * as formItemTypes from '../../../constants/FormItemTypes';
import * as classifiers from '../../../constants/ClassifiersNames';
import { STARTS_WITH, ENDS_WITH, CONTAINS, NOT_CONTAINS, EQUALS, NOT_EQUALS } from './criterias';

import { phoneNumber } from '../../formFields/administration/phonesFields';

import { emailName } from '../../formFields/administration/emailsFields';

import { wwwPage } from '../../formFields/administration/sitesFields';

import { kopfg, mainKved } from '../../formFields/counterparty/fopFields';

import {
  ownerShip,
  formOfFunding,
  formSubjectOfEconomy,
  typeBySKODY,
  legalEntityStatus,
  syPablicGroup,
  rateToBudget,
  isModelStatut,
  regRecNumber,
} from '../../formFields/counterparty/legalFields';

const defaultCriterias = [STARTS_WITH, ENDS_WITH, CONTAINS, NOT_CONTAINS, EQUALS, NOT_EQUALS];
const equalityCriterias = [EQUALS, NOT_EQUALS];
const contentCriterias = [CONTAINS, NOT_CONTAINS];
const filterValueRequiredRules = [
  {
    required: true,
    message: "Значення фільтру обов'язкове до вибору",
  },
];

const getStringFormFieldModel = (fieldName) => ({
  field: fieldName,
  type: formItemTypes.INPUT,
  rules: filterValueRequiredRules,
  colSpan: 24,
});

const getDateFormFieldModel = (fieldName) => ({
  field: fieldName,
  type: formItemTypes.DATEPICKER,
  rules: filterValueRequiredRules,
  colSpan: 24,
});

const getFilterValueFormFieldModel = (inputModel) => ({
  field: inputModel.field,
  type: inputModel.type,
  classifier: inputModel.classifier,
  placeholder: inputModel.placeholder,
  rules: filterValueRequiredRules,
  colSpan: 24,
});

export const counterpartyFilters = {
  fullName: {
    type: 'fullName',
    label: 'Назва коротко ЮО',
    criterias: defaultCriterias,
    valueFormFieldModel: getStringFormFieldModel('fullName'),
  },
  shortName: {
    type: 'shortName',
    label: 'ПІБ коротко ФО/ФОП',
    criterias: defaultCriterias,
    valueFormFieldModel: getStringFormFieldModel('shortName'),
  },
  itnEdrpou: {
    type: 'itnEdrpou',
    label: 'КОД ЄДРПОУ/ІПН',
    criterias: defaultCriterias,
    valueFormFieldModel: getStringFormFieldModel('itnEdrpou'),
  },
  kopfg: {
    type: 'kopfg', // live_search
    label: 'Форма господарювання',
    criterias: equalityCriterias,
    valueFormFieldModel: getFilterValueFormFieldModel(kopfg),
  },
  phoneNumber: {
    type: 'phoneNumber',
    label: 'Телефони',
    criterias: defaultCriterias,
    valueFormFieldModel: getFilterValueFormFieldModel(phoneNumber),
  },
  email: {
    type: 'email',
    label: 'Електронні адреси',
    criterias: defaultCriterias,
    valueFormFieldModel: getFilterValueFormFieldModel(emailName),
  },
  site: {
    type: 'site',
    label: 'Сайт',
    criterias: defaultCriterias,
    valueFormFieldModel: getFilterValueFormFieldModel(wwwPage),
  },
  docType: {
    type: 'docType', // cascade_document_type_selection
    label: "Тип  прив'язаного документа",
    criterias: [EQUALS, NOT_EQUALS],
  },
  mainKved: {
    type: 'mainKved', // live_search
    label: 'Основний за КВЕД',
    criterias: equalityCriterias,
    valueFormFieldModel: getFilterValueFormFieldModel(mainKved),
  },
  kvedInternal: {
    type: 'kvedInternal', // is it true type choosed?  live_search
    label: 'Види діяльності за КВЕД',
    criterias: contentCriterias,
    valueFormFieldModel: getFilterValueFormFieldModel(mainKved),
  },
  kvedType: {
    type: 'kvedType', // live_search
    label: 'Форма власності',
    criterias: equalityCriterias,
    valueFormFieldModel: getFilterValueFormFieldModel(ownerShip),
  },
  finSourceType: {
    type: 'finSourceType', // live_search
    label: 'Форма фінансування',
    criterias: contentCriterias,
    valueFormFieldModel: getFilterValueFormFieldModel(formOfFunding),
  },
  skof: {
    type: 'skof',
    label: "Форма суб'єкту економіки", // live_search
    criterias: equalityCriterias,
    valueFormFieldModel: getFilterValueFormFieldModel(formSubjectOfEconomy),
  },
  legalMainOrganization: {
    // text field
    type: 'legalMainOrganization',
    label: 'Головна організація, повна назва',
    criterias: defaultCriterias,
    valueFormFieldModel: getStringFormFieldModel('legalMainOrganization'),
  },
  legalSkodu: {
    type: 'legalSkodu', // live search
    label: 'Тип за СКОДУ',
    criterias: equalityCriterias,
    valueFormFieldModel: getFilterValueFormFieldModel(typeBySKODY),
  },
  legalStatus: {
    type: 'legalStatus', // yes_no classification
    label: 'Статус юридичної особи',
    criterias: equalityCriterias,
    valueFormFieldModel: getFilterValueFormFieldModel(legalEntityStatus),
  },
  legalPartOfParty: {
    type: 'legalPartOfParty', // yes_no classification
    label: 'СУ громадської партії',
    criterias: equalityCriterias,
    valueFormFieldModel: getFilterValueFormFieldModel(syPablicGroup),
  },
  legalPartOfCivilFormation: {
    type: 'legalPartOfCivilFormation', // yes_no classification
    label: 'СУ громадського формування',
    criterias: equalityCriterias,
    valueFormFieldModel: getFilterValueFormFieldModel(syPablicGroup),
  },
  legalBudgetDeductionRate: {
    type: 'legalBudgetDeductionRate',
    label: 'Ставка відр. До бюдж.',
    criterias: equalityCriterias,
    valueFormFieldModel: getFilterValueFormFieldModel(rateToBudget),
  },
  stateRegistration: {
    type: 'stateRegistration', // &
    label: 'Стан реєстрації',
    criterias: [EQUALS, NOT_EQUALS],
    valueFormFieldModel: {
      field: 'stateRegistration',
      type: formItemTypes.SELECT,
      classifier: classifiers.LEGAL_ENTITY_STATE,
      placeholder: 'Виберіть стан реєстрації',
      rules: filterValueRequiredRules,
      colSpan: 24,
    },
  },
  isModelStatut: {
    type: 'isModelStatut', // yes_no classification
    label: 'Модельний статут',
    criterias: equalityCriterias,
    valueFormFieldModel: getFilterValueFormFieldModel(isModelStatut),
  },
  regRecNumber: {
    type: 'regRecNumber',
    label: 'Номер запису про реєстрацію',
    criterias: defaultCriterias,
    valueFormFieldModel: getFilterValueFormFieldModel(regRecNumber),
  },
  legalStatutCapital: {
    type: 'legalStatutCapital',
    label: 'Розмір Статут. Кап., грн',
    criterias: defaultCriterias,
    valueFormFieldModel: getStringFormFieldModel('legalStatutCapital'),
  },
};

export const claimActionActivityFilters = {
  regNumber: {
    type: 'regNumber',
    label: 'Реєстраційний номер ',
    criterias: defaultCriterias,
    valueFormFieldModel: getStringFormFieldModel('regNumber'),
  },
  contractNumber: {
    type: 'contractNumber',
    label: 'Договір оренди: Номер',
    criterias: defaultCriterias,
    valueFormFieldModel: getStringFormFieldModel('contractNumber'),
  },
  contractRegDate: {
    type: 'contractRegDate',
    label: 'Договір оренди: Дата',
    criterias: equalityCriterias,
    valueFormFieldModel: getDateFormFieldModel('contractRegDate'),
  },
  landlordName: {
    type: 'landlordName',
    label: 'Орендодавець',
    criterias: defaultCriterias,
    valueFormFieldModel: getStringFormFieldModel('landlordName'),
  },
  renterName: {
    type: 'renterName',
    label: 'Орендар',
    criterias: defaultCriterias,
    valueFormFieldModel: getStringFormFieldModel('renterName'),
  },
  balanceKeeperName: {
    type: 'balanceKeeperName',
    label: 'Балансоутримувач',
    criterias: defaultCriterias,
    valueFormFieldModel: getStringFormFieldModel('balanceKeeperName'),
  },
  initialDebtTotal: {
    type: 'initialDebtTotal',
    label: 'Початкова сума заборгованості - загальна',
    criterias: equalityCriterias,
    valueFormFieldModel: getStringFormFieldModel('initialDebtTotal'),
  },
  initialDebtLease: {
    type: 'initialDebtLease',
    label: 'Початкова сума заборгованості - по оренді',
    criterias: equalityCriterias,
    valueFormFieldModel: getStringFormFieldModel('initialDebtLease'),
  },
  initialDebtFine: {
    type: 'initialDebtFine',
    label: 'Початкова сума заборгованості - штраф/пеня',
    criterias: equalityCriterias,
    valueFormFieldModel: getStringFormFieldModel('initialDebtFine'),
  },
  currentDebtTotal: {
    type: 'currentDebtTotal',
    label: 'Поточна сума заборгованості - загальна',
    criterias: equalityCriterias,
    valueFormFieldModel: getStringFormFieldModel('currentDebtTotal'),
  },
  currentDebtLease: {
    type: 'currentDebtLease',
    label: 'Поточна сума заборгованості - по оренді',
    criterias: equalityCriterias,
    valueFormFieldModel: getStringFormFieldModel('currentDebtLease'),
  },
  currentDebtFine: {
    type: 'currentDebtFine',
    label: 'Поточна сума заборгованості - штраф/пеня',
    criterias: equalityCriterias,
    valueFormFieldModel: getStringFormFieldModel('currentDebtFine'),
  },
  statusType: {
    type: 'statusType',
    label: 'Стан ППД',
    criterias: equalityCriterias,
    valueFormFieldModel: {
      field: 'statusType',
      type: formItemTypes.SELECT,
      classifier: classifiers.CLAIM_ACTION_ACTIVITY_STATUS,
      placeholder: 'Виберіть стан реєстрації',
      rules: filterValueRequiredRules,
      colSpan: 24,
    },
  },
  stepsCount: {
    type: 'stepsCount',
    label: 'Кількість заходів',
    criterias: equalityCriterias,
    valueFormFieldModel: getStringFormFieldModel('stepsCount'),
  },
  // legalAffair: {
  //   type: 'legalAffair',
  //   label: 'Юридична справа',
  //   criterias: defaultCriterias,
  //   valueFormFieldModel: getDocumentsLiveSearchFormField('legalAffair'),
  // }, TODO: revert after BE implemented filtering by this field
};
