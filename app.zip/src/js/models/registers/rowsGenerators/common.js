const getCommonColumns = (entity) => ({
  guid: entity.guid,
  checkbox: null,
  action: [
    {
      icon: 'eye',
      text: 'Переглянути',
      onClick: (history, id) => {
        console.log('Viewing', id); // eslint-disable-line
      },
    },
    {
      icon: 'edit',
      text: 'Редагувати',
      onClick: (history, id) => {
        console.log('Editing', id); // eslint-disable-line
      },
    },
    {
      icon: 'database',
      text: 'До архіву',
      onClick: (id) => {
        console.log('Archive', id); // eslint-disable-line
      },
    },
  ],
});

export default getCommonColumns;
