import {
  EDIT,
  EVALUATION,
  EVALUATION_FO_LEASE_FORM,
  EVALUATION_FO_PRIVATIZATION_FORM,
  VIEW,
} from '../../../constants/RouteNames';
import { getEnumLabel } from '../../../helpers/enums';
import {
  ASSESSMENT_REASON_TYPE,
  ASSESSMENT_REVIEWING_CONCLUSION,
  LEASE_ASSESSMENT_TYPE,
} from '../../../constants/ClassifiersNames';
import { getDocumentLabel } from '../../../helpers/entities/documents';
import { getFeDate, getStr } from '../../../helpers/geters';
import { getCounterpartyLabel } from '../../../helpers/entities/countrerparty';

const getEvaluationRoute = (obj, mode, guid) => {
  if (obj.type === 'LEASE') {
    return `/${EVALUATION}/${EVALUATION_FO_LEASE_FORM}/${mode}/${guid}`;
  }
  return `/${EVALUATION}/${EVALUATION_FO_PRIVATIZATION_FORM}/${mode}/${guid}`;
};
const getEvaluationGenerateRow = (evaluationObject) => ({
  guid: evaluationObject.guid,
  checkbox: null,
  action: [
    {
      icon: 'eye',
      text: 'Переглянути',
      onClick: (history, guid) => history.push(getEvaluationRoute(evaluationObject, VIEW, guid)),
    },
    {
      icon: 'edit',
      text: 'Редагувати',
      onClick: (history, guid) => history.push(getEvaluationRoute(evaluationObject, EDIT, guid)),
    },
    {
      icon: 'database',
      text: 'До архіву',
      onClick: (guid) => {
        console.log('Archive', guid); // eslint-disable-line
      },
    },
  ],
  caseRegNumber: evaluationObject.regNumber || '',
  startDate: getFeDate(evaluationObject.startDate),
  endDatePlan: getFeDate(evaluationObject.endDate),
  controlDate: getFeDate(evaluationObject.controlDate),
  state: evaluationObject.state ? `${evaluationObject.state.name || ''}` : '',
  evaluationReasonType: getEnumLabel({
    enumValue: evaluationObject.type,
    classifierName: ASSESSMENT_REASON_TYPE,
  }),
  balanceHolder: getCounterpartyLabel({ counterparty: evaluationObject.balanceHolder }),
  appraiser: getCounterpartyLabel({ counterparty: evaluationObject.appraiser }),
  assessmentContract: evaluationObject.assessmentContract
    ? `${
        evaluationObject.assessmentContract.refDocumentType
          ? getStr(evaluationObject.assessmentContract.refDocumentType.name)
          : ''`${getStr(evaluationObject.assessmentContract.docSerialNumber)}``${getStr(
              evaluationObject.assessmentContract.docNumber,
            )}`
      }`
    : '',
  reviewer: getCounterpartyLabel({ counterparty: evaluationObject.reviewer }),
  reviewingCategory: evaluationObject.category ? getStr(evaluationObject.category.name) : '',
  docForReviewing: evaluationObject.docForReviewing
    ? `${
        evaluationObject.docForReviewing.refDocumentType
          ? getStr(evaluationObject.docForReviewing.refDocumentType.name)
          : ''`${getStr(evaluationObject.docForReviewing.docSerialNumber)}``${getStr(
              evaluationObject.docForReviewing.docNumber,
            )}`
      }`
    : '',
  assessmentDate: getFeDate(evaluationObject.assessmentDate),
  reviewingConclusion: getEnumLabel({
    enumValue: evaluationObject.conclusion,
    classifierName: ASSESSMENT_REVIEWING_CONCLUSION,
  }),
  endFactDate: getFeDate(evaluationObject.endFactDate),
  aplicationToLease: evaluationObject.applicationToLease
    ? getDocumentLabel({ documentData: evaluationObject.applicationToLease })
    : '',
  assessmentType: getEnumLabel({
    enumValue: evaluationObject.leaseAssessmentType,
    classifierName: LEASE_ASSESSMENT_TYPE,
  }),
  renter: getCounterpartyLabel({ counterparty: evaluationObject.renter }),
  leaseObjects: evaluationObject.leaseObjects
    ? getStr(evaluationObject.leaseObjects.leaseObjectFullName)
    : '',
  // localityArea: 'Оболонський',
  // assessmentObjectStreet: 'вул. Малиновського',
  // assessmentObjectAdrObLegalno: 'буд. 43',
  // assessmentObjectBuildingBTIletter: 'корп. 4, літера БТІ "Г"',
  // assessmentObjectFloor: '2 "Парадний", цокольний'
});

export default getEvaluationGenerateRow;
