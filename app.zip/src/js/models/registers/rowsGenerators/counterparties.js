import { COUNTERPARTY_TYPE_MAP } from '../../../constants/VocabularyForBE';
import { VIEW, EDIT } from '../../../constants/RouteNames';
import EnumToLabelsMap from '../../../constants/EnumToLabelsMap';
import {
  getLinkToLegalForm,
  getLinkToFOForm,
  getLinkToFOPForm,
  getLinkToCounterpartyForm,
} from '../../../helpers/entities/countrerparty';
import { dateToFe } from '../../../helpers/date';

const getStr = (str) => (str ? str : ''); // eslint-disable-line
const isArray = (el) => (Array.isArray(el) ? el : [el]);

const getCounterpartyRegisterRow = (counterparty) => {
  const getCounterpartyColumns = (el) => {
    const tableRow = {
      guid: el.guid,
      fullName: null,
      action: [
        {
          icon: 'eye',
          text: 'Переглянути',
          onClick: (history, guid) =>
            history.push(
              getLinkToCounterpartyForm({
                guid,
                type: el.counterpartyType,
                mode: VIEW,
              }),
            ),
        },
        {
          icon: 'edit',
          text: 'Редагувати',
          onClick: (history, guid) =>
            history.push(
              getLinkToCounterpartyForm({
                guid,
                type: el.counterpartyType,
                mode: EDIT,
              }),
            ),
        },
        {
          icon: 'database',
          text: 'До архіву',
          onClick: (guid) => {
            console.log('Archive', guid); // eslint-disable-line
          },
        },
      ],
      counterpartyType: COUNTERPARTY_TYPE_MAP[el.counterpartyType],
      shortName: null,
      itnEdrpou: null,
      kopfg: '', // Форма господарювання
      phones: (el.phones || []).map((item) => ({
        text: `${item.phoneTypes ? item.phoneTypes[0].name : ''}: ${item.phoneNumber}`,
      })),
      // Этого полня нету в таблице
      // address: (el.address ? isArray(el.address) : []).map((item) => ({
      //   text: item.addressAsString,
      // })),
      addresses: (el.addresses ? isArray(el.addresses) : []).map((item) => ({
        text: item.addressAsString,
      })),
      emails: (el.emails || []).map((item) => ({
        text: item.emailName,
      })),
      webSites: (el.webSites || []).map((item) => ({
        text: item.wwwPage,
      })),
      bankAccounts: (el.bankAccounts || []).map((item) => ({
        text: `${item.mfo} ${item.fullName} (${item.account})`,
      })), // Банк. Рахунки
      documents: (el.documents || []).map((item) => ({
        text: `${item.docDescription}: ${item.docDescription}${item.docNumber}${item.creationDate}`,
      })),
      files: (el.files || []).map((item) => ({
        text: `${item.fileName}.${item.fileExtension}`,
      })),
      mainKvedActivity: null, // 'Основний за КВЕД
      kvedActivities: (el.kvedActivities || []).map((item) => ({
        text: item.name,
      })), // Види діяльності за КВЕД
      kfv: null, // Форма власності
      finSource: null, // Форма фінансування
      skof: null, // Форма суб\'єкту економіки
      homeOrganization: null, // Головна організація
      legalSkodu: null, // Тип за СКОДУ
      regDate: null, // Дата державної реєстрації
      legalStatus: null, // Статус юридичної особи
      legalPartOfParty: null, // СУ громадської партії
      legalPartOfCivilFormation: null, // СУ громадського формування
      legalBudgetDeductionRate: null, // Ставка відр. До бюдж.
      stateRegistration: null, // Стан реєстрації
      isModelStatut: null, // Модельний статут
      regRecDate: null, // Дата запису про реєстрацію
      regRecNumber: null, // Номер запису про реєстрацію
      legalStatutCapital: null, // Розмір Статут. Кап., грн
      legalStatutCapitalFinishDate: null, // Дата формув. СК
      founders: null, // Засновники
      positions: null, // Орг.структура
      closeDate: null, // Дата ліквідації
      personBirthDate: null, // Дата народження
      personDeathDate: null, // Дата смерті
    };

    switch (el.counterpartyType) {
      case 'LegalEntity':
        return {
          ...tableRow,
          fullName: {
            link: getLinkToLegalForm(el.guid, VIEW),
            text: getStr(el.fullName),
          },
          shortName: el.shortName,
          itnEdrpou: el.itnEdrpou,
          kopfg: (el.kopfg && el.kopfg.name) || '',
          mainKvedActivity: el.mainKvedActivity && el.mainKvedActivity.name, // 'Основний за КВЕД
          kfv: el.kfv ? el.kfv.name : '',
          finSource: el.finSource ? el.finSource.name : null,
          skof: el.skof ? el.skof.name : null, // [DKV-1579]
          legalSkodu: el.legalSkodu ? el.legalSkodu.name : null,
          regDate: dateToFe(el.regDate),
          legalStatus: el.legalStatus ? 'Так' : 'Ні',
          legalPartOfParty: el.legalPartOfParty ? 'Так' : 'Ні',
          legalPartOfCivilFormation: el.legalPartOfCivilFormation ? 'Так' : 'Ні',
          legalBudgetDeductionRate: el.legalBudgetDeductionRate,
          stateRegistration: el.stateRegistration ? EnumToLabelsMap[el.stateRegistration] : '',
          isModelStatut: el.isModelStatut ? 'Так' : 'Ні',
          regRecDate: dateToFe(el.regRecDate),
          regRecNumber: el.regRecNumber,
          legalStatutCapital: el.legalStatutCapital,
          legalStatutCapitalFinishDate: dateToFe(el.legalStatutCapitalFinishDate),
          founders: (el.founders || []).map((item) => ({
            text: `${item.typeName}: ${item.fullName || item.shortOfficeName}`,
          })),
          positions: (el.positions || []).map((item) => ({
            text: `${item.positionShortName}: ${item.employees ? item.employees.shortName : ''}`,
          })),
          closeDate: dateToFe(el.closeDate),
        };
      case 'Person':
        return {
          ...tableRow,
          fullName: {
            link: getLinkToFOForm(el.guid, VIEW),
            text: `${getStr(el.fullName)}`,
          },
          shortName: el.shortName,
          itnEdrpou: el.itnEdrpou,
          personBirthDate: dateToFe(el.personBirthDate),
          personDeathDate: dateToFe(el.personDeathDate),
        };
      case 'SelfEmployed':
        return {
          ...tableRow,
          fullName: {
            link: getLinkToFOPForm(el.guid, VIEW),
            text: `${getStr(el.fullName)}`,
          },
          shortName: el.shortName,
          itnEdrpou: el.itnEdrpou,
          kopfg: el.kopfg ? el.kopfg.name : '',
          mainKvedActivity: el.mainKvedActivity && el.mainKvedActivity.name, // 'Основний за КВЕД
          kfv: el.kfv ? el.kfv.name : null,
          finSource: el.finSource ? el.finSource.name : null,
          skof: el.skof ? el.skof.name : null,
          regDate: el.regDate,
          stateRegistration: el.stateRegistration ? EnumToLabelsMap[el.stateRegistration] : '',
          isModelStatut: el.isModelStatut ? 'Так' : 'Ні',
          regRecDate: dateToFe(el.regRecDate),
          regRecNumber: el.regRecNumber,
          positions: (el.positions || []).map((item) => ({
            text: `${item.positionName}: ${item.personShortOfficename}`,
          })),
          closeDate: dateToFe(el.closeDate),
        };
      default:
        return tableRow;
    }
  };
  return getCounterpartyColumns(counterparty);
};

export default getCounterpartyRegisterRow;
