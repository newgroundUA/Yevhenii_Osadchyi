import { generateOptionForDropDown } from '../../../../helpers/index';
import * as rn from '../../../../constants/RouteNames';
import { getCounterpartyLabel } from '../../../../helpers/entities/countrerparty';
import { getFeDate } from '../../../../helpers/geters';
import {
  getAccountingItemLabel,
  getAccountingItemLink,
} from '../../../../helpers/entities/accountingItem';

const getLegalCasesAffairsGenerateRow = (legCase) => {
  const getLegalCasesAffairsColumns = () => ({
    regNumber: legCase.regNumber,
    courtNumber: legCase.courtNumber,
    legalAffairsType: legCase.legalAffairsType && legCase.legalAffairsType.name,
    legalAffairsStartDate: getFeDate(legCase.legalAffairsStartDate),
    legalAffairsEndDate: getFeDate(legCase.legalAffairsEndDate),
    legalAffairsStages: legCase.legalAffairsStages
      ? legCase.legalAffairsStages.length > 0 &&
        legCase.legalAffairsStages.map((item) =>
          generateOptionForDropDown(
            item.guid,
            `${item.clLegalAffairsStagesType ? item.clLegalAffairsStagesType.name : ''}`,
          ),
        )
      : '',
    legalAffairCourt:
      legCase.legalAffairCourt &&
      legCase.legalAffairCourt.length > 0 &&
      legCase.legalAffairCourt.map((item) =>
        generateOptionForDropDown(
          item.guid,
          getCounterpartyLabel({
            counterparty: item.court[0],
          }), // must be single value and fixed after BE fixes
        ),
      ),
    courtSessionPlannings:
      legCase.courtSessionPlannings &&
      legCase.courtSessionPlannings.length > 0 &&
      legCase.courtSessionPlannings.map((item) =>
        generateOptionForDropDown(
          item.guid,
          `${item.courtSessionDate ? getFeDate(item.courtSessionDate) : ''}`,
        ),
      ),
    startRequest: `${
      legCase.startRequest
        ? `${legCase.startRequest.requestNumber} від
           ${getFeDate(legCase.startRequest.requestStartDate)}
           ${getCounterpartyLabel({ counterparty: legCase.startRequest.requestAuthor })}`
        : ''
    }`, // NOT implem
    responsibleLawyer: getCounterpartyLabel({
      counterparty: legCase.responsibleLawyer,
    }),
    complainants:
      legCase.complainants &&
      legCase.complainants.length > 0 &&
      legCase.complainants.map((item) =>
        generateOptionForDropDown(
          item.guid,
          getCounterpartyLabel({
            counterparty: item,
          }),
        ),
      ),
    defendants:
      legCase.defendants &&
      legCase.defendants.length > 0 &&
      legCase.defendants.map((item) =>
        generateOptionForDropDown(
          item.guid,
          getCounterpartyLabel({
            counterparty: item,
          }),
        ),
      ),
    thirdPartys:
      legCase.thirdPartys &&
      legCase.thirdPartys.length > 0 &&
      legCase.thirdPartys.map((item) =>
        generateOptionForDropDown(
          item.guid,
          getCounterpartyLabel({
            counterparty: item,
          }),
        ),
      ),
    prosecutor: getCounterpartyLabel({
      counterparty: legCase.prosecutor,
    }),
    bailsman:
      legCase.bailsman &&
      legCase.bailsman.length > 0 &&
      legCase.bailsman.map((item) =>
        generateOptionForDropDown(
          item.guid,
          getCounterpartyLabel({
            counterparty: item,
          }),
        ),
      ),
    accountingItems: (legCase.accountingItems || []).map((el) => ({
      link: getAccountingItemLink({
        id: el.guid,
        type: el.accountingItemType,
        mode: rn.VIEW,
      }),
      text: getAccountingItemLabel({
        accountingItem: el,
      }),
    })),
  });

  return {
    guid: legCase.guid,
    checkbox: null,
    action: [
      {
        icon: 'eye',
        text: 'Переглянути',
        onClick: (history, id) =>
          history.push(`/${rn.LEGAL_CASES}/${rn.FORM_LEGAL_CASES_AFFAIRS}/${rn.VIEW}/${id}`),
      },
      {
        icon: 'edit',
        text: 'Редагувати',
        onClick: (history, id) =>
          history.push(`/${rn.LEGAL_CASES}/${rn.FORM_LEGAL_CASES_AFFAIRS}/${rn.EDIT}/${id}`),
      },
      {
        icon: 'database',
        text: 'До архіву',
        onClick: (id) => {
          console.log('Archive', id); // eslint-disable-line
        },
      },
    ],
    ...getLegalCasesAffairsColumns(legCase),
  };
};

export default getLegalCasesAffairsGenerateRow;
