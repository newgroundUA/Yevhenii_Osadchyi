import getCommonColumns from '../common';

const getLegalCasesInitiativesGenerateRow = (doc) => {
  const getLegalCasesInitiativesColumns = () => ({
    fullName: 'Приміщення в будівлі КМДА',
    receivingDate: '29.08.2017',
    initiator: 'ФОП Семенюк О.А.',
    documentTitle: 'Документ-21',
    documentNumber: '34523452345',
  });
  return {
    ...getCommonColumns(doc),
    ...getLegalCasesInitiativesColumns(doc),
  };
};

export default getLegalCasesInitiativesGenerateRow;
