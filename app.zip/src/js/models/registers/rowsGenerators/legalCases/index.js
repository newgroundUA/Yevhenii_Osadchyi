import legalCasesAffairs from './legalCasesAffairs';
import legalCasesCourtSessionsPlannings from './legalCasesCourtSessionsPlannings';
import legalCasesInitiatives from './legalCasesInitiatives';
import legalCasesRequestForLegalProcessing from './legalCasesRequestForLegalProcessing';

export {
  legalCasesAffairs,
  legalCasesInitiatives,
  legalCasesRequestForLegalProcessing,
  legalCasesCourtSessionsPlannings,
};
