import { generateOptionForDropDown } from '../../../../helpers/index';
import { VIEW, EDIT, LEGAL_CASES, FORM_PROCEEDING_CARD } from '../../../../constants/RouteNames';
import EnumToLabelsMap from '../../../../constants/EnumToLabelsMap';
import { LEGAL_PROCESSING_STATUS_ENUM } from '../../../../constants/ClassifiersNames';

import {
  getLinkToCounterpartyForm,
  getCounterpartyLabel,
} from '../../../../helpers/entities/countrerparty';
import { getFeDate } from '../../../../helpers/geters';
import { getDocumentLink, getDocumentLabel } from '../../../../helpers/entities/documents';
import {
  getAccountingItemLabel,
  getAccountingItemLink,
} from '../../../../helpers/entities/accountingItem';

// TODO: use getCounterpartyLabel
const getLegalCasesInitiativesGenerateRow = (doc) => {
  const getLegalCasesInitiativesColumns = (el) => ({
    guid: el.guid,
    checkbox: null,
    fullName: null,
    action: [
      {
        icon: 'eye',
        text: 'Переглянути',
        onClick: (history, id) =>
          history.push(`/${LEGAL_CASES}/${FORM_PROCEEDING_CARD}/${VIEW}/${id}`),
      },
      {
        icon: 'edit',
        text: 'Редагувати',
        onClick: (history, id) =>
          history.push(`/${LEGAL_CASES}/${FORM_PROCEEDING_CARD}/${EDIT}/${id}`),
      },
      {
        icon: 'database',
        text: 'До архіву',
        onClick: (id) => {
          console.log('Archive', id); // eslint-disable-line
        },
      },
    ],

    requestNumber: {
      guid: el.guid,
      text: el.requestNumber,
      link: `/${LEGAL_CASES}/${FORM_PROCEEDING_CARD}/${EDIT}`,
    },
    requestStartDate: getFeDate(el.requestStartDate),
    requestEndDate: getFeDate(el.requestEndDate),
    requestStatus: el.requestStatus
      ? EnumToLabelsMap[LEGAL_PROCESSING_STATUS_ENUM][el.requestStatus]
      : '',
    requestInitiator: el.requestInitiator
      ? {
          link: getLinkToCounterpartyForm({
            guid: el.requestInitiator.guid,
            type: el.requestInitiator.counterpartyType,
            mode: VIEW,
          }),
          text: getCounterpartyLabel({
            counterparty: el.requestInitiator,
          }),
        }
      : null,
    requestAuthor: el.requestAuthor
      ? {
          link: getLinkToCounterpartyForm({
            guid: el.requestAuthor.guid,
            type: el.requestAuthor.counterpartyType,
            mode: VIEW,
          }),
          text: getCounterpartyLabel({
            counterparty: el.requestAuthor,
          }),
        }
      : null,
    requestResponsibleLawyer: el.requestResponsibleLawyer
      ? {
          link: getLinkToCounterpartyForm({
            guid: el.requestResponsibleLawyer.guid,
            type: el.requestResponsibleLawyer.counterpartyType,
            mode: VIEW,
          }),
          text: getCounterpartyLabel({
            counterparty: el.requestResponsibleLawyer,
          }),
        }
      : null,

    clLegalAffairs: el.clLegalAffairs && el.clLegalAffairs.name,
    requestDocuments:
      el.requestDocuments &&
      !!el.requestDocuments.length &&
      el.requestDocuments.map((rd) => ({
        link: getDocumentLink({
          guid: rd.guid,
          type: rd.accountingItemType,
          mode: VIEW,
        }),
        text: getDocumentLabel({
          documentData: rd,
        }),
      })),
    accountingItems: (el.accountingItems || []).map((ai) => ({
      link: getAccountingItemLink({
        id: ai.guid,
        type: ai.accountingItemType,
        mode: VIEW,
      }),
      text: getAccountingItemLabel({
        accountingItem: ai,
      }),
    })),
    accountingItemsAdresses:
      el.accountingItemsAdresses &&
      !!el.accountingItemsAdresses.length &&
      el.accountingItemsAdresses.map((ai) =>
        generateOptionForDropDown(
          `${ai.guid}: ${(ai.address || []).map((a) => a.guid).join(',')}`,
          `${ai.guid}: ${(ai.address || []).map((a) => a.guid).join(',')}`,
        ),
      ),
  });
  return getLegalCasesInitiativesColumns(doc);
};

export default getLegalCasesInitiativesGenerateRow;
