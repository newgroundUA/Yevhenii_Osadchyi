import moment from 'moment';
import getCommonColumns from '../common';
import { generateOptionForDropDown } from '../../../../helpers/index';

const DATE_FORMAT_FE = 'DD.MM.YYYY';
const DATE_FORMAT_BE = 'YYYY-MM-DD HH:mm:ss.SSS Z';
const getStringValue = (prop) => prop || '';
const getKopfgName = (counterparty) =>
  `${counterparty.kopfgDto ? getStringValue(counterparty.kopfgDto.name) : ''}`;
const getPersonString = (person) =>
  `${getStringValue(person.lastName)} ${getStringValue(person.firstName)} ${getStringValue(
    person.middleName,
  )}`;
const getLegalEntitytString = (legal) => `${getKopfgName(legal)} ${getStringValue(legal.fullName)}`;
const getSelfEmployedString = (selfEmployed) =>
  `${getKopfgName(selfEmployed)} ${getPersonString(selfEmployed)}`;
const getRandomArbitrary = (min, max) => Math.floor(Math.random() * (max - min) + min);

const getCounterpartyString = (counterparty) => {
  if (!counterparty) return '';
  switch (counterparty.counterpartyType) {
    case 'Person':
      return getPersonString(counterparty);
    case 'LegalEntity':
      return getLegalEntitytString(counterparty);
    case 'SelfEmployed':
      return getSelfEmployedString(counterparty);
    default:
      return 'Error';
  }
};

const getLegalCasesCourtSessionsPlanningsGenerateRow = (courtSession) => {
  const getLegalCasesCourtSessionsPlanningsColumns = () => ({
    courtSessionDate: courtSession.courtSessionDate
      ? moment(courtSession.courtSessionDate, DATE_FORMAT_BE).format(DATE_FORMAT_FE)
      : null,
    legalAffairRegNumber: courtSession.legalAffairs ? courtSession.legalAffairs.regNumber : '',
    legalAffairCourtNumber: `${getRandomArbitrary(100, 300)}/${getRandomArbitrary(1, 20)}`,
    legalAffairType:
      courtSession.legalAffairs && courtSession.legalAffairs.legalAffairsType
        ? courtSession.legalAffairs.legalAffairsType.name
        : '',
    representers:
      courtSession.representers &&
      courtSession.representers.length > 0 &&
      courtSession.representers.map((item) =>
        generateOptionForDropDown(item.guid, getCounterpartyString(item)),
      ),
    court: courtSession.court ? getCounterpartyString(courtSession.court) : '',
    // courtAddress: 'Не смог найти',
    courtSessionRoomNumber: courtSession.courtSessionRoomNumber || '',
    judjes:
      courtSession.judjes &&
      courtSession.judjes.length > 0 &&
      courtSession.judjes.map((item) =>
        generateOptionForDropDown(item.guid, getCounterpartyString(item)),
      ),
    responsibleLawyer:
      courtSession.legalAffairs && courtSession.legalAffairs.responsibleLawyer
        ? getCounterpartyString(courtSession.legalAffairs.responsibleLawyer)
        : '',
    complainants:
      courtSession.legalAffairs &&
      courtSession.legalAffairs.complainants &&
      courtSession.legalAffairs.complainants.length > 0 &&
      courtSession.legalAffairs.complainants.map((item) =>
        generateOptionForDropDown(item.guid, getCounterpartyString(item)),
      ),
    defendants:
      courtSession.legalAffairs &&
      courtSession.legalAffairs.defendants &&
      courtSession.legalAffairs.defendants.length > 0 &&
      courtSession.legalAffairs.defendants.map((item) =>
        generateOptionForDropDown(item.guid, getCounterpartyString(item)),
      ),
    thirdPartys:
      courtSession.legalAffairs &&
      courtSession.legalAffairs.thirdPartys &&
      courtSession.legalAffairs.thirdPartys.length > 0 &&
      courtSession.legalAffairs.thirdPartys.map((item) =>
        generateOptionForDropDown(item.guid, getCounterpartyString(item)),
      ),
  });
  return {
    ...getCommonColumns(courtSession),
    ...getLegalCasesCourtSessionsPlanningsColumns(courtSession),
  };
};

export default getLegalCasesCourtSessionsPlanningsGenerateRow;
