import moment from 'moment';
// import { generateOptionForDropDown } from '../../../../helpers/index';
// import * as rn from '../../../../constants/RouteNames';

const DATE_FORMAT_FE = 'DD.MM.YYYY';
const DATE_FORMAT_BE = 'YYYY-MM-DD HH:mm:ss.SSS Z';
const getDate = (date) => (date ? moment(date, DATE_FORMAT_BE).format(DATE_FORMAT_FE) : null);
const getStr = (prop) => prop || '';
const getKopfgName = (counterparty) =>
  `${counterparty.kopfgDto ? getStr(counterparty.kopfgDto.name) : ''}`;
const getPersonString = (person) =>
  `${getStr(person.lastName)} ${getStr(person.firstName)} ${getStr(person.middleName)}`;
const getLegalEntitytString = (legal) => `${getKopfgName(legal)} ${getStr(legal.fullName)}`;
const getSelfEmployedString = (selfEmployed) =>
  `${getKopfgName(selfEmployed)} ${getPersonString(selfEmployed)}`;

const getCounterpartyString = (counterparty) => {
  if (!counterparty) return '';
  switch (counterparty.counterpartyType) {
    case 'Person':
      return getPersonString(counterparty);
    case 'LegalEntity':
      return getLegalEntitytString(counterparty);
    case 'SelfEmployed':
      return getSelfEmployedString(counterparty);
    default:
      return 'Error';
  }
};

const getRow = (el) => ({
  guid: el.guid,
  checkbox: null,
  action: [
    {
      icon: 'eye',
      text: 'Переглянути',
      onClick: (history, id) => console.log('id', id), // eslint-disable-line
    },
    {
      icon: 'edit',
      text: 'Редагувати',
      onClick: (history, id) => console.log('id', id), // eslint-disable-line
    },
    {
      icon: 'database',
      text: 'До архіву',
      onClick: (id) => {
        console.log('Archive', id); // eslint-disable-line
      },
    },
  ],

  leaseContract: el.leaseContract
    ? `
      ${getStr(el.leaseContract.docRegNumber)} 
      ${getStr(el.leaseContract.docSerialNumber)} 
      ${getStr(el.leaseContract.docNumber)} 
      ${getDate(el.leaseContract.docDate)}
    `
    : undefined,
  reportingPeriodYear: el.reportingPeriodYear,
  reportingPeriodMonth: el.reportingPeriodMonth,

  // common
  landlord: el.landlord ? getCounterpartyString(el.landlord) : undefined,
  balanceKeeper: el.balanceKeeper ? getCounterpartyString(el.balanceKeeper) : undefined,
  renter: el.renter ? getCounterpartyString(el.renter) : undefined,
  forecastLeaseTotalAmount: el.forecastLeaseTotalAmount,
  contractLeaseTotalAmount: el.contractLeaseTotalAmount,
  factLeaseTotalAmount: el.factLeaseTotalAmount,
  receivedMoneyTotal: el.receivedMoneyTotal,
  penaltyGrossAmountTotal: el.penaltyGrossAmountTotal,
  penaltyReceivedGrossAmountTotal: el.penaltyReceivedGrossAmountTotal,
  balanceAtTheEndOfThePeriod: el.balanceAtTheEndOfThePeriod,
});

export default getRow;
