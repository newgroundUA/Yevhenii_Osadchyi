import {
  LEASE,
  LEASE_CLAIM_ACTION_ACTIVITY,
  CARD,
  VIEW,
  LEGAL_CASES,
  FORM_LEGAL_CASES_AFFAIRS,
} from '../../../../constants/RouteNames';
import { getLinkToCounterpartyForm } from '../../../../helpers/entities/countrerparty';
import { getDocumentLink } from '../../../../helpers/entities/documents';

import { dateToFe } from '../../../../helpers/date';

const claimActivitiesGenerateRow = (claimActivity) => ({
  guid: claimActivity.guid,
  checkbox: null,
  action: [
    {
      icon: 'eye',
      text: 'Переглянути',
      onClick: (history, id) =>
        history.push(`/${LEASE}/${LEASE_CLAIM_ACTION_ACTIVITY}/${CARD}/${id}`),
    },
    // {
    //   icon: 'edit',
    //   text: 'Редагувати',
    //   onClick: () => console.log('editing'),
    // },
    // {
    //   icon: 'database',
    //   text: 'До архіву',
    //   onClick: (id) => {
    //     console.log('Archive', id); // eslint-disable-li ne
    //   },
    // },
  ],
  regNumber: claimActivity.regNumber || '',
  contractNumber:
    claimActivity.contractGuid && claimActivity.contractNumber
      ? {
          link: getDocumentLink({
            guid: claimActivity.contractGuid,
            type: 'LeaseContract',
            mode: VIEW,
          }),
          text: claimActivity.contractNumber,
        }
      : '',
  contractRegDate: dateToFe(claimActivity.contractRegDate),
  landlordName:
    claimActivity.landlordGuid && claimActivity.landlordName && claimActivity.landlordType
      ? {
          link: getLinkToCounterpartyForm({
            guid: claimActivity.landlordGuid,
            type: claimActivity.landlordType,
            mode: VIEW,
          }),
          text: claimActivity.landlordName,
        }
      : '',
  renterName:
    claimActivity.renterGuid && claimActivity.renterName && claimActivity.renterType
      ? {
          link: getLinkToCounterpartyForm({
            guid: claimActivity.renterGuid,
            type: claimActivity.renterType,
            mode: VIEW,
          }),
          text: claimActivity.renterName,
        }
      : '',
  balanceKeeperName:
    claimActivity.balanceKeeperGuid &&
    claimActivity.balanceKeeperName &&
    claimActivity.balanceKeeperType
      ? {
          link: getLinkToCounterpartyForm({
            guid: claimActivity.renterGuid,
            type: claimActivity.renterType,
            mode: VIEW,
          }),
          text: claimActivity.renterName,
        }
      : '',
  initialDebtTotal: claimActivity.initialDebtTotal || '0',
  initialDebtLease: claimActivity.initialDebtLease || '0',
  initialDebtFine: claimActivity.initialDebtFine || '0',
  currentDebtTotal: claimActivity.currentDebtTotal || '0',
  currentDebtLease: claimActivity.currentDebtLease || '0',
  currentDebtFine: claimActivity.currentDebtFine || '0',
  statusType: claimActivity.statusType || '0',
  stepsCount: claimActivity.stepsCount || '0',
  legalAffairs: (claimActivity.legalAffairs || []).map((la) => ({
    link: `/${LEGAL_CASES}/${FORM_LEGAL_CASES_AFFAIRS}/${VIEW}`,
    guid: la.guid,
    text: la.courtNumber,
  })),
});

export default claimActivitiesGenerateRow;
