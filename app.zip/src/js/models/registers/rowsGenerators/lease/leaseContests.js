import moment from 'moment';
import { generateOptionForDropDown } from '../../../../helpers/index';
import {
  // COUNTERPARTIES,
  // LEGALPAGE,
  // FOP,
  // FO,
  VIEW,
  EDIT,
  LEASE,
  LEASE_COMPETITIONS,
} from '../../../../constants/RouteNames';

const accountingItemsNamesMap = {
  Stead: 'Земельна ділянка',
  Building: 'Будівля',
  Construction: 'Інша споруда',
  RailRoad: 'Залізничні шляхи',
  Equipment: 'Обладнання та устаткування',
  Animal: 'Худоба',
  IntellRight: "Об'єкти інтелектального права",
  WhTransport: 'Колісний транспорт',
  ElectricityCable: 'Електрокомунікації',
  Floor: 'Поверх',
  Premise: 'Приміщення',
  GroupOfPremise: 'Група приміщень',
  Field: 'Частина приміщення',
  Plant: 'Рослини',
  Pipeline: 'Комунікації: трубопроводи',
  Road: 'Шляхопровід',
};

const DATE_FORMAT_FE = 'DD.MM.YYYY';
const DATE_FORMAT_BE = 'YYYY-MM-DD HH:mm:ss.SSS Z';
const getStringValue = (prop) => prop || '';
const getKopfgName = (counterparty) =>
  `${counterparty.kopfgDto ? getStringValue(counterparty.kopfgDto.name) : ''}`;
const getPersonString = (person) =>
  `${getStringValue(person.lastName)} ${getStringValue(person.firstName)} ${getStringValue(
    person.middleName,
  )}`;
const getLegalEntitytString = (legal) => `${getKopfgName(legal)} ${getStringValue(legal.fullName)}`;
const getSelfEmployedString = (selfEmployed) =>
  `${getKopfgName(selfEmployed)} ${getPersonString(selfEmployed)}`;

// const getLinkToCounterpartyForm = (id, mode, formType) => {
//   switch (formType) {
//     case 'LegalEntity':
//       return `/${COUNTERPARTIES}/${LEGALPAGE}/${mode}/${id}`;
//     case 'SelfEmployed':
//       return `/${COUNTERPARTIES}/${FOP}/${mode}/${id}`;
//     case 'Person':
//       return `/${COUNTERPARTIES}/${FO}/${mode}/${id}`;
//     default:
//       return '';
//   }
// };

const getCounterpartyString = (counterparty) => {
  if (!counterparty) return '';
  switch (counterparty.counterpartyType) {
    case 'Person':
      return getPersonString(counterparty);
    case 'LegalEntity':
      return getLegalEntitytString(counterparty);
    case 'SelfEmployed':
      return getSelfEmployedString(counterparty);
    default:
      return 'Error';
  }
};

const getObjectsCountString = (leaseObj) => {
  let res = '';
  const keys = Object.keys(leaseObj);
  keys.forEach((key, index) => {
    res += `${accountingItemsNamesMap[key]} ${leaseObj[key]}`;
    if (index !== keys.length - 1) {
      res += ' ,';
    }
  });

  return res;
};

const getLeaseContestsGenerateRow = (leaseComp) => {
  const getLeaseContestsColumns = () => ({
    competitionNumber: getStringValue(leaseComp.leaseCompetitionsNumber),
    competitionStatus: leaseComp.leaseCompetitionsStatus
      ? getStringValue(leaseComp.leaseCompetitionsStatus.name)
      : '',
    leaseСase:
      leaseComp && leaseComp.leaseCases
        ? `${getStringValue(leaseComp.leaseCases.leaseCasesNumber)} ${
            leaseComp.leaseCases.leaseCasesStatus
              ? leaseComp.leaseCases.leaseCasesStatus.map((i) => `${i.name} `)
              : ''
          }`
        : '',
    execDate: leaseComp.execDateTime
      ? moment(leaseComp.execDateTime, DATE_FORMAT_BE).format(DATE_FORMAT_FE)
      : null,
    addressAndNotes: `${getStringValue(leaseComp.address)} ${getStringValue(
      leaseComp.addressNotes,
    )}`,
    endrecievDate: leaseComp.endrecievDate
      ? moment(leaseComp.endrecievDate, DATE_FORMAT_BE).format(DATE_FORMAT_FE)
      : null,

    phoneList:
      leaseComp.phoneList && leaseComp.phoneList.length > 0
        ? leaseComp.phoneList.map((item) =>
            generateOptionForDropDown(
              item.guid,
              `${
                item.phoneTypes && item.phoneTypes.length > 0
                  ? item.phoneTypes.map((pt) => getStringValue(pt.shortName))
                  : ''
              } ${item.phoneNumber}`,
            ),
          )
        : null,
    emailList:
      leaseComp.emailList && leaseComp.emailList.length > 0
        ? leaseComp.emailList.map((item) =>
            generateOptionForDropDown(
              item.guid,
              `${
                item.emailTypes && item.emailTypes.length > 0
                  ? item.emailTypes.map((et) => getStringValue(et.shortName))
                  : ''
              } ${item.emailName}`,
            ),
          )
        : null,
    advancePaymentSize: getStringValue(leaseComp.advancePaymentSize),
    primaryCompetition: leaseComp.leaseCompetition
      ? getStringValue(leaseComp.leaseCompetition.leaseCompetitionsNumber)
      : '',
    startCompetitionBet: getStringValue(leaseComp.startCompetitionBet),
    minAuctionStep: getStringValue(leaseComp.minAuctionStep),
    competitionProtocol: leaseComp.competitionProtocol
      ? `${getStringValue(leaseComp.competitionProtocol.docSerialNumber)} ${getStringValue(
          leaseComp.competitionProtocol.docNumber,
        )} ${getStringValue(leaseComp.competitionProtocol.docDate)}`
      : '',
    winner: leaseComp.winner ? getCounterpartyString(leaseComp.winner) : '',
    maxMembersBet: getStringValue(leaseComp.maxMembersBet),
    // advertLists: leaseComp.competitionAdvertLists ? leaseComp.competitionAdvertLists.length > 0
    //   && leaseComp.competitionAdvertLists.map((item) =>
    //     generateOptionForDropDown(
    //       item.guid,
    //       `${item.emailTypes && item.emailTypes.length > 0 ? item.emailTypes.map((et) =>
    // getStringValue(et.shortName)) : ''} ${item.emailName}`
    //     )) : '', BE отдает долько guid (classifier)
    leaseObject: leaseComp.leaseObject
      ? `${getStringValue(leaseComp.leaseObject.leaseObjectShortName)} ${getStringValue(
          leaseComp.leaseObject.leaseObjectNumber,
        )}`
      : '',
    landLordCounterparty: leaseComp.landLordCounterparty
      ? getCounterpartyString(leaseComp.landLordCounterparty)
      : '',
    landlordLegalType: leaseComp.landlordLegalType
      ? getStringValue(leaseComp.landlordLegalType.shortName)
      : '',
    // localityarea: 'Оболонський', посмотреть в каком виде приходит с БЕ и распарсить
    // adress: 'вул. Малиновського, буд. 43, корп. 4, літера БТІ "Г"',
    // посмотреть в каком виде приходит с БЕ и распарсить
    leaseObjectTotalSpace: leaseComp.leaseObjectTotalSpace
      ? getStringValue(leaseComp.leaseObjectTotalSpace)
      : '',
    leaseObjectUsefullSpace: leaseComp.leaseObjectUsefullSpace
      ? getStringValue(leaseComp.leaseObjectUsefullSpace)
      : '',
    leaseObjectCommonUsesSpace: leaseComp.leaseObjectCommonUsesSpace
      ? getStringValue(leaseComp.leaseObjectCommonUsesSpace)
      : '',
    objectsCount: leaseComp.accountingItemTypes
      ? getObjectsCountString(leaseComp.accountingItemTypes)
      : '',
    plannedLeasePurpose:
      leaseComp.leaseRateDirectoryDto && leaseComp.leaseRateDirectoryDto.length > 0
        ? leaseComp.leaseRateDirectoryDto.map((item) =>
            generateOptionForDropDown(
              item.guid,
              `${getStringValue(item.name)} ${getStringValue(item.leaseRateByDict)}`,
            ),
          )
        : '',
    leaseCompetitionsReasonDocs:
      leaseComp.leaseCompetitionsReasonDocs && leaseComp.leaseCompetitionsReasonDocs.length > 0
        ? leaseComp.leaseCompetitionsReasonDocs.map((item) =>
            generateOptionForDropDown(
              item.guid,
              `${getStringValue(item.docSerialNumber)} ${getStringValue(
                item.docNumber,
              )} ${getStringValue(item.docDate)}`,
            ),
          )
        : '',
    competitionCancelReasonType: leaseComp.competitionCancelReasonType
      ? getStringValue(leaseComp.competitionCancelReasonType.name)
      : '',
  });

  return {
    guid: leaseComp.guid,
    checkbox: null,
    action: [
      {
        icon: 'eye',
        text: 'Переглянути',
        onClick: (history, id) => history.push(`/${LEASE}/${LEASE_COMPETITIONS}/${VIEW}/${id}`),
      },
      {
        icon: 'edit',
        text: 'Редагувати',
        onClick: (history, id) => history.push(`/${LEASE}/${LEASE_COMPETITIONS}/${EDIT}/${id}`),
      },
      {
        icon: 'database',
        text: 'До архіву',
        onClick: (id) => {
          console.log('Archive', id); // eslint-disable-line
        },
      },
    ],
    ...getLeaseContestsColumns(leaseComp),
  };
};

export default getLeaseContestsGenerateRow;
