import _get from 'lodash/get';

import { generateOptionForDropDown } from '../../../../helpers/index';
import { getPropertyFormName } from '../property/common';
import { getCounterpartyString, getFeDate, getStr } from '../../../../helpers/geters';
import { PROPERTY, VIEW } from '../../../../constants/RouteNames';

const getLeaseRoomsGenerateRow = (el) => ({
  guid: el.objects.objects.guid,
  checkbox: null,
  action: [
    {
      icon: 'eye',
      text: 'Переглянути',
      onClick: (history, id) => {
        const accountingItemType = _get(el.objects, 'objects.accountingItemType');
        if (accountingItemType) {
          return history.push(
            `/${PROPERTY}/${getPropertyFormName(accountingItemType)}/${VIEW}/${id}`,
          );
        }
      },
    },
  ],
  shortName: _get(el.objects, 'objects.shortName', ''), // пурга!!!

  accountingItemId: el.objects ? el.objects.objects.accountingItemId : '', // тоже пурга!!!
  ...(el.holders || []).reduce(
    (prev, curr) => ({
      holder: [
        ...prev.holder,
        generateOptionForDropDown(`${curr.guid}`, getCounterpartyString(curr.derivativeOwner)),
      ],
      propertyLawType: [
        ...prev.propertyLawType,
        generateOptionForDropDown(
          `${curr.guid}`,
          `${getStr(curr.derivativePropertyRightsType.name)}`,
        ),
      ],
    }),
    {
      holder: '',
      propertyLawType: '',
    },
  ),
  localityArea: el.address ? el.address.localityAreaName : '',
  streetTypeAndName: el.address
    ? `${getStr(el.address.streetTypeShort)} ${getStr(el.address.streetName)}`
    : '',
  adrObjAndType: el.address
    ? `${getStr(el.address.addressObjectTypeShortName)} ${getStr(el.address.addressObjectName)}`
    : '',
  adrBuilding: el.address
    ? `${getStr(el.address.premiseTypeShortName)} ${getStr(el.address.premiseName)}`
    : '',
  floor:
    el.floors && el.floors.length > 0
      ? el.floors.map((item) =>
          generateOptionForDropDown(
            `${item.floorNumber}: ${item.floorName}`,
            `${getStr(item.floorNumber)}: ${getStr(item.floorName)}`,
          ),
        )
      : null,
  premiseSpace: el.totalSpace,
  usefullSpace: el.usefullSpace,
  premisePurpose: _get(el.premisePurpose, 'name', ''),
  premiseEquip: _get(el.premiseEquip, 'name', ''),
  totalFieldSpace: el.totalFieldSpace,
  freeDate: el.dateFrom ? getFeDate(el.dateFrom) : null,
  declarationsCount: _get(el.declarationsCount, 'value', ''),
});

export default getLeaseRoomsGenerateRow;
