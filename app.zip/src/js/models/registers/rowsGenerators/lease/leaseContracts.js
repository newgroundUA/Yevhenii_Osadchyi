import { DOCUMENTS, DOCUMENT_TYPICAL_CONTRACT, EDIT, VIEW } from '../../../../constants/RouteNames';
import { generateOptionForDropDown } from '../../../../helpers/index';
import {
  getCounterpartyLabel,
  getDocumentLabel,
} from '../../../../helpers/formHelpers/dropdownValueCreators';

import { getLinkToCounterpartyForm } from '../../../../helpers/entities/countrerparty';
import { dateToFe } from '../../../../helpers/date';
import { getStr } from '../../../../helpers/geters';

const vocab = {
  Building: 'Будівля',
  Premise: 'Приміщення',
  Field: 'Частина приміщення',
};

const getLeaseContractsGenerateRow = (doc) => {
  const getLeaseContractsColumns = (el) => ({
    guid: el.guid,
    checkbox: null,
    fullName: null,
    action: [
      {
        icon: 'eye',
        text: 'Переглянути',
        onClick: (history, id) =>
          history.push(`/${DOCUMENTS}/${DOCUMENT_TYPICAL_CONTRACT}/${VIEW}/${id}`),
      },
      {
        icon: 'edit',
        text: 'Редагувати',
        onClick: (history, id) =>
          history.push(`/${DOCUMENTS}/${DOCUMENT_TYPICAL_CONTRACT}/${EDIT}/${id}`),
      },
      {
        icon: 'database',
        text: 'До архіву',
        onClick: (id) => {
          console.log('Archive', id); // eslint-disable-line
        },
      },
    ],

    docSerialAndNumber: {
      guid: el.guid,
      text: `${getStr(el.docSerialNumber)} ${getStr(el.docNumber)}`,
      link: `/${DOCUMENTS}/${DOCUMENT_TYPICAL_CONTRACT}/${VIEW}`,
    },

    docregnumber: el.docRegNumber,
    docDate: dateToFe(el.docDate),
    dvalidtillDate: dateToFe(el.dateTo),
    landlord: el.landlord
      ? {
          text: getCounterpartyLabel(el.landlord).label,
          link: getLinkToCounterpartyForm({
            guid: el.landlord.guid,
            type: el.landlord.counterpartyType,
            mode: VIEW,
          }),
        }
      : null,
    renter: el.renter
      ? {
          text: getCounterpartyLabel(el.renter).label,
          link: getLinkToCounterpartyForm({
            guid: el.renter.guid,
            type: el.renter.counterpartyType,
            mode: VIEW,
          }),
        }
      : null,
    balanceKeeper: el.balanceKeeper
      ? {
          text: getCounterpartyLabel(el.balanceKeeper).label,
          link: getLinkToCounterpartyForm({
            guid: el.balanceKeeper.guid,
            type: el.balanceKeeper.counterpartyType,
            mode: VIEW,
          }),
        }
      : null,
    objectsCount: Object.keys(el.objectsCount)
      .map((key) => `${vocab[key]}: ${el.objectsCount[key]}`)
      .join(', '),
    objectsSquare: Object.keys(el.objectsSquare)
      .map((key) => `${vocab[key]}: ${el.objectsSquare[key]}`)
      .join(', '),
    objectsCUCount: Object.keys(el.objectsCommonUseCount)
      .map((key) => `${vocab[key]}: ${el.objectsCommonUseCount[key]}`)
      .join(', '),
    objectsCUSquare: Object.keys(el.objectsCommonUseSquare)
      .map((key) => `${vocab[key]}: ${el.objectsCommonUseSquare[key]}`)
      .join(', '),
    leaseratedetectmethods:
      el.leaseRateDetectMethods &&
      !!el.leaseRateDetectMethods.length &&
      el.leaseRateDetectMethods.map((ll) => generateOptionForDropDown(ll, ll)),
    leasebaseperiods:
      el.leaseOperationModes &&
      !!el.leaseOperationModes.length &&
      el.leaseOperationModes.map((ll) => generateOptionForDropDown(ll, ll)),
    leaseratedirectories:
      el.leaseRateDirectories &&
      !!el.leaseRateDirectories.length &&
      el.leaseRateDirectories.map((ll) => generateOptionForDropDown(ll.guid, ll.name)),
    initialtotalleasepriceyearSum: el.legalYearRental,
    actualtotalleasepriceyearSum: el.factYearRental,
    totalleasepriceperbasemonthSum: el.baseRental,
    // totalleasepriceperbasedaySum: '100.32',
    // totalleasepriceperbasehourSum: '100.32',
    // leasepriceperoneunitmonthSum: '100.32',
    basementcontractdocs:
      el.basementContractDocs &&
      !!el.basementContractDocs.length &&
      el.basementContractDocs.map((ll) =>
        generateOptionForDropDown(ll.guid, getDocumentLabel(ll).label),
      ),
    rentpaymentallowedterm: el.rentPaymentAllowedTerm,
    suranceDate: dateToFe(el.insuranceDate),
    insurancedocs:
      el.insuranceDoc &&
      !!el.insuranceDoc.length &&
      el.insuranceDoc.map((ll) => generateOptionForDropDown(ll.guid, getDocumentLabel(ll).label)),
    additionalregistrationTypeAndDate: el.contractAdditionalRegistration,
    autoprolongation: el.autoProlongation ? 'Так' : 'Ні',
    // numlistMonthAndYear: 'квітень 2017',
    paymentRateAndPeriodShort: `${el.shortPenaltyPaymentRate}, ${el.shortPenaltyPaymentPeriod}`,
    paymentRateAndPeriodLong: `${el.longPenaltyPaymentRate}, ${el.longPenaltyPaymentPeriod}`,
    committalperiod: el.committalPeriod,
    cautionEndDate: dateToFe(el.cautionEndDate),
  });
  return getLeaseContractsColumns(doc);
};

export default getLeaseContractsGenerateRow;
