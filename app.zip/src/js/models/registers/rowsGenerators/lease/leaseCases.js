import _get from 'lodash/_baseGet';
import { generateOptionForDropDown } from '../../../../helpers/index';
import * as rn from '../../../../constants/RouteNames';
import { getCounterpartyString, getFeDate, getStr, getOptions } from '../../../../helpers/geters';

const getLeaseAffairsGenerateRow = (el) => ({
  guid: el.guid,
  checkbox: null,
  action: [
    {
      icon: 'eye',
      text: 'Переглянути',
      onClick: (history, id) => history.push(`/${rn.LEASE}/${rn.LEASE_CASES}/${rn.VIEW}/${id}`),
    },
    {
      icon: 'edit',
      text: 'Редагувати',
      onClick: (history, id) => history.push(`/${rn.LEASE}/${rn.LEASE_CASES}/${rn.EDIT}/${id}`),
    },
    {
      icon: 'database',
      text: 'До архіву',
      onClick: (id) => {
        console.log('Archive', id); // eslint-disable-line
      },
    },
  ],
  leaseCasesNumber: _get(el, 'leaseCases.leaseCasesNumber', null),
  leaseCaseStatus: getOptions(el, 'leaseCases.leaseCasesStatuses', 'guid', 'name'),
  caseDateFrom: getFeDate(_get(el, 'leaseCases.caseDateFrom')),
  caseDateTo: getFeDate(_get(el, 'leaseCases.caseDateTo')),
  leaseObjectNameAndNumber: el.leaseObject
    ? `${getStr(el.leaseObject.leaseObjectNumber)} ${getStr(el.leaseObject.leaseObjectFullName)}`
    : '',
  landlord: el.landlord ? getCounterpartyString(el.landlord.landlord) : null,
  ...(el.holders
    ? el.holders.reduce(
        (prev, curr) => ({
          holders: [
            ...prev.holders,
            generateOptionForDropDown(curr.guid, getCounterpartyString(curr.derivativeOwner)),
          ],
        }),
        { holders: [] },
      )
    : { holders: [] }),
  lessee: 'уточнить lessee',
  localityArea: el.leaseObject.leaseObjectAddress
    ? el.leaseObject.leaseObjectAddress.localityAreaName
    : null,
  streetTypeAndName: el.leaseObject.leaseObjectAddress
    ? `${getStr(el.leaseObject.leaseObjectAddress.streetTypeShort)} 
    ${getStr(el.leaseObject.leaseObjectAddress.streetName)}`
    : null,
  externalAddress: `
    ${getStr(
      el.leaseObject.leaseObjectAddress
        ? el.leaseObject.leaseObjectAddress.addressObjectTypeShortName
        : '',
    )} 
    ${getStr(
      el.leaseObject.leaseObjectAddress ? el.leaseObject.leaseObjectAddress.addressObjectName : '',
    )}`, // буд. 43
  externalBuilding: `
    ${getStr(
      el.leaseObject.leaseObjectAddress
        ? el.leaseObject.leaseObjectAddress.inheritAddressObjectTypeShortName
        : '',
    )} 
    ${getStr(
      el.leaseObject.leaseObjectAddress
        ? el.leaseObject.leaseObjectAddress.inheritAddressObjectName
        : '',
    )}`, // корп. 4
  floors: el.floors
    ? el.floors.map((item) =>
        generateOptionForDropDown(
          item.guid,
          `№${getStr(item.floorNumber)} ${getStr(item.floorName)}`,
        ),
      )
    : null,
  leaseObjectUsefullSpace: el.leaseObject ? el.leaseObject.leaseObjectUsefullSpace : null,
  objectsInLeaseNumber: el.objectsInLeaseNumber,
  plannedLeasePurpose: el.landlord
    ? (el.landlord.plannedLeasePurpose || []).map((item) =>
        generateOptionForDropDown(
          item.guid,
          `${getStr(item.name)} (${getStr(item.leaseRateByDict)}%)`,
        ),
      )
    : null,
  applicationToLeaseCounter: el.statistics // было el.declarationsCount,
    ? el.statistics.applicationToLeaseCounter.value
    : null,
  contractsDocCounter: el.statistics ? el.statistics.contractsDocCounter.value : null,
  leaseObjectEvaluationDocsCounter: el.statistics
    ? el.statistics.leaseObjectEvaluationDocsCounter.value
    : null,
  insuranceDocCounter: el.statistics ? el.statistics.insuranceDocCounter.value : null,
});

export default getLeaseAffairsGenerateRow;
