import moment from 'moment';
// import { generateOptionForDropDown } from '../../../../helpers/index';
import * as rn from '../../../../constants/RouteNames';
import EnumToLabelsMap from '../../../../constants/EnumToLabelsMap';
import { MONTH } from '../../../../constants/ClassifiersNames';

const DATE_FORMAT_FE = 'DD.MM.YYYY';
const DATE_FORMAT_BE = 'YYYY-MM-DD HH:mm:ss.SSS Z';
const getDate = (date) => (date ? moment(date, DATE_FORMAT_BE).format(DATE_FORMAT_FE) : null);
const getStr = (prop) => prop || '';
const getKopfgName = (counterparty) =>
  `${counterparty.kopfgDto ? getStr(counterparty.kopfgDto.name) : ''}`;
const getPersonString = (person) =>
  `${getStr(person.lastName)} ${getStr(person.firstName)} ${getStr(person.middleName)}`;
const getLegalEntitytString = (legal) => `${getKopfgName(legal)} ${getStr(legal.fullName)}`;
const getSelfEmployedString = (selfEmployed) =>
  `${getKopfgName(selfEmployed)} ${getPersonString(selfEmployed)}`;

const getCounterpartyString = (counterparty) => {
  if (!counterparty) return '';
  switch (counterparty.counterpartyType) {
    case 'Person':
      return getPersonString(counterparty);
    case 'LegalEntity':
      return getLegalEntitytString(counterparty);
    case 'SelfEmployed':
      return getSelfEmployedString(counterparty);
    default:
      return 'Error';
  }
};

const getRow = (el) => ({
  guid: el.guid,
  checkbox: null,
  action: [
    {
      icon: 'eye',
      text: 'Переглянути',
      onClick: (history, id) =>
        history.push(`/${rn.LEASE}/${rn.LEASE_CONTRACT_PAYMENT_SCHEDULE}/${rn.VIEW}/${id}`),
    },
    {
      icon: 'edit',
      text: 'Редагувати',
      onClick: (history, id) =>
        history.push(`/${rn.LEASE}/${rn.LEASE_CONTRACT_PAYMENT_SCHEDULE}/${rn.EDIT}/${id}`),
    },
    {
      icon: 'database',
      text: 'До архіву',
      onClick: (id) => {
        console.log('Archive', id); // eslint-disable-line
      },
    },
  ],
  leaseContract: `
    ${getStr(el.leaseContract.docSerialNumber)} 
    ${getStr(el.leaseContract.docNumber)} 
    ${getDate(el.leaseContract.docDate)}
  `,
  periodYear: el.periodYear,
  periodMonth: el.periodMonth ? EnumToLabelsMap[MONTH][el.periodMonth] : '',
  landlord: getCounterpartyString(el.leaseContract.landlord),
  balanceKeeper: getCounterpartyString(el.leaseContract.balanceKeeper),
  renter: getCounterpartyString(el.leaseContract.renter),
  paymentDatePlan: getDate(el.paymentDatePlan),
  // leaseOperationMode: el.leaseOperationMode,
  // forecastMLTQuantityByPeriod: el.forecastMLTQuantityByPeriod,
  forecastRental: el.forecastRental,
  forecastLeaseTotalAmount: el.forecastLeaseTotalAmount,
  contractRental: el.contractRental,
  contractLeaseTotalAmount: el.contractLeaseTotalAmount,
  // factMLTQuantityByPeriod: el.factMLTQuantityByPeriod,
  factRental: el.factRental,
  factLeaseTotalAmount: el.factLeaseTotalAmount,
});

export default getRow;
