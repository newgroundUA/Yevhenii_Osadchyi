import leaseAffairs from './leaseAffairs';
import leaseCases from './leaseCases';
import leaseContests from './leaseContests';
import leaseContracts from './leaseContracts';
import leaseDeclarations from './leaseDeclarations';
import leaseObjects from './leaseObjects';
import leaseRooms from './leaseRooms';
import leaseContractPaymentSchedule from './leaseContractPaymentSchedule';
import leaseConsolidatedPaymentScheduleContractPeriod from './leaseConsolidatedPaymentScheduleContractPeriod';
import leaseConsolidatedPaymentScheduleContractByPeriod from './leaseConsolidatedPaymentScheduleContractByPeriod';
import leaseConsolidatedPaymentScheduleByPeriod from './leaseConsolidatedPaymentScheduleByPeriod';
import leasePaymentToPurpose from './leasePaymentToPurpose';
import leaseContractPenalty from './leaseContractPenalty';
import claimActionActivity from './claimActionActivityRegister';

export {
  leaseAffairs,
  leaseCases,
  leaseContests,
  leaseContracts,
  leaseDeclarations,
  leaseObjects,
  leaseContractPaymentSchedule,
  leaseConsolidatedPaymentScheduleContractPeriod,
  leaseConsolidatedPaymentScheduleContractByPeriod,
  leaseConsolidatedPaymentScheduleByPeriod,
  leaseRooms,
  leaseContractPenalty,
  leasePaymentToPurpose,
  claimActionActivity,
};
