import moment from 'moment';
import { generateOptionForDropDown } from '../../../../helpers/index';
import * as rn from '../../../../constants/RouteNames';

const DATE_FORMAT_FE = 'DD.MM.YYYY';
const DATE_FORMAT_BE = 'YYYY-MM-DD HH:mm:ss.SSS Z';
const getDate = (date) => (date ? moment(date, DATE_FORMAT_BE).format(DATE_FORMAT_FE) : null);
const getStrVal = (prop) => prop || '';
const getKopfgName = (counterparty) =>
  `${counterparty.kopfgDto ? getStrVal(counterparty.kopfgDto.name) : ''}`;
const getPersonString = (person) =>
  `${getStrVal(person.lastName)} ${getStrVal(person.firstName)} ${getStrVal(person.middleName)}`;
const getLegalEntitytString = (legal) => `${getKopfgName(legal)} ${getStrVal(legal.fullName)}`;
const getSelfEmployedString = (selfEmployed) =>
  `${getKopfgName(selfEmployed)} ${getPersonString(selfEmployed)}`;

const getCounterpartyString = (counterparty) => {
  if (!counterparty) return '';
  switch (counterparty.counterpartyType) {
    case 'Person':
      return getPersonString(counterparty);
    case 'LegalEntity':
      return getLegalEntitytString(counterparty);
    case 'SelfEmployed':
      return getSelfEmployedString(counterparty);
    default:
      return 'Error';
  }
};

const getLeaseObjectsGenerateRow = (el) => ({
  guid: el.guid,
  checkbox: null,
  action: [
    {
      icon: 'eye',
      text: 'Переглянути',
      onClick: (history, id) =>
        history.push(`/${rn.LEASE}/${rn.LANDLORD_TO_OBJECTS}/${rn.VIEW}/${id}`),
    },
    {
      icon: 'edit',
      text: 'Редагувати',
      onClick: (history, id) =>
        history.push(`/${rn.LEASE}/${rn.LANDLORD_TO_OBJECTS}/${rn.EDIT}/${id}`),
    },
    {
      icon: 'database',
      text: 'До архіву',
      onClick: (id) => {
        console.log('Archive', id); // eslint-disable-line
      },
    },
  ],
  shortname: el.leaseObject ? el.leaseObject.leaseObjectFullName : null,
  leaseobjectnumber: el.leaseObject ? el.leaseObject.leaseObjectNumber : null,
  landlord: getCounterpartyString(el.landlord),
  landlordlegaltype: el.landlordLegalType ? el.landlordLegalType.name : null,
  ...(el.holder
    ? el.holder.reduce(
        (prev, curr) => ({
          holder: [
            ...prev.holder,
            generateOptionForDropDown(curr.guid, getCounterpartyString(curr.derivativeOwner)),
          ],
          rightstype: [
            ...prev.rightstype,
            generateOptionForDropDown(curr.guid, curr.derivativePropertyRightsType.shortName),
          ],
        }),
        { holder: [], rightstype: [] },
      )
    : { holder: [], rightstype: [] }),
  localityarea: 'уточнить localityarea',
  streetTypeAndName: 'уточнить streetTypeAndName',
  externalAddress: 'уточнить externalAddress',
  externalBuilding: 'уточнить externalBuilding',
  floor: el.floors
    ? el.floors.map((item) =>
        generateOptionForDropDown(item.guid, `№${item.floorNumber} ${item.floorName}`),
      )
    : [],
  leaseobjecttotalspace: el.leaseObject ? el.leaseObject.leaseObjectTotalSpace : null,
  leaseobjectusefullspace: el.leaseObject ? el.leaseObject.leaseObjectUsefullSpace : null,
  leaseobjectcommonusespace: el.leaseObject ? el.leaseObject.leaseObjectCommonUsesSpace : null,
  objectsCount: 'уточнить objectsCount',
  leaseobjecttype: el.leaseObjectType ? el.leaseObjectType.name : null,
  plannedleasepurpose: el.plannedLeasePurpose
    ? el.plannedLeasePurpose.map((item) =>
        generateOptionForDropDown(
          item.guid,
          `${getStrVal(item.leaseRateByDict)} ${getStrVal(item.propertyObjType)}`,
        ),
      )
    : [],
  fromDate: getDate(el.dateFrom),
  tillDate: getDate(el.tillDate),
  declarationsCount: el.declarationsCount ? el.declarationsCount.value : null,
  leasecases:
    el.leaseCases && el.leaseCases.length > 0
      ? el.leaseCases.map((item) =>
          generateOptionForDropDown(item.guid, `№${item.leaseCasesNumber}`),
        )
      : [],
});

export default getLeaseObjectsGenerateRow;
