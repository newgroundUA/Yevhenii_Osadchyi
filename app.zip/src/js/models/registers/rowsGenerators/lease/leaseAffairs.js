import getCommonColumns from '../common';

const getLeaseAffairsGenerateRow = (doc) => {
  const getLeaseAffairsColumns = () => ({
    leasecasesnumber: '32423424',

    leasecasestatus: 'дійючий договір оренди',
    fromDate: '25.11.2016',
    toDate: '25.12.2016',
    objectNameAndNumber: '1233.3211.3233 правое крыло 4го этажа',
    landlord: 'ФОП Олекандр',
    holder: 'КП "КЖСЕ"',
    lessee: 'ТОВ "АрендуюВсеНашару"',
    localityarea: 'Оболонський',
    streetTypeAndName: 'вул. Малиновського',
    externalAddress: 'буд. 43',
    externalBuilding: 'корп. 4, літера БТІ "Г"',
    floor: '2 "Парадний", цокольний, -1 "Парковка", подвальний',
    leaseobjectusefullspace: '40.56',
    objectsCount: '3 приміщення, 2 будівлі, 4 ділянки',
    plannedleasepurpose: 'для медичної діяльності (10%) , ігорний бізнес (100%)',
    declarationsCount: '3 (5)',
    contractsDocCount: '4 (9)',
    ratingDocCount: '1 (3)',
    insuranceDocCount: '2 (4)',
  });
  return {
    ...getCommonColumns(doc),
    ...getLeaseAffairsColumns(doc),
  };
};

export default getLeaseAffairsGenerateRow;
