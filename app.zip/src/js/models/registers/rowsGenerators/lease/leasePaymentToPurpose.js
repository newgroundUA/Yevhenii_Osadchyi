import moment from 'moment';
// import { generateOptionForDropDown } from '../../../../helpers/index';
// import * as rn from '../../../../constants/RouteNames';

const DATE_FORMAT_FE = 'DD.MM.YYYY';
const DATE_FORMAT_BE = 'YYYY-MM-DD HH:mm:ss.SSS Z';
const getDate = (date) => (date ? moment(date, DATE_FORMAT_BE).format(DATE_FORMAT_FE) : null);
const getStr = (prop) => prop || '';
const getKopfgName = (counterparty) =>
  `${counterparty.kopfgDto ? getStr(counterparty.kopfgDto.name) : ''}`;
const getPersonString = (person) =>
  `${getStr(person.lastName)} ${getStr(person.firstName)} ${getStr(person.middleName)}`;
const getLegalEntitytString = (legal) => `${getKopfgName(legal)} ${getStr(legal.fullName)}`;
const getSelfEmployedString = (selfEmployed) =>
  `${getKopfgName(selfEmployed)} ${getPersonString(selfEmployed)}`;

const getCounterpartyString = (counterparty) => {
  if (!counterparty) return '';
  switch (counterparty.counterpartyType) {
    case 'Person':
      return getPersonString(counterparty);
    case 'LegalEntity':
      return getLegalEntitytString(counterparty);
    case 'SelfEmployed':
      return getSelfEmployedString(counterparty);
    default:
      return 'Error';
  }
};

const getRow = (el) => ({
  guid: el.guid,
  checkbox: null,
  leaseContractGUID: `
    ${getStr(el.leaseContract.docRegNumber)},
    ${getStr(el.leaseContract.docSerialNumber)},
    ${getStr(el.leaseContract.docNumber)},
    ${getStr(el.leaseContract.docDate)}
  `,
  ReportingPeriodYear: getStr(el.reportingPeriodYear),
  ReportingPeriodMonth: getStr(el.reportingPeriodMonth),
  LandlordGUID: getCounterpartyString(el.landlord),
  BalancekeeperGUID: getCounterpartyString(el.balanceKeeper),
  RenterGUID: getCounterpartyString(el.renter),
  PlanningPaymentDate: getDate(el.paymentDatePlan),
  Docdate: getDate(el.bankStatementDocDate),
  RecievedMoneyList: getStr(el.nominatedPaymentAmount),
});

export default getRow;
