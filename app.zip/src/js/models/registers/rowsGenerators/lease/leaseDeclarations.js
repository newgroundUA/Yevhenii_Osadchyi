import moment from 'moment';
import * as rn from '../../../../constants/RouteNames';
import { generateOptionForDropDown } from '../../../../helpers/index';

const DATE_FORMAT_FE = 'DD.MM.YYYY';
const DATE_FORMAT_BE = 'YYYY-MM-DD HH:mm:ss.SSS Z';
const getStringValue = (prop) => prop || '';
const getKopfgName = (counterparty) =>
  `${counterparty.kopfgDto ? getStringValue(counterparty.kopfgDto.name) : ''}`;
const getPersonString = (person) =>
  `${getStringValue(person.lastName)} ${getStringValue(person.firstName)} ${getStringValue(
    person.middleName,
  )}`;
const getLegalEntitytString = (legal) => `${getKopfgName(legal)} ${getStringValue(legal.fullName)}`;
const getSelfEmployedString = (selfEmployed) =>
  `${getKopfgName(selfEmployed)} ${getPersonString(selfEmployed)}`;

const getCounterpartyString = (counterparty) => {
  if (!counterparty) return '';
  switch (counterparty.counterpartyType) {
    case 'Person':
      return getPersonString(counterparty);
    case 'LegalEntity':
      return getLegalEntitytString(counterparty);
    case 'SelfEmployed':
      return getSelfEmployedString(counterparty);
    default:
      return 'Error';
  }
};

const getDate = (date) => (date ? moment(date, DATE_FORMAT_BE).format(DATE_FORMAT_FE) : null);

const getLeaseDeclarationsGenerateRow = (doc) => ({
  guid: doc.guid,
  checkbox: null,
  action: [
    {
      icon: 'eye',
      text: 'Переглянути',
      onClick: (history, id) =>
        history.push(`/${rn.DOCUMENTS}/${rn.DOCUMENT_RENT_STATEMENT}/${rn.VIEW}/${id}`),
    },
    {
      icon: 'edit',
      text: 'Редагувати',
      onClick: (history, id) =>
        history.push(`/${rn.DOCUMENTS}/${rn.DOCUMENT_RENT_STATEMENT}/${rn.EDIT}/${id}`),
    },
    {
      icon: 'database',
      text: 'До архіву',
      onClick: (id) => {
        console.log('Archive', id); // eslint-disable-line
      },
    },
  ],
  docRegNumber: doc.docRegNumber,
  docSerialAndNumber: `${doc.docSerialNumber} ${doc.docNumber}`,
  docDate: getDate(doc.docDate),
  dateTo: getDate(doc.dateTo),
  applicant: getCounterpartyString(doc.applicant),
  landlord: getCounterpartyString(doc.landlord),
  holders: doc.holders
    ? doc.holders.map((el) => generateOptionForDropDown(el.guid, getCounterpartyString(el)))
    : [],
  objectsInApplicationToLeaseListCount: doc.objectsInApplicationToLeaseListCount,
  leaseRateDirectoriesInObjects: '', // doc.leaseRateDirectoriesInObjects, // array of ???
  planLeaseBasePeriodsInObjects: '', // doc.planLeaseBasePeriodsInObjects, // array of ???
  planLeaseTermsInObjects: doc.planLeaseTermsInObjects // array of number
    ? doc.planLeaseTermsInObjects.map((el) => generateOptionForDropDown(el, el))
    : [],
  leaseObjectsCountAndObjectsSum: doc.leaseObjectsCountAndObjectsSum,
  leaseRateDirectoriesInLeaseObjects: doc.leaseRateDirectoriesInLeaseObjects
    ? doc.leaseRateDirectoriesInLeaseObjects.map((el) =>
        generateOptionForDropDown(el.guid, `${el.name}`),
      )
    : [],
  planLeaseBasePeriodsInLeaseObjects: doc.planLeaseBasePeriodsInLeaseObjects // походу ENUM
    ? doc.planLeaseBasePeriodsInLeaseObjects.map((el) => generateOptionForDropDown(el, el))
    : [],
  planLeaseTermsInLeaseObjects: doc.planLeaseTermsInLeaseObjects // array of numbers
    ? doc.planLeaseTermsInLeaseObjects.map((el) => generateOptionForDropDown(el, el))
    : [],
});

export default getLeaseDeclarationsGenerateRow;
