import { VIEW, EDIT } from '../../../constants/RouteNames';
import EnumToLabelsMap from '../../../constants/EnumToLabelsMap';
import {
  getLinkToCounterpartyForm,
  getCounterpartyLabel,
} from '../../../helpers/entities/countrerparty';
import { getDocumentLink, getDocumentLabel } from '../../../helpers/entities/documents';

import { dateToFe } from '../../../helpers/date';
import { DOCUMENT_VALIDITY_STATUS_ENUM } from '../../../constants/ClassifiersNames';

const getDocumentsRegisterRow = (doc) => {
  const getDocumentColumns = () => ({
    guid: doc.guid,
    checkbox: null,
    fullName: null,
    action: [
      {
        icon: 'eye',
        text: 'Переглянути',
        onClick: (history, guid) =>
          history.push(
            getDocumentLink({
              guid,
              type: doc.documentType,
              mode: VIEW,
            }),
          ),
      },
      {
        icon: 'edit',
        text: 'Редагувати',
        onClick: (history, guid) =>
          history.push(
            getDocumentLink({
              guid,
              type: doc.documentType,
              mode: EDIT,
            }),
          ),
      },
      {
        icon: 'database',
        text: 'До архіву',
        onClick: (guid) => {
          console.log('Archive', guid); // eslint-disable-line
        },
      },
    ],

    refDocumentType: doc.refDocumentType.name, // +
    docRegNumber: doc.docRegNumber, // +
    docRegDate: dateToFe(doc.docRegDate), // +
    docSerialNumber: doc.docSerialNumber,
    docNumber: doc.docNumber, // +
    docDate: dateToFe(doc.docDate), // +
    publishers: (doc.publishers || []).map((item) => ({
      link: getLinkToCounterpartyForm({
        guid: item.guid,
        type: item.counterpartyType,
        mode: VIEW,
      }),
      text: getCounterpartyLabel({
        counterparty: item,
      }),
    })),
    recipients: (doc.recipients || []).map((item) => ({
      link: getLinkToCounterpartyForm({
        guid: item.guid,
        type: item.counterpartyType,
        mode: VIEW,
      }),
      text: getCounterpartyLabel({
        counterparty: item,
      }),
    })),
    docDescription: doc.docDescription, // +
    docWWWPage: doc.docWWWPage,
    docValidityStatus:
      doc.validityStatus && EnumToLabelsMap[DOCUMENT_VALIDITY_STATUS_ENUM][doc.validityStatus],
    parentDocument: doc.parentDocument && {
      link: getDocumentLink({
        guid: doc.parentDocument.guid,
        type: doc.parentDocument.documentType,
        mode: VIEW,
      }), // documentType === refDocumentType
      text: getDocumentLabel({
        documentData: doc.parentDocument,
      }),
    },
    childrenDocuments: (doc.childrenDocuments || []).map((el) => ({
      link: getDocumentLink({
        guid: el.guid,
        type: el.documentType,
        mode: VIEW,
      }), // documentType === refDocumentType
      text: getDocumentLabel({
        documentData: el,
      }),
    })),
    linkedDocuments: (doc.linkedDocuments || []).map((el) => ({
      link: getDocumentLink({
        guid: el.guid,
        type: el.documentType,
        mode: VIEW,
      }), // documentType === refDocumentType
      text: getDocumentLabel({
        documentData: el,
      }),
    })),
    creator: doc.creator && {
      link: getLinkToCounterpartyForm({
        guid: doc.creator.guid,
        type: doc.creator.counterpartyType,
        mode: VIEW,
      }),
      text: doc.creator.shortName,
    },
    receptionist: doc.receptionist && {
      link: getLinkToCounterpartyForm({
        guid: doc.receptionist.guid,
        type: doc.receptionist.counterpartyType,
        mode: VIEW,
      }),
      text: getCounterpartyLabel({
        counterparty: doc.receptionist,
      }),
    },
    validFrom: dateToFe(doc.validFrom),
    validTill: dateToFe(doc.validTill),
  });

  return getDocumentColumns(doc);
};

export default getDocumentsRegisterRow;
