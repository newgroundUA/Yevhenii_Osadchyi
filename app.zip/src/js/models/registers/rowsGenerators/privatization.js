import moment from 'moment';
import { get } from 'lodash';
import { generateOptionForDropDown } from '../../../helpers/index';
import { PRIVATIZATION, PRIVATISATION_FORM, EDIT, VIEW } from '../../../constants/RouteNames';
import { getNumber, getStr } from '../../../helpers/geters';

const DATE_FORMAT_FE = 'DD.MM.YYYY';
const DATE_FORMAT_BE = 'YYYY-MM-DD HH:mm:ss.SSS Z';

const getKopfgName = (counterparty) =>
  `${counterparty.kopfgDto ? getStr(counterparty.kopfgDto.name) : ''}`;
const getPersonString = (person) =>
  `${getStr(person.lastName)} ${getStr(person.firstName)} ${getStr(person.middleName)}`;
const getLegalEntitytString = (legal) => `${getKopfgName(legal)} ${getStr(legal.fullName)}`;
const getSelfEmployedString = (selfEmployed) =>
  `${getKopfgName(selfEmployed)} ${getPersonString(selfEmployed)}`;
const getDate = (date) => (date ? moment(date, DATE_FORMAT_BE).format(DATE_FORMAT_FE) : undefined);

const getCounterpartyString = (counterparty) => {
  if (!counterparty) return '';
  switch (counterparty.counterpartyType) {
    case 'Person':
      return getPersonString(counterparty);
    case 'LegalEntity':
      return getLegalEntitytString(counterparty);
    case 'SelfEmployed':
      return getSelfEmployedString(counterparty);
    default:
      return 'Error';
  }
};

// const getAddressField = (addressObj, adressStrArr) => {
// TODO: Create this func
// };

const getPrivatizationGenerateRow = (el) => {
  let privatisationOrganisationType;
  let privatisationMethodType;
  if (el.privatisationProgram) {
    privatisationOrganisationType = get(
      el.privatisationProgram,
      ['privatisationOrganisationType', 'name'],
      '',
    );
    privatisationMethodType = get(el.privatisationProgram, ['privatisationMethodType', 'name'], '');
  }

  return {
    guid: el.privatisationProgram ? el.privatisationProgram.guid : '',
    checkbox: undefined,
    action: [
      {
        icon: 'eye',
        text: 'Переглянути',
        onClick: (history, id) =>
          id && history.push(`/${PRIVATIZATION}/${PRIVATISATION_FORM}/${VIEW}/${id}`), // eslint-disable-line
      },
      {
        icon: 'edit',
        text: 'Редагувати',
        onClick: (history, id) =>
          id && history.push(`/${PRIVATIZATION}/${PRIVATISATION_FORM}/${EDIT}/${id}`), // eslint-disable-line
      },
      {
        icon: 'database',
        text: 'До архіву',
        onClick: (id) => {
          console.log('Archive', id); // eslint-disable-line
        },
      },
    ],
    privatObjectFullName: el.privatObjectFullName,
    privatObjectNumber: el.privatObjectNumber,
    privatisationOrganisation: el.privatisationProgram
      ? getCounterpartyString(el.privatisationProgram.privatisationOrganisation)
      : undefined,
    privatisationOrganisationType,
    balanceKeepers: el.balanceKeepers
      ? el.balanceKeepers.map((item) =>
          generateOptionForDropDown(item.guid, getCounterpartyString(item)),
        )
      : [],
    derivativePropertyRightsTypeList: el.derivativePropertyRightsTypeList
      ? el.derivativePropertyRightsTypeList.map((item) =>
          generateOptionForDropDown(item.guid, getStr(item.name)),
        )
      : [],
    renters: el.renters
      ? el.renters.map((item) => generateOptionForDropDown(item.guid, getCounterpartyString(item)))
      : [],
    localityArea: el.address ? el.address.localityAreaName : undefined,
    streetTypeAndName: el.address
      ? `${getStr(el.address.streetTypeShort)}
      ${getStr(el.address.streetName)}`
      : undefined,
    externalAddress: `
      ${getStr(el.address ? el.address.addressObjectTypeShortName : '')}
      ${getStr(el.address ? el.address.addressObjectName : '')}`, // буд. 43
    externalBuilding: `
      ${getStr(el.address ? el.address.inheritAddressObjectTypeShortName : '')}
      ${getStr(el.address ? el.address.inheritAddressObjectName : '')}`, // корп. 4
    floors: el.floors
      ? Object.values(el.floors).map((item) =>
          generateOptionForDropDown(
            item.guid,
            `${getStr(item.floorNumber)} ${getStr(item.floorName)}`,
          ),
        )
      : [],
    privatObjectTotalSpace: el.privatObjectTotalSpace,
    privatObjectUsefullSpace: el.privatObjectUsefullSpace,
    privatObjectCommonUseSpace: el.privatObjectCommonUseSpace,
    accountingItemTypes: el.accountingItemTypes
      ? `${getNumber(el.accountingItemTypes.Premise)} приміщення, ${getNumber(
          el.accountingItemTypes.Building,
        )} будівлі, ${getNumber(el.accountingItemTypes.ElectricityCable)} частини приміщення`
      : '',
    privatObjectGroupType: el.privatisationProgram
      ? el.privatisationProgram.privatObjectGroupType.name
      : undefined,
    privatisationMethodType,
    privatisationObjectStatus: el.privatisationObjectStatus,
    privatisationStageType: el.privatisationProgram
      ? el.privatisationProgram.privatisationStageType.name
      : undefined,
    privatisationProcStartDate: getDate(el.privatisationProcStartDate),
    privatisationProcEndDate: getDate(el.privatisationProcEndDate),
    privatisationProcNextControlDate: getDate(el.privatisationProcNextControlDate),
    docAboutPrivatisation: el.privatisationProgram
      ? (el.privatisationProgram.docAboutPrivatisation || []).map((item) =>
          generateOptionForDropDown(
            item.guid,
            `${getStr(item.docSerialNumber)} ${getStr(item.docNumber)} ${getDate(item.docDate)}`,
          ),
        )
      : [],
    orderNumberInDoc: el.privatisationProgram
      ? el.privatisationProgram.orderNumberInDoc
      : undefined,
    privContract: el.privatisationProgram
      ? (el.privatisationProgram.privContract || []).map((item) =>
          generateOptionForDropDown(
            item.guid,
            `${getStr(item.docSerialNumber)} ${getStr(item.docNumber)} ${getDate(item.docDate)}`,
          ),
        )
      : [],
    buyer: '',
    sellPrice: '',
  };
};

export default getPrivatizationGenerateRow;
