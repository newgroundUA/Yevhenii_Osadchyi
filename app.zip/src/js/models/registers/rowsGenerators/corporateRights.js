// import getCommonColumns from './common';
import _get from 'lodash/get';
import {
  getCounterpartyITN,
  getCounterpartyLabel,
  getKopfgName,
} from '../../../helpers/entities/countrerparty';
import {
  SHARES_FORM_TYPE,
  STATUS_OF_STATE_REGISTRATION,
} from '../../../constants/ClassifiersNames';
import { getEnumLabel } from '../../../helpers/enums';

const getCorporateRightsGenerateRow = (el) => ({
  guid: el.guid,
  fullName: getCounterpartyLabel({
    counterparty: el.corporateRightsOwner,
    withoutType: true,
    kopfg: false,
  }),
  itn_edrpou: getCounterpartyITN({ counterparty: el.corporateRightsOwner }),
  kopfgtype: getKopfgName(el.corporateRightsOwner),
  address: _get(el, ['corporateRightOwnerAddress', 'addressAsString'], ''),
  isFounder: el.isFounder ? 'Так' : 'Ні',
  stocksQuantity: el.stocksQuantity,
  percentShareSize: el.percentShareSize,
  shareSize: el.shareSize,
  legalentityFullname: getCounterpartyLabel({
    counterparty: el.corporateRightsObject,
    withoutType: true,
    kopfg: false,
  }),
  legalentityEdrpou: getCounterpartyITN({ counterparty: el.corporateRightsObject }),
  legalentityKopfgtypeFullname: getKopfgName(el.corporateRightsObject),
  counterpartyAddress: _get(el, ['corporateRightsObjectAddress', 'addressAsString'], ''),
  shareCapital: el.shareCapital,
  shareParValue: el.shareParValue,
  sharesFormType: getEnumLabel({ enumValue: el.sharesFormType, classifierName: SHARES_FORM_TYPE }),
  statusOfStateRegistration: getEnumLabel({
    enumValue: el.statusOfStateRegistration,
    classifierName: STATUS_OF_STATE_REGISTRATION,
  }),
  mainKvedActivity: _get(el, ['mainKvedActivity', 'name'], ''),
});

export default getCorporateRightsGenerateRow;
