import getCommonColumns from './common';

const generateRow = (el) => ({
  ...getCommonColumns(el),
  cableElectricityPurpose: el.cableElectricityPurpose ? el.cableElectricityPurpose.name : '',
  cableVoltage: el.cableVoltage ? el.cableVoltage : '',
  cableLenght: el.cableLenght ? el.cableLenght : '',
  cableDiameter: el.cableDiameter ? el.cableDiameter : '',
  cableClassifier: el.cableClassifier ? el.cableClassifier.name : '',
  cableHeight: el.cableHeight ? el.cableHeight : '',
  cablePillarQty: el.cablePillarQty ? el.cablePillarQty : '',
  cablePillarMaterial: el.cablePillarMaterial
    ? el.cablePillarMaterial.map((d) => d.name).join(', ')
    : '',
  cableDepth: el.cableDepth ? el.cableDepth : '',
  cableWellQty: el.cableWellQty ? el.cableWellQty : '',
  cableTechnology: el.cableTechnology ? el.cableTechnology.name : '',
});

export default generateRow;
