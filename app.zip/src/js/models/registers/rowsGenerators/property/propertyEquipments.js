import getCommonColumns from './common';

const generateRow = (el) => ({
  ...getCommonColumns(el),
  equipmentManufacture: el.equipmentManufacture ? el.equipmentManufacture.name : '',
  equipmentClassifier: el.equipmentClassifier ? el.equipmentClassifier.name : '',
  equipmentWarrantyPeriod: el.equipmentWarrantyPeriod ? el.equipmentWarrantyPeriod : '',
  equipmentTechNote: el.equipmentTechNote ? el.equipmentTechNote : '',
});

export default generateRow;
