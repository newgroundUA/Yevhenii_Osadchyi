import getCommonColumns from './common';

const generateRow = (el) => ({
  ...getCommonColumns(el),
  plantClassifier: el.plantClassifier ? el.plantClassifier.name : '',
  plantPurpose: el.plantPurpose ? el.plantPurpose.name : '',
});

export default generateRow;
