import getCommonColumns from './common';

const generateRow = (el) => ({
  ...getCommonColumns(el),
  buildingCadastreNumber: el.buildingCadastreNumber ? el.buildingCadastreNumber : '',
  buildingBTILetter: el.buildingBTILetter ? el.buildingBTILetter : '',
  buildingDMALetter: el.buildingDMALetter ? el.buildingDMALetter : '',
  buildingAddressNote: el.buildingAddressNote ? el.buildingAddressNote : '',
  buildingHistoryValue: el.buildingHistoryValue ? 'Так' : 'Ні',
  buildingHasFacade: el.buildingHasFacade ? 'Так' : 'Ні',
  buildingLength: el.buildingLength ? el.buildingLength : '',
  buildingWidth: el.buildingWidth ? el.buildingWidth : '',
  buildingHeight: el.buildingHeight ? el.buildingHeight : '',
  buildingVolume: el.buildingVolume ? el.buildingVolume : '',
  buildingUsefullVolume: el.buildingUsefullVolume ? el.buildingUsefullVolume : '',
  buildingPremiseEquip: el.buildingPremiseEquip
    ? el.buildingPremiseEquip.map((e) => e.name).join(', ')
    : '',
  buildingControlAreaByFloor: el.buildingControlAreaByFloor ? 'Так' : 'Ні',
  buildingTotalSpace: el.buildingTotalSpace ? el.buildingTotalSpace : '',
  buildingFloorAmount: el.buildingFloorAmount ? el.buildingFloorAmount : '',
  buildingLivingSpace: el.buildingLivingSpace ? el.buildingLivingSpace : '',
  buildingUnLivingSpace: el.buildingUnLivingSpace ? el.buildingUnLivingSpace : '',
  buildingUsefullUnLivingSpace: el.buildingUsefullUnLivingSpace
    ? el.buildingUsefullUnLivingSpace
    : '',
  buildingTechnicalSpace: el.buildingTechnicalSpace ? el.buildingTechnicalSpace : '',
  buildingCommonSpace: el.buildingCommonSpace ? el.buildingCommonSpace : '',
  buildingSocleSpace: el.buildingSocleSpace ? el.buildingSocleSpace : '',
  buildingBasementSpace: el.buildingBasementSpace ? el.buildingBasementSpace : '',
  buildingLoftSpace: el.buildingLoftSpace ? el.buildingLoftSpace : '',
  buildingSubStructureMaterial: el.buildingSubStructureMaterial
    ? el.buildingSubStructureMaterial.map((d) => d.name).join(', ')
    : '',
  buildingExtWallMaterial: el.buildingExtWallMaterial
    ? el.buildingExtWallMaterial.map((d) => d.name).join(', ')
    : '',
  buildingIntWallMaterial: el.buildingIntWallMaterial
    ? el.buildingIntWallMaterial.map((d) => d.name).join(', ')
    : '',
  buildingRoofMaterial: el.buildingRoofMaterial
    ? el.buildingRoofMaterial.map((d) => d.name).join(', ')
    : '',
  buildingOverLapMaterial: el.buildingOverLapMaterial
    ? el.buildingOverLapMaterial.map((d) => d.name).join(', ')
    : '',
  buildingFlooringMaterial: el.buildingFlooringMaterial
    ? el.buildingFlooringMaterial.map((d) => d.name).join(', ')
    : '',
  buildingStairMaterial: el.buildingStairMaterial
    ? el.buildingStairMaterial.map((d) => d.name).join(', ')
    : '',
  buildingElectroSupply: el.buildingElectroSupply
    ? el.buildingElectroSupply.map((d) => d.name).join(', ')
    : '',
  buildingColdWaterSupply: el.buildingColdWaterSupply ? el.buildingColdWaterSupply.name : '',
  buildingHotWaterSupply: el.buildingHotWaterSupply ? el.buildingHotWaterSupply.name : '',
  buildingSewerageSupply: el.buildingSewerageSupply ? el.buildingSewerageSupply.name : '',
  buildingGasSupply: el.buildingGasSupply ? el.buildingGasSupply.name : '',
  buildingHeatingSupply: el.buildingHeatingSupply
    ? el.buildingHeatingSupply.map((d) => d.name).join(', ')
    : '',
  buildingLift: el.buildingLift ? el.buildingLift.map((d) => d.name).join(', ') : '',
  buildingRubbishSupply: el.buildingRubbishSupply ? el.buildingRubbishSupply.name : '',
});

export default generateRow;
