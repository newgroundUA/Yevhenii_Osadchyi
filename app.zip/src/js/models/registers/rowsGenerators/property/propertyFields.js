import getCommonColumns from './common';

const generateRow = (el) => ({
  ...getCommonColumns(el),
  fieldCommonSpace: el.fieldCommonSpace ? el.fieldCommonSpace : '',
  fieldLength: el.fieldLength ? el.fieldLength : '',
  fieldWidth: el.fieldWidth ? el.fieldWidth : '',
  fieldPremiseFullname: el.fieldPremise ? el.fieldPremise.fullName : '',
  fieldFloorNumber: el.fieldPremiseFloor ? el.fieldPremiseFloor.floorNumber : '',
  fieldPremisePurpose: el.fieldPremisePurpose ? el.fieldPremisePurpose.name : '',
  premiseCommonUse: el.fieldPremise && el.fieldPremise.premiseCommonUse ? 'Так' : 'Ні',
});

export default generateRow;
