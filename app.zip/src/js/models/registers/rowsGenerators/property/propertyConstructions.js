import getCommonColumns from './common';

const generateRow = (el) => ({
  ...getCommonColumns(el),
  constructionCadastreNumber: el.constructionCadastreNumber ? el.constructionCadastreNumber : '',
  constructionBuildingBTILetter: el.constructionBuildingBTILetter
    ? el.constructionBuildingBTILetter
    : '',
  constructionBuildingDMALetter: el.constructionBuildingDMALetter
    ? el.constructionBuildingDMALetter
    : '',
  constructionAddressNote: el.constructionAddressNote ? el.constructionAddressNote : '',
  constructionLength: el.constructionLength ? el.constructionLength : 0,
  constructionWidth: el.constructionWidth ? el.constructionWidth : 0,
  constructionHeight: el.constructionHeight ? el.constructionHeight : 0,
  constructionDiameter: el.constructionDiameter ? el.constructionDiameter : 0,
  constructionWeight: el.constructionWeight ? el.constructionWeight : 0,
  constructionVolume: el.constructionVolume ? el.constructionVolume : 0,
  constructionUsefullVolume: el.constructionUsefullVolume ? el.constructionUsefullVolume : 0,
  constructionTotalSpace: el.constructionTotalSpace ? el.constructionTotalSpace : 0,
  constructionMaterials: el.constructionMaterials
    ? el.constructionMaterials.map((d) => d.name).join(', ')
    : '',
});

export default generateRow;
