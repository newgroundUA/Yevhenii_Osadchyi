import * as iconNames from '../../../../constants/IconNames';
import * as routes from '../../../../constants/RouteNames';
import { getFeDate } from '../../../../helpers/geters';
import {
  getRegionLabel,
  getLocalityLabel,
  getStreetLabel,
  getInheritAddressObjectLabel,
  getPremiseLabel,
  getBuildingLabel,
  getLocalityAreaLabel,
  getLocalityDstrict,
} from '../../../../helpers/entities/address';

// TODO: move out to helpers file
const getParsedAddressParts = (addressObject) => {
  if (!addressObject) {
    return {
      addressLocality: '',
      addressLocalityArea: '',
      addressStreet: '',
      addressBuilding: '',
      addressInheritAddressObject: '',
      addressPremise: '',
      addressLocalityDstrict: '',
    };
  }
  return {
    addressLocality: getLocalityLabel(addressObject) || getRegionLabel(addressObject),
    addressLocalityArea: getLocalityAreaLabel(addressObject),
    addressStreet: getStreetLabel(addressObject),
    addressBuilding: getBuildingLabel(addressObject),
    addressInheritAddressObject: getInheritAddressObjectLabel(addressObject),
    addressPremise: getPremiseLabel(addressObject),
    addressLocalityDstrict: getLocalityDstrict(addressObject),
  };
};

export const getPropertyFormName = (beType) => {
  const mappingObj = {
    Building: routes.BUILDINGS_FORM,
    Premise: routes.PREMISE_FORM,
    Stead: routes.STEAD_FORM,
    Field: routes.FIELD_FORM,
    Road: routes.ROAD_FORM,
    Pipeline: routes.PIPELINE_FORM,
    RailRoad: routes.RAILROAD_FORM,
    ElectricityCable: routes.ELECTRICITY_FORM,
    Construction: routes.CONSTRUCTION_FORM,
    Equipment: routes.EQUIPMENT_FORM,
    WhTransport: routes.WHTRANSPORT_FORM,
    Plant: routes.PLANT_FORM,
    Animal: routes.ANIMAL_FORM,
    IntellRight: routes.INTELLRIGHT_FORM,
  };
  return mappingObj[beType] || routes.BUILDINGS_FORM;
};

const getCommonColumns = (el) => ({
  guid: el.guid,
  checkbox: null,
  fullName: el.fullName,
  action: [
    {
      icon: iconNames.EYE,
      text: 'Переглянути',
      onClick: (history, id) =>
        history.push(
          `/${routes.PROPERTY}/${getPropertyFormName(el.accountingItemType)}/${routes.VIEW}/${id}`,
        ),
    },
    {
      icon: iconNames.PENCIL,
      text: 'Редагувати',
      onClick: (history, id) =>
        history.push(
          `/${routes.PROPERTY}/${getPropertyFormName(el.accountingItemType)}/${routes.EDIT}/${id}`,
        ),
    },
    {
      icon: iconNames.ARCHIVE,
      text: 'До архіву',
      onClick: () => {
        // console.log(iconNames.ARCHIVE, id);
      },
    },
  ],
  creationDate: el.creationDate ? getFeDate(el.creationDate) : null,
  accountingItemType: el.accountingItemType || '',
  parentName: el.parentName || null,
  ...getParsedAddressParts(el.address),
  shortName: el.shortName || '',
  objectType: el.stateProperty ? el.stateProperty.name : '',
  usablePeriod: el.usablePeriod || 0,
  currentNumber: el.currentNumber || '',
  operationDate: el.operationDate || '',
  initialCost: el.initialCost || '',
  revaluedCost: el.revaluedCost || '',
  wearCost: el.wearCost || '',
  residualValue: el.residualValue || '',
  calculationDate: el.calculationDate || null,
  marketCost: el.marketCost || 0,
  definitionMarketConstDate: el.definitionMarketConstDate || null,
  physicalObjectState: el.physicalObjectState || '',
  functionalObjectMatching: el.functionalObjectMatching || '',
  assetSpecialization: el.assetSpecialization || '',
  amortizationCountMethod: el.amortizationCountMethod || '',
  writingOffWay: el.writingOffWay || '',
  liquidationDate: el.liquidationDate ? getFeDate(el.liquidationDate) : '',
});

export default getCommonColumns;
