import getCommonColumns from './common';

const generateRow = (el) => ({
  ...getCommonColumns(el),
  floorNumber: el.premiseFloor ? el.premiseFloor.floorName + el.premiseFloor.floorNumber : '',
  groupNumber: el.premiseGroup ? el.premiseGroup.groupName + el.premiseGroup.groupNumber : '',
  premiseSpace: el.premiseSpace ? el.premiseSpace : '',
  premisePurpose: el.premisePurpose ? el.premisePurpose.name : '',
  premiseConstruction: el.premiseConstruction ? el.premiseConstruction.name : '',
  premiseUsefullSpace: el.premiseUsefullSpace ? el.premiseUsefullSpace : '',
  premiseCommonUse: el.premiseCommonUse ? 'Так' : 'Ні',
  premiseEquip: el.premiseEquip ? el.premiseEquip.name : '',
  premiseFields: el.premiseFields ? el.premiseFields.length : '',
});

export default generateRow;
