import getCommonColumns from './common';

const generateRow = (el) => ({
  ...getCommonColumns(el),
  railRoadLength: el.railRoadLength ? el.railRoadLength : '',
  railRoadWidth: el.railRoadWidth ? el.railRoadWidth : '',
  railRoadHeight: el.railRoadHeight ? el.railRoadHeight : '',
  railRoadDept: el.railRoadDept ? el.railRoadDept : '',
  railRoadTunnelDiameter: el.railRoadTunnelDiameter ? el.railRoadTunnelDiameter : '',
  railRoadTunnelVolume: el.railRoadTunnelVolume ? el.railRoadTunnelVolume : '',
  railRoadWeight: el.railRoadWeight ? el.railRoadWeight : '',
  railRoadTrackQty: el.railRoadTrackQty ? el.railRoadTrackQty : '',
  railRoadCrossQty: el.railRoadCrossQty ? el.railRoadCrossQty : '',
  railRoadTrackCrossQty: el.railRoadTrackCrossQty ? el.railRoadTrackCrossQty : '',
  railRoadMaterial: el.railRoadMaterial ? el.railRoadMaterial.name : '',
  railRoadBalastMaterial: el.railRoadBalastMaterial ? el.railRoadBalastMaterial.name : '',
  railRoadSleepersMaterial: el.railRoadSleepersMaterial ? el.railRoadSleepersMaterial.name : '',
  railRoadTechnology: el.railRoadTechnology ? el.railRoadTechnology.name : '',
});

export default generateRow;
