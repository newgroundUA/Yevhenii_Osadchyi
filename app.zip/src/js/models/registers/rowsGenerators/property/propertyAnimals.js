import getCommonColumns from './common';

const generateRow = (el) => ({
  ...getCommonColumns(el),
  animalClassifier: el.animalClassifier ? el.animalClassifier.name : '',
  animalPurpose: el.animalPurpose ? el.animalPurpose.name : '',
});

export default generateRow;
