import propertyAnimals from './propertyAnimals';
import propertyBuildings from './propertyBuildings';
import propertyConstructions from './propertyConstructions';
import propertyElectricities from './propertyElectricities';
import propertyEquipments from './propertyEquipments';
import propertyEstates from './propertyEstates';
import propertyFields from './propertyFields';
import propertyIntellRights from './propertyIntellRights';
import propertyPipelines from './propertyPipelines';
import propertyPlants from './propertyPlants';
import propertyPremises from './propertyPremises';
import propertyRailRoads from './propertyRailRoads';
import propertyRoads from './propertyRoads';
import propertySteads from './propertySteads';
import propertyWhTransports from './propertyWhTransports';
import realEstate from './realEstate';

export {
  propertyAnimals,
  propertyBuildings,
  propertyConstructions,
  propertyElectricities,
  propertyEquipments,
  propertyEstates,
  propertyFields,
  propertyIntellRights,
  propertyPipelines,
  propertyPlants,
  propertyPremises,
  propertyRailRoads,
  propertyRoads,
  propertySteads,
  propertyWhTransports,
  realEstate,
};
