import getCommonColumns from './common';

const generateRow = (el) => ({
  ...getCommonColumns(el),
  pipelineLength: el.pipelineLength ? el.pipelineLength : '',
  pipelineDiameter: el.pipelineDiameter ? el.pipelineDiameter : '',
  pipelineTubeClassifier: el.pipelineTubeClassifier ? el.pipelineTubeClassifier.name : '',
  pipelineHeight: el.pipelineHeight ? el.pipelineHeight : '',
  pipelineDepth: el.pipelineDepth ? el.pipelineDepth : '',
  pipelineTunnelDiameter: el.pipelineTunnelDiameter ? el.pipelineTunnelDiameter : '',
  pipelineTunnelVolume: el.pipelineTunnelVolume ? el.pipelineTunnelVolume : '',
  pipelineWeight: el.pipelineWeight ? el.pipelineWeight : '',
  pipelineTubeBaseMaterial: el.pipelineTubeBaseMaterial ? el.pipelineTubeBaseMaterial.name : '',
  pipelineTubeTechnology: el.pipelineTubeTechnology ? el.pipelineTubeTechnology.name : '',
});

export default generateRow;
