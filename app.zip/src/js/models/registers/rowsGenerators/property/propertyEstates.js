import getCommonColumns from './common';

const generateRow = (el) => ({
  ...getCommonColumns(el),
});

export default generateRow;
