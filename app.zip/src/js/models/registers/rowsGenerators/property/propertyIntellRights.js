import getCommonColumns from './common';

const generateRow = (el) => ({
  ...getCommonColumns(el),
  intelCreationType: el.intelCreationType ? el.intelCreationType.name : '',
  intelLicence: el.intelLicence ? el.intelLicence.map((d) => d.name).join(', ') : '',
  intelManufacture: el.intelManufacture ? el.intelManufacture.name : '',
  intelAuthors: el.intelAuthors ? el.intelAuthors : '',
  intelPatentData: el.intelPatentData ? el.intelPatentData : '',
});

export default generateRow;
