import {
  getCounterpartyITN,
  getCounterpartyLabel,
  getLinkToCounterpartyForm,
} from '../../../helpers/entities/countrerparty';
import { VIEW } from '../../../constants/RouteNames';
import { getEnumLabel } from '../../../helpers/enums';
import {
  CORPORATE_RIGHTS_OPERATION_TYPE,
  OPERATION_METHOD_TYPE,
  STOCKS_TYPE,
} from '../../../constants/ClassifiersNames';
import { getDocumentLabel, getDocumentLink } from '../../../helpers/entities/documents';
import { dateToFe } from '../../../helpers/date';

const getCorporateRightsMovementGenerateRow = (el) => ({
  guid: el.guid,
  corporateRightsStructureEdrpou: el.corporateRightsStructure
    ? {
        link: getLinkToCounterpartyForm({
          guid: el.corporateRightsStructure.guid,
          type: 'LegalEntity',
          mode: VIEW,
        }),
        text: el.corporateRightsStructure.legalEntityEdrpou,
      }
    : '',
  corporateRightsStructureFullName: el.corporateRightsStructure
    ? {
        link: getLinkToCounterpartyForm({
          guid: el.corporateRightsStructure.guid,
          type: 'LegalEntity',
          mode: VIEW,
        }),
        text: el.corporateRightsStructure.legalEntityFullName,
      }
    : '',
  corporateRightsMovementDate: dateToFe(el.corporateRightsMovementDate),
  corporateRightsMovementRegNumber: el.corporateRightsMovementRegNumber,
  shareReceiver: el.shareReceiver
    ? {
        link: getLinkToCounterpartyForm({
          guid: el.shareReceiver.guid,
          type: el.shareReceiver.counterpartyType,
          mode: VIEW,
        }),
        text: `${getCounterpartyLabel({
          counterparty: el.shareReceiver,
        })} ${getCounterpartyITN({ counterparty: el.shareReceiver })}`,
      }
    : '',
  shareSender: el.shareSender
    ? {
        link: getLinkToCounterpartyForm({
          guid: el.shareSender.guid,
          type: el.shareSender.counterpartyType,
          mode: VIEW,
        }),
        text: `${getCounterpartyLabel({
          counterparty: el.shareSender,
        })} ${getCounterpartyITN({ counterparty: el.shareSender })}`,
      }
    : '',
  corporateRightsOperationType: getEnumLabel({
    enumValue: el.corporateRightsOperationType,
    classifierName: CORPORATE_RIGHTS_OPERATION_TYPE,
  }),
  stocksQuantity: el.stocksQuantity,
  stocksPrice: el.stocksPrice,
  stocksType: getEnumLabel({ enumValue: el.stocksType, classifierName: STOCKS_TYPE }),
  shareSizeInOperationFact: el.shareSizeInOperationFact,
  shareSizeInOperationPlan: el.shareSizeInOperationPlan,
  operationMethodType: getEnumLabel({
    enumValue: el.operationMethodType,
    classifierName: OPERATION_METHOD_TYPE,
  }),
  corporateRightsMovementDocs: (el.corporateRightsMovementDocs || []).map((doc) => ({
    link: getDocumentLink({
      guid: doc.guid,
      type: doc.documentType,
      mode: VIEW,
    }),
    text: getDocumentLabel({
      documentData: doc,
    }),
  })),
  moneySendersInOperation: (el.moneySendersInOperation || []).map((item) => ({
    link: getLinkToCounterpartyForm({
      guid: item.guid,
      type: item.counterpartyType,
      mode: VIEW,
    }),
    text: `${getCounterpartyLabel({
      counterparty: item,
    })} ${getCounterpartyITN({ counterparty: item })}`,
  })),
  moneyReceiversInOperation: (el.moneyReceiversInOperation || []).map((item) => ({
    link: getLinkToCounterpartyForm({
      guid: item.guid,
      type: item.counterpartyType,
      mode: VIEW,
    }),
    text: `${getCounterpartyLabel({
      counterparty: item,
    })} ${getCounterpartyITN({ counterparty: item })}`,
  })),
});

export default getCorporateRightsMovementGenerateRow;
