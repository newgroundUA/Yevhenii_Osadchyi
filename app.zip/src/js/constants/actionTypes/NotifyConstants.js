// notify start
export const SCHOW_SUCCESS_MESSAGE = 'SCHOW_SUCCESS_MESSAGE';
export const SCHOW_ERROR_MESSAGE = 'SCHOW_ERROR_MESSAGE';
export const SCHOW_INFO_MESSAGE = 'SCHOW_INFO_MESSAGE';
export const CLOSE_MESSAGE = 'CLOSE_MESSAGE';

// notify end
