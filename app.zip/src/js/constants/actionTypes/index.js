import * as App from './AppConstants';
import * as Classifiers from './ClassifiersConstants';
import * as Counterparties from './counterparty/CounterpartiesConstants';
import * as Documents from './documents/DocumentsConstants';
import * as Notify from './NotifyConstants';
import * as Property from './property/PropertyConstants';
import * as User from './UserConstants';
import * as Lease from './lease/LeaseConstants';

export default {
  App,
  Classifiers,
  Counterparties,
  Documents,
  Lease,
  Notify,
  Property,
  User,
};
