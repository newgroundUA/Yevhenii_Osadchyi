// ADMINISTRATION
export const PHONES_CONTAINER = 'PHONES_CONTAINER';
export const EMAILS_CONTAINER = 'EMAILS_CONTAINER';
export const SITES_CONTAINER = 'SITES_CONTAINER';

// COUNTER PARTY NA HATE
export const BANK_DETAILS_FORM_CONTAINER = 'bankDetailsFormContainer';
export const FO_FORM_CONTAINER = 'foFormContainer';
export const FOP_FORM_CONTAINER = 'fopFormContainer';
export const LEGAL_PAGE_CONTAINER = 'legalPageContainer';
export const CORPORATE_RIGHTS_STRUCTURE_CONTAINER = 'corporateRightsStructureContainer';
export const DIVISION_CONTAINER = 'DIVISION_CONTAINER';
export const POSITION_CONTAINER = 'POSITION_CONTAINER';
export const EMPLOYEE_CONTAINER = 'EMPLOYEE_CONTAINER';

// DOCUMENTS
export const BIND_DOCUMENT_CONTAINER = 'bindDocumenContainer';
export const BALANCE_FORM_CONTAINER = 'balanceFormContainer';
export const BANK_STATEMENT_FORM_CONTAINER = 'bankStatementFormContainer';
export const CONTESTS_FORM_CONTAINER = 'contestsFormContainer';
export const FILE_TABLE = 'fileTable';
export const MARKET_VALUE_FORM_CONTAINER = 'marketValueFormContainer';
export const PASSPORT_FORM_CONTAINER = 'passportFormContainer';
export const RENT_STATEMENT_FORM_CONTAINER = 'rentStatementFormContainer';
export const TYPICAL_CONTRACT_FORM_CONTAINER = 'typicalContractFormContainer';
export const WRITE_OFF_FORM_CONTAINER = 'writeOffFormContainer';
export const GENERAL_DOCUMENT_FORM_CONTAINER = 'generalDocumentFormContainer';
export const APPEALS_FORM_CONTAINER = 'appealsFormContainer';
export const JUDICIAL_DECISION_FORM_CONTAINER = 'judicialDecisionFormContainer';

// EVALUATION
export const CREATE_EVALUATION_CONTAINER = 'createEvaluationContainer';
export const EVALUATION_FO_LEASE_FORM_CONTAINER = 'EvaluationFoLeaseFormContainer';
export const EVALUATION_FO_PRIVATIZATION_FORM_CONTAINER = 'EvaluationFoPrivatizationFormContainer';

// LEASE
export const LEASE_PERIODICAL_BY_BALANCE_HOLDER_REPORT_FORM_CONTAINER =
  'LEASE_PERIODICAL_BY_BALANCE_HOLDER_REPORT_FORM_CONTAINER';
export const LEASE_PERIODICAL_BY_CONTRACT_REPORT_FORM_CONTAINER =
  'LEASE_PERIODICAL_BY_CONTRACT_REPORT_FORM_CONTAINER';
export const LEASE_CONTRACT_PAYMENT_SCHEDULE_FORM_CONTAINER =
  'LEASE_CONTRACT_PAYMENT_SCHEDULE_FORM_CONTAINER';
export const LEASE_CASES_CONTAINER = 'leaseCasesContainer';
export const LANDLORD_TO_OBJECTS_CONTAINER = 'leaseLandlordToObjectsContainer';
export const LEASE_CLAIM_ACTION_ACTIVITY = 'leaseClaimActionActivity';
export const LEASE_COMPETITIONS_CONTAINER = 'LEASE_COMPETITIONS_CONTAINER';

// LEGAL CASES
export const LEGAL_CASES_AFFAIRS_FORM_CONTAINER = 'LegalCasesAffairsFormContainer';
export const CREATE_LEGAL_CASES_INITIATIVE_CONTAINER = 'createLegalCasesInitiativeContainer';
export const PROCEEDING_FORM_CONTAINER = 'PROCEEDING_FORM_CONTAINER';

// PRIVATIZATION
export const CREATE_PRIVATIZATION_CONTAINER = 'createPrivatizationContainer';

// PROPERTY
export const PREMISE_FORM_CONTAINER = 'premiseFormContainer';
export const STEADS_FORM_CONTAINER = 'steadsFormContainer';
export const CONSTRUCTIONS_FORM_CONTAINER = 'сonstructionsFormContainer';
export const BUILDING_FORM_CONTAINER = 'buildingFormContainer';

export const FIELDS_FORM_CONTAINER = 'fieldsFormContainer';
export const EQUIPMENTS_FORM_CONTAINER = 'equipmentsFormContainer';
export const ROADS_FORM_CONTAINER = 'roadsFormContainer';
export const WH_TRANSPORTS_FORM_CONTAINER = 'whTransportsFormContainer';
export const RAIL_ROADS_FORM_CONTAINER = 'railRoadsFormContainer';
export const PLANTS_FORM_CONTAINER = 'plantsFormContainer';
export const INTELL_RIGHTS_FORM_CONTAINER = 'intellRightsFormContainer';
export const ANIMALS_FORM_CONTAINER = 'animalsFormContainer';
export const PIPELINE_FORM_CONTAINER = 'pipelineFormContainer';
export const ELECTRICITY_FORM_CONTAINER = 'electricityFormContainer';

export const RELATED_COUNTERPARTIES = 'relatedCounterparties';
export const FLOOR_FORM_CONTAINER = 'FLOOR_FORM_CONTAINER';

export const OPERATIONS_REGISTER = 'OPERATIONS_REGISTER';
export const CREATE_LEGAL_CASES_AFFAIRS_CONTAINER = 'CREATE_LEGAL_CASES_AFFAIRS_CONTAINER';
export const LEASE_CLAIM_ACTION_ACTIVITY_CARD = 'LEASE_CLAIM_ACTION_ACTIVITY_CARD';
