import * as classifiers from './ClassifiersNames';
import { NEW, ANALYZED, REJECTED, OPEN, AFTER_TREATMENT } from './legalAffairs';

const EnumToLabelsMap = {
  // classifiers.DOCUMENT_TYPE_ENUM
  [classifiers.DOCUMENT_TYPE]: {
    Document: 'Всі',
    PersonPassport: 'Паспортний',
    ApplicationToLease: 'Заява на оренду',
    CompetitionProtocol: 'Переможця конкурсу',
    DocJudicialDecision: 'Рішення суду',
    DocAppeals: 'Заяви та скарги до суду',
    AccountItemReceiptAct: 'Про приймання на баланс',
    LeaseContract: 'Типовий договір на оренду',
    ApplicationToPrivatization: 'Заяви на приватизацію',
    AccountingDocs: 'Звітні документа контрагента',
    AccountItemWriteOff: 'Про списання з балансу',
    MarketPriceDetect: 'Ринкової вартості',
    BankStatement: 'Банківська виписка',
  },

  // accounting item type
  AccountingItem: '',
  Stead: 'Земельна ділянка',
  Building: 'Будівля',
  Construction: 'Інша споруда',
  RailRoad: 'Залізничний шлях',
  Equipment: 'Обладнання',
  Animal: 'Худоба',
  IntellRight: "Об'єкти інтелектуальної власності",
  WhTransport: 'Колісний транспорт',
  ElectricityCable: 'Електрокомунікація',
  Floor: 'Поверх',
  Premise: 'Приміщення',
  GroupOfPremise: 'Група приміщень',
  Field: 'Ділянка',
  Plant: 'Рослини',
  Pipeline: 'Трубопровід',
  Road: 'Шляхопровід',

  // mock classifiers.APPEAL_INIT_TYPE
  [classifiers.APPEAL_INIT_TYPE]: {
    INTERNAL: 'Внутрішній',
    EXTERNAL: 'Зовнішній',
  },
  [classifiers.CONTRACT_ADDITIONAL_REGISTRATION_ENUM]: {
    No: 'Ні',
    State: 'Державна',
    Notarial: 'Нотаріальна',
  },
  [classifiers.MONTH]: {
    JANUARY: 'Січень',
    FEBRUARY: 'Лютий',
    MARCH: 'Березень',
    APRIL: 'Квітень',
    MAY: 'Травень',
    JUNE: 'Червень',
    JULY: 'Липень',
    AUGUST: 'Серпень',
    SEPTEMBER: 'Вересень',
    OCTOBER: 'Жовтень',
    NOVEMBER: 'Листопад',
    DECEMBER: 'Грудень',
  },

  [classifiers.LEASE_OPERATION_MODE]: {
    // TODO: think about removing of data duplication
    HOURLY: 'Погодинний',
    DAILY: 'Поденний',
    MONTHLY: 'Помісячний',
  },
  [classifiers.BASE_LEASE_PERIODS]: {
    HOURLY: 'Погодинний',
    DAILY: 'Поденний',
    MONTHLY: 'Помісячний',
  },
  [classifiers.LEASE_START_USING_TERM]: {
    FromTheEffectiveDateOfTheContract: 'Від дати початку дії контракту',
    FromTheDateOfSigningTheContract: 'Від дати підписання контракту',
    FromTheDateOfSigningTheAcceptanceCertificate: 'Від дати підписання затверджуючого сертифікату',
    FromTheDateOfTheStateNotaryRegistrationOfTheContract:
      'Від дати державної реєтрації контракту нотаріусом',
    FromTheDateOfNotarialRegistrationOfTheAgreement: 'Від дати реєстрації угоди нотаріусом',
  },
  [classifiers.GROUPED_OBJECTS_TYPE]: {
    LeaseObjects: "Об'єкт оренди",
    PrivatizationObjects: "Об'єкт приватизації",
    AccountingGroupOfPremises: "Майновий об'єкт ",
  },
  [classifiers.ENUM_JUDICIAL_SHOT_RESULT]: {
    NO_SATISFY: 'Не задоволено',
    SATISFY: 'Задоволено',
    SATISFY_IN_PART: 'Задоволено частково',
    CANCEL: 'Скасовано',
    DIRECTED_FOR_NEW_REVIEW: 'Направлено на новий розгляд',
  },

  // ENUM DocumentRelationshipTypeEnum

  CHILDREN: 'Підпорядкований', // TODO: think
  LINKED: "Пов'язаний",
  PARENT: 'Головний',

  [classifiers.DOCUMENT_VALIDITY_STATUS_ENUM]: {
    Valid: 'Чиний',
    InValid: 'Не чиний',
  },

  // LEASE PPD
  LETTER_SENDING: 'Надсилання листа',
  LAWSUIT: 'Судове провадження',
  ENFORCEMENT: 'Виконавче провадження',
  PENALTY_REMISSION: 'Списання штрафу/пені',
  DEBT_REMISSION: 'Списання заборгованості',
  DEBT_RESTRUCTURING: 'Реструктуризація заборгованості',

  INITIATION: 'Ініціалізація',
  PROCEEDINGS: 'Провадження',
  RESPONSE_WAITING: 'Очікування відповіді',
  PAYMENT_WAITING: 'Очікування оплати',
  RESULT: 'Результат',

  INC_DEB_AMOUNT: 'Збільшення суми заборгованості',
  DEC_DEB_AMOUNT: 'Зменшення суми заборгованості',

  REGISTERED: 'Зареєстровано',
  IN_PROGRESS: 'В процесі реєстрації',
  SUSPENDED: 'Призупинено',
  EXCERPT: 'З випискою',
  DELETED_WIRE: 'Видалено за проводкою',
  ADDED_WIRE: 'Додано за проводкою',

  [classifiers.STATUS_OF_STATE_REGISTRATION]: {
    REGISTERED: 'Зареєстровано',
    IN_PROGRESS: 'Припинено',
    SUSPENDED: 'В процесі реєстрації',
  },
  // CLAIM_ACTION_ACTIVITY_STATUS
  [classifiers.CLAIM_ACTION_ACTIVITY_STATUS]: {
    NEW: 'Нова',
    IN_WORK: 'В роботі',
    CLOSED: 'Закрита',
  },
  // classifiers.OBJECT_LIST_RECORD_STATUS_ENUM
  [classifiers.OBJECT_LIST_RECORD_STATUS_ENUM]: {
    DraftContract: 'Проект договору',
    ApprovedInTheContract: 'Затверджено в договорі',
    DraftAnnex: 'Проект додатку',
    ApprovedInTheAppendix: 'Затверджено в додатку',
  },
  // classifiers.BASE_LEASE_RATE_DETECT_METHOD_ENUM
  [classifiers.BASE_LEASE_RATE_DETECT_METHOD_ENUM]: {
    AccordingToTheMethodology: 'За Методикою',
    ByTender: 'За конкурсом',
    ByDecisionOfTheCommission: 'За рішенням комісії',
    PrivilegedOneHryvniaForYear: '"1 грн на рік"',
  },

  // classifiers.ASSESSMENT_REASON_TYPE
  [classifiers.ASSESSMENT_REASON_TYPE]: {
    LEASE: 'Оренда',
    PRIVATIZATION: 'Приватизація',
  },

  // classifiers.LEASE_ASSESSMENT_TYPE
  [classifiers.LEASE_ASSESSMENT_TYPE]: {
    INDEPENDENT_ASSESSMENT: 'Незалежна оцінка',
    STANDARDIZED_ASSESSMENT: 'Стандартизована оцінка',
  },

  // classifiers.ASSESSMENT_REVIEWING_CONCLUSION
  [classifiers.ASSESSMENT_REVIEWING_CONCLUSION]: {
    USED: 'Може бути використаний',
    NOT_USED: 'Не може бути використаний',
  },

  // classifiers.PRIVAT_OBJECT_STATUS
  [classifiers.PRIVAT_OBJECT_STATUS]: {
    EXCLUDED: 'Виключено',
    PRIVATIZED: 'Приватизовано',
    INCLUDED_IN_PROGRAMM: 'Включено до переліку',
    INCLUDED_IN_PROJECT_DECISION: 'Включено в проект рішення',
  },

  [classifiers.LEGAL_PROCESSING_STATUS_ENUM]: {
    [NEW]: 'Новий',
    [ANALYZED]: 'В роботі',
    [REJECTED]: 'Відхилений',
    [OPEN]: 'Відкрито справу',
    [AFTER_TREATMENT]: 'Доопрацювання',
  },

  [classifiers.COURT_SESSION_STATUS_ENUM]: {
    Planned: 'Заплановано',
    Been: 'Перенесено',
    Transferred: 'Відбулось',
    Canceled: 'Відмінено',
  },

  [classifiers.COURT_INSTANCE_LEVEL_ENUM]: {
    CourtInstanceLevel1: '1-ша інстанція',
    CourtInstanceLevel2: '2-га інстанція',
    CourtInstanceLevel3: '3-тя інстанція',
  },
  [classifiers.SHARES_FORM_TYPE]: {
    DOCUMENTORY: 'Документарна',
    NONE_DOCUMENTORY: 'Бездокументарна',
    UNDEFINED: 'Невизначена',
  },
  [classifiers.CORPORATE_RIGHTS_OPERATION_TYPE]: {
    ESTABLISH: 'Заснування',
    BUY: 'Купівля',
    ADDITIONAL_ISSUE: 'Додаткова емісія',
    PAY_FREE_TRANSFER: 'Безоплатна передача',
    EXIT: 'Вихід',
  },
  [classifiers.STOCKS_TYPE]: {
    COMMON: 'Звичайні',
    PREFERENCE: 'Привілейовані',
  },
  [classifiers.OPERATION_METHOD_TYPE]: {
    AUCTION: 'Аукціон',
    REDEMPTION: 'Викуп',
  },
};

export default EnumToLabelsMap;
