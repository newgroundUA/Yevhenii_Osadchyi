export const YES_NO = 'YES_NO';
export const APPEAL = 'appeal';
export const APPEAL_INIT_TYPE = 'appealInitType';
export const PERSON_TYPE_ENUM_ON_FE = 'personTypeEnumOnFe';
export const BANKS = 'banks';

// THESE ARE NOT CLASSIFIERS !!!!!!!!!!!!!!!!!!!!!!
export const FILTER_TYPE = 'filterType';
export const FILTER_CRITERIA = 'filterCriteria';
export const GROUPED_OBJECTS_TYPE = 'groupedObjectsType';
export const MARKET_PRICE_DETECT_METHOD = 'marketPriceDetectMethod'; // Використані методічні підходи
export const REQUEST_FOR_LEGAL_PROCESSING = 'RequestForLegalProcessing'; // Запрос на юрпровадження
export const COUNTERPARTY = 'counterparty';
export const DOCUMENTS = 'documents';
export const BANKDETAILS = 'bankDetails';
export const FILE_CONTENT_TYPE = 'fileContentTypes';
export const LANDLORD_LEGAL_TYPE = 'landlordLegalType';
export const LEASE_CASES = 'leaseCases';
export const LEASE_CASES_STATUS = 'leaseCasesStatus';
export const LEASE_COMPETITIONS = 'leaseCompetitions';
export const LEASE_UNUSED_COMPETITIONS = 'leaseUnusedCompetitions';
export const PROCESS = 'process';
export const STATE = 'state';
export const CASE_CLASIFICATION = 'caseClasification';
export const BODIES = 'bodies';
export const LANDLORD_TO_OBJECTS = 'landlordToObjects';

export const ADDITIONAL_REGISTRATION = 'additionalRegistration'; // Потребує додаткову реєстрацію
export const LEASE_START_USING_TERM = 'leaseStartUsingTerm'; // Термін вступу Орендаря в користування
export const BASE_LEASE_RATE_DETECT_METHOD = 'baseLeaseRateDetectMethod'; // Баз. Метод визначення орендної ставки (платні)
export const LEASE_RATE_DISCOUNTBASE_TYPE = 'leaseRateDiscountbaseType';
export const LEASE_OPERATION_MODE = 'leaseOperationMode';
export const CONTRACT_ADDITIONAL_REGISTRATION_ENUM = 'contractAdditionalRegistrationEnum';
export const OBJECT_LIST_RECORD_STATUS_ENUM = 'objectListRecordStatusEnum';
export const BASE_LEASE_RATE_DETECT_METHOD_ENUM = 'baseLeaseRateDetectMethodEnum';
export const PHONE_TYPE = 'phoneType';
export const EMAIL_TYPE = 'emailType';
export const SITE_TYPE = 'siteType';
export const POST = 'post';
export const PERSON_TYPE_ENUM = 'personTypeEnum';
export const PERSON_ADDRESSING = 'personAddressing';
export const PAYMENT_PURPOSE_TYPE = 'paymentPurposeType';

export const ASSESSMENT_REVIEWING_CATEGORY = 'assessmentReviewingCategory';
export const EVALUATION_STAGE = 'evaluationStage'; // Етап оцінки
export const CONCLUSION_EVALUATION_LEASE = 'conclusionEvaluationLease'; // Висновок про можливість застосування результату оцінки об’єкта оренди
export const REVIEW_CATEGORY = 'reviewCategory'; // Категорія рецензії
export const CLASSIFICATION_PROCESS = 'classificationProcess'; // Класифікація процесу

export const INVENTORY = 'inventory'; // Інвентаризація
export const INCOMING_DOCUMENT = 'incomingDocument'; // Вхідний документ
export const OUTGOING_DOCUMENT = 'outgoingDocument'; // Інвентаризація
export const CONTRACT_SUBJECT_EVALUATION_ACTIVITY = 'contractSubjectEvaluationActivity'; // Інвентаризація
export const SUBJECT_EVALUATION_ACTIVITY = 'contractSubjectEvaluationActivity'; // Інвентаризація
export const STATEMENT = 'statement'; // Заява

export const YEARS = 'years'; // Роки
export const MONTH = 'MONTH'; // місяці

// legal cases
export const CL_LEGAL_AFFAIRS_TYPE = 'clLegalAffairsType';
export const CL_LEGAL_AFFAIRS_STAGES_TYPE = 'clLegalAffairsStagesType';
export const LEGAL_PROCESSING_STATUS_ENUM = 'legalProcessingStatusEnum';

// документи
export const DOCUMENT_TYPE = 'documentType';
export const DOCUMENT_TYPE_ENUM = 'documentTypeEnum';
export const DOCTYPE_SCOPE_OF_APP = 'docTypeScopeOfApp';
export const DOCTYPE_CATEGORY = 'docTypeCategory';
export const DOCTYPE_NAME = 'docTypeName';
export const CL_DOC_VALIDITY_STATUS = 'clDocValidityStatus';
export const DOCUMENT_VALIDITY_STATUS_ENUM = 'documentValidityStatusEnum';
export const REF_DOCUMENT_TYPE_GENERAL_DOC_CLASSNAME = 'refDocumentTypeGeneralDocClassName';
export const PLAN_GOAL_TARGET = 'planGoalTarget';
export const MEMBER_AUCTION_STATE = 'memberAuctionState';
export const ENUM_JUDICIAL_SHOT_RESULT = 'enumJudicialShortResult';

// lease
export const CL_LEASE_COMPETITION_STATUS = 'ClLeaseCompetitionsStatus';
export const CL_COMPETION_REQUREMENT_TYPE = 'ClCompetitionRequrementType';
export const REF_PUBLICATION_RESOURCE = 'refPublicationResource';
export const DOC_FILLING_FORM = 'docFilingFormEnum';
export const COMPETITION_CANCEL_REASON_TYPE = 'ClCompetitionCancelReasonType';

// privatisation
export const PRIVAT_OBJECT_GROUP_TYPE = 'ClPrivatObjectGroupType';
export const PRIVAT_ORGANISATION_TYPE = 'ClPrivatisationOrganisationType';
export const PRIVAT_METHOD_TYPE = 'ClPrivatisationMethodType';
export const PRIVAT_STAGE_TYPE = 'ClPrivatisationStageType';
export const PRIVAT_OBJECT_STATUS = 'PrivatisationObjectStatus';

// майно

export const STATE_PROPERTY_OF_ACCOUNTING_ITEM = 'statePropertyOfAccountingItem';
export const STATE_PROPERTY_OF_ACCOUNTING_ITEM_TYPE = 'statePropertyOfAccountingItemType';
export const KDM_SECTIONS = 'kdmSections';
export const KDM_PARTITIONS = 'kdmPartitions';
export const KDM_SUBSECTIONS = 'kdmSubsections';
export const KDM_GROUPS = 'kdmGroups';
export const KDM_CLASS = 'kdmClass';
export const KDM_SUBCLASS = 'kdmSubclass';

export const CL_PREMISE_PURPOSE = 'clPremisePurpose';
export const CL_PREMISE_CONSTRUCTION = 'clPremiseConstruction';
export const CL_PREMISE_EQUIP = 'clPremiseEquip';
export const CL_PROPERTY_STRUCT = 'clPropertyStruct';
export const CL_WRITE_OFF = 'clWriteOff';
export const CL_FLOOR = 'clFloor';
export const CL_BUILDING_MATERIAL = 'clBuildingMaterial';
export const CL_ELECTRO_SUPPLY = 'clElectroSupply';
export const CL_COLD_WATER_SUPPLY = 'clColdWaterSupply';
export const CL_HOT_WATER_SUPPLY = 'clHotWaterSupply';
export const CL_SEWERAGE_SUPPLY = 'clSewerageSupply';
export const CL_GAS_SUPPLY = 'clGasSupply';
export const CL_LIFT = 'clLift';
export const CL_HEATING_SUPPLY = 'clHeatingSupply';
export const CL_RUBBISH_SUPPLY = 'clRibbishSupply';
export const CL_LAND_CATEGORY = 'clLandCategory';
export const CL_LAND_PURPOSE = 'clLandPurpose';

export const CL_OBJECTS_OPERATION_STATUS_TYPE = 'clObjectsOperationStatusType';
export const CL_STATE_PROPERTY = 'clStateProperty';

export const CL_MANUFACTURER = 'clManufacturer';
export const EQUIPMENT_TYPE = 'equipmentType';

export const CL_ROAD_MOVE_LINE = 'clRoadMoveLine';
export const CL_ROAD_TECHNOLOGY = 'clRoadTechnology';

export const REF_WH_TRANSPORT_TYPE = 'refWhTransportType';
export const REF_WH_TRANSPORT_COLOR_TYPE = 'refWhTransportColorType';

export const REF_RAIL_ROAD_MATERIAL = 'refRailRoadMaterial';
export const REF_RAIL_ROAD_BALAST_MATERIAL = 'refRailRoadBalastMaterial';

export const REF_RAIL_ROAD_SLEEPERS_MATERIAL = 'refRailRoadSleepersMaterial';
export const REF_RAIL_ROAD_TECHNOLOGY = 'refRailRoadTechnology';

export const CL_PLANT = 'clPlant';
export const CL_PLANT_PURPOSE = 'clPlantPurpose';

export const CL_INTELL_CREATION_TYPE = 'clIntelCreationType';
export const CL_INTELL_LICENSE_TYPE = 'intelLicenseType';
export const CL_INTELL_PATENT_DATA = 'clIntelPatentData';

export const REF_ANIMAL_CLASSIFIER = 'refAnimalClassifier';
export const CL_ANIMAL_PURPOSE = 'clAnimalPurpose';

// couterparties related to objects
export const CL_PROPERTY_RIGHTS_TYPE = 'clPropertyRightsType';
export const CL_PROPERTY_OWNERSHIP_TYPE = 'clPropertyOwnershipType';

// об'єкти
export const OBJECTS = 'objects';
export const OBJECT_EVALUATION = 'objectEvaluation'; // Об\'єкт оцінки
export const OBJECT_ADDRESS = 'objectAddress'; // Адреса об\'єкту
export const OBJECT_TYPE = 'objectType'; // Адреса об\'єкту
export const OBJECTS_TYPE_BY_ACCOUNTING = 'objectsTypeByAccounting'; // Тип майна за бухобліком
export const CL_PHYSICAL_STATE = 'clPhysicalState';
export const CL_FUNK_ACCORDANCE = 'clFunkAccordance';
export const CL_MARKET_PRICE_DETECT_METHOD = 'clMarketPriceDetectMethod';
export const CL_ASSET_SPECIALIZATION = 'clAssetSpecialization';
export const PROPERTY_PARENT_OBJECTS = 'propertyParentObjects';
export const CL_CABLE_ELECTRICITY_PURPOSE = 'clCableElectricityPurpose';
export const CL_CABLE_CLASSIFIER = 'clCableClassifier';
export const CL_CABLE_PILLAR_MATERIAL = 'clCablePillarMaterial';
export const CL_CABLE_TECHNOLOGY = 'clCableTechnology';
// property pipelines
export const CL_PROPERTY_TUBE_CLASSIFIER = 'clPropertyTubeClassifier';
export const CL_PROPERTY_TUBE_TEHNOLOGY = 'clPropertyTubeTehnology';
export const CL_PROPERTY_TUBE_BASE_MATERIAL = 'clPropertyTubeBaseMaterial';

export const GROUP_OF_PREMISE = 'groupOfPremise';
export const PREMISE = 'premise';

// майно і об'єкти оренди
export const LEASE_RATE_DIRECTORY = 'leaseRateDirectory'; // Баз. Цільове призначення об'єкта за класифікатором
export const BASE_LEASE_PERIODS = 'baseLeasePeriods'; // Базовий період оренди
export const CL_AMORTIZATION = 'clAmortization'; // Базовий період оренди

// BALANCE CONTAINER
export const CL_ASSET_SPECIALISATION = 'clAssetSpecialisation';

// есть в контрагентах
export const DEPARTMENT_TYPE = 'refDepartmentType'; // Классификатор типов департаментов
export const KOPFG = 'kopfg'; // Організаційно-правова форма господарювання (за КОПФГ)
export const KVED = 'kved'; // Вид дільності (КВЕД)
export const KVED_LIVE_SEARCH = 'kvedLiveSearch'; // Вид дільності (КВЕД)
export const SKOF = 'skof'; // Форма суб'єкту економіки
export const SKODY = 'skody'; // Тип органу державного управління
export const KFV = 'kfv'; // Форма власності
export const FIN_SOURSE_TYPE = 'finSourseType'; // Форма фінансування
export const REGISTRATION_STATE = 'registratoinState'; // Стан реєстрації ЮО
export const LEGAL_ENTITY_STATE = 'legalEntityState'; // Стан реєстрації ЮО
export const IS_MODEL_STATUT = 'isModelStatut'; // Модельний статут
export const PHONELIST = 'phoneList'; // Список телефонов
export const EMAILLIST = 'emailList'; // Список emails
export const WEBSITELIST = 'webSiteList'; // Список сайтів

export const CORPORATE_RIGHTS_OPERATION_TYPE = 'corporateRightsOperationType';
export const STOCKS_TYPE = 'stocksType';
export const OPERATION_METHOD_TYPE = 'operationMethodType';
export const SHARES_FORM_TYPE = 'sharesFormType';
export const STATUS_OF_STATE_REGISTRATION = 'statusOfStateRegistration';

// documents

export const COUNTRIES_LIST = 'countriesList';
export const LAND_LORDS_TO_LEASE_OBJECTS = 'landlordsToLeaseObjects';

//  оцінка
export const ASSESSMENT_REASON_TYPE = 'assessmentReasonType';
export const LEASE_ASSESSMENT_TYPE = 'leaseAssessmentType';
export const CL_ASSESSMENT_REVIEWING_STATE = 'clAssessmentReviewingType';
export const ASSESSMENT_REVIEWING_CONCLUSION = 'AssessmentReviewingConsultion';
// Юр справи
export const COURT_INSTANCE_LEVEL_ENUM = 'courtInstanceLevelEnum'; // Рівень інстанції суду
export const COURT_SESSION_STATUS_ENUM = 'courtSessionStatusEnum'; // Стасус засідання

// LEASE CCA (PPD)
export const CLAIM_ACTION_ACTIVITY_STEP = 'claimActionActivityStep';
export const CLAIM_ACTION_ACTIVITY_STEP_STAGE = 'claimActionActivityStepStage';
export const CL_CLAIM_ACTION_ACTIVITY_STEP_TYPE = 'clClaimActionActivityStepType';
export const CLAIM_ACTION_ACTIVITY_STEP_STAGE_SUM_OPERATION =
  'claimActionActivityStepStageSumOperation';

export const PAYMENT_STATE = 'paymentState';
export const CLAIM_ACTION_ACTIVITY_STATUS = 'claimActionActivityStatus';
export const LEGAL_AFFAIRS = 'legalAffairs'; // TODO: temp solution, must be live search

// ADDRESS PARTS
export const ADDRESS_LOCALITY_AREA = 'localityArea';
export const ADDRESS_STREET = 'addressStreet';
export const ADDRESS_BUILDIND = 'addressBuildind';
export const ADDRESS_BUILDIND_SUB_OBJECT = 'addressBuildindSubObject';
export const ADDRESS_PREMISE = 'addressPremise';
