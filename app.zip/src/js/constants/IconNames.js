export const EYE = 'EYE';
export const PENCIL = 'PENCIL';
export const ARROW = 'ARROW';
export const SORT_ASC = 'SORT_ASC';
export const SORT_DESC = 'SORT_DESC';
export const ARCHIVE = 'ARCHIVE';
export const CHECKBOX = 'CHECKBOX';
export const CHECKBOX_CHECKED = 'CHECKBOX_CHECKED';

export const CHECK = 'CHECK';
export const CROSS = 'CROSS';
