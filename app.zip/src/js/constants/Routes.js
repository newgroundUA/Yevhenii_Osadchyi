import React from 'react';
import { Redirect, Switch, Route } from 'react-router-dom';
import * as rn from './RouteNames';

// 404
import Exception from '../components/Exception';

// Administration
import Users from '../components/administration/Users';
import Add from '../components/administration/Add';
import UserGroups from '../components/administration/UserGroups';
import Dictionaries from '../components/administration/Dictionaries';
import Documents from '../components/administration/Documents';

import PhonesContainer from '../containers/registry/PhonesContainer';
import EmailsContainer from '../containers/registry/EmailsContainer';
import SitesContainer from '../containers/registry/SitesContainer';

// Counterparties
import CounterpartyRegisterContainer from '../containers/counterparty/CounterpartyRegisterContainer';
import FoFormContainer from '../containers/counterparty/FoFormContainer';
import FopFormContainer from '../containers/counterparty/FopFormContainer';
import LegalPage from '../containers/counterparty/LegalPageContainer';

// PropertyRegister
import PropertyRegisterContainer from '../containers/property/registers/PropertyRegisterContainer';
/* registers */
import BuildingsRegisterContainer from '../containers/property/registers/BuildingsRegisterContainer';
import SteadsRegisterContainer from '../containers/property/registers/SteadsRegisterContainer';
import FieldsRegisterContainer from '../containers/property/registers/FieldsRegisterContainer';
import PremisesRegisterContainer from '../containers/property/registers/PremisesRegisterContainer';
import RoadsRegisterContainer from '../containers/property/registers/RoadsRegisterContainer';
import PipelinesRegisterContainer from '../containers/property/registers/PipelinesRegisterContainer';
import RailRoadsRegisterContainer from '../containers/property/registers/RailRoadsRegisterContainer';
import ElectricitiesRegisterContainer from '../containers/property/registers/ElectricitiesRegisterContainer';
import ConstructionsRegisterContainer from '../containers/property/registers/ConstructionsRegisterContainer';
import EquipmentsRegisterContainer from '../containers/property/registers/EquipmentsRegisterContainer';
import WhTransportsRegisterContainer from '../containers/property/registers/WhTransportsRegisterContainer';
import PlantsRegisterContainer from '../containers/property/registers/PlantsRegisterContainer';
import AnimalsRegisterContainer from '../containers/property/registers/AnimalsRegisterContainer';
import IntellRightsRegisterContainer from '../containers/property/registers/IntellRightsRegisterContainer';
import RealEstateRegistryContainer from '../containers/property/registers/RealEstateRegistryContainer';
/* forms */
import BuildingsFormContainer from '../containers/property/forms/building/BuildingsFormContainer';
import SteadsFormContainer from '../containers/property/forms/SteadsFormContainer';
import FieldsFormContainer from '../containers/property/forms/building/FieldsFormContainer';
import PremisesFormContainer from '../containers/property/forms/building/PremisesFormContainer';
import RoadsFormContainer from '../containers/property/forms/RoadsFormContainer';
import PipelinesFormContainer from '../containers/property/forms/PipelinesFormContainer';
import RailRoadsFormContainer from '../containers/property/forms/RailRoadsFormContainer';
import ElectricitiesFormContainer from '../containers/property/forms/ElectricitiesFormContainer';
import ConstructionsFormContainer from '../containers/property/forms/ConstructionsFormContainer';
import EquipmentsFormContainer from '../containers/property/forms/EquipmentsFormContainer';
import WhTransportsFormContainer from '../containers/property/forms/WhTransportsFormContainer';
import PlantsFormContainer from '../containers/property/forms/PlantsFormContainer';
import AnimalsFormContainer from '../containers/property/forms/AnimalsFormContainer';
import IntellRightsFormContainer from '../containers/property/forms/IntellRightsFormContainer';

// Evaluation
import EvaluationRegisterContainer from '../containers/evaluation/EvaluationRegisterContainer';
import CreateEvaluation from '../containers/evaluation/CreateEvaluationContainer';
import EvaluationFoLeaseForm from '../containers/evaluation/EvaluationFoLeaseFormContainer';
import EvaluationFoPrivatizationForm from '../containers/evaluation/EvaluationFoPrivatizationFormContainer';

// Privatization
import PrivatizationRegisterContainer from '../containers/privatization/PrivatizationRegisterContainer';
import CreatePrivatization from '../containers/privatization/PrivatizationContainer';

// UsageControl
import UsageControlRegisterContainer from '../containers/usageControl/UsageControlRegisterContainer';
import CreateUsageControl from '../containers/usageControl/CreateUsageControlContainer';
import MunicipalPropRentRefContainer from '../containers/usageControl/MunicipalPropRentRefContainer';
import ReducedPaymentsRegisterContainer from '../containers/usageControl/ReducedPaymentsRegisterContainer';
import ReducedLeaseMarksContainer from '../containers/usageControl/ReducedLeaseMarksContainer';
import BankStatementsRegisterContainer from '../containers/usageControl/BankStatementsRegisterContainer';
import ReportsByContractsRegisterContainer from '../containers/usageControl/ReportsByContractsRegisterContainer';
import ReportsByPeriodsRegisterContainer from '../containers/usageControl/ReportsByPeriodsRegisterContainer';

// CorporateRights
import CorporateRightsRegisterContainer from '../containers/corporateRights/CorporateRightsRegisterContainer';
import CorporateRightsMovementRegisterContainer from '../containers/corporateRights/CorporateRightsMovementRegisterContainer';
// import CreateCorporateRights from '../containers/corporateRights/CreateCorporateRightsContainer';

// LegalCases
import LegalCasesRegisterInitiativeContainer from '../containers/legalCases/LegalCasesRegisterInitiativeContainer';
import CreateLegalCasesInitiative from '../containers/legalCases/CreateLegalCasesInitiativeContainer';
import LegalCasesAffairsRegisterContainer from '../containers/legalCases/LegalCasesAffairsRegisterContainer';
import LegalCasesAffairsFormContainer from '../containers/legalCases/LegalCasesAffairsFormContainer';
import LegalCasesRequestForLegalProcessingRegisterContainer from '../containers/legalCases/LegalCasesRequestForLegalProcessingRegisterContainer';
import ProceedingFromContainer from '../containers/legalCases/ProceedingFromContainer';
import LegalCasesCourtSessionsPlanningsRegisterContainer from '../containers/legalCases/LegalCasesCourtSessionsPlanningsRegisterContainer';

// Reports
import ReportsRegisterContainer from '../containers/reports/ReportsRegisterContainer';

// Documents
import DocumentsRegisterContainer from '../containers/documents/DocumentsRegisterContainer';
import PassportFormContainer from '../containers/documents/PassportFormContainer';
import MarketValueFormContainer from '../containers/documents/MarketValueFormContainer';
import WriteOffFormContainer from '../containers/documents/WriteOffFormContainer';
import BalanceFormContainer from '../containers/documents/BalanceFormContainer';
import ContestsFormContariner from '../containers/documents/ContestsFormContariner';
import RentStatementFormContariner from '../containers/documents/RentStatementFormContariner';
import TypicalContractFormContainer from '../containers/documents/TypicalContractFormContainer';
import BankStatementFormContainer from '../containers/documents/BankStatementFormContainer';
import DocumentEditorContainer from '../containers/documents/DocumentEditorContainer';
import GeneralDocumentFormContainer from '../containers/documents/GeneralDocumentFormContainer';
import AppealsFormContainer from '../containers/documents/AppealsFormContainer';
import JudicialDecisionFormContainer from '../containers/documents/JudicialDecisionFormContainer';

// Lease
import LeasePeriodicalByBalanceholderlReportFormContainer from '../containers/lease/LeasePeriodicalByBalanceholderlReportFormContainer';
import LeasePeriodicalByContractReportFormContainer from '../containers/lease/LeasePeriodicalByContractReportFormContainer';
import LeaseContractPaymentScheduleFormContainer from '../containers/lease/LeaseContractPaymentScheduleFormContainer';
import LeaseContactsRegisterContainer from '../containers/lease/LeaseContractsRegisterContainer';
import LeaseDeclarationsRegisterContainer from '../containers/lease/LeaseDeclarationsRegisterContainer';
import LeaseRoomsRegisterContainer from '../containers/lease/LeaseRoomsRegisterContainer';
import LeaseContestsRegisterContainer from '../containers/lease/LeaseContestsRegisterContainer';
import LeaseObjectsRegisterContainer from '../containers/lease/LeaseObjectsRegisterContainer';
import LeaseAffairsRegisterContainer from '../containers/lease/LeaseAffairsRegisterContainer';
import LeaseContractPaymentScheduleRegisterContainer from '../containers/lease/LeaseContractPaymentScheduleRegisterContainer';
import LeaseConsolidatedPaymentScheduleContractPeriodRegisterContainer from '../containers/lease/LeaseConsolidatedPaymentScheduleContractPeriodRegisterContainer';
import LeaseConsolidatedPaymentScheduleContractByPeriodRegisterContainer from '../containers/lease/LeaseConsolidatedPaymentScheduleContractByPeriodRegisterContainer';
import LeaseConsolidatedPaymentScheduleByPeriodRegisterContainer from '../containers/lease/LeaseConsolidatedPaymentScheduleByPeriodRegisterContainer';
import LeaseContractPenaltyRegisterContainer from '../containers/lease/LeaseContractPenaltyRegisterContainer';
import LeaseLandlordToObjectsContainer from '../containers/lease/LeaseLandlordToObjectsContainer';
import LeaseCasesContainer from '../containers/lease/LeaseCasesContainer';
import LeaseCasesRegisterContainer from '../containers/lease/LeaseCasesRegisterContainer';
import LeaseCompetitionsContainer from '../containers/lease/LeaseCompetitionsContainer';
import LeasePaymentToPurposeContainer from '../containers/lease/LeasePaymentToPurposeContainer';
import LeaseClaimActionActivityRegister from '../containers/lease/leasePPD/LeaseClaimActionActivityRegister';
import LeaseClaimActionActivityCardContainer from '../containers/lease/leasePPD/LeaseClaimActionActivityCardContainer';
import PersonConnected from '../view/containers/Person';

// User
// import LoginContainer from '../containers/LoginContainer';

// eslint-disable-next-line
const commonContainer = (page, container) => ({ routes }) => (
  <div className="content_main">
    <Switch>
      {routes.map((route, i) => (
        <Route
          exact={!route.routes}
          key={i}
          path={route.path}
          render={(props) => <route.component {...props} routes={route.routes} />}
        />
      ))}
      <Redirect exact from={`/${page}`} to={`/${page}/${container}`} />
      <Redirect to={`/${rn.NOT_FOUND}`} />
    </Switch>
  </div>
);

const routes = [
  {
    path: `/${rn.NOT_FOUND}`,
    component: () => <Exception type="404" />,
  },
  {
    path: `/${rn.ADMINISTRATION}`,
    component: commonContainer(`${rn.ADMINISTRATION}`, `${rn.USERS}`),
    routes: [
      { path: `/${rn.ADMINISTRATION}/${rn.USERS}`, component: Users },
      { path: `/${rn.ADMINISTRATION}/${rn.ADD}`, component: Add },
      { path: `/${rn.ADMINISTRATION}/${rn.USER_GROUPS}`, component: UserGroups },
      { path: `/${rn.ADMINISTRATION}/${rn.DICTIONARIES}`, component: Dictionaries },
      { path: `/${rn.ADMINISTRATION}/${rn.DOCUMENTS}`, component: Documents },
      { path: `/${rn.ADMINISTRATION}/${rn.TELEPHONES}/:mode/:guid?`, component: PhonesContainer },
      { path: `/${rn.ADMINISTRATION}/${rn.EMAILS}/:mode/:guid?`, component: EmailsContainer },
      { path: `/${rn.ADMINISTRATION}/${rn.SITES}/:mode/:guid?`, component: SitesContainer },
    ],
  },
  {
    path: `/${rn.COUNTERPARTIES}`,
    component: commonContainer(`${rn.COUNTERPARTIES}`, `${rn.REGISTER}`),
    routes: [
      { path: `/${rn.COUNTERPARTIES}/${rn.REGISTER}`, component: CounterpartyRegisterContainer },
      { path: `/${rn.COUNTERPARTIES}/${rn.FO}/:mode/:guid?`, component: PersonConnected },
      { path: `/${rn.COUNTERPARTIES}/${rn.FOP}/:mode/:guid?`, component: FopFormContainer },
      { path: `/${rn.COUNTERPARTIES}/${rn.LEGALPAGE}/:mode/:guid?`, component: LegalPage },
    ],
  },
  {
    path: `/${rn.PROPERTY}`,
    component: commonContainer(`${rn.PROPERTY}`, `${rn.REGISTER}`),
    routes: [
      // registers
      {
        path: `/${rn.PROPERTY}/${rn.REAL_ESTATE_REGISTER}`,
        component: RealEstateRegistryContainer,
      },
      { path: `/${rn.PROPERTY}/${rn.REGISTER}`, component: PropertyRegisterContainer }, // 0
      { path: `/${rn.PROPERTY}/${rn.BUILDINGS_REGISTER}`, component: BuildingsRegisterContainer }, // 1
      { path: `/${rn.PROPERTY}/${rn.STEAD_REGISTER}`, component: SteadsRegisterContainer }, // 2
      { path: `/${rn.PROPERTY}/${rn.FIELD_REGISTER}`, component: FieldsRegisterContainer }, // 3
      { path: `/${rn.PROPERTY}/${rn.PREMISE_REGISTER}`, component: PremisesRegisterContainer }, // 4
      { path: `/${rn.PROPERTY}/${rn.ROAD_REGISTER}`, component: RoadsRegisterContainer }, // 5
      { path: `/${rn.PROPERTY}/${rn.PIPELINE_REGISTER}`, component: PipelinesRegisterContainer }, // 6
      { path: `/${rn.PROPERTY}/${rn.RAILROAD_REGISTER}`, component: RailRoadsRegisterContainer }, // 7
      {
        path: `/${rn.PROPERTY}/${rn.ELECTRICITY_REGISTER}`,
        component: ElectricitiesRegisterContainer,
      }, // 8
      {
        path: `/${rn.PROPERTY}/${rn.CONSTRUCTION_REGISTER}`,
        component: ConstructionsRegisterContainer,
      }, // 9
      { path: `/${rn.PROPERTY}/${rn.EQUIPMENT_REGISTER}`, component: EquipmentsRegisterContainer }, // 10
      {
        path: `/${rn.PROPERTY}/${rn.WHTRANSPORT_REGISTER}`,
        component: WhTransportsRegisterContainer,
      }, // 11
      { path: `/${rn.PROPERTY}/${rn.PLANT_REGISTER}`, component: PlantsRegisterContainer }, // 12
      { path: `/${rn.PROPERTY}/${rn.ANIMAL_REGISTER}`, component: AnimalsRegisterContainer }, // 13
      {
        path: `/${rn.PROPERTY}/${rn.INTELLRIGHT_REGISTER}`,
        component: IntellRightsRegisterContainer,
      }, // 14
      // forms
      {
        path: `/${rn.PROPERTY}/${rn.BUILDINGS_FORM}/:mode/:guid?`,
        component: BuildingsFormContainer,
      }, // 1
      { path: `/${rn.PROPERTY}/${rn.STEAD_FORM}/:mode/:guid?`, component: SteadsFormContainer }, // 2
      { path: `/${rn.PROPERTY}/${rn.FIELD_FORM}/:mode/:guid?`, component: FieldsFormContainer }, // 3
      { path: `/${rn.PROPERTY}/${rn.PREMISE_FORM}/:mode/:guid?`, component: PremisesFormContainer }, // 4
      { path: `/${rn.PROPERTY}/${rn.ROAD_FORM}/:mode/:guid?`, component: RoadsFormContainer }, // 5
      {
        path: `/${rn.PROPERTY}/${rn.PIPELINE_FORM}/:mode/:guid?`,
        component: PipelinesFormContainer,
      }, // 6
      {
        path: `/${rn.PROPERTY}/${rn.RAILROAD_FORM}/:mode/:guid?`,
        component: RailRoadsFormContainer,
      }, // 7
      {
        path: `/${rn.PROPERTY}/${rn.ELECTRICITY_FORM}/:mode/:guid?`,
        component: ElectricitiesFormContainer,
      }, // 8
      {
        path: `/${rn.PROPERTY}/${rn.CONSTRUCTION_FORM}/:mode/:guid?`,
        component: ConstructionsFormContainer,
      }, // 9
      {
        path: `/${rn.PROPERTY}/${rn.EQUIPMENT_FORM}/:mode/:guid?`,
        component: EquipmentsFormContainer,
      }, // 10
      {
        path: `/${rn.PROPERTY}/${rn.WHTRANSPORT_FORM}/:mode/:guid?`,
        component: WhTransportsFormContainer,
      }, // 11
      { path: `/${rn.PROPERTY}/${rn.PLANT_FORM}/:mode/:guid?`, component: PlantsFormContainer }, // 12
      { path: `/${rn.PROPERTY}/${rn.ANIMAL_FORM}/:mode/:guid?`, component: AnimalsFormContainer }, // 13
      {
        path: `/${rn.PROPERTY}/${rn.INTELLRIGHT_FORM}/:mode/:guid?`,
        component: IntellRightsFormContainer,
      }, // 14
    ],
  },
  {
    path: `/${rn.DOCUMENTS}`,
    component: commonContainer(`${rn.DOCUMENTS}`, `${rn.REGISTER}`),
    routes: [
      { path: `/${rn.DOCUMENTS}/${rn.REGISTER}`, component: DocumentsRegisterContainer },
      {
        path: `/${rn.DOCUMENTS}/${rn.DOCUMENT_GENERAL}/:mode?/:guid?`,
        component: GeneralDocumentFormContainer,
      },
      {
        path: `/${rn.DOCUMENTS}/${rn.DOCUMENT_PASSPORT}/:mode/:guid?`,
        component: PassportFormContainer,
      },
      {
        path: `/${rn.DOCUMENTS}/${rn.DOCUMENT_MARKET}/:mode/:guid?`,
        component: MarketValueFormContainer,
      },
      {
        path: `/${rn.DOCUMENTS}/${rn.DOCUMENT_WRITEOFF}/:mode?/:formType?/:guid?`,
        component: WriteOffFormContainer,
      },
      {
        path: `/${rn.DOCUMENTS}/${rn.DOCUMENT_BALANCE}/:mode/:guid?`,
        component: BalanceFormContainer,
      },
      {
        path: `/${rn.DOCUMENTS}/${rn.DOCUMENT_CONTESTS}/:mode/:guid?`,
        component: ContestsFormContariner,
      },
      {
        path: `/${rn.DOCUMENTS}/${rn.DOCUMENT_RENT_STATEMENT}/:mode?/:guid?`,
        component: RentStatementFormContariner,
      },
      {
        path: `/${rn.DOCUMENTS}/${rn.DOCUMENT_TYPICAL_CONTRACT}/:mode?/:guid?`,
        component: TypicalContractFormContainer,
      },
      {
        path: `/${rn.DOCUMENTS}/${rn.DOCUMENT_APPEALS}/:mode/:guid?`,
        component: AppealsFormContainer,
      },
      {
        path: `/${rn.DOCUMENTS}/${rn.DOCUMENT_JUDICIAL_DECISION}/:mode/:guid?`,
        component: JudicialDecisionFormContainer,
      },
      {
        path: `/${rn.DOCUMENTS}/${rn.DOCUMENT_EDITOR}/:mode/:documentGuid`,
        component: DocumentEditorContainer,
      },
      {
        path: `/${rn.DOCUMENTS}/${rn.DOCUMENT_BANK_STATEMENT}/:mode?/:guid?`,
        component: BankStatementFormContainer,
      },
    ],
  },
  {
    // LeasePaymentToPurposeContainer
    path: `/${rn.LEASE}`,
    component: commonContainer(`${rn.LEASE}`, `${rn.ROOMS_REGISTER}`),
    routes: [
      { path: `/${rn.LEASE}/${rn.CONTRACTS_REGISTER}`, component: LeaseContactsRegisterContainer },
      {
        path: `/${rn.LEASE}/${rn.DECLARATIONS_REGISTER}`,
        component: LeaseDeclarationsRegisterContainer,
      },
      { path: `/${rn.LEASE}/${rn.ROOMS_REGISTER}`, component: LeaseRoomsRegisterContainer },
      { path: `/${rn.LEASE}/${rn.CONTESTS_REGISTER}`, component: LeaseContestsRegisterContainer },
      { path: `/${rn.LEASE}/${rn.OBJECTS_REGISTER}`, component: LeaseObjectsRegisterContainer },
      { path: `/${rn.LEASE}/${rn.AFFAIRS_REGISTER}`, component: LeaseAffairsRegisterContainer },
      {
        path: `/${rn.LEASE}/${rn.LEASE_CONTRACT_PAYMENT_SCHEDULE}/:mode/:guid?`,
        component: LeaseContractPaymentScheduleFormContainer,
      },
      {
        path: `/${rn.LEASE}/${rn.LEASE_CONTRACT_PAYMENT_SCHEDULE_REGISTER}`,
        component: LeaseContractPaymentScheduleRegisterContainer,
      },
      {
        path: `/${rn.LEASE}/${rn.LEASE_PAYMENT_TO_PURPOSE_REGISTER}`,
        component: LeasePaymentToPurposeContainer,
      },
      {
        path: `/${rn.LEASE}/${rn.LEASE_CLAIM_ACTION_ACTIVITY}`,
        component: commonContainer(`${rn.LEASE}/${rn.LEASE_CLAIM_ACTION_ACTIVITY}`, rn.REGISTER),
        routes: [
          {
            path: `/${rn.LEASE}/${rn.LEASE_CLAIM_ACTION_ACTIVITY}/${rn.REGISTER}`,
            component: LeaseClaimActionActivityRegister,
          },
          {
            path: `/${rn.LEASE}/${rn.LEASE_CLAIM_ACTION_ACTIVITY}/${rn.CARD}/:guid`,
            component: LeaseClaimActionActivityCardContainer,
          },
        ],
      },
      {
        path: `/${rn.LEASE}/${rn.LANDLORD_TO_OBJECTS}/:mode/:guid?`,
        component: LeaseLandlordToObjectsContainer,
      },
      { path: `/${rn.LEASE}/${rn.LEASE_CASES}/:mode/:guid?`, component: LeaseCasesContainer },
      { path: `/${rn.LEASE}/${rn.LEASE_CASES_REGISTER}`, component: LeaseCasesRegisterContainer },
      {
        path: `/${rn.LEASE}/${rn.LEASE_CONSOLIDATED_PAYMENT_SCHEDULE_CONTRACT_PERIOD}`,
        component: LeaseConsolidatedPaymentScheduleContractPeriodRegisterContainer,
      },
      {
        path: `/${rn.LEASE}/${rn.LEASE_CONSOLIDATED_PAYMENT_SCHEDULE_CONTRACT_BY_PERIOD}`,
        component: LeaseConsolidatedPaymentScheduleContractByPeriodRegisterContainer,
      },
      {
        path: `/${rn.LEASE}/${rn.LEASE_CONSOLIDATED_PAYMENT_SCHEDULE_BY_PERIOD}`,
        component: LeaseConsolidatedPaymentScheduleByPeriodRegisterContainer,
      },
      {
        path: `/${rn.LEASE}/${rn.LEASE_CONTRACT_PENALTY}`,
        component: LeaseContractPenaltyRegisterContainer,
      },
      {
        path: `/${rn.LEASE}/${rn.LEASE_COMPETITIONS}/:mode/:guid?`,
        component: LeaseCompetitionsContainer,
      },
    ],
  },
  {
    path: `/${rn.EVALUATION}`,
    component: commonContainer(`${rn.EVALUATION}`, `${rn.REGISTER}`),
    routes: [
      { path: `/${rn.EVALUATION}/${rn.REGISTER}`, component: EvaluationRegisterContainer },
      {
        path: `/${rn.EVALUATION}/${rn.FORM_EVALUATION}/:mode?/:formType?/:guid?`,
        component: CreateEvaluation,
      },
      {
        path: `/${rn.EVALUATION}/${rn.EVALUATION_FO_LEASE_FORM}/:mode/:guid?`,
        component: EvaluationFoLeaseForm,
      },
      {
        path: `/${rn.EVALUATION}/${rn.EVALUATION_FO_PRIVATIZATION_FORM}/:mode/:guid?`,
        component: EvaluationFoPrivatizationForm,
      },
    ],
  },
  {
    path: `/${rn.PRIVATIZATION}`,
    component: commonContainer(`${rn.PRIVATIZATION}`, `${rn.REGISTER}`),
    routes: [
      { path: `/${rn.PRIVATIZATION}/${rn.REGISTER}`, component: PrivatizationRegisterContainer },
      {
        path: `/${rn.PRIVATIZATION}/${rn.PRIVATISATION_FORM}/:mode/:guid?`,
        component: CreatePrivatization,
      },
    ],
  },
  {
    path: `/${rn.USAGE_CONTROL}`,
    component: commonContainer(`${rn.USAGE_CONTROL}`, `${rn.MUNICIPAL_PROP_RENT_REFERENCE}`),
    routes: [
      { path: `/${rn.USAGE_CONTROL}/${rn.REGISTER}`, component: UsageControlRegisterContainer },
      {
        path: `/${rn.USAGE_CONTROL}/${rn.FORM_USAGE_CONTROL}/:mode?/:formType?/:guid?`,
        component: CreateUsageControl,
      },
      {
        path: `/${rn.USAGE_CONTROL}/${rn.MUNICIPAL_PROP_RENT_REFERENCE}`,
        component: MunicipalPropRentRefContainer,
      },
      {
        path: `/${rn.USAGE_CONTROL}/${rn.REDUCED_PMNT_REGISTER}`,
        component: ReducedPaymentsRegisterContainer,
      },
      {
        path: `/${rn.USAGE_CONTROL}/${rn.REDUCED_LEASE_MARKS}`,
        component: ReducedLeaseMarksContainer,
      },
      {
        path: `/${rn.USAGE_CONTROL}/${rn.BANK_STATEMENTS_REGISTER}`,
        component: BankStatementsRegisterContainer,
      },
      {
        path: `/${rn.USAGE_CONTROL}/${rn.REPORTS_CONTRACTS_REGISTER}`,
        component: ReportsByContractsRegisterContainer,
      },
      {
        path: `/${rn.USAGE_CONTROL}/${rn.REPORTS_PERIODS_REGISTER}`,
        component: ReportsByPeriodsRegisterContainer,
      },
      {
        path: `/${rn.USAGE_CONTROL}/${rn.PERIODICAL_BY_BALANCE_HOLDER_REPORT}/:mode/:guid?`,
        component: LeasePeriodicalByBalanceholderlReportFormContainer,
      },
      {
        path: `/${rn.USAGE_CONTROL}/${rn.PERIODICAL_BY_CONTRACT_REPORT}/:mode/:guid?`,
        component: LeasePeriodicalByContractReportFormContainer,
      },
    ],
  },
  {
    path: `/${rn.CORPORATE_RIGHTS}`,
    component: commonContainer(`${rn.CORPORATE_RIGHTS}`, `${rn.REGISTER_CORPORATE_RIGHTS}`),
    routes: [
      {
        path: `/${rn.CORPORATE_RIGHTS}/${rn.REGISTER_CORPORATE_RIGHTS}`,
        component: CorporateRightsRegisterContainer,
      },
      {
        path: `/${rn.CORPORATE_RIGHTS}/${rn.REGISTER_CORPORATE_RIGHTS_MOVEMENT}`,
        component: CorporateRightsMovementRegisterContainer,
      },
      {
        path: `/${rn.CORPORATE_RIGHTS}/${rn.FORM_CORPORATE_RIGHTS}/:mode/:guid?`,
        component: LegalPage,
      },
    ],
  },
  {
    path: `/${rn.LEGAL_CASES}`,
    component: commonContainer(`${rn.LEGAL_CASES}`, `${rn.AFFAIRS_REGISTER}`),
    routes: [
      {
        path: `/${rn.LEGAL_CASES}/${rn.REGISTER_INITIATIVE}`,
        component: LegalCasesRegisterInitiativeContainer,
      },
      {
        path: `/${rn.LEGAL_CASES}/${rn.AFFAIRS_REGISTER}`,
        component: LegalCasesAffairsRegisterContainer,
      },
      {
        path: `/${rn.LEGAL_CASES}/${rn.COURT_SESSIONS_PLANNINGS_REGISTER}`,
        component: LegalCasesCourtSessionsPlanningsRegisterContainer,
      },
      {
        path: `/${rn.LEGAL_CASES}/${rn.REGISTER_REQUEST_FOR_LEGAL_PROCESSING}`,
        component: LegalCasesRequestForLegalProcessingRegisterContainer,
      },
      {
        path: `/${rn.LEGAL_CASES}/${rn.FORM_LEGAL_CASES_INITIATIVE}/:mode?/:formType?/:guid?`,
        component: CreateLegalCasesInitiative,
      },
      {
        path: `/${rn.LEGAL_CASES}/${rn.FORM_LEGAL_CASES_AFFAIRS}/:mode/:guid?`,
        component: LegalCasesAffairsFormContainer,
      },
      {
        path: `/${rn.LEGAL_CASES}/${rn.FORM_PROCEEDING_CARD}/:mode?/:guid?`,
        component: ProceedingFromContainer,
      },
    ],
  },
  {
    path: `/${rn.REPORTS}`,
    component: commonContainer(`${rn.REPORTS}`, `${rn.REGISTER}`),
    routes: [{ path: `/${rn.REPORTS}/${rn.REGISTER}`, component: ReportsRegisterContainer }],
  },
  // {
  //   path: `/${rn.LOGIN}`,
  //   component: LoginContainer
  // }
];

export default routes;
