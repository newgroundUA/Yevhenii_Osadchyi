// common
// import leasePaymentToPurposeReducer
// from '../reducers/modules/lease/leasePaymentToPurposeReducer';

export const REGISTER = 'register';
export const CARD = 'card';
export const CREATE = 'create';
export const VIEW = 'view';
export const EDIT = 'edit';
export const ADD = 'add';
export const LOGIN = 'login';
export const NOT_FOUND = '404';

// header
export const CERTIFICATE = 'certificate';
export const NOTIFICATIONS = 'notifications';
export const CURRENT_USER = 'user';

// administration
export const ADMINISTRATION = 'administration';
export const USERS = 'users';
export const USER_GROUPS = 'usergroups';
export const DICTIONARIES = 'dictionaries';
export const TELEPHONES = 'telephones';
export const EMAILS = 'emails';
export const SITES = 'sites';

// counterparties
export const COUNTERPARTIES = 'counterparties';
export const FO = 'fo';
export const FOP = 'fop';
export const LEGALPAGE = 'legalpage';

// evaluation
export const EVALUATION = 'evaluation';
export const FORM_EVALUATION = 'formevaluation';
export const EVALUATION_FO_LEASE_FORM = 'EvaluationFoLeaseForm';
export const EVALUATION_FO_PRIVATIZATION_FORM = 'EvaluationFoPrivatizationForm';

// privatization
export const PRIVATIZATION = 'privatization';
export const PRIVATISATION_FORM = 'privatisationForm';

// usage control
export const USAGE_CONTROL = 'usagecontrol';
export const FORM_USAGE_CONTROL = 'formusagecontrol';
export const MUNICIPAL_PROP_RENT_REFERENCE = 'municipalproprentreference';
export const REDUCED_PMNT_REGISTER = 'reducedpaymentsregister';
export const REDUCED_LEASE_MARKS = 'reducedleasemarks';
export const BANK_STATEMENTS_REGISTER = 'bankstatementsregister';
export const REPORTS_CONTRACTS_REGISTER = 'reportsbycontractsregister';
export const REPORTS_PERIODS_REGISTER = 'reportsbyperiodsregister';

// corporate rights
export const REGISTER_CORPORATE_RIGHTS = 'registerCorporateRights'; // Реєстр корпоративних прав
export const REGISTER_CORPORATE_RIGHTS_MOVEMENT = 'registerCorporateRightsMovement'; // Реєстр руху корпоративних прав
export const CORPORATE_RIGHTS = 'corporaterights';
export const FORM_CORPORATE_RIGHTS = 'formcorporaterights';

// legal cases
export const LEGAL_CASES = 'legalcases';
export const REGISTER_INITIATIVE = 'registerinitiative';
export const REGISTER_REQUEST_FOR_LEGAL_PROCESSING = 'registerRequestForLegalProcessing';
export const FORM_LEGAL_CASES_INITIATIVE = 'formlegalcasesinitiative';
export const FORM_LEGAL_CASES_AFFAIRS = 'formlegalcasesaffairs';
export const FORM_PROCEEDING_CARD = 'proceedingcard';
export const COURT_SESSIONS_PLANNINGS_REGISTER = 'courtSessionsPlanningsRegister';

// documents
export const DOCUMENTS = 'documents';
export const DOCUMENT_GENERAL = 'documentsGeneral';
export const DOCUMENT_PASSPORT = 'passport';
export const DOCUMENT_MARKET = 'market';
export const DOCUMENT_WRITEOFF = 'writeoff';
export const DOCUMENT_BALANCE = 'balance';
export const DOCUMENT_BALANCE_OLD = 'balance_old';
export const DOCUMENT_CONTESTS = 'contests';
export const DOCUMENT_RENT_STATEMENT = 'rentstatement';
export const DOCUMENT_TYPICAL_CONTRACT = 'typicalcontract';
export const DOCUMENT_BANK_STATEMENT = 'bankstatement';
export const DOCUMENT_EDITOR = 'editor';
export const DOCUMENT_APPEALS = 'appeals';
export const DOCUMENT_JUDICIAL_DECISION = 'judicialDecision';

// lease
export const PERIODICAL_BY_BALANCE_HOLDER_REPORT = 'leasePeriodicalByBalanceHolderReport';
export const PERIODICAL_BY_CONTRACT_REPORT = 'leasePeriodicalByContractReport';
export const LEASE_CONSOLIDATED_PAYMENT_SCHEDULE_CONTRACT_PERIOD =
  'leaseConsolidatedPaymentScheduleContractPeriod'; // Консолідований Графік Призначених платежів та Здійснених оплат ContractPeriod
export const LEASE_CONSOLIDATED_PAYMENT_SCHEDULE_CONTRACT_BY_PERIOD =
  'leaseConsolidatedPaymentScheduleContractByPeriod'; // Консолідований Графік Призначених платежів та Здійснених оплат ContractByPeriod
export const LEASE_CONSOLIDATED_PAYMENT_SCHEDULE_BY_PERIOD =
  'leaseConsolidatedPaymentScheduleByPeriod'; // Консолідований Графік Призначених платежів та Здійснених оплат ByPeriod
export const LEASE_CONTRACT_PAYMENT_SCHEDULE = 'leaseContractPaymentSchedule'; // Форма Графік Платежів по периодах оренди в Договорах оренди
export const LEASE_CONTRACT_PENALTY = 'leaseContractPenalty'; // Реэстр нарахованих неустойок по Договорах Оренди
export const LEASE = 'lease';
export const CONTRACTS_REGISTER = 'contractsregister';
export const DECLARATIONS_REGISTER = 'declarationsregister';
export const ROOMS_REGISTER = 'roomsregister';
export const CONTESTS_REGISTER = 'contestsregister';
export const OBJECTS_REGISTER = 'objectsregister';
export const AFFAIRS_REGISTER = 'affairsregister';
export const LANDLORD_TO_OBJECTS = 'landlordtoobjects';
export const LEASE_CASES = 'leaseCases';
export const LEASE_CASES_REGISTER = 'leaseCasesRegister';
export const LEASE_COMPETITIONS = 'competitions';
export const LEASE_PAYMENT_TO_PURPOSE_REGISTER = 'leasePaymentToPurposeRegister'; // Реэстр отриманих коштів по Договорах Оренди
export const LEASE_CONTRACT_PAYMENT_SCHEDULE_REGISTER = 'leaseContractPaymentScheduleRegister'; // Графік Платежів по периодах оренди в Договорах оренди
export const LEASE_CLAIM_ACTION_ACTIVITY_REGISTER = 'claimActionActivityRegister';
export const LEASE_CLAIM_ACTION_ACTIVITY_CARD = 'claimActionActivityCard';
export const LEASE_CLAIM_ACTION_ACTIVITY = 'claimActionActivity';

// reports
export const REPORTS = 'reports';

// property
export const PROPERTY = 'property';
export const OBJECT = 'object';
export const FORM_OBJECT = 'formobject';
/* registers */
export const BUILDINGS_REGISTER = 'buildingsregister'; // 1
export const STEAD_REGISTER = 'steadregister'; // 2
export const FIELD_REGISTER = 'fieldregister'; // 3
export const PREMISE_REGISTER = 'premiseregister'; // 4
export const ROAD_REGISTER = 'roadregister'; // 5
export const PIPELINE_REGISTER = 'pipelineregister'; // 6
export const RAILROAD_REGISTER = 'railroadregister'; // 7
export const ELECTRICITY_REGISTER = 'electricityregister'; // 8
export const CONSTRUCTION_REGISTER = 'constructionregister'; // 9
export const EQUIPMENT_REGISTER = 'equipmentregister'; // 10
export const WHTRANSPORT_REGISTER = 'whtransportregister'; // 11
export const PLANT_REGISTER = 'plantregister'; // 12
export const ANIMAL_REGISTER = 'animalregister'; // 13
export const INTELLRIGHT_REGISTER = 'intellrightregister'; // 14
export const REAL_ESTATE_REGISTER = 'realestateregister';
/* forms */
export const BUILDINGS_FORM = 'buildingsform'; // 1
export const STEAD_FORM = 'steadform'; // 2
export const FIELD_FORM = 'fieldform'; // 3
export const PREMISE_FORM = 'premiseform'; // 4
export const ROAD_FORM = 'roadform'; // 5
export const PIPELINE_FORM = 'pipelineform'; // 6
export const RAILROAD_FORM = 'railroadform'; // 7
export const ELECTRICITY_FORM = 'electricityform'; // 8
export const CONSTRUCTION_FORM = 'constructionform'; // 9
export const EQUIPMENT_FORM = 'equipmentform'; // 10
export const WHTRANSPORT_FORM = 'whtransportform'; // 11
export const PLANT_FORM = 'plantform'; // 12
export const ANIMAL_FORM = 'animalform'; // 13
export const INTELLRIGHT_FORM = 'intellrightform'; // 14

// unused??? may be yes )))
export const ADDOBJECT = 'addobject';
export const VIEWOBJECT = 'viewobject';
export const EDITOBJECT = 'editobject';
