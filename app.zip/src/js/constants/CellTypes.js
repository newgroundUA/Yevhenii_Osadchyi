export const TEXT = 'TEXT';
export const LINK = 'LINK';
export const SORT = 'SORT';
export const DROP_DOWN = 'DROP_DOWN';
export const CHECKBOX = 'CHECKBOX';
export const BUTTONS = 'BUTTONS';
