import React from 'react';

import { connect } from 'react-redux';
import PropTypes from 'prop-types';

import { Route, withRouter } from 'react-router-dom';

import * as actions from '../actions';

import Title from '../components/navigation/Title';
import HeaderNav from '../components/navigation/HeaderNav';
import TopMenu from '../components/navigation/TopMenu';
import { doLogOut } from '../actions/usersActions';

const CONTAINER_ACTIONS = {
  doLogOut,
  ...actions,
};

class HeaderContainer extends React.Component {
  componentWillMount() {}

  render() {
    return (
      <div>
        <div className="header">
          <Title />
          <Route
            path="/:page?"
            render={(props) => (
              <HeaderNav
                doLogOut={this.props.doLogOut}
                history={props.history}
                route={props.match.params.page || ''}
              />
            )}
          />
        </div>
        <Route
          path="/:page?"
          render={(props) => (
            <TopMenu items={this.props.menuItems} route={props.match.params.page || ''} />
          )}
        />
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  menuItems: state.menuItems.topMenuItems,
});

HeaderContainer.propTypes = {
  menuItems: PropTypes.objectOf(PropTypes.object).isRequired,
  doLogOut: PropTypes.func.isRequired,
};

export default withRouter(connect(mapStateToProps, CONTAINER_ACTIONS)(HeaderContainer));
