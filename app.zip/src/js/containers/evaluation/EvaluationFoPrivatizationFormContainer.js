import React from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import PropTypes from 'prop-types';
import _get from 'lodash/get';

import { Form, Modal, Button, Row, Icon } from 'antd';
import * as classifiersActions from '../../actions/classifiersActions';
import * as evaluationForPrivatizationActions from '../../actions/modules/evaluation/evaluationForPrivatization';
import * as commonActions from '../../actions';

import * as RouteNames from '../../constants/RouteNames';
import { WEBSITELIST } from '../../constants/ClassifiersNames';

import { mapFormItems } from '../../helpers/formHelpers/mapFormHelper';
import {
  evaluationObjectFields,
  reviewCaseOptionsFields,
  caseIncomingDocumentsFields,
  caseReviewingResultrsFields,
  caseCounterpartiesFields,
  parseToFE,
  parseToBE,
} from '../../models/formFields/evaluation/evaluationFoPrivatizationFields';

import * as marketValueDocumentActions from '../../actions/modules/documents/marketValueDocumentActions';
import * as privatisationActions from '../../actions/modules/privatisation/privatisationFormActions';

import { EVALUATION_FO_PRIVATIZATION_FORM_CONTAINER } from '../../constants/ContainerNames';

import Separator from '../../components/common/form/Separator';
import { getFormEntityData } from '../../helpers/formHelpers/formHelpers';

const EVALUATION_FO_PRIVATIZATION_FORM_ACTIONS = {
  ...classifiersActions,
  ...evaluationForPrivatizationActions,
  ...commonActions,
  ...marketValueDocumentActions,
  ...privatisationActions, // change
};
const ButtonGroup = Button.Group;

class EvaluationFoPrivatizationFormContainer extends React.Component {
  constructor(props) {
    super(props);

    const curMode = this.props.match.params.mode || 'create';
    this.curGuid = this.props.match.params.guid || '';

    this.state = {
      curMode,
      dialogOpen: false,
      dialogMessage: '',
      selectedPrivatizationObject: null,
    };

    this.loaded = false;
  }

  selectedDocForReviewingId = null;

  // хуйня
  componentDidMount = () => {
    const { curMode } = this.state;

    this.props.loadClassifiersForContainer(EVALUATION_FO_PRIVATIZATION_FORM_CONTAINER, {
      [WEBSITELIST]: {
        webSiteRegistryParam: {
          limit: '100',
          offset: '0',
        },
      },
    });

    if (curMode === 'view' || curMode === 'edit') {
      this.props.getPrivatizationAssessmentReviewingCase(this.curGuid).then((res) => {
        this.selectedDocForReviewingId = res.data.docForReviewingGuid;
      });
    }
  };

  componentWillReceiveProps(nextProps) {
    const {
      formParam: { createdForm, status, errors },
      match: {
        params: { mode },
      },
      resetPrivatizationAssessmentReviewingCaseDoneStatus,
      form: { getFieldValue, setFieldsValue },
      getMarketValueDocument,
      getPrivatisationObjects,
    } = nextProps;

    if (this.state.curMode !== mode) this.setState({ curMode: mode });

    if (createdForm.guid && (mode === 'view' || mode === 'edit') && !this.loaded) {
      this.loaded = true;
      if (createdForm && createdForm.privatizationObject) {
        this.selectedDocForReviewingId = createdForm.docForReviewing.guid;
        this.setState({
          selectedPrivatizationObject: {
            guid: createdForm.privatizationObject.guid,
            versionId: createdForm.privatizationObject.versionId,
          },
        });
      }
      setFieldsValue(parseToFE(createdForm));
    }

    if (status.isDone) {
      this.loaded = true;
      this.curGuid = createdForm.guid;
      this.handleToggleDialog();
      resetPrivatizationAssessmentReviewingCaseDoneStatus();
    }

    if (errors.length > 0) {
      const errorsText = errors.map((el) => el.message).join(', ');
      this.setState({ dialogMessage: errorsText, dialogOpen: true });
      resetPrivatizationAssessmentReviewingCaseDoneStatus();
    }

    const newDocForReviewingValue = getFieldValue('docForReviewing');
    const newDocForReviewingId = newDocForReviewingValue ? newDocForReviewingValue.key : null;

    if (this.selectedDocForReviewingId !== newDocForReviewingId) {
      let assessObject;
      this.selectedDocForReviewingId = newDocForReviewingId;

      getMarketValueDocument(newDocForReviewingId).then((res) => {
        assessObject = res.data && res.data.assessObject;

        if (assessObject && assessObject.guid) {
          getPrivatisationObjects(assessObject.guid).then((privatizationObjectServerResponce) => {
            const privatizationObject = privatizationObjectServerResponce.data;
            this.setState({
              selectedPrivatizationObject: {
                guid: assessObject.guid,
                versionId: assessObject.versionId,
              },
            });
            setFieldsValue({
              evaluationObjectNumber: privatizationObject.privatObjectNumber,
              evaluationObjectName: privatizationObject.privatObjectFullName,
              evaluationObjectAddress: _get(
                privatizationObject,
                ['address', 'addressAsString'],
                '',
              ),
              evaluationObjectTotalSpace: privatizationObject.privatObjectTotalSpace,
              evaluationObjectUsefullSpace: privatizationObject.privatObjectUsefullSpace,
              evaluationObjectCommonUsesSpace: privatizationObject.privatObjectCommonUseSpace,
            });
          });
        }
      });
    }
  }

  handleCreateNew = () => {
    this.changeRouteTo(
      `/${RouteNames.EVALUATION}/${RouteNames.EVALUATION_FO_PRIVATIZATION_FORM}/create`,
    );
    this.curGuid = '';
    this.loaded = false;
    this.props.form.resetFields();
    this.props.resetPrivatizationAssessmentReviewingCaseForm();
    this.handleToggleDialog();
  };

  clearForm = () => {
    this.props.form.resetFields();
  };

  changeRouteTo = (route) => {
    this.props.history.push(route);
  };

  handleToggleDialog = (isOpened) => {
    if (isOpened !== undefined) this.setState({ dialogOpen: isOpened });
    else this.setState((prevState) => ({ dialogOpen: !prevState.dialogOpen }));
  };

  handleDialogCancel = () => {
    this.handleToggleDialog();
    this.switchToViewMode();
  };

  switchToEditMode = () => {
    this.changeRouteTo(
      `/${RouteNames.EVALUATION}/${RouteNames.EVALUATION_FO_PRIVATIZATION_FORM}/edit/${
        this.curGuid
      }`,
    );
  };

  switchToViewMode = () => {
    this.changeRouteTo(
      `/${RouteNames.EVALUATION}/${RouteNames.EVALUATION_FO_PRIVATIZATION_FORM}/view/${
        this.curGuid
      }`,
    );
  };

  handleSubmit = () => {
    const { curMode } = this.state;
    const {
      postPrivatizationAssessmentReviewingCase,
      putPrivatizationAssessmentReviewingCase,
      classifiers,
      form,
      formParam,
    } = this.props;

    const fields = [
      // ...Object.keys(evaluationObjectFields),
      ...Object.keys(reviewCaseOptionsFields),
      ...Object.keys(caseIncomingDocumentsFields),
      ...Object.keys(caseReviewingResultrsFields),
      ...Object.keys(caseCounterpartiesFields),
    ];

    const formFieldsTamplate = {
      ...reviewCaseOptionsFields,
      ...caseIncomingDocumentsFields,
      ...caseReviewingResultrsFields,
      ...caseCounterpartiesFields,
    };

    form.validateFields(fields, (err, values) => {
      if (!err) {
        const normilizedValue = getFormEntityData(values, classifiers, formFieldsTamplate);

        if (curMode === 'create') {
          postPrivatizationAssessmentReviewingCase(
            parseToBE({
              privatizationObject: this.state.selectedPrivatizationObject,
              ...normilizedValue,
            }),
          );
        }

        if (curMode === 'edit') {
          putPrivatizationAssessmentReviewingCase({
            ...formParam.createdForm,
            ...parseToBE(normilizedValue),
            privatizationObject: this.state.selectedPrivatizationObject,
            guid: this.curGuid,
          });
        }
      }
    });
  };

  render() {
    const { curMode, dialogMessage } = this.state;

    const { classifiers, form } = this.props;
    const dialogText = curMode === 'create' ? 'створено' : 'відредаговано';
    const isViewMode = curMode === 'view';

    const mapFormItemsForFields = (fields) =>
      mapFormItems({
        viewMode: curMode,
        fields,
        classifiers,
        isViewMode,
        form,
      });

    return (
      <Row>
        <Modal
          title="Реэстраційна картка справи з рецензування оцінки для приватизації"
          visible={this.state.dialogOpen}
          onOk={() => {
            this.handleCreateNew();
          }}
          onCancel={() => {
            this.handleDialogCancel();
          }}
          cancelText="Переглянути"
          okText="Створити нову"
        >
          {dialogMessage === '' ? (
            <p>{`Справу з рецензування оцінки для приватизації успішно ${dialogText}`}</p>
          ) : (
            <p>{`${dialogMessage}`}</p>
          )}
        </Modal>
        <Row>
          <Row type="flex" justify="center">
            <ButtonGroup>
              <Button onClick={() => (isViewMode ? this.switchToEditMode() : this.clearForm())}>
                <Icon type={isViewMode ? 'edit' : 'delete'} />
                {isViewMode ? 'Регадувати' : 'Очистити поля'}
              </Button>
              <Button
                onClick={() => {
                  this.goToRegister();
                }}
              >
                <Icon type="logout" />
                Перейти до реєстру
              </Button>
            </ButtonGroup>
          </Row>
          <Row>
            <Form>
              <Row>
                <Separator text="Параметри справи з рецензування" />
                {mapFormItemsForFields(reviewCaseOptionsFields)}
              </Row>
              <Row>
                <Separator text="Вхідні документи по справі" />
                {mapFormItemsForFields(caseIncomingDocumentsFields)}
              </Row>
              <Row>
                <Separator text="Результати рецензування по справі" />
                {mapFormItemsForFields(caseReviewingResultrsFields)}
              </Row>
              <Row>
                <Separator text="Контрагенти по справі" />
                {mapFormItemsForFields(caseCounterpartiesFields)}
              </Row>
              <Row>
                <Separator text="Об'єкт оцінки" />
                {mapFormItemsForFields(evaluationObjectFields)}
              </Row>
              <Row>
                <Separator text="Складові об'єкту оцінки" />
              </Row>
              <Row type="flex" justify="end">
                <Button
                  disabled={isViewMode}
                  style={{ marginRight: '1.5rem' }}
                  type="primary"
                  onClick={() => {
                    this.handleSubmit();
                  }}
                >
                  Зберегти
                </Button>
              </Row>
            </Form>
          </Row>
        </Row>
      </Row>
    );
  }
}

EvaluationFoPrivatizationFormContainer.propTypes = {
  loadClassifiersForContainer: PropTypes.func.isRequired,
  history: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
  match: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,

  postPrivatizationAssessmentReviewingCase: PropTypes.func.isRequired,
  putPrivatizationAssessmentReviewingCase: PropTypes.func.isRequired,
  getPrivatizationAssessmentReviewingCase: PropTypes.func.isRequired,

  getMarketValueDocument: PropTypes.func.isRequired,
  getPrivatisationObjects: PropTypes.func.isRequired,

  classifiers: PropTypes.objectOf(PropTypes.array).isRequired,
  resetPrivatizationAssessmentReviewingCaseForm: PropTypes.func.isRequired,
  resetPrivatizationAssessmentReviewingCaseDoneStatus: PropTypes.func.isRequired,
  formParam: PropTypes.objectOf(PropTypes.any).isRequired,

  form: PropTypes.objectOf(PropTypes.any).isRequired,
};

const mapStateToProps = (state) => ({
  classifiers: state.classifiers,
  formParam: state.evaluation.evaluationForPrivatization.form.default,
});

export default withRouter(
  connect(mapStateToProps, EVALUATION_FO_PRIVATIZATION_FORM_ACTIONS)(
    Form.create()(EvaluationFoPrivatizationFormContainer),
  ),
);
