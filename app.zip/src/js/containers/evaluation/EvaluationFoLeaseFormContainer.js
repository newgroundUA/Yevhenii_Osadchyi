import React from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import PropTypes from 'prop-types';
import _get from 'lodash/get';

import { Form, Modal, Button, Row, Icon } from 'antd';
import * as classifiersActions from '../../actions/classifiersActions';
import * as evaluationForLeaseActions from '../../actions/modules/evaluation/evaluationForLease';
import * as commonActions from '../../actions';

import * as RouteNames from '../../constants/RouteNames';
import { WEBSITELIST } from '../../constants/ClassifiersNames';

import { mapFormItems } from '../../helpers/formHelpers/mapFormHelper';

import {
  evaluationObjectFields,
  reviewCaseOptionsFields,
  caseIncomingDocumentsFields,
  caseReviewingResultrsFields,
  caseCounterpartiesFields,
  getParsedForm,
  getMappedForm,
} from '../../models/formFields/evaluation/evaluationFoLeaseFields';

import * as marketValueDocumentActions from '../../actions/modules/documents/marketValueDocumentActions';
import * as landlordToObjectActions from '../../actions/modules/lease/landlordToObjectActions';

import { EVALUATION_FO_LEASE_FORM_CONTAINER } from '../../constants/ContainerNames';

import Separator from '../../components/common/form/Separator';
import { getFormEntityData } from '../../helpers/formHelpers/formHelpers';

const EVALUATION_FO_LEASE_FORM_ACTIONS = {
  ...classifiersActions,
  ...evaluationForLeaseActions,
  ...commonActions,
  ...marketValueDocumentActions,
  ...landlordToObjectActions,
};
const ButtonGroup = Button.Group;

class EvaluationFoLeaseFormContainer extends React.Component {
  constructor(props) {
    super(props);

    const curMode = this.props.match.params.mode || 'create';
    this.curGuid = this.props.match.params.guid || '';

    this.state = {
      curMode,
      dialogOpen: false,
      dialogMessage: '',
      selectedLeaseObject: null,
    };

    this.loaded = false;
  }

  selectedDocForReviewingId = null;

  componentDidMount = () => {
    const { curMode } = this.state;

    this.props.loadClassifiersForContainer(EVALUATION_FO_LEASE_FORM_CONTAINER, {
      [WEBSITELIST]: {
        webSiteRegistryParam: {
          limit: '100',
          offset: '0',
        },
      },
    });

    if (curMode === 'view' || curMode === 'edit') {
      this.props.getlLeaseAssessmentReviewingCase(this.curGuid).then((res) => {
        this.selectedDocForReviewingId = res.data.docForReviewingGuid;
      });
    }
  };

  componentWillReceiveProps(nextProps) {
    const {
      formParam: { createdForm, status, errors },
      match: {
        params: { mode },
      },
      resetLeaseAssessmentReviewingCaseDoneStatus,
      form: { getFieldValue, setFieldsValue },
      getMarketValueDocument,
      getLeaseObjects,
    } = nextProps;

    if (this.state.curMode !== mode) this.setState({ curMode: mode });

    if (createdForm.guid && (mode === 'view' || mode === 'edit') && !this.loaded) {
      this.loaded = true;
      if (createdForm && createdForm.leaseObject) {
        this.selectedDocForReviewingId = createdForm.docForReviewing.guid;
        this.setState({
          selectedLeaseObject: {
            guid: createdForm.leaseObject.guid,
            versionId: createdForm.leaseObject.versionId,
          },
        });
      }
      setFieldsValue(getParsedForm(createdForm));
    }

    if (status.isDone) {
      this.loaded = true;
      this.curGuid = createdForm.guid;
      this.handleToggleDialog();
      resetLeaseAssessmentReviewingCaseDoneStatus();
    }

    if (errors.length > 0) {
      const errorsText = errors.map((el) => el.message).join(', ');
      this.setState({ dialogMessage: errorsText, dialogOpen: true });
      resetLeaseAssessmentReviewingCaseDoneStatus();
    }

    const newDocForReviewingValue = getFieldValue('docForReviewing');
    const newDocForReviewingId = newDocForReviewingValue ? newDocForReviewingValue.key : null;

    if (this.selectedDocForReviewingId !== newDocForReviewingId) {
      let assessObject;
      this.selectedDocForReviewingId = newDocForReviewingId;
      getMarketValueDocument(newDocForReviewingId).then((res) => {
        assessObject = res.data && res.data.assessObject;

        if (assessObject && assessObject.guid) {
          getLeaseObjects(assessObject.guid).then((leaseObjectServerResponce) => {
            const leaseObject = leaseObjectServerResponce.data;
            this.setState({
              selectedLeaseObject: {
                guid: assessObject.guid,
                versionId: assessObject.versionId,
              },
            });

            setFieldsValue({
              evaluationObjectNumber: leaseObject.leaseObjectNumber,
              evaluationObjectName: leaseObject.leaseObjectFullName,
              evaluationObjectAddress: _get(leaseObject, ['leaseObjectAddress', 'addressAsString']),
              evaluationObjectTotalSpace: leaseObject.leaseObjectTotalSpace,
              evaluationObjectUsefullSpace: leaseObject.leaseObjectUsefullSpace,
              evaluationObjectCommonUsesSpace: leaseObject.leaseObjectCommonUsesSpace,
              // evaluationObjectTotalAssessmentPrice: 0,
              // oneSqMeterUsdPrice: 0,
            });
          });
        }
      });
    }
  }

  handleCreateNew = () => {
    this.changeRouteTo(`/${RouteNames.EVALUATION}/${RouteNames.EVALUATION_FO_LEASE_FORM}/create`);
    this.curGuid = '';
    this.loaded = false;
    this.props.form.resetFields();
    this.props.resetLeaseAssessmentReviewingCaseForm();
    this.handleToggleDialog();
  };

  clearForm = () => {
    this.props.form.resetFields();
  };

  changeRouteTo = (route) => {
    this.props.history.push(route);
  };

  handleToggleDialog = (isOpened) => {
    if (isOpened !== undefined) this.setState({ dialogOpen: isOpened });
    else this.setState((prevState) => ({ dialogOpen: !prevState.dialogOpen }));
  };

  handleDialogCancel = () => {
    this.handleToggleDialog();
    this.switchToViewMode();
  };

  switchToEditMode = () => {
    this.changeRouteTo(
      `/${RouteNames.EVALUATION}/${RouteNames.EVALUATION_FO_LEASE_FORM}/edit/${this.curGuid}`,
    );
  };

  switchToViewMode = () => {
    this.changeRouteTo(
      `/${RouteNames.EVALUATION}/${RouteNames.EVALUATION_FO_LEASE_FORM}/view/${this.curGuid}`,
    );
  };

  handleSubmit = () => {
    const { curMode } = this.state;
    const {
      postLeaseAssessmentReviewingCase,
      putlLeaseAssessmentReviewingCase,
      classifiers,
      form,
      formParam,
    } = this.props;

    const fields = [
      ...Object.keys(evaluationObjectFields),
      ...Object.keys(reviewCaseOptionsFields),
      ...Object.keys(caseIncomingDocumentsFields),
      ...Object.keys(caseReviewingResultrsFields),
      ...Object.keys(caseCounterpartiesFields),
    ];

    const formFieldsTamplate = {
      ...evaluationObjectFields,
      ...reviewCaseOptionsFields,
      ...caseIncomingDocumentsFields,
      ...caseReviewingResultrsFields,
      ...caseCounterpartiesFields,
    };

    form.validateFields(fields, (err, values) => {
      if (!err) {
        const normilizedValue = getFormEntityData(values, classifiers, formFieldsTamplate);

        if (curMode === 'create') {
          postLeaseAssessmentReviewingCase(
            getMappedForm({
              leaseObject: this.state.selectedLeaseObject,
              ...normilizedValue,
            }),
          );
        }

        if (curMode === 'edit') {
          putlLeaseAssessmentReviewingCase({
            ...formParam.createdForm,
            ...getMappedForm(normilizedValue),
            leaseObject: this.state.selectedLeaseObject,
            guid: this.curGuid,
          });
        }
      }
    });
  };

  goToRegister = () => {
    const { history } = this.props;

    history.push(`/${RouteNames.EVALUATION}/${RouteNames.REGISTER}`);
  };

  render() {
    const { curMode, dialogMessage } = this.state;

    const { classifiers, form } = this.props;
    const dialogText = curMode === 'create' ? 'створено' : 'відредаговано';
    const isViewMode = curMode === 'view';

    const mapFormItemsForFields = (fields) =>
      mapFormItems({
        viewMode: curMode,
        fields,
        classifiers,
        isViewMode,
        form,
      });

    return (
      <Row>
        <Modal
          title="Реєстраційна картка справи з рецензування оцінки для оренди"
          visible={this.state.dialogOpen}
          onOk={this.handleCreateNew}
          onCancel={this.handleDialogCancel}
          cancelText="Переглянути документ"
          okText="Створити новий"
        >
          {dialogMessage === '' ? (
            <p>{`Справу з рецензування оцінки для оренди успішно ${dialogText}`}</p>
          ) : (
            <p>{`${dialogMessage}`}</p>
          )}
        </Modal>
        <Row>
          <Row type="flex" justify="center">
            <ButtonGroup>
              <Button onClick={() => (isViewMode ? this.switchToEditMode() : this.clearForm())}>
                <Icon type={isViewMode ? 'edit' : 'delete'} />
                {isViewMode ? 'Регадувати' : 'Очистити поля'}
              </Button>
              <Button onClick={this.goToRegister}>
                <Icon type="logout" />
                Перейти до реєстру
              </Button>
            </ButtonGroup>
          </Row>
          <Row>
            <Form>
              <Row>
                <Separator text="Параметри справи з рецензування" />
                {mapFormItemsForFields(reviewCaseOptionsFields)}
              </Row>
              <Row>
                <Separator text="Вхідні документи по справі" />
                {mapFormItemsForFields(caseIncomingDocumentsFields)}
              </Row>
              <Row>
                <Separator text="Результати рецензування по справі" />
                {mapFormItemsForFields(caseReviewingResultrsFields)}
              </Row>
              <Row>
                <Separator text="Контрагенти по справі" />
                {mapFormItemsForFields(caseCounterpartiesFields)}
              </Row>
              <Row>
                <Separator text="Об'єкт оцінки" />
                {mapFormItemsForFields(evaluationObjectFields)}
              </Row>
              <Row>
                <Separator text="Складові об'єкту оцінки" />
              </Row>
              <Row type="flex" justify="end">
                <Button
                  disabled={isViewMode}
                  style={{ marginRight: '1.5rem' }}
                  type="primary"
                  onClick={() => {
                    this.handleSubmit();
                  }}
                >
                  Зберегти
                </Button>
              </Row>
            </Form>
          </Row>
        </Row>
      </Row>
    );
  }
}

EvaluationFoLeaseFormContainer.propTypes = {
  loadClassifiersForContainer: PropTypes.func.isRequired,
  history: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
  match: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,

  postLeaseAssessmentReviewingCase: PropTypes.func.isRequired,
  putlLeaseAssessmentReviewingCase: PropTypes.func.isRequired,
  getlLeaseAssessmentReviewingCase: PropTypes.func.isRequired,

  getMarketValueDocument: PropTypes.func.isRequired,
  getLeaseObjects: PropTypes.func.isRequired,
  classifiers: PropTypes.objectOf(PropTypes.array).isRequired,

  resetLeaseAssessmentReviewingCaseForm: PropTypes.func.isRequired,
  resetLeaseAssessmentReviewingCaseDoneStatus: PropTypes.func.isRequired,
  formParam: PropTypes.objectOf(PropTypes.any).isRequired,

  form: PropTypes.objectOf(PropTypes.any).isRequired,
};

const mapStateToProps = (state) => ({
  classifiers: state.classifiers,
  formParam: state.evaluation.evaluationForLease.form.default,
});

export default withRouter(
  connect(mapStateToProps, EVALUATION_FO_LEASE_FORM_ACTIONS)(
    Form.create()(EvaluationFoLeaseFormContainer),
  ),
);
