import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';

import * as classifiersActions from '../../actions/classifiersActions';

// import {
//   ApplicationForEvaluationFields,
//   ObjectEvaluationFields,
//   EvaluationProcessFields
// } from '../../models/formFields/evaluationFields';

import { CREATE_EVALUATION_CONTAINER } from '../../constants/ContainerNames';

const CONTAINER_ACTIONS = {
  ...classifiersActions,
};

class CreateEvaluationContainer extends Component {
  constructor(props) {
    super(props);

    this.state = { ...this.initialState };
  }

  componentDidMount() {
    this.props.loadClassifiersForContainer(CREATE_EVALUATION_CONTAINER);
  }

  render() {
    return <div />;
  }
}

CreateEvaluationContainer.propTypes = {
  // classifiers: PropTypes.objectOf(PropTypes.array).isRequired,
  loadClassifiersForContainer: PropTypes.func.isRequired,
};

const mapStateToProps = (state) => ({
  classifiers: state.classifiers,
});

export default withRouter(connect(mapStateToProps, CONTAINER_ACTIONS)(CreateEvaluationContainer));
