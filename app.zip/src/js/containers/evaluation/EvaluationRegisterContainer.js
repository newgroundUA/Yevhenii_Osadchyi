import React, { PureComponent } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';

import { withRouter, Link } from 'react-router-dom';
import { Button, Modal, List } from 'antd';

import wrapRegister from '../HOCs/wrapRegister';
import { evaluationRegisterSelector } from '../../selectors';

import * as appActions from '../../actions/appActions';
import * as commonActions from '../../actions';
import * as evaluationActions from '../../actions/modules/evaluation/evaluationActions';
import * as usersActions from '../../actions/usersActions';
import TableToolbar from '../../components/common/toolbar/TableToolbar';
import * as RouteNames from '../../constants/RouteNames';

const ButtonGroup = Button.Group;

const CONTAINER_ACTIONS = {
  ...appActions,
  ...commonActions,
  ...evaluationActions,
  ...usersActions,
};

const newDocFormTypes = {
  Document: RouteNames.DOCUMENT_GENERAL,
  PersonPassport: RouteNames.DOCUMENT_PASSPORT,
  ApplicationToLease: RouteNames.DOCUMENT_RENT_STATEMENT,
  CompetitionProtocol: RouteNames.DOCUMENT_CONTESTS,
  DocJudicialDecision: RouteNames.DOCUMENT_JUDICIAL_DECISION,
  DocAppeals: RouteNames.DOCUMENT_APPEALS,
  AccountItemReceiptAct: RouteNames.DOCUMENT_BALANCE,
  LeaseContract: RouteNames.DOCUMENT_TYPICAL_CONTRACT,
  MarketPriceDetect: RouteNames.DOCUMENT_MARKET,
  BankStatement: RouteNames.DOCUMENT_BANK_STATEMENT,
};

const formsUrlData = [
  {
    formType: RouteNames.EVALUATION_FO_LEASE_FORM,
    formLabel: 'Картка на оцінку для оренди',
  },
  {
    formType: RouteNames.EVALUATION_FO_PRIVATIZATION_FORM,
    formLabel: 'Картка на оцінку для приватизації',
  },
];

class EvaluationRegisterContainer extends PureComponent {
  constructor(props) {
    super(props);

    this.state = {
      showDocumentsClassifierForm: false,
    };
  }

  handleCreateNewDocumentCanceled = () => {
    this.setState({
      showDocumentsClassifierForm: false,
    });
  };

  handleCreateDocumentClick = () => {
    this.setState({
      showDocumentsClassifierForm: true,
    });
  };

  handleCloseModal = (choiceIsDone, typeOfNewDoc) => {
    this.setState({
      showDocumentsClassifierForm: false,
    });
    const formType = newDocFormTypes[typeOfNewDoc || RouteNames.DOCUMENT_GENERAL];
    if (choiceIsDone) {
      this.props.history.push(`/${RouteNames.DOCUMENTS}/${formType}/${RouteNames.CREATE}`);
    }
  };

  render() {
    const { sortedColumns, tableToolbar } = this.props;

    // const filters = () => {};

    return (
      <div className="content__table-items">
        <Modal
          title="Створення нового документа"
          visible={this.state.showDocumentsClassifierForm}
          onCancel={this.handleCreateNewDocumentCanceled}
          footer={false}
        >
          <List
            bordered
            dataSource={formsUrlData}
            renderItem={(item) => (
              <List.Item>
                <Link to={`/${RouteNames.EVALUATION}/${item.formType}/${RouteNames.CREATE}`}>
                  {item.formLabel}
                </Link>
              </List.Item>
            )}
          />
        </Modal>
        <div className="content__table-menu">
          <TableToolbar
            items={tableToolbar}
            columnsForFilter={[]}
            setValueRequestBody={this.props.setValueRequestBody}
            handleToggleToolbarItem={this.props.handleToggleToolbarItem}
            isActive={false}
            columns={sortedColumns}
            handleChangeColumns={this.props.handleChangeColumns}
            handleClickToolbarItem={() => {}}
          >
            <ButtonGroup>
              <Button type="primary" size="large" onClick={this.handleCreateDocumentClick}>
                + Картка
              </Button>
            </ButtonGroup>
          </TableToolbar>
        </div>

        {/* <div className="content__fast-filters">
          <FastFiltersPanel
            useAll={this.props.handleSubmitFilters}
            cancelAll={this.props.handleCancelFilters}
            filters={filters}
          >
            <div className="table-menu__icon">
              <Icon type="filter" />
            </div>
            <Select
              mode="multiple"
              style={{ minWidth: 200 }}
              allowClear
              placeholder="Швидкий фільтр"
            />
          </FastFiltersPanel>
        </div> */}
      </div>
    );
  }
}

EvaluationRegisterContainer.propTypes = {
  history: PropTypes.shape({
    push: PropTypes.func.isRequired,
  }).isRequired,
  tableToolbar: PropTypes.objectOf(PropTypes.any).isRequired,
  sortedColumns: PropTypes.shape({
    fixed: PropTypes.object,
    fluid: PropTypes.object,
  }).isRequired,
  setValueRequestBody: PropTypes.func.isRequired,

  handleChangeColumns: PropTypes.func.isRequired,
  handleToggleToolbarItem: PropTypes.func.isRequired,
  // handleSubmitFilters: PropTypes.func.isRequired,
  // handleCancelFilters: PropTypes.func.isRequired,
};

export default withRouter(
  connect(evaluationRegisterSelector, CONTAINER_ACTIONS)(
    wrapRegister(EvaluationRegisterContainer, 'evaluation', 'getEvaluationRegister'),
  ),
);
