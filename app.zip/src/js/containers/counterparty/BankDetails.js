import React, { Component } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { Row, Table, Button, Icon } from 'antd';

import selectors from '../../selectors/modules/bankDetailsSelector';
import * as commonCounterpartiesActions from '../../actions/modules/counterparties/commonActions';
import BankDetailsForm from '../../components/counterparties/BankDetailsForm';
import { bankDetailsFields } from '../../models/formFields/counterparty/bankDetailsFields';

const CONTAINER_ACTIONS = {
  ...commonCounterpartiesActions,
};

class BankDetails extends Component {
  state = {
    collapsed: false,
    bankDetail: {},
  };

  componentDidMount() {
    this.loadBankDetails();
  }

  loadBankDetails = () => {
    const {
      getBankDetails,
      accountOwner: { guid },
    } = this.props;
    getBankDetails(guid);
  };

  onSaveForm = () => {
    this.hideForm();
    this.loadBankDetails();
  };

  hideForm = () => this.setState({ bankDetail: {}, collapsed: false });

  showForm = () => this.setState({ collapsed: true });

  editBankDetail = (bankDetail) => () => this.setState({ bankDetail, collapsed: true });

  getColumn = () => {
    bankDetailsFields.action.render = (cell) => (
      <Button disabled={this.props.isViewMode} onClick={this.editBankDetail(cell.beFields)}>
        <Icon type="edit" />
      </Button>
    );

    return Object.values(bankDetailsFields);
  };

  render() {
    const { bankDetailsTableList, accountOwner, isViewMode } = this.props;

    const { collapsed, bankDetail } = this.state;
    return (
      <Row>
        {!collapsed && (
          <Button
            type="primary"
            disabled={isViewMode}
            onClick={this.showForm}
            style={{ margin: '0 0 15px 15px' }}
          >
            Додати реквізити
          </Button>
        )}

        {collapsed && (
          <BankDetailsForm
            accountOwner={accountOwner}
            onSave={this.onSaveForm}
            onCancel={this.hideForm}
            bankDetail={bankDetail}
          />
        )}

        <Table dataSource={bankDetailsTableList} columns={this.getColumn()} rowKey="guid" />
      </Row>
    );
  }
}
BankDetails.defaultProps = {
  isViewMode: false,
};

BankDetails.propTypes = {
  getBankDetails: PropTypes.func.isRequired,
  isViewMode: PropTypes.bool,
  accountOwner: PropTypes.objectOf(PropTypes.any).isRequired,
  bankDetailsTableList: PropTypes.arrayOf(PropTypes.object).isRequired,
};

export default connect(selectors, CONTAINER_ACTIONS)(BankDetails);
