import React from 'react';
import PropTypes from 'prop-types';

import { Row, Col, Tree } from 'antd';

import DivisionTables from './tables/DivisionTablesContainer';
import EmployeeTables from './tables/EmployeeTablesContainer';
import OrganizationTables from './tables/OrganizationTablesContainer';
import PositionTables from './tables/PositionTablesContainer';
import { getPersonString } from '../../../helpers/entities/countrerparty';

const TreeNode = Tree.TreeNode;

const types = {
  ORGANIZATION: 'ORGANIZATION',
  DIVISION: 'DIVISION',
  EMPLOYEE: 'EMPLOYEE',
  POSITION: 'POSITION',
};

class CounterpartyStructureContainer extends React.Component {
  constructor(props) {
    super(props);

    const { form } = this.props;
    this.objects = this.normalizeData(form);

    this.state = {
      expandedKeys: [],
      selectedKeys: [this.props.form.guid],
      autoExpandParent: false,
    };
  }

  objects = {};

  componentWillReceiveProps(nextProps) {
    const form = nextProps.form;

    if (form.departments !== undefined) {
      this.objects = this.normalizeData(form);
    }
  }

  normalizeData = (data) => {
    const objects = {};
    const { departments } = data;

    const positions = [];
    const employees = [];

    let titleName = '';
    if (data.counterpartyType === 'SelfEmployed') {
      const person = data.personDto;
      titleName = getPersonString(person); // TODO: BE must change fistName to firstName
    }

    if (data.counterpartyType === 'LegalEntity') {
      titleName = data.fullName;
    }

    objects[data.guid] = {
      ...data,
      type: types.ORGANIZATION,
      title: titleName,
      children: (departments || []).map((item) => item.guid),
    };

    const mapDepartments = (level) => {
      (level || []).forEach((el) => {
        if (el.subDivisions && el.subDivisions.length > 0) {
          mapDepartments(el.subDivisions); // recursion here
        }

        positions.push(...(el.positions || []));

        const curChildren = [
          ...(el.positions || []).map((item) => item.guid),
          ...(el.subDivisions || []).map((item) => item.guid),
        ];

        objects[el.guid] = {
          ...el,
          type: types.DIVISION,
          title: el.name,
          parent:
            (el.counterpartyOwner && el.counterpartyOwner.guid) ||
            (el.departmentParent && el.departmentParent.guid) ||
            undefined,
          children: curChildren,
        };
      });
    };

    mapDepartments(departments);

    positions.forEach((el) => {
      employees.push(...(el.employees || []));
      const curChildren = (el.employees || []).map((item) => item.guid);
      objects[el.guid] = {
        ...el,
        type: types.POSITION,
        title: el.positionName,
        parent: el.department ? el.department.guid : undefined,
        children: curChildren,
      };
    });

    employees.forEach((el) => {
      objects[el.guid] = {
        ...el,
        type: types.EMPLOYEE,
        title: getPersonString(el.person),
        parent: el.position && el.position.guid,
        children: [],
      };
    });

    return objects;
  };

  getTree = (parentGuid) => {
    const curEl = this.objects[parentGuid];
    if (!curEl) return false;
    return (
      <TreeNode key={curEl.guid} title={curEl.title}>
        {curEl.children &&
          curEl.children.length > 0 &&
          curEl.children.map((children) => this.getTree(children))}
      </TreeNode>
    );
  };

  onExpand = (expandedKeys) => {
    this.setState({
      expandedKeys,
      autoExpandParent: false,
    });
  };

  onSelect = (selectedKeys) => {
    this.setState({
      selectedKeys,
    });
  };

  getTablePart = (item) => {
    const parentOrganization = this.props.form;
    const curProps = {
      updateParent: this.props.updateParent,
      data: this.objects,
      curMode: this.props.curMode,
      item,
    };

    if (!item) {
      // this.props.updateParent();
      return false;
    }

    if (item.type === types.ORGANIZATION) {
      return <OrganizationTables {...curProps} parentOrganization={parentOrganization} />;
    }
    if (item.type === types.DIVISION) {
      return <DivisionTables {...curProps} parentOrganization={parentOrganization} />;
    }
    if (item.type === types.POSITION) {
      return <PositionTables {...curProps} parentOrganization={parentOrganization} />;
    }
    if (item.type === types.EMPLOYEE) {
      return <EmployeeTables {...curProps} parentOrganization={parentOrganization} />;
    }
  };

  render() {
    const { expandedKeys, selectedKeys, autoExpandParent } = this.state;

    const treeData = this.getTree(this.props.form.guid);
    const selectedElement = selectedKeys.length > 0 && this.objects[selectedKeys[0]];

    const tablePart = this.getTablePart(selectedElement);

    return (
      <Row>
        <Col span={9}>
          <Row />
          <Row>
            {treeData && (
              <Tree
                expandedKeys={expandedKeys}
                autoExpandParent={autoExpandParent}
                onExpand={this.onExpand}
                onSelect={this.onSelect}
              >
                {treeData}
              </Tree>
            )}
          </Row>
        </Col>
        <Col span={15}>{tablePart}</Col>
      </Row>
    );
  }
}

CounterpartyStructureContainer.propTypes = {
  updateParent: PropTypes.func.isRequired,
  curMode: PropTypes.string.isRequired,
  form: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default CounterpartyStructureContainer;
