import React from 'react';

import { connect } from 'react-redux';
import PropTypes from 'prop-types';

import { Form, Button, Row } from 'antd';

import * as classifiersActions from '../../../actions/classifiersActions';
import * as counterpartiesStructureActions from '../../../actions/modules/counterparties/structureActions';
import * as commonActions from '../../../actions/index';

import {
  fields,
  getMappedForm,
  getParsedForm,
} from '../../../models/formFields/counterparty/positionFields';

import { mapFormItems } from '../../../helpers/formHelpers/mapFormHelper';
import { POSITION_CONTAINER } from '../../../constants/ContainerNames';
import { getFormEntityData } from '../../../helpers/formHelpers/formHelpers';

class PositionContainer extends React.Component {
  constructor(props) {
    super(props);

    const curMode = this.props.match.params.mode || 'create';
    this.curGuid = this.props.match.params.guid || '';

    this.state = {
      curMode,
      // dialogOpen: false,
      // dialogMessage: '',
    };
  }

  componentDidMount() {
    const { getPosition } = this.props;
    const { curMode } = this.state;

    const department = this.props.parentDepartment;
    const departmentName = department ? department.name : undefined;

    this.props.form.setFieldsValue({ parentdep: departmentName });

    this.props.loadClassifiersForContainer(POSITION_CONTAINER);

    if (curMode === 'view' || curMode === 'edit') {
      getPosition(this.curGuid);
    }
  }

  componentWillReceiveProps(nextProps) {
    const {
      formParam: { createdForm, status, errors },
      match: {
        params: { mode },
      },
      resetPositions,
      resetPositionsDoneStatus,
      form,
    } = nextProps;

    if (this.state.curMode !== mode) this.setState({ curMode: mode });

    if (createdForm.guid && (mode === 'view' || mode === 'edit') && !this.loaded) {
      this.loaded = true;
      form.setFieldsValue(getParsedForm(createdForm));
    }

    if (status.isDone) {
      this.loaded = true;
      this.curGuid = createdForm.guid;
      // this.handleToggleDialog();
      this.props.onCreatedCB();
      resetPositionsDoneStatus();
    }

    if (errors.length > 0) {
      // const errorsText = errors.map((el) => el.message).join(', ');
      // this.setState({ dialogMessage: errorsText, dialogOpen: true });
      resetPositions();
    }
  }

  componentWillUnmount() {
    this.props.resetPositions();
  }

  handleSubmit = () => {
    const { curMode } = this.state;
    const {
      formParam: { createdForm },
      putPosition,
      postPosition,
      classifiers,
      form,
    } = this.props;

    const curFields = Object.keys(fields);

    form.validateFields(curFields, (err, values) => {
      if (!err) {
        const normilizedValue = getFormEntityData(values, classifiers, fields);

        if (curMode === 'create') {
          postPosition({
            ...getMappedForm(normilizedValue),
            department: this.props.parentDepartment
              ? {
                  guid: this.props.parentDepartment.guid,
                  versionId: this.props.parentDepartment.versionId,
                }
              : undefined,
          });
        }

        if (curMode === 'edit') {
          putPosition({
            ...createdForm,
            ...getMappedForm(normilizedValue),
          });
        }
      }
    });
  };

  render() {
    const { classifiers } = this.props;
    const { curMode } = this.state;

    const isViewMode = curMode === 'view';

    return (
      <Row>
        {mapFormItems({
          viewMode: curMode,
          fields,
          classifiers,
          isViewMode,
          form: this.props.form,
        })}
        <Row type="flex" justify="end">
          <Button
            style={{ marginRight: '1.5rem' }}
            type="primary"
            onClick={this.handleSubmit}
            disabled={isViewMode}
          >
            {`Відправити`}
          </Button>
        </Row>
      </Row>
    );
  }
}

PositionContainer.propTypes = {
  match: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
  onCreatedCB: PropTypes.func.isRequired,
  parentDepartment: PropTypes.objectOf(PropTypes.any).isRequired,

  postPosition: PropTypes.func.isRequired,
  putPosition: PropTypes.func.isRequired,
  getPosition: PropTypes.func.isRequired,
  resetPositions: PropTypes.func.isRequired,
  resetPositionsDoneStatus: PropTypes.func.isRequired,

  loadClassifiersForContainer: PropTypes.func.isRequired,
  classifiers: PropTypes.objectOf(PropTypes.array).isRequired,
  formParam: PropTypes.objectOf(PropTypes.any).isRequired,

  form: PropTypes.objectOf(PropTypes.any).isRequired,
};

const mapStateToProps = (state) => ({
  formParam: state.counterparties.modals.rootCounterpartyContainer.forms.positionsForm,
  classifiers: state.classifiers,
});

export default connect(mapStateToProps, {
  ...classifiersActions,
  ...counterpartiesStructureActions,
  ...commonActions,
})(Form.create()(PositionContainer));
