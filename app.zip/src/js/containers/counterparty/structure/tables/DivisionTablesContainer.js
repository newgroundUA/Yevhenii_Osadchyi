import React from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { Button, Table, Row, Modal } from 'antd';

import {
  divisionParent as parentColumns,
  positionChildren as childrenColumns,
  divisionChildren as additionalColumns,
} from '../../../../models/formFields/counterparty/counterpartyTables';

import * as counterpartiesStructureActions from '../../../../actions/modules/counterparties/structureActions';
import ChildrenContainer from '../PositionContainer';
import AdditionalContainer from '../DivisionContainer';
import { getStr } from '../../../../helpers/geters';

class DivisionTables extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      dialogOpen: false,
      positions: false,
      divisions: false,
      positionEdit: false,
    };
  }

  componentDidMount() {
    this.props.getDepartmentsView(this.props.item.guid, this.props.parentOrganization.guid);
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.item !== nextProps.item) {
      this.props.getDepartmentsView(nextProps.item.guid, this.props.parentOrganization.guid);
    }
  }

  componentWillUnmount() {
    this.props.resetDepartmentsView();
  }

  handleToggleDialog = (isOpened) => {
    if (isOpened !== undefined) this.setState({ dialogOpen: isOpened });
    else this.setState((prevState) => ({ dialogOpen: !prevState.dialogOpen }));
  };

  onChildrenCreated = () => {
    this.handleToggleDialog(false);
    this.props.updateParent();
    this.props.getDepartmentsView(this.props.item.guid, this.props.parentOrganization.guid);
  };

  handleOpenForm = (formName) => {
    this.setState({
      positions: formName === 'positions',
      divisions: formName === 'divisions',
      positionEdit: formName === 'positionEdit',
    });
    this.handleToggleDialog();
  };

  render() {
    const parent = this.props.item;

    const viewItem = this.props.departmentsView;

    if (!viewItem) return false;

    const dataSourceParent = [
      {
        key: viewItem.guid,
        name: viewItem.fullName,
        shortName: viewItem.shortName,
        divisionType: (viewItem.type || {}).name,
        parentDepartment: viewItem.parentDepartmentName,
        phones: (viewItem.phones || []).map((el) => el.phoneNumber).join(', '),
        addresses: '',
        notes: viewItem.notes,
      },
    ];

    const dataSourceChildren = (viewItem.persons || []).map((child) => ({
      key: child.guid,
      positionType: child.positionType ? child.positionType.name : '',
      fullName: child.positionFullName,
      shortName: child.positionShortName,
      personName: `${getStr(child.personFirstName)} ${getStr(child.personMiddleName)} ${getStr(
        child.personLastName,
      )}`,
      phones: (child.phones || []).map((el) => el.phoneNumber).join(', '),
      email: (child.emails || []).map((el) => el.emailName).join(', '),
      eis: child.eisMember !== null && (child.eisMember === false ? 'Так' : 'Ні'),
      // eisRoles: '',
    }));

    const dataSourceAdditional = (viewItem.childDepartments || []).map((child) => ({
      key: child.guid,
      name: child.fullName,
      shortName: child.shortName,
      divisionType: (child.type || {}).name,
      parentDepartment: child.parentDepartmentName,
      phones: (child.phones || []).map((el) => el.phoneNumber).join(', '),
      addresses: '',
      notes: child.notes,
    }));

    const isViewMode = this.props.curMode === 'view';

    return (
      <Row>
        <Modal
          title="Картка "
          visible={this.state.dialogOpen}
          width={1300}
          footer={false}
          onCancel={() => {
            this.handleToggleDialog(false);
          }}
        >
          <Row>
            {this.state.dialogOpen && (
              <Row>
                {this.state.positionEdit ? (
                  <AdditionalContainer // divisions
                    parentOrganization={this.props.parentOrganization}
                    parentDepartment={parent}
                    match={{ params: { mode: 'edit', guid: parent.guid } }}
                    onCreatedCB={this.onChildrenCreated}
                    visible={this.state.dialogOpen}
                    inModal
                  />
                ) : (
                  false
                )}
                {this.state.positions ? (
                  <ChildrenContainer // positions
                    parentOrganization={this.props.parentOrganization}
                    parentDepartment={parent}
                    match={{ params: { mode: 'create' } }}
                    onCreatedCB={this.onChildrenCreated}
                    visible={this.state.dialogOpen}
                    inModal
                  />
                ) : (
                  false
                )}
                {this.state.divisions ? (
                  <AdditionalContainer // divisions
                    parentOrganization={this.props.parentOrganization}
                    parentDepartment={parent}
                    match={{ params: { mode: 'create' } }}
                    onCreatedCB={this.onChildrenCreated}
                    visible={this.state.dialogOpen}
                    inModal
                  />
                ) : (
                  false
                )}
              </Row>
            )}
          </Row>
        </Modal>
        <Row style={{ marginBottom: '1rem' }}>
          <Button
            onClick={() => {
              this.handleOpenForm('positionEdit');
            }}
            disabled={isViewMode}
          >
            Редагувати підрозділ
          </Button>
          <Button
            onClick={() => {
              this.handleOpenForm('divisions');
            }}
            disabled={isViewMode}
          >
            Додати підрозділ
          </Button>
          <Button
            onClick={() => {
              this.handleOpenForm('positions');
            }}
            disabled={isViewMode}
          >
            Додати посаду
          </Button>
        </Row>
        <Row>Параметри підрозділу:</Row>
        <Row style={{ marginBottom: '1rem' }}>
          <Table
            dataSource={dataSourceParent}
            columns={parentColumns}
            pagination={false}
            bordered
          />
        </Row>
        <Row>Підпорядковані підрозділи:</Row>
        <Row>
          <Table
            dataSource={dataSourceAdditional}
            columns={additionalColumns}
            pagination={false}
            bordered
          />
        </Row>
        <Row>Особи на посадах:</Row>
        <Row>
          <Table
            dataSource={dataSourceChildren}
            columns={childrenColumns}
            pagination={false}
            bordered
          />
        </Row>
      </Row>
    );
  }
}

DivisionTables.defaultProps = {
  departmentsView: {},
};

DivisionTables.propTypes = {
  updateParent: PropTypes.func.isRequired,
  parentOrganization: PropTypes.objectOf(PropTypes.any).isRequired,
  item: PropTypes.objectOf(PropTypes.any).isRequired,

  curMode: PropTypes.string.isRequired,
  departmentsView: PropTypes.objectOf(PropTypes.any),
  getDepartmentsView: PropTypes.func.isRequired,
  resetDepartmentsView: PropTypes.func.isRequired,
};

const mapStateToProps = (state) => ({
  departmentsView: state.counterparties.structureView.departmentView,
});

export default connect(mapStateToProps, counterpartiesStructureActions)(DivisionTables);
