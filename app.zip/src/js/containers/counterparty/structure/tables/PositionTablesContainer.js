import React from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { Button, Table, Row, Modal } from 'antd';

import {
  positionParent as parentColumns,
  employeeChildren as childrenColumns,
} from '../../../../models/formFields/counterparty/counterpartyTables';

import * as counterpartiesStructureActions from '../../../../actions/modules/counterparties/structureActions';
import ChildrenContainer from '../EmployeeContainer';
import PositionContainer from '../PositionContainer';

class PositionTables extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      dialogOpen: false,
      employee: false,
      positionEdit: false,
    };
  }

  componentDidMount() {
    this.props.getPositionsView(this.props.item.department.guid, this.props.item.guid);
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.item !== nextProps.item) {
      this.props.getPositionsView(nextProps.item.department.guid, nextProps.item.guid);
    }
  }

  componentWillUnmount() {
    this.props.resetPositionsView();
  }

  handleToggleDialog = (isOpened) => {
    if (isOpened !== undefined) this.setState({ dialogOpen: isOpened });
    else this.setState((prevState) => ({ dialogOpen: !prevState.dialogOpen }));
  };

  onChildrenCreated = () => {
    this.handleToggleDialog(false);
    this.props.updateParent();
  };

  handleOpenForm = (formName) => {
    this.setState({
      employee: formName === 'employee',
      positionEdit: formName === 'positionEdit',
    });
    this.handleToggleDialog();
  };

  render() {
    const parent = this.props.item;
    const parentDepartment = this.props.data[parent.parent];

    const position = this.props.positionView;
    if (!position) return false;

    const dataSourceParent = [
      {
        key: position.guid,
        positionType: position.positionType ? position.positionType.name : '',
        fullName: position.positionFullName,
        shortName: position.positionShortName,
        departmentFullName: position.departmentFullName,
        departmentShortName: position.departmentShortName,
      },
    ];

    const dataSourceChildren = (position.employee || []).map((child) => ({
      key: child.guid,
      name: `${child.personFirstName} ${child.personMiddleName} ${child.personLastName}`,
      phones: (child.phones || []).map((el) => el.phoneNumber).join(', '),
      email: (child.emails || []).map((el) => el.emailName).join(', '),
      eis: child.eisMember !== null && (child.eisMember === false ? 'Так' : 'Ні'),
      eisRoles: '',
    }));

    const isViewMode = this.props.curMode === 'view';

    return (
      <Row>
        <Modal
          title="Картка "
          visible={this.state.dialogOpen}
          width={1300}
          footer={false}
          onCancel={() => {
            this.handleToggleDialog(false);
          }}
        >
          <Row>
            {this.state.dialogOpen && (
              <Row>
                {this.state.employee ? (
                  <ChildrenContainer
                    parentPosition={parent}
                    match={{ params: { mode: 'create' } }}
                    onCreatedCB={this.onChildrenCreated}
                    visible={this.state.dialogOpen}
                    inModal
                  />
                ) : (
                  false
                )}
                {this.state.positionEdit ? (
                  <PositionContainer // positions
                    parentOrganization={this.props.parentOrganization}
                    parentDepartment={parentDepartment}
                    match={{ params: { mode: 'edit', guid: parent.guid } }}
                    onCreatedCB={this.onChildrenCreated}
                    visible={this.state.dialogOpen}
                    inModal
                  />
                ) : (
                  false
                )}
              </Row>
            )}
          </Row>
        </Modal>
        <Row style={{ marginBottom: '1rem' }}>
          <Button
            onClick={() => {
              this.handleOpenForm('positionEdit');
            }}
            disabled={isViewMode}
          >
            Редагувати позицію
          </Button>
          <Button
            onClick={() => {
              this.handleOpenForm('employee');
            }}
            disabled={isViewMode}
          >
            Додати працівника
          </Button>
        </Row>
        <Row>Параметри позиції:</Row>
        <Row style={{ marginBottom: '1rem' }}>
          <Table
            dataSource={dataSourceParent}
            columns={parentColumns}
            pagination={false}
            bordered
          />
        </Row>
        <Row>Працівники:</Row>
        <Row>
          <Table
            dataSource={dataSourceChildren}
            columns={childrenColumns}
            pagination={false}
            bordered
          />
        </Row>
      </Row>
    );
  }
}

PositionTables.defaultProps = {
  positionView: {},
};

PositionTables.propTypes = {
  updateParent: PropTypes.func.isRequired,
  parentOrganization: PropTypes.objectOf(PropTypes.any).isRequired,
  item: PropTypes.objectOf(PropTypes.any).isRequired,
  data: PropTypes.objectOf(PropTypes.any).isRequired,

  curMode: PropTypes.string.isRequired,
  positionView: PropTypes.objectOf(PropTypes.any),
  getPositionsView: PropTypes.func.isRequired,
  resetPositionsView: PropTypes.func.isRequired,
};

const mapStateToProps = (state) => ({
  positionView: state.counterparties.structureView.positionView,
});

export default connect(mapStateToProps, counterpartiesStructureActions)(PositionTables);
