import React from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import {
  // Button,
  Table,
  Row,
  Modal,
  Button,
} from 'antd';

import { employeeParent as parentColumns } from '../../../../models/formFields/counterparty/counterpartyTables';

import * as counterpartiesStructrueActions from '../../../../actions/modules/counterparties/structureActions';
import ChildrenContainer from '../EmployeeContainer';

class DivisionTables extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      dialogOpen: false,
      employeeEdit: false,
    };
  }

  componentDidMount() {
    this.props.getEmployeesView(
      this.props.item.parent,
      this.props.item.position.guid,
      this.props.item.person.guid,
    );
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.item !== nextProps.item) {
      this.props.getEmployeesView(
        nextProps.item.parent,
        nextProps.item.position.guid,
        nextProps.item.person.guid,
      );
    }
  }

  componentWillUnmount() {
    this.props.resetEmployeesView();
  }

  handleToggleDialog = (isOpened) => {
    if (isOpened !== undefined) this.setState({ dialogOpen: isOpened });
    else this.setState((prevState) => ({ dialogOpen: !prevState.dialogOpen }));
  };

  onChildrenCreated = () => {
    this.handleToggleDialog(false);
    this.props.updateParent();
  };

  handleOpenForm = (formName) => {
    this.setState({
      employeeEdit: formName === 'employeeEdit',
    });
    this.handleToggleDialog();
  };

  render() {
    const parent = this.props.item;
    const parentPosition = this.props.data[parent.parent];

    const employee = this.props.employeeView;
    if (!employee) return false;

    const dataSourceParent = [
      {
        key: employee.guid,
        departmentFullName: employee.departmentFullName,
        positionType: employee.positionType ? employee.positionType.name : '',
        positionFullName: employee.positionFullName,
        name: `${employee.personLastName} ${employee.personFirstName} ${employee.personMiddleName}`,
        phones: (employee.phones || []).map((el) => el.phoneNumber).join(', '),
        email: (employee.emails || []).map((el) => el.emailName).join(', '),
      },
    ];

    const isViewMode = this.props.curMode === 'view';

    return (
      <Row>
        <Modal
          title="Картка "
          visible={this.state.dialogOpen}
          width={1300}
          footer={false}
          onCancel={() => {
            this.handleToggleDialog(false);
          }}
        >
          <Row>
            {this.state.dialogOpen && (
              <Row>
                {this.state.employeeEdit ? (
                  <ChildrenContainer
                    parentPosition={parentPosition}
                    match={{ params: { mode: 'edit', guid: parent.guid } }}
                    onCreatedCB={this.onChildrenCreated}
                    visible={this.state.dialogOpen}
                    inModal
                  />
                ) : (
                  false
                )}
              </Row>
            )}
          </Row>
        </Modal>
        <Row style={{ marginBottom: '1rem' }}>
          <Button
            onClick={() => {
              this.handleOpenForm('employeeEdit');
            }}
            disabled={isViewMode}
          >
            Редагувати працівника
          </Button>
        </Row>
        <Row>Працівник:</Row>
        <Row style={{ marginBottom: '1rem' }}>
          <Table
            dataSource={dataSourceParent}
            columns={parentColumns}
            pagination={false}
            bordered
          />
        </Row>
      </Row>
    );
  }
}

DivisionTables.defaultProps = {
  employeeView: {},
};

DivisionTables.propTypes = {
  updateParent: PropTypes.func.isRequired,
  // parentOrganization: PropTypes.objectOf(PropTypes.any).isRequired,
  item: PropTypes.objectOf(PropTypes.any).isRequired,
  data: PropTypes.objectOf(PropTypes.any).isRequired,

  curMode: PropTypes.string.isRequired,
  employeeView: PropTypes.objectOf(PropTypes.any),
  getEmployeesView: PropTypes.func.isRequired,
  resetEmployeesView: PropTypes.func.isRequired,
};

const mapStateToProps = (state) => ({
  employeeView: state.counterparties.structureView.employeeView,
});

export default connect(mapStateToProps, counterpartiesStructrueActions)(DivisionTables);
