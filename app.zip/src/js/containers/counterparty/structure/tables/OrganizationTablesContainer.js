import React from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { Button, Table, Row, Modal } from 'antd';

import * as counterpartiesStructureActions from '../../../../actions/modules/counterparties/structureActions';

import {
  organizationParent as parentColumns,
  divisionChildren as childrenColumns,
} from '../../../../models/formFields/counterparty/counterpartyTables';

import ChildrenContainer from '../DivisionContainer';
import { getPersonString } from '../../../../helpers/entities/countrerparty';

class OrganizationTables extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      dialogOpen: false,
    };
  }

  componentDidMount() {
    this.props.getDepartmentsView('', this.props.parentOrganization.guid);
  }

  componentWillUnmount() {
    this.props.resetDepartmentsView();
  }

  handleToggleDialog = (isOpened) => {
    if (isOpened !== undefined) this.setState({ dialogOpen: isOpened });
    else this.setState((prevState) => ({ dialogOpen: !prevState.dialogOpen }));
  };

  onChildrenCreated = () => {
    this.handleToggleDialog(false);
    this.props.updateParent();
    this.props.getDepartmentsView('', this.props.parentOrganization.guid);
  };

  render() {
    const { curMode } = this.props;
    const parent = this.props.item;

    let titleName = '';
    if (parent.counterpartyType === 'SelfEmployed') {
      const person = parent.personDto;
      titleName = getPersonString(person);
    }

    if (parent.counterpartyType === 'LegalEntity') {
      titleName = parent.fullName;
    }

    const dataSourceParent = [
      {
        key: parent.guid,
        name: titleName,
        phones: (parent.phones || []).map((item) => item.phoneNumber).join(', '),
      },
    ];
    const departments = Array.isArray(this.props.departmentsView)
      ? this.props.departmentsView
      : [this.props.departmentsView];

    const dataSourceChildren = departments.map(Boolean).map((child) => ({
      key: child.guid,
      name: child.name,
      shortName: child.shortName,
      divisionType: (child.refDepartmentType || {}).name,
      parentDepartment: '',
      phones: (child.phones || []).map((el) => el.phoneNumber).join(', '),
      addresses: '',
      notes: child.notes,
    }));

    const isViewMode = curMode === 'view';

    return (
      <Row>
        <Modal
          title="Картка "
          visible={this.state.dialogOpen}
          width={1300}
          footer={false}
          onCancel={() => {
            this.handleToggleDialog(false);
          }}
        >
          <Row>
            {this.state.dialogOpen && (
              <ChildrenContainer
                parentOrganization={this.props.parentOrganization}
                match={{ params: { mode: 'create' } }}
                onCreatedCB={this.onChildrenCreated}
                visible={this.state.dialogOpen}
                inModal
              />
            )}
          </Row>
        </Modal>
        <Row style={{ marginBottom: '1rem' }}>
          <Button onClick={this.handleToggleDialog} disabled={isViewMode}>
            Додати підрозділ
          </Button>
        </Row>
        <Row>Параметри організації:</Row>
        <Row style={{ marginBottom: '1rem' }}>
          <Table
            dataSource={dataSourceParent}
            columns={parentColumns}
            pagination={false}
            bordered
          />
        </Row>
        <Row>Підрозділи:</Row>
        <Row>
          <Table
            dataSource={dataSourceChildren}
            columns={childrenColumns}
            pagination={false}
            bordered
          />
        </Row>
      </Row>
    );
  }
}

OrganizationTables.defaultProps = {
  departmentsView: [],
};

OrganizationTables.propTypes = {
  updateParent: PropTypes.func.isRequired,
  item: PropTypes.objectOf(PropTypes.any).isRequired,
  parentOrganization: PropTypes.objectOf(PropTypes.any).isRequired,

  departmentsView: PropTypes.arrayOf(PropTypes.object),
  getDepartmentsView: PropTypes.func.isRequired,
  curMode: PropTypes.string.isRequired,
  resetDepartmentsView: PropTypes.func.isRequired,
};

const mapStateToProps = (state) => ({
  departmentsView: state.counterparties.structureView.departmentView,
});

export default connect(mapStateToProps, counterpartiesStructureActions)(OrganizationTables);
