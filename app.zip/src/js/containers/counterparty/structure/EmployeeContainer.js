import React from 'react';

import { connect } from 'react-redux';
import PropTypes from 'prop-types';

import { Form, Button, Row } from 'antd';

import * as classifiersActions from '../../../actions/classifiersActions';
import * as counterpartiesStructureActions from '../../../actions/modules/counterparties/structureActions';
import * as commonActions from '../../../actions/index';

import {
  fields,
  getMappedForm,
  getParsedForm,
} from '../../../models/formFields/counterparty/employeeFields';

import { mapFormItems } from '../../../helpers/formHelpers/mapFormHelper';

// import CounterpartiesDropdownContainer from '../../common/CounterpartiesDropdownContainer';
import { getFormEntityData } from '../../../helpers/formHelpers/formHelpers';

class EmployeeContainer extends React.Component {
  constructor(props) {
    super(props);

    const curMode = this.props.match.params.mode || 'create';
    this.curGuid = this.props.match.params.guid || '';

    this.state = {
      curMode,
      // dialogOpen: false,
      // dialogMessage: '',
    };
  }

  componentDidMount() {
    const { getEmployee } = this.props;
    const { curMode } = this.state;

    const position = this.props.parentPosition;
    const positionName = position ? position.positionName : undefined;

    this.props.form.setFieldsValue({ position: positionName });

    if (curMode === 'view' || curMode === 'edit') {
      getEmployee(this.curGuid);
    }
  }

  componentWillReceiveProps(nextProps) {
    const {
      formParam: { createdForm, status, errors },
      match: {
        params: { mode },
      },
      resetEmployees,
      resetEmployeesDoneStatus,
      form,
    } = nextProps;

    if (this.state.curMode !== mode) this.setState({ curMode: mode });

    if (createdForm.guid && (mode === 'view' || mode === 'edit') && !this.loaded) {
      this.loaded = true;
      form.setFieldsValue(getParsedForm(createdForm));
    }

    if (status.isDone) {
      this.loaded = true;
      this.curGuid = createdForm.guid;
      // this.handleToggleDialog();
      this.props.onCreatedCB();
      resetEmployeesDoneStatus();
    }

    if (errors.length > 0) {
      // const errorsText = errors.map((el) => el.message).join(', ');
      // this.setState({ dialogMessage: errorsText, dialogOpen: true });
      resetEmployees();
    }
  }

  componentWillUnmount() {
    this.props.resetEmployees();
  }

  handleSubmit = () => {
    const { curMode } = this.state;
    const {
      formParam: { createdForm },
      putEmployee,
      postEmployee,
      classifiers,
      form,
    } = this.props;

    const curFields = Object.keys(fields);

    form.validateFields(curFields, (err, values) => {
      if (!err) {
        const normilizedValue = getFormEntityData(values, classifiers, fields);

        if (curMode === 'create') {
          postEmployee({
            ...getMappedForm(normilizedValue),
            position: {
              guid: this.props.parentPosition.guid,
              versionId: this.props.parentPosition.versionId,
            },
          });
        }

        if (curMode === 'edit') {
          putEmployee({
            ...createdForm,
            ...getMappedForm(normilizedValue),
          });
        }
      }
    });
  };

  render() {
    const { classifiers } = this.props;
    const { curMode } = this.state;

    // const formItemLayout = {
    //   labelCol: {
    //     xs: { span: 8 }
    //   },
    //   wrapperCol: {
    //     xs: { span: 16 }
    //   }
    // };

    const isViewMode = curMode === 'view';

    return (
      <Row>
        {mapFormItems({
          viewMode: curMode,
          fields,
          classifiers,
          isViewMode,
          form: this.props.form,
        })}
        <Row type="flex" justify="end">
          <Button
            style={{ marginRight: '1.5rem' }}
            type="primary"
            onClick={() => {
              this.handleSubmit();
            }}
            disabled={isViewMode}
          >
            {`Відправити`}
          </Button>
        </Row>
      </Row>
    );
  }
}

EmployeeContainer.propTypes = {
  match: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
  onCreatedCB: PropTypes.func.isRequired,
  parentPosition: PropTypes.objectOf(PropTypes.any).isRequired,

  postEmployee: PropTypes.func.isRequired,
  putEmployee: PropTypes.func.isRequired,
  getEmployee: PropTypes.func.isRequired,
  resetEmployees: PropTypes.func.isRequired,
  resetEmployeesDoneStatus: PropTypes.func.isRequired,

  classifiers: PropTypes.objectOf(PropTypes.array).isRequired,
  formParam: PropTypes.objectOf(PropTypes.any).isRequired,

  form: PropTypes.objectOf(PropTypes.any).isRequired,
};

const mapStateToProps = (state) => ({
  formParam: state.counterparties.modals.rootCounterpartyContainer.forms.employeeForm,
  classifiers: state.classifiers,
});

export default connect(mapStateToProps, {
  ...classifiersActions,
  ...counterpartiesStructureActions,
  ...commonActions,
})(Form.create()(EmployeeContainer));
