import React from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import PropTypes from 'prop-types';

import { Form, Modal, Button, Row, Icon, Collapse, Table } from 'antd';

import * as classifiersActions from '../../actions/classifiersActions';
import * as corporateRightsActions from '../../actions/modules/corporateRights/corporateRightsActions';
import * as corporateRightsMovementActions from '../../actions/modules/corporateRights/corporateRightsMovementActions';
import * as commonActions from '../../actions';

import { mapFormItems } from '../../helpers/formHelpers/mapFormHelper';
import { mapRowsToTable } from '../../helpers/formHelpers/formHelpers';

import {
  structureFields,
  ownersFields,
  movementsFields,
  getMappedStructure,
  getParsedStructure,
  getParsedOwners,
  getMappedMovements,
  getParsedMovements,
} from '../../models/formFields/counterparty/corporateRightsFields';

import { CORPORATE_RIGHTS_STRUCTURE_CONTAINER } from '../../constants/ContainerNames';

import Separator from '../../components/common/form/Separator';

import CounterpartiesDropdownContainer from '../common/CounterpartiesDropdownContainer';
import DocumentsDropdownContainer from '../common/DocumentsDropdownContainer';
import { getTableColumns } from '../../helpers/table';
import { isNumberWithTwoDecimal, isRequired } from '../../services/validator/rules';
import { getEnumLabel } from '../../helpers/enums';
import { getCounterpartyString } from '../../helpers/geters';
import { getDocumentLabel } from '../../helpers/entities/documents';

const CORPORATE_RIGHTS_STRUCTURE_ACTIONS = {
  ...classifiersActions,
  ...corporateRightsActions,
  ...corporateRightsMovementActions,
  ...commonActions,
};

const Panel = Collapse.Panel;

const formsMap = {
  structure: {
    fields: structureFields,
  },
  owners: {
    fields: ownersFields,
  },
  movements: {
    fields: movementsFields,
  },
};

const moneyReceiverInOperationGuidField = movementsFields.moneyReceiversInOperation;
const moneySenderInOperationGuidField = movementsFields.moneySendersInOperation;
const shareReceiverField = movementsFields.shareReceiver;
const shareSenderField = movementsFields.shareSender;

class CorporateRightsStructureContainer extends React.Component {
  constructor(props) {
    super(props);

    const curMode = this.props.match.params.mode || 'create';

    this.state = {
      curMode,
      dialogOpen: false,
      dialogMessage: '',

      owners: {
        curIndex: -1,
        activeKey: 0,
        collapsed: false,
      },
      movements: {
        curIndex: -1,
        activeKey: 0,
        collapsed: false,
      },
    };

    const formFields = { ...movementsFields };
    delete formFields.paymentDocs;
    this.ownersColumns = getTableColumns({
      formFields: ownersFields,
    });
    this.movementsColumns = getTableColumns({
      actionsData: {
        deleteParams: {
          handler: this.handleDeleteRow,
        },
      },
      formFields,
    });

    this.participantKey = `counterpatiesDropdown-${`${Math.random()}`.substring(2)}`;
    this.moneyRecieverInOperationGuidKey = `counterpatiesDropdown-${`${Math.random()}`.substring(
      2,
    )}`;
    this.moneySenderInOperationGuidFieldKey = `counterpatiesDropdown-${`${Math.random()}`.substring(
      2,
    )}`;
    this.shareReceiverGuidKey = `counterpatiesDropdown-${`${Math.random()}`.substring(2)}`;
    this.shareSenderGuidKey = `counterpatiesDropdown-${`${Math.random()}`.substring(2)}`;
  }

  componentDidMount = () => {
    const {
      structureDto,
      loadClassifiersForContainer,
      loadCorporateRightsOwners,
      loadCorporateRightsMovements,
      form: { setFieldsValue },
    } = this.props;

    loadClassifiersForContainer(CORPORATE_RIGHTS_STRUCTURE_CONTAINER);

    if (structureDto) {
      setFieldsValue(getParsedStructure(structureDto));
      loadCorporateRightsOwners(structureDto.guid);
      loadCorporateRightsMovements(structureDto.guid);
    }
  };

  componentWillReceiveProps(nextProps) {
    const {
      structureDto,
      match: {
        params: { mode, guid },
      },
      tables: { movements, isDone, errors },
      form: { setFieldsValue },
      resetCorporateRights,
      loadCorporateRightsOwners,
      loadCorporateRightsMovements,
    } = nextProps;

    if (this.state.curMode !== mode) this.setState({ curMode: mode });

    if (this.props.structureDto !== structureDto) {
      if (structureDto) {
        setFieldsValue(getParsedStructure(structureDto));
        loadCorporateRightsOwners(guid);
        loadCorporateRightsMovements(structureDto.guid);
      } else {
        this.clearForm();
        resetCorporateRights();
      }
    }

    if (
      this.props.tables.isDone &&
      isDone &&
      structureDto &&
      this.props.tables.movements !== movements
    ) {
      loadCorporateRightsOwners(guid);
    }

    if (errors.length > 0) {
      const errorsText = errors.map((el) => el.message).join(', ');
      this.setState({ dialogMessage: errorsText, dialogOpen: true });
      resetCorporateRights();
    }
  }

  componentWillUnmount() {
    this.props.resetCorporateRights();
  }

  handleSaveTableForm = (formName) => () => {
    const { structureDto, postCorporateRightsMovements } = this.props;

    const fieldsArr = Object.keys(formsMap[formName].fields);
    this.props.form.validateFields(fieldsArr, (err, values) => {
      if (!err) {
        postCorporateRightsMovements({
          ...getMappedMovements(values),
          corporateRightsStructure: {
            guid: structureDto.guid,
            versionId: structureDto.versionId,
          },
        });

        this.setState((prevState) => ({
          [formName]: {
            ...prevState[formName],
            collapsed: false,
            activeKey: 0,
            curIndex: -1,
          },
        }));
      }
    });
  };

  handleDeleteRow = (rowIndex) => {
    const {
      deleteCorporateRightsMovements,
      tables: { movements },
    } = this.props;

    deleteCorporateRightsMovements(movements[rowIndex].guid);
  };

  handleAddTableRow = (formName) => () => {
    this.props.form.resetFields(Object.keys(formsMap[formName].fields));
    this.setState((prevState) => ({
      [formName]: {
        ...prevState[formName],
        collapsed: true,
        isAddingNewRow: true,
        activeKey: 1,
      },
    }));
  };

  handleCancelTableRow = (formName) => () => {
    this.props.form.resetFields(Object.keys(formsMap[formName].fields));
    this.setState((prevState) => ({
      [formName]: {
        ...prevState[formName],
        collapsed: false,
        activeKey: 0,
      },
    }));
  };

  clearForm = () => {
    this.props.form.resetFields();
  };

  handleToggleDialog = (isOpened) => {
    if (isOpened !== undefined) this.setState({ dialogOpen: isOpened });
    else this.setState((prevState) => ({ dialogOpen: !prevState.dialogOpen }));
  };

  handleDialogCancel = () => {
    this.handleToggleDialog();
  };

  getStructureFields = () => {
    const { form } = this.props;
    const withShares =
      form.getFieldValue('totalNumberOfShares') || form.getFieldValue('shareParValue');
    const sharesFormTypeHasUndefinedValue = form.getFieldValue('sharesFormType') === 'UNDEFINED';
    return {
      ...structureFields,
      shareCapital: {
        ...structureFields.shareCapital,
        rules: [isNumberWithTwoDecimal(), !withShares ? isRequired() : null].filter(Boolean),
        readOnly: Boolean(withShares),
      },
      shareParValue: {
        ...structureFields.shareParValue,
        onBlur: this.setShareCapital,
        readOnly: sharesFormTypeHasUndefinedValue,
        rules: [isNumberWithTwoDecimal()],
      },
      totalNumberOfShares: {
        ...structureFields.totalNumberOfShares,
        onBlur: () => {
          this.setShareCapital();
          this.setTotalEnterprisePrice();
        },
        readOnly: sharesFormTypeHasUndefinedValue,
        rules: [isNumberWithTwoDecimal()],
      },
      sharesFormType: {
        ...structureFields.sharesFormType,
        onChange: this.onSharesFormTypeChange,
      },
      shareMarketValue: {
        ...structureFields.shareMarketValue,
        onBlur: this.setTotalEnterprisePrice,
      },
    };
  };

  setTotalEnterprisePrice = () => {
    const { form } = this.props;
    const shareMarketValue = form.getFieldValue('shareMarketValue');
    const totalNumberOfShares = form.getFieldValue('totalNumberOfShares');
    const totalEnterprisePrice = form.getFieldValue('totalEnterprisePrice');
    const newTotalEnterprisePrice = Number(shareMarketValue) * Number(totalNumberOfShares);
    setTimeout(
      () =>
        form.setFieldsValue({
          totalEnterprisePrice: newTotalEnterprisePrice || totalEnterprisePrice,
        }),
      50,
    );
  };

  onSharesFormTypeChange = (value) => {
    if (value === 'UNDEFINED') {
      this.props.form.setFieldsValue({
        totalNumberOfShares: '',
        shareParValue: '',
        shareCapital: '',
      });
    }
  };

  setShareCapital = () => {
    const { form } = this.props;
    const shareCapital = form.getFieldValue('shareCapital');
    const totalNumberOfShares = form.getFieldValue('totalNumberOfShares');
    const shareParValue = form.getFieldValue('shareParValue');
    if (totalNumberOfShares && shareParValue) {
      const newShareCapital = Number(shareParValue) * Number(totalNumberOfShares);
      return setTimeout(
        () => form.setFieldsValue({ shareCapital: newShareCapital || shareCapital }),
        50,
      );
    }
    if (totalNumberOfShares || shareParValue) {
      setTimeout(() => form.setFieldsValue({ shareCapital: '' }), 50);
    }
  };

  handleSubmit = () => {
    const {
      legalGuid,
      legalVersionId,
      structureDto,
      postCorporateRightsStructure,
      putCorporateRightsStructure,
      form,
    } = this.props;

    const curFields = Object.keys(this.getStructureFields());

    form.validateFields(curFields, (err, values) => {
      if (!err) {
        if (!structureDto) {
          postCorporateRightsStructure({
            legalEntity: {
              guid: legalGuid,
              versionId: legalVersionId,
            },
            ...getMappedStructure(values),
          });
        } else {
          putCorporateRightsStructure({
            ...getMappedStructure(values),
            legalEntity: {
              guid: legalGuid,
              versionId: legalVersionId,
            },
            guid: structureDto.guid,
            versionId: structureDto.versionId,
          });
        }
      }
    });
  };

  formatMovementsTableRows = (rows, movements) =>
    rows.map((row, i) => ({
      ...row,
      moneyReceiversInOperation: (row.moneyReceiversInOperation || [])
        .map((item) => this.getMovementPerson(item))
        .join(','),
      moneySendersInOperation: (row.moneySendersInOperation || [])
        .map((item) => this.getMovementPerson(item))
        .join(','),
      corporateRightsMovementDocs: (row.corporateRightsMovementDocs || [])
        .map((item) => getDocumentLabel({ documentData: item }))
        .join(','),
      shareReceiver: this.getMovementPerson(row.shareReceiver),
      shareSender: this.getMovementPerson(row.shareSender),
      corporateRightsOperationType: getEnumLabel({
        enumValue: movements[i].corporateRightsOperationType,
        classifierName: 'corporateRightsOperationType',
      }),
      operationMethodType: getEnumLabel({
        enumValue: movements[i].operationMethodType,
        classifierName: 'operationMethodType',
      }),
      stocksType: getEnumLabel({
        enumValue: movements[i].stocksType,
        classifierName: 'stocksType',
      }),
    }));

  getMovementPerson = (person) =>
    person ? `${getCounterpartyString(person)}, ${person.itn || person.edrpou || ''}` : '';

  render() {
    const { curMode, dialogMessage } = this.state;

    const {
      structureDto,
      classifiers,
      tables: { owners, movements },
    } = this.props;

    const movementsPanelStyle = this.state.movements.collapsed
      ? { marginBottom: '1rem' }
      : { display: 'none' };
    const dialogText = structureDto ? 'створено' : 'відредаговано';
    const isViewMode = curMode === 'view';
    const ownersTableRows = mapRowsToTable(
      owners.map((el) => getParsedOwners(el)),
      ownersFields,
      classifiers,
    );
    const parsedMovements = movements.map((el) => getParsedMovements(el));
    const movementsTableRows = mapRowsToTable(parsedMovements, movementsFields, classifiers);

    const mappedMovementTableRows = this.formatMovementsTableRows(
      movementsTableRows,
      parsedMovements,
    );

    return (
      <Row>
        <Modal
          title="Корпоративні права"
          visible={this.state.dialogOpen}
          onCancel={() => {
            this.handleDialogCancel();
          }}
          cancelText="Переглянути картку"
        >
          {dialogMessage === '' ? (
            <p>{`Структуру корпоративних прав успішно ${dialogText}`}</p>
          ) : (
            <p>{`${dialogMessage}`}</p>
          )}
        </Modal>
        <Row>
          <Row>
            <Separator text="Корпоративні права" />
            <Row>
              {mapFormItems({
                viewMode: curMode,
                fields: this.getStructureFields(),
                classifiers,
                isViewMode,
                form: this.props.form,
              })}
            </Row>
            <Row type="flex" justify="end">
              <Button
                style={{ marginRight: '1.5rem' }}
                type="primary"
                onClick={() => {
                  this.handleSubmit();
                }}
                disabled={isViewMode}
              >
                Відправити
              </Button>
            </Row>
          </Row>
          <Row>
            <Separator text="Поточні учасники підприємства" />
            <Table
              style={{ margin: '1rem 0', background: '#fff' }}
              bordered
              pagination={false}
              columns={this.ownersColumns}
              dataSource={ownersTableRows}
            />
          </Row>
          <Row>
            <Separator text="Рух корпоративних прав" />
            <Button
              disabled={this.state.movements.collapsed || curMode === 'create'}
              onClick={this.handleAddTableRow('movements')}
            >
              <Icon type="plus" />
              Додати
            </Button>
            <Collapse
              style={movementsPanelStyle}
              bordered={false}
              activeKey={`${this.state.movements.activeKey}`}
              onChange={(key) => this.setState({ activeKey: key })}
            >
              <Panel header="Форма створення" key="1" disabled={!this.state.movements.collapsed}>
                {mapFormItems({
                  viewMode: curMode,
                  fields: movementsFields,
                  classifiers,
                  isViewMode,
                  form: this.props.form,
                })}
                <Row>
                  <DocumentsDropdownContainer
                    mode="multiple"
                    withOutTable
                    form={this.props.form}
                    isViewMode={isViewMode}
                    fieldSpec={movementsFields.corporateRightsMovementDocs}
                    includeVersionIdInKey
                    updater={{}}
                  />
                </Row>
                <Row>
                  <DocumentsDropdownContainer
                    mode="multiple"
                    withOutTable
                    form={this.props.form}
                    isViewMode={isViewMode}
                    fieldSpec={movementsFields.paymentDocs}
                    includeVersionIdInKey
                    updater={{}}
                  />
                </Row>
                <Row>
                  <CounterpartiesDropdownContainer
                    mode="multiple"
                    form={this.props.form}
                    isViewMode={isViewMode}
                    includeVersionIdInKey
                    fieldSpec={moneyReceiverInOperationGuidField}
                    updater={{}}
                  />
                  <CounterpartiesDropdownContainer
                    mode="multiple"
                    form={this.props.form}
                    isViewMode={isViewMode}
                    includeVersionIdInKey
                    fieldSpec={moneySenderInOperationGuidField}
                    updater={{}}
                  />
                  <CounterpartiesDropdownContainer
                    form={this.props.form}
                    isViewMode={isViewMode}
                    fieldSpec={shareReceiverField}
                    includeVersionIdInKey
                    updater={{}}
                  />
                </Row>
                <Row>
                  <CounterpartiesDropdownContainer
                    form={this.props.form}
                    isViewMode={isViewMode}
                    fieldSpec={shareSenderField}
                    includeVersionIdInKey
                    updater={{}}
                  />
                </Row>
                <Row>
                  <Button
                    style={{ marginRight: '1rem' }}
                    onClick={this.handleSaveTableForm('movements')}
                    type="primary"
                  >
                    <Icon type="save" />
                    Зберегти
                  </Button>
                  <Button onClick={this.handleCancelTableRow('movements')}>
                    <Icon type="close" />
                    Вiдмiнити
                  </Button>
                </Row>
              </Panel>
            </Collapse>
            <Table
              style={{ margin: '1rem 0', background: '#fff' }}
              bordered
              pagination={false}
              columns={this.movementsColumns}
              dataSource={mappedMovementTableRows}
            />
          </Row>
        </Row>
      </Row>
    );
  }
}

CorporateRightsStructureContainer.propTypes = {
  // own props
  legalGuid: PropTypes.string.isRequired,
  legalVersionId: PropTypes.number.isRequired,
  structureDto: PropTypes.objectOf(PropTypes.any),

  // router hoc
  match: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,

  // actions (store hoc)
  loadClassifiersForContainer: PropTypes.func.isRequired,
  postCorporateRightsStructure: PropTypes.func.isRequired,
  putCorporateRightsStructure: PropTypes.func.isRequired,
  postCorporateRightsMovements: PropTypes.func.isRequired,
  deleteCorporateRightsMovements: PropTypes.func.isRequired,
  resetCorporateRights: PropTypes.func.isRequired,
  loadCorporateRightsOwners: PropTypes.func.isRequired,
  loadCorporateRightsMovements: PropTypes.func.isRequired,

  // state (store hoc)
  classifiers: PropTypes.objectOf(PropTypes.array).isRequired,
  tables: PropTypes.shape({
    errors: PropTypes.arrayOf(PropTypes.any),
    isDone: PropTypes.bool,
    owners: PropTypes.arrayOf(PropTypes.object),
    movements: PropTypes.arrayOf(PropTypes.object),
  }).isRequired,

  // antd form hoc
  form: PropTypes.objectOf(PropTypes.any).isRequired,
};

CorporateRightsStructureContainer.defaultProps = {
  structureDto: null,
};

export default withRouter(
  connect(
    (state) => ({
      classifiers: state.classifiers,
      tables: state.corporateRightsMovement.tables,
    }),
    CORPORATE_RIGHTS_STRUCTURE_ACTIONS,
  )(Form.create()(CorporateRightsStructureContainer)),
);
