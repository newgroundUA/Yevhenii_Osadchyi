import React from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';

import { Form, Modal, Button, Row, Col, Icon, Tabs } from 'antd';

import AddressList from '../common/address/AddressList';

import * as classifiersActions from '../../actions/classifiersActions';
import * as counterpartiesLegalActions from '../../actions/modules/counterparties/legalActions';
import * as counterpartiesCommonActions from '../../actions/modules/counterparties/commonActions';
import * as commonActions from '../../actions';

import { mapFormItems } from '../../helpers/formHelpers/mapFormHelper';
import {
  legalFastFields,
  legalDataFields,
  legalRegistrationFields,
  getLegalShort,
  getLegalFull,
  parseLegal,
} from '../../models/formFields/counterparty/legalFields';
import { foContactFields } from '../../models/formFields/counterparty/foFields';
import Separator from '../../components/common/form/Separator';
import * as RouteNames from '../../constants/RouteNames';
import Structure from './structure/CounterpartyStructureContainer';
// import CorporateRightsStructureContainer from './CorporateRightsStructureContainer';

import { LEGAL_PAGE_CONTAINER } from '../../constants/ContainerNames';
import {
  PHONELIST,
  EMAILLIST,
  WEBSITELIST,
  KOPFG,
  SKOF,
  REF_DOCUMENT_TYPE_GENERAL_DOC_CLASSNAME,
} from '../../constants/ClassifiersNames';
import { getFormEntityData } from '../../helpers/formHelpers/formHelpers';
import BankDetails from './BankDetails';
import BoundedDocumentsTab from '../../components/counterparties/BoundedDocumentsTab';
import CorporateRightsStructureContainer from './CorporateRightsStructureContainer';

const ButtonGroup = Button.Group;
const TabPane = Tabs.TabPane;

class LegalPageContainer extends React.Component {
  constructor(props) {
    super(props);

    const curMode = this.props.match.params.mode || 'create';
    this.curGuid = this.props.match.params.guid || '';
    this.buyerKey = `counterpatiesDropdown-${`${Math.random()}`.substring(2)}`;

    this.state = {
      curMode,
      dialogOpen: false,
      dialogMessage: '',
    };

    this.loaded = false;
    this.storeKey = props.storeKey || 'rootCounterpartyContainer';
    this.formFiels = this.getFormFields();
  }

  componentDidMount() {
    const {
      formParam: { createdLegal, phoneList, emailList, webSiteList },
      getLegalByGuid,
    } = this.props;
    const { curMode } = this.state;

    this.legalDocuments = createdLegal.documents;

    this.props.loadClassifiersForContainer(LEGAL_PAGE_CONTAINER, {
      [PHONELIST]: { phoneRegistryParam: phoneList.requestParam },
      [EMAILLIST]: { emailRegistryParam: emailList.requestParam },
      [WEBSITELIST]: { webSiteRegistryParam: webSiteList.requestParam },
      [REF_DOCUMENT_TYPE_GENERAL_DOC_CLASSNAME]: { generalDocClassName: 'Document' },
    });

    if (curMode === 'view' || curMode === 'edit') {
      getLegalByGuid(this.storeKey, this.curGuid);
    }
  }

  componentWillReceiveProps(nextProps) {
    const {
      formParam: { createdLegal, status, errors },
      match: {
        params: { mode: nextMode },
      },
      resetCounterpartiesForm,
      resetLegalIsDoneStatus,
    } = nextProps;

    if (this.state.curMode !== nextMode) {
      this.setState({ curMode: nextMode });
      if (nextMode === 'create') this.props.form.resetFields(); // [BUG-1442]
    }

    if (!this.loaded && createdLegal.fullName && (nextMode === 'view' || nextMode === 'edit')) {
      this.loaded = true;
      this.legalDocuments = createdLegal.documents;
      this.props.form.setFieldsValue(parseLegal(createdLegal));
    }

    if (status.isDone) {
      if (this.props.inModal && !this.loaded) {
        this.clearForm();
        this.props.onLegalCreated(createdLegal);
      }
      this.handleToggleDialog();
      this.props.form.setFieldsValue(parseLegal(createdLegal));
      resetLegalIsDoneStatus(this.storeKey);
      // resetCounterpartiesForm(this.storeKey);

      this.loaded = true;
      this.curGuid = createdLegal.guid;

      this.legalDocuments = createdLegal.documents;
    }

    if (errors.length > 0) {
      const errorsText = errors.map((el) => el.message).join(', ');
      this.setState({ dialogMessage: errorsText, dialogOpen: true });
      resetCounterpartiesForm(this.storeKey);
    }
  }

  componentWillUnmount() {
    this.props.resetCounterpartiesForm(this.storeKey);
  }

  updateLegal = () => {
    this.loaded = false;
    this.props.getLegalByGuid(this.storeKey, this.curGuid);
  };

  handleSubmit = (type = 'short', docArr = []) => {
    const { curMode } = this.state;
    const {
      putLegalByGuid,
      postNewLegal,
      form,
      formParam: { createdLegal },
      classifiers,
    } = this.props;

    let curFields = Object.keys(legalFastFields);
    if (type === 'full' || type === 'withCorp') {
      curFields = curFields.concat([
        ...Object.keys(legalDataFields),
        ...Object.keys(legalRegistrationFields),
        ...Object.keys(foContactFields),
      ]);
    }
    if (type === 'documents') {
      curFields = curFields.concat([
        ...Object.keys(legalDataFields),
        ...Object.keys(legalRegistrationFields),
        ...Object.keys(foContactFields),
      ]);
    }

    form.validateFields(curFields, (err, values) => {
      if (!err) {
        const getDtoByType = {
          short: getLegalShort,
          full: getLegalFull,
          'full+fop': getLegalFull,
          documents: getLegalFull,
        };
        const formFieldsTamplate = {
          ...legalFastFields,
          ...legalDataFields,
          ...legalRegistrationFields,
          ...foContactFields,
        };
        const normilizedValue = getFormEntityData(values, classifiers, formFieldsTamplate);

        const legalData = getDtoByType[type](normilizedValue);

        const getDoc = (guid) => {
          const document = classifiers.documents.find((doc) => doc.guid === guid);
          if (!document) {
            return undefined;
          }
          return {
            guid: document.guid,
            versionId: document.versionId,
          };
        };

        if (curMode === 'create') {
          if (type === 'short' || type === 'full') postNewLegal(this.storeKey, legalData);
        }

        if (curMode === 'edit') {
          if (type === 'short' || type === 'full') {
            putLegalByGuid(this.storeKey, {
              ...createdLegal,
              ...legalData,
              guid: this.curGuid,
            });
          }
          if (type === 'withCorp') {
            // do some shit
            // ^_^
          }
          if (type === 'documents') {
            putLegalByGuid(this.storeKey, {
              ...createdLegal,
              ...legalData,
              documents: docArr.map((guid) => {
                const doc = createdLegal.documents.find((el) => el.guid === guid);
                if (doc) return doc;
                return getDoc(guid);
              }),
              guid: this.curGuid,
            });
          }
        }

        if (curMode === RouteNames.VIEW) {
          if (type === 'documents') {
            putLegalByGuid(this.storeKey, {
              ...createdLegal,
              ...legalData,
              documents: docArr.map((guid) => {
                const doc = createdLegal.documents.find((el) => el.guid === guid);
                if (doc) return doc;
                return getDoc(guid);
              }),
              guid: this.curGuid,
            });
          }
        }
      }
    });
  };

  handleCreateNew = () => {
    this.changeRouteTo(`/${RouteNames.COUNTERPARTIES}/${RouteNames.LEGALPAGE}/create`);
    this.curGuid = '';
    this.loaded = false;
    this.props.form.resetFields();
    this.props.resetCounterpartiesForm(this.storeKey);
    this.handleToggleDialog();
  };

  switchToEditMode = () => {
    this.changeRouteTo(
      `/${RouteNames.COUNTERPARTIES}/${RouteNames.LEGALPAGE}/${RouteNames.EDIT}/${this.curGuid}`,
    );
  };

  switchToViewMode = () => {
    this.changeRouteTo(
      `/${RouteNames.COUNTERPARTIES}/${RouteNames.LEGALPAGE}/${RouteNames.VIEW}/${this.curGuid}`,
    );
  };

  handleDialogCancel = () => {
    this.handleToggleDialog();
    this.switchToViewMode();
  };

  handleToggleDialog = (isOpened, dialogName = 'dialogOpen') => {
    if (isOpened !== undefined) this.setState({ [dialogName]: isOpened });
    else this.setState((prevState) => ({ [dialogName]: !prevState[dialogName] }));
  };

  clearForm = () => {
    this.props.form.resetFields();
  };

  changeRouteTo = (route) => {
    this.props.history.push(route);
  };

  handleAddressCreated = (addressData) => {
    const {
      form: { getFieldValue, setFieldsValue },
    } = this.props;
    const currentAddressesValue = getFieldValue('addresses');
    const newAddressesValue = !currentAddressesValue
      ? [addressData]
      : [...currentAddressesValue, addressData];

    setFieldsValue({
      addresses: newAddressesValue,
    });
  };

  handleAddressDeleted = (addressGuid) => {
    const {
      form: { getFieldValue, setFieldsValue },
    } = this.props;
    const currentAddressesValue = getFieldValue('addresses');
    const newAddressesValue = currentAddressesValue.filter(
      (address) => address.guid !== addressGuid,
    );

    setFieldsValue({
      addresses: newAddressesValue,
    });
  };

  handleAddDocuments = (docArr) => {
    this.handleSubmit('documents', docArr);
  };

  validateEdrpouUnique = (rule, value, callback) => {
    const { curMode } = this.state;
    const {
      formParam: { createdLegal },
    } = this.props;

    if (value && value.length === 8) {
      if (curMode === 'edit' && createdLegal.edrpou === value) {
        callback();
      } else {
        this.props.getLegalEntityByEdrpou(value).then((serverResponce) => {
          const findedCounterpartyes = serverResponce.data;

          if (
            findedCounterpartyes.length > 0 &&
            findedCounterpartyes[0].counterpartyType === 'LegalEntity'
          ) {
            const guid = findedCounterpartyes[0].legalEntityGuid;
            this.props.getLegalByGuid(this.storeKey, guid);
            this.changeRouteTo(
              `/${RouteNames.COUNTERPARTIES}/${RouteNames.LEGALPAGE}/${RouteNames.EDIT}/${guid}`,
            );
          }
          callback();
        });
      }
    } else {
      callback();
    }
  };

  concatInternalIdAndName = (classifiersName) =>
    this.props.classifiers[classifiersName]
      .map((item) => ({
        ...item,
        name: `${item.internalId} ${item.name}`,
      }))
      .sort((a, b) => a.internalId - b.internalId);

  getFormFields = () => {
    const res = {
      legalFastFields: {
        ...legalFastFields,
        edrpoy: {
          ...legalFastFields.edrpoy,
          rules: [
            ...legalFastFields.edrpoy.rules,
            {
              validator: this.validateEdrpouUnique,
              message: 'Контрагент з таким номером ЄДРПОУ вже існує',
            },
          ],
        },
      },
      legalDataFields: this.getLegalDataFields(),
      legalRegistrationFields: {
        ...legalRegistrationFields,
      },
      foContactFields: {
        ...foContactFields,
      },
    };
    return res;
  };

  getLegalDataFields = () => legalDataFields;

  render() {
    const {
      formParam: { createdLegal },
      classifiers,
    } = this.props;
    const { dialogMessage, curMode } = this.state;

    const classifiersLegal = {
      ...classifiers,
      [KOPFG]: this.concatInternalIdAndName(KOPFG),
      [SKOF]: this.concatInternalIdAndName(SKOF),
    };

    const isCreateMode = curMode === 'create';
    const isViewMode = curMode === 'view';
    const dialogText = curMode === 'create' ? 'створено' : 'відредаговано';
    return (
      <Row>
        <Modal
          title="Картка ЮО"
          visible={this.state.dialogOpen}
          onOk={() => {
            this.handleCreateNew();
          }}
          onCancel={() => {
            this.handleDialogCancel();
          }}
          cancelText="Переглянути картку"
          okText="Створити нову"
        >
          {dialogMessage === '' ? (
            <p>{`Картку успішно ${dialogText}`}</p>
          ) : (
            <p>{`${dialogMessage}`}</p>
          )}
        </Modal>
        <Tabs>
          <TabPane tab="Поля форми ЮО" key="0">
            <Row>
              <Row type="flex" justify="center">
                <ButtonGroup>
                  {isViewMode && (
                    <Button
                      onClick={() => {
                        this.switchToEditMode();
                      }}
                    >
                      <Icon type="edit" />
                      Редагувати
                    </Button>
                  )}
                  {!isViewMode && (
                    <Button
                      onClick={() => {
                        this.clearForm();
                      }}
                    >
                      <Icon type="delete" />
                      Очистити поля
                    </Button>
                  )}
                  <Button
                    onClick={() => {
                      this.changeRouteTo(`/${RouteNames.COUNTERPARTIES}/${RouteNames.REGISTER}`);
                    }}
                  >
                    <Icon type="logout" />
                    Перейти до реєстру
                  </Button>
                </ButtonGroup>
              </Row>
              <Row>
                <Form>
                  <Row>
                    <Separator text="Основна інформація" />
                    {mapFormItems({
                      viewMode: curMode,
                      fields: this.formFiels.legalFastFields,
                      classifiers: classifiersLegal,
                      isViewMode,
                      form: this.props.form,
                    })}
                    {curMode === 'create' && (
                      <Row type="flex" justify="end">
                        <Button
                          style={{ marginRight: '1.5rem' }}
                          type="primary"
                          onClick={() => {
                            this.handleSubmit('short');
                          }}
                          disabled={isViewMode}
                        >
                          Відправити частково
                        </Button>
                      </Row>
                    )}
                  </Row>
                  <Row>
                    <Separator text="Облікові дані" />
                    {mapFormItems({
                      viewMode: curMode,
                      fields: this.getLegalDataFields(),
                      classifiers: classifiersLegal,
                      isViewMode,
                      form: this.props.form,
                    })}
                  </Row>
                  <Row>
                    <Separator text="Дані державної реєстрації" />
                    {mapFormItems({
                      viewMode: curMode,
                      fields: this.formFiels.legalRegistrationFields,
                      classifiers,
                      isViewMode,
                      form: this.props.form,
                    })}
                  </Row>
                  <Row>
                    <Separator text="Контакти" />
                    {mapFormItems({
                      viewMode: curMode,
                      fields: this.formFiels.foContactFields,
                      classifiers,
                      isViewMode,
                      form: this.props.form,
                    })}
                    <Row>
                      <Col span={12}>
                        <AddressList
                          allowEditFrom="region"
                          multy
                          required
                          form={this.props.form}
                          fieldName="addresses"
                          isViewMode={isViewMode}
                        />
                      </Col>
                    </Row>

                    <Row type="flex" justify="end">
                      <Button
                        style={{ marginRight: '1.5rem' }}
                        type="primary"
                        onClick={() => {
                          this.handleSubmit('full');
                        }}
                        disabled={isViewMode}
                      >
                        Відправити
                      </Button>
                    </Row>
                  </Row>
                  {createdLegal && createdLegal.guid ? (
                    <CorporateRightsStructureContainer
                      legalGuid={createdLegal.guid}
                      legalVersionId={createdLegal.versionId}
                      structureDto={createdLegal.structureDto}
                    />
                  ) : null}
                </Form>
              </Row>
            </Row>
          </TabPane>
          <TabPane tab="Організаційна структура" disabled={isCreateMode} key="1">
            <Structure
              curMode={curMode}
              form={this.props.formParam.createdLegal || {}}
              updateParent={this.updateLegal}
            />
          </TabPane>
          <TabPane tab="Зв'язані документи" disabled={isCreateMode} key="2">
            <BoundedDocumentsTab
              routeName={RouteNames.LEGALPAGE}
              curGuid={this.curGuid}
              form={this.props.form}
            />
          </TabPane>
          <TabPane tab="Банківські реквізити" disabled={isCreateMode} key="3">
            <BankDetails accountOwner={this.props.formParam.createdLegal} isViewMode={isViewMode} />
          </TabPane>
        </Tabs>
      </Row>
    );
  }
}

LegalPageContainer.propTypes = {
  history: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]),
  match: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
  inModal: PropTypes.bool,
  storeKey: PropTypes.string,

  getLegalEntityByEdrpou: PropTypes.func.isRequired,
  resetLegalIsDoneStatus: PropTypes.func.isRequired,
  resetCounterpartiesForm: PropTypes.func.isRequired,
  putLegalByGuid: PropTypes.func.isRequired,
  postNewLegal: PropTypes.func.isRequired,
  getLegalByGuid: PropTypes.func.isRequired,
  // loadCounterparties: PropTypes.func.isRequired,
  loadClassifiersForContainer: PropTypes.func.isRequired,
  onLegalCreated: PropTypes.func,
  classifiers: PropTypes.objectOf(PropTypes.array).isRequired,
  formParam: PropTypes.objectOf(PropTypes.any).isRequired,

  form: PropTypes.objectOf(PropTypes.any).isRequired,
};

LegalPageContainer.defaultProps = {
  history: null,
  inModal: false,
  onLegalCreated: null,
  storeKey: null,
};

const mapStateToProps = (state, props) => ({
  formParam: (
    state.counterparties.modals[props.storeKey || 'rootCounterpartyContainer'] || { forms: {} }
  ).forms.createLegal,
  classifiers: state.classifiers,
});

export default connect(mapStateToProps, {
  ...classifiersActions,
  ...counterpartiesLegalActions,
  ...counterpartiesCommonActions,
  ...commonActions,
})(Form.create()(LegalPageContainer));
