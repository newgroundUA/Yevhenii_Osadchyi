import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
// import update from 'immutability-helper';
// import _debounce from 'lodash/debounce';

import { Form, Modal, Button, Row, Icon, Col, Tabs } from 'antd';

import Separator from '../../components/common/form/Separator';
import AddressList from '../common/address/AddressList';
import Structure from './structure/CounterpartyStructureContainer';
import { mapFormItems } from '../../helpers/formHelpers/mapFormHelper';

import {
  foMainFields,
  foContactFields,
  parseFo,
} from '../../models/formFields/counterparty/foFields';

import {
  fopDataFOPFields,
  fopRegistrationDataFields,
  parseFop,
  getFopBEFields,
} from '../../models/formFields/counterparty/fopFields';

import * as RouteNames from '../../constants/RouteNames';
import * as classifiersActions from '../../actions/classifiersActions';
import * as counterpartiesFoFopActions from '../../actions/modules/counterparties/foFopActions';
import * as counterpartiesCommonActions from '../../actions/modules/counterparties/commonActions';
import * as addressActions from '../../actions/modules/addressActions';
import * as commonActions from '../../actions/index';

import { FOP_FORM_CONTAINER } from '../../constants/ContainerNames';
import {
  PHONELIST,
  EMAILLIST,
  WEBSITELIST,
  REF_DOCUMENT_TYPE_GENERAL_DOC_CLASSNAME,
} from '../../constants/ClassifiersNames';
import { getFormEntityData } from '../../helpers/formHelpers/formHelpers';
import { getObjGuidAndVersionId } from '../../helpers/commonUtils';
import BankDetails from './BankDetails';
import { getCounterpartyLabel, getCounterpartyITN } from '../../helpers/entities/countrerparty';
import BoundedDocumentsTab from '../../components/counterparties/BoundedDocumentsTab';

const CONTAINER_ACTIONS = {
  ...classifiersActions,
  ...commonActions,
  ...addressActions,
  ...counterpartiesFoFopActions,
  ...counterpartiesCommonActions,
};

const modelStatutListData = [{ guid: true, name: 'Так' }, { guid: false, name: 'Ні' }];

// const appealListData = [
//   { guid: 'Пан', name: 'Пан' },
//   { guid: 'Пані', name: 'Пані' }
// ];

const ButtonGroup = Button.Group;
const TabPane = Tabs.TabPane;

class FopFormContainer extends Component {
  constructor(props) {
    super(props);
    const {
      match: {
        params: { mode, guid },
      },
    } = this.props;

    this.guid = guid;
    this.loaded = false;

    this.initialState = {
      mode: 'create',
      isOpenModal: false,
    };

    this.state = {
      ...this.initialState,
      mode: mode || 'create',
    };
    this.storeKey = props.storeKey || 'rootCounterpartyContainer';
  }

  componentDidMount() {
    const {
      loadClassifiersForContainer,
      getSelfemployedByGuid,
      formHelpers: { phoneList, webSiteList, emailList },
      match: {
        params: { mode },
      },
    } = this.props;

    if (mode === 'view' || mode === 'edit') {
      getSelfemployedByGuid(this.storeKey, this.guid);
    }

    loadClassifiersForContainer(FOP_FORM_CONTAINER, {
      [PHONELIST]: { phoneRegistryParam: phoneList.requestParam },
      [EMAILLIST]: { emailRegistryParam: emailList.requestParam },
      [WEBSITELIST]: { webSiteRegistryParam: webSiteList.requestParam },
      [REF_DOCUMENT_TYPE_GENERAL_DOC_CLASSNAME]: { generalDocClassName: 'Document' },
    });
  }

  componentWillReceiveProps(nextProps) {
    const {
      foFormParam,
      history,
      // form: {
      //   setFieldsValue
      // },
      // fopFormParam: nextfopFormParam,
      match: {
        params: { mode: nextMode },
      },
    } = nextProps;

    const { mode } = this.state;

    if (mode !== nextMode) {
      this.setState({ mode: nextMode });
      if (nextMode === 'create') this.props.form.resetFields(); // [BUG-1442]
    }

    if (!foFormParam.guid && mode === RouteNames.CREATE) {
      history.push(`/${RouteNames.COUNTERPARTIES}/${RouteNames.FO}/${RouteNames.CREATE}`);
    }
  }

  componentDidUpdate = () => {
    const {
      fopFormParam: nextfopFormParam,
      match: {
        params: { mode: nextMode },
      },
      form: { setFieldsValue },
    } = this.props;

    if (
      !this.loaded &&
      nextfopFormParam.guid &&
      (nextMode === RouteNames.VIEW || nextMode === RouteNames.EDIT)
    ) {
      this.loaded = true;
      setFieldsValue({
        ...parseFo(nextfopFormParam.personDto),
        ...parseFop(nextfopFormParam),
      });
    }
  };

  componentWillUnmount() {
    this.props.resetCounterpartiesForm(this.storeKey);
  }

  updateFOP() {
    this.loaded = false;
    this.props.getSelfemployedByGuid(this.storeKey, this.guid);
  }

  goToRegister = () => {
    const { history } = this.props;

    history.push(`/${RouteNames.COUNTERPARTIES}/${RouteNames.REGISTER}`);
  };

  clearForm = () => this.props.form.resetFields();

  editForm = () => {
    this.props.history.push(
      `/${RouteNames.COUNTERPARTIES}/${RouteNames.FOP}/${RouteNames.EDIT}/${this.guid}`,
    );
  };

  createNewFo = () => {
    this.guid = '';
    this.setState(() => ({
      ...this.initialState,
    }));
    this.clearForm();
    this.props.resetCounterpartiesForm(this.storeKey);
    this.props.history.push(`/${RouteNames.COUNTERPARTIES}/${RouteNames.FO}/${RouteNames.CREATE}`);
  };

  handleCloseModal = () => {
    const { fopFormParam, history } = this.props;

    this.guid = fopFormParam.guid;
    history.push(`/${RouteNames.COUNTERPARTIES}/${RouteNames.FOP}/${RouteNames.VIEW}/${this.guid}`);
    this.setState(() => ({ isOpenModal: false }));
  };

  handleSubmit = (type, docArr) => {
    const { mode } = this.state;
    const {
      foFormParam,
      fopFormParam,
      postNewSelfemployed,
      putSelfemployedByGuid,
      form,
      classifiers,
    } = this.props;

    const curFields = [...Object.keys(fopDataFOPFields), ...Object.keys(fopRegistrationDataFields)];

    const showError = (errors) =>
      Modal.error({
        title: 'Помилка!',
        content: (
          <div>
            {errors.map((err, i) => (
              <p key={i}>
                {i + 1}
                .
                {err.message}
              </p>
            ))}
          </div>
        ),
      });

    const readResponse = (res) => {
      if (res.statusCode === 200) {
        if (this.props.inModal) {
          this.props.onSelfEmployedCreated(res.data);
          this.props.resetCounterpartiesForm(this.storeKey);
          this.clearForm();
        } else {
          this.setState(() => ({ isOpenModal: true }));
        }
      } else {
        showError(res.errors);
      }
    };

    form.validateFields(curFields, (err, values) => {
      if (!err) {
        const formFieldsTamplate = {
          ...foMainFields,
          ...foContactFields,
          ...fopDataFOPFields,
          ...fopRegistrationDataFields,
        };
        const post = getFopBEFields({
          ...getFormEntityData(values, classifiers, formFieldsTamplate),
          foData: fopFormParam && fopFormParam.personDto ? fopFormParam.personDto : foFormParam,
        });

        const put = {
          ...post,
          ...getObjGuidAndVersionId(fopFormParam),
          documents: fopFormParam.documents,
        };

        const getDoc = (guid) => {
          const document = classifiers.documents.find((doc) => doc.guid === guid);
          if (!document) {
            console.warn(`Document with guid "${guid}" not found in classifiers`); // eslint-disable-line
            return undefined;
          }
          return getObjGuidAndVersionId(document);
        };

        if (mode === 'create') postNewSelfemployed(this.storeKey, post).then(readResponse);
        if (mode === 'edit') {
          if (type === 'documents') {
            putSelfemployedByGuid(this.storeKey, {
              ...put,
              documents: docArr.map((guid) => {
                const doc = put.documents.find((el) => el.guid === guid);
                if (doc) return doc;
                return getDoc(guid);
              }),
            });
          } else {
            putSelfemployedByGuid(this.storeKey, put).then(readResponse);
          }
        }
        if (mode === RouteNames.VIEW) {
          if (type === 'documents') {
            putSelfemployedByGuid(this.storeKey, {
              ...put,
              documents: docArr.map((guid) => {
                const doc = put.documents.find((el) => el.guid === guid);
                if (doc) return doc;
                return getDoc(guid);
              }),
            });
          }
        }
      }
    });
  };

  handleAddDocuments = (docArr) => {
    this.handleSubmit('documents', docArr);
  };

  render() {
    const { mode, isOpenModal } = this.state;

    const { classifiers, fopFormParam } = this.props;

    const isCreateMode = mode === 'create';
    const isViewMode = mode === 'view';
    const modalText = mode === 'edit' ? ' відредагована' : 'створена';

    const sisi = {
      ...classifiers,
      isModelStatut: modelStatutListData,
    };

    const rows = () => (
      <Row>
        <Row type="flex" justify="center">
          <ButtonGroup>
            <Button onClick={() => (isViewMode ? this.editForm() : this.clearForm())}>
              <Icon type={isViewMode ? 'edit' : 'delete'} />
              {isViewMode ? 'Регадувати' : 'Очистити поля'}
            </Button>
            <Button
              onClick={() => {
                this.goToRegister();
              }}
            >
              <Icon type="logout" />
              Перейти до реєстру
            </Button>
          </ButtonGroup>
        </Row>
        <Row>
          <Form>
            {mode !== 'create' && (
              <Row>
                <Separator text="Основна інформація" />
                {mapFormItems({
                  viewMode: mode,
                  fields: foMainFields,
                  classifiers: sisi,
                  isViewMode: true,
                  form: this.props.form,
                })}
              </Row>
            )}
            {mode !== 'create' && (
              <Row>
                <Separator text="Контакти" />
                {mapFormItems({
                  viewMode: mode,
                  fields: foContactFields,
                  classifiers: sisi,
                  isViewMode: true,
                  form: this.props.form,
                })}
                <Row>
                  <Col span={12}>
                    <AddressList
                      allowEditFrom="region"
                      required
                      fieldName="addresses"
                      form={this.props.form}
                      isViewMode
                    />
                  </Col>
                </Row>
              </Row>
            )}
            <Row>
              <Separator text="Облікові дані ФОП" />
              {mapFormItems({
                viewMode: mode,
                fields: fopDataFOPFields,
                classifiers: sisi,
                isViewMode,
                form: this.props.form,
              })}
            </Row>
            <Row>
              <Separator text="Реєстраційні дані ФОП" />
              {mapFormItems({
                viewMode: mode,
                fields: fopRegistrationDataFields,
                classifiers: sisi,
                isViewMode,
                form: this.props.form,
              })}
              <Row type="flex" justify="end">
                <Button
                  disabled={isViewMode}
                  style={{ marginRight: '1.5rem' }}
                  type="primary"
                  onClick={() => {
                    this.handleSubmit();
                  }}
                >
                  Зберегти
                </Button>
              </Row>
            </Row>
          </Form>
        </Row>
      </Row>
    );

    return (
      <Row>
        <Tabs>
          <TabPane tab="Поля форми ФОП" key="0">
            {rows()}
          </TabPane>
          <TabPane tab="Організаційна структура" disabled={isCreateMode} key="1">
            <Structure
              curMode={mode}
              form={fopFormParam || {}}
              updateParent={() => {
                this.updateFOP();
              }}
            />
          </TabPane>
          <TabPane tab="Зв'язані документи" disabled={isCreateMode} key="2">
            <BoundedDocumentsTab
              routeName={RouteNames.FOP}
              curGuid={this.guid}
              form={this.props.form}
            />
          </TabPane>
          <TabPane tab="Банківські реквізити" disabled={isCreateMode} key="3">
            <BankDetails
              isViewMode={isViewMode}
              accountOwner={{
                ...fopFormParam,
                shortName: getCounterpartyLabel({
                  counterparty: {
                    ...fopFormParam.personDto,
                    counterpartyType: 'Person',
                  },
                  withoutType: true,
                }),
                itn: getCounterpartyITN({
                  counterparty: {
                    ...fopFormParam.personDto,
                    counterpartyType: 'Person',
                  },
                }),
              }}
            />
          </TabPane>
        </Tabs>

        <Modal
          visible={isOpenModal}
          title="Карта Фізичної особи"
          onCancel={this.handleCloseModal}
          footer={[
            <Button key="back" size="large" onClick={this.handleCloseModal}>
              Переглянути карту
            </Button>,
            <Button key="submit" type="primary" size="large" onClick={this.createNewFo}>
              Створити нову
            </Button>,
          ]}
        >
          <p>
            Карта успішно була
            {modalText}
            .
          </p>
        </Modal>
      </Row>
    );
  }
}

FopFormContainer.propTypes = {
  formHelpers: PropTypes.objectOf(PropTypes.object).isRequired,
  history: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]),
  classifiers: PropTypes.objectOf(PropTypes.array).isRequired,
  resetCounterpartiesForm: PropTypes.func.isRequired,
  match: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
  getSelfemployedByGuid: PropTypes.func.isRequired,
  postNewSelfemployed: PropTypes.func.isRequired,
  putSelfemployedByGuid: PropTypes.func.isRequired,
  loadClassifiersForContainer: PropTypes.func.isRequired,
  form: PropTypes.objectOf(PropTypes.any).isRequired,
  foFormParam: PropTypes.objectOf(PropTypes.any).isRequired,
  fopFormParam: PropTypes.objectOf(PropTypes.any).isRequired,
  inModal: PropTypes.bool,
  storeKey: PropTypes.string,
  onSelfEmployedCreated: PropTypes.func,
};

FopFormContainer.defaultProps = {
  history: null,
  inModal: false,
  onSelfEmployedCreated: null,
  storeKey: null,
};

const mapStateToProps = (state, props) => ({
  formHelpers: (
    state.counterparties.modals[props.storeKey || 'rootCounterpartyContainer'] || { forms: {} }
  ).forms.helpers,
  foFormParam: (
    state.counterparties.modals[props.storeKey || 'rootCounterpartyContainer'] || { forms: {} }
  ).forms.fo,
  fopFormParam: (
    state.counterparties.modals[props.storeKey || 'rootCounterpartyContainer'] || { forms: {} }
  ).forms.fop,
  classifiers: state.classifiers,
});

export default connect(mapStateToProps, CONTAINER_ACTIONS)(Form.create()(FopFormContainer));
