import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { Select, Button, Icon, Pagination } from 'antd';

// import wrapRegister from '../HOCs/wrapRegister';
import * as commonActions from '../../actions/index';
import * as counterpartiesRegisterActions from '../../actions/modules/counterparties/registerActions';
import * as usersActions from '../../actions/usersActions';
import * as appActions from '../../actions/appActions';

import TableToolbar from '../../components/common/toolbar/TableToolbar';
import FastFiltersPanel from '../../components/common/FastFiltersPanel';

import * as RouteNames from '../../constants/RouteNames';
import * as toolNames from '../../constants/TableToolNames';

// import { counterpartiesRegisterSelector } from '../../selectors';
import { counterpartyFilters } from '../../models/registers/filters/templates/counterparties';
import { getExportToXlsColumns } from '../../helpers/table';
import RegisterTableComponent from '../../components/RegisterTable/RegisterTableComponent';
import getCounterpartyRegisterRow from '../../models/registers/rowsGenerators/counterparties';

const ButtonGroup = Button.Group;
const Option = Select.Option;

const CONTAINER_ACTIONS = {
  ...appActions,
  ...usersActions,
  ...commonActions,
  ...counterpartiesRegisterActions,
};

const toolBarLeftButtons = [
  {
    action: `/${RouteNames.COUNTERPARTIES}/${RouteNames.FO}/${RouteNames.CREATE}`,
    label: '+ ФО/ФОП',
  },
  {
    action: `/${RouteNames.COUNTERPARTIES}/${RouteNames.LEGALPAGE}/${RouteNames.CREATE}`,
    label: '+ ЮО',
  },
];

// TODO: add save table settings to BE. Use getUserAppSettings()
// const keySettings = ['counterparties', 'register'];

const limitOption = ['25', '50', '100'];

class CounterpartyRegisterContainer extends Component {
  componentDidMount() {
    const { loadCounterparties, requestBody } = this.props;
    loadCounterparties(requestBody);
  }

  handleClickToolbarItem = (el) => {
    const { sortedColumns, requestCounterpartyXLS, requestBody, fastFilters } = this.props;
    const exportColumns = getExportToXlsColumns({
      ...sortedColumns.fixed,
      ...sortedColumns.fluid,
    });
    // TODO: need to be rewritten
    const counterpartyTypes =
      fastFilters.type.selected && fastFilters.type.selected.length > 0
        ? fastFilters.type.selected
        : ['LegalEntity', 'Person', 'SelfEmployed'];
    switch (el.title) {
      case toolNames.XLS:
        requestCounterpartyXLS({
          exportColumns,
          requestBody,
          counterpartyTypes,
        });
        break;
      default:
        break;
    }
  };

  handleSubmitFilters = () => {
    const {
      setValueRequestBody,
      setValuePages,
      fastFilters: {
        type: { selected },
      },
    } = this.props;

    setValueRequestBody('offset', '0');
    setValueRequestBody('counterpartyTypes', selected.length > 0 ? selected : undefined);
    setValuePages('currentPage', 0);
  };

  handleCancelFilters = () => {
    const { resetFilters } = this.props;

    resetFilters();
  };

  handleChangeFastFilters = (item) => (value) => {
    const { setValueFastFilters } = this.props;

    setValueFastFilters([item, 'selected'], value);
  };

  handleChangePage = (page, pageSize) => {
    const {
      pages: { currentPage },
    } = this.props;

    const newPage = page - 1;
    if (currentPage !== newPage) {
      const offset = (pageSize * page - pageSize).toString();
      this.props.setValueRequestBody('page', newPage);
      this.props.setValueRequestBody('offset', offset);
      this.props.setValuePages('currentPage', newPage);
    }
  };

  handleChangeLimit = (current, pageSize) => {
    this.props.setValueRequestBody('limit', pageSize);
    this.props.setValueRequestBody('page', 0);
    this.props.setValueRequestBody('offset', '0');
    this.props.setValuePages('currentPage', 0);
  };


  // TableToolbar functions ---------------------
  handleToggleToolbarItem = (value) => {
    const toolbarItems = this.props.tableToolbar;
    const curSection = Object.keys(toolbarItems).find((key) =>
      Object.keys(toolbarItems[key]).includes(value),
    );
    const isVisible = toolbarItems[curSection][value].isVisible;
    this.props.setValueAppSettings(
      ['components', 'counterparties', 'register', 'tableToolbar', curSection, value, 'isVisible'],
      !isVisible,
    );
  };

  handleChangeColumns = (obj) => {
    this.props.setValueAppSettings(
      ['components', 'counterparties', 'register', 'tableBody', 'columns', 'fluid'],
      { ...this.props.tableBody.columns.fluid, ...obj },
    );
  };
  // --------------------------------------------


  render() {
    const {
      sortedColumns,
      registers,
      tableToolbar,
      history,
      fastFilters,
      requestBody,
      requestBody: { limit },
      pages: { totalFinded, currentPage },
    } = this.props;

    const filters = () => {};
    const columns = Object.values(sortedColumns);

    return (
      <div className="content__table-items">
        <div className="content__table-menu">
          <TableToolbar
            items={tableToolbar}
            requestBody={requestBody}
            setValueRequestBody={this.props.setValueRequestBody}
            handleToggleToolbarItem={this.handleToggleToolbarItem}
            isActive={false}
            columns={sortedColumns}
            handleChangeColumns={this.handleChangeColumns}
            handleClickToolbarItem={this.handleClickToolbarItem}
            registryFiltersTemplate={counterpartyFilters}
          >
            <ButtonGroup>
              {toolBarLeftButtons.map((el) => (
                <Button type="primary" key={el.label} onClick={() => history.push(el.action)}>
                  {el.label}
                </Button>
              ))}
            </ButtonGroup>
          </TableToolbar>
        </div>

        <div className="content__fast-filters">
          <FastFiltersPanel
            useAll={this.handleSubmitFilters}
            cancelAll={this.handleCancelFilters}
            filters={filters}
          >
            <div className="table-menu__icon">
              <Icon type="filter" />
            </div>
            {Object.values(fastFilters).map((el) => (
              <Select
                key={el.id}
                mode="multiple"
                style={{ minWidth: 200 }}
                value={el.selected}
                allowClear
                placeholder="Виберіть тип контрагента"
                onChange={this.handleChangeFastFilters(el.id)}
              >
                {el.child.map((item) => (
                  <Option value={item.value} key={item.label}>
                    {item.label}
                  </Option>
                ))}
              </Select>
            ))}
          </FastFiltersPanel>
        </div>

        <RegisterTableComponent columns={columns} dataSource={registers} />

        <div className="content__pagination">
          <Pagination
            showSizeChanger
            pageSize={+limit}
            total={totalFinded}
            current={currentPage + 1}
            pageSizeOptions={limitOption}
            onChange={this.handleChangePage}
            onShowSizeChange={this.handleChangeLimit}
            showTotal={(total) => `Знайдено: ${total}`}
          />
        </div>
      </div>
    );
  }
}

CounterpartyRegisterContainer.propTypes = {
  history: PropTypes.objectOf(PropTypes.any).isRequired,
  tableToolbar: PropTypes.objectOf(PropTypes.any).isRequired,
  sortedColumns: PropTypes.shape({
    fixed: PropTypes.object,
    fluid: PropTypes.object,
  }).isRequired,
  requestBody: PropTypes.objectOf(PropTypes.any).isRequired,
  setValueRequestBody: PropTypes.func.isRequired,
  setValueFastFilters: PropTypes.func.isRequired,

  setValueAppSettings: PropTypes.func.isRequired,
  // handleChangeColumns: PropTypes.func.isRequired,
  // handleToggleToolbarItem: PropTypes.func.isRequired,
  // handleSubmitFilters: PropTypes.func.isRequired,
  // handleCancelFilters: PropTypes.func.isRequired,
  setValuePages: PropTypes.func.isRequired,
  resetFilters: PropTypes.func.isRequired,
  loadCounterparties: PropTypes.func.isRequired,
  fastFilters: PropTypes.objectOf(PropTypes.any).isRequired,
  registers: PropTypes.arrayOf(PropTypes.object).isRequired,
  requestCounterpartyXLS: PropTypes.func.isRequired,
};

const mapStateToProps = (state) => ({
  tableToolbar: state.user.appSettings.components.counterparties.register.tableToolbar,
  sortedColumns: state.user.appSettings.components.counterparties.register.tableBody.columns,
  requestBody: state.counterparties.registers.requestBody,
  registers: (state.counterparties.registers.registers || []).map(getCounterpartyRegisterRow),
  pages: state.counterparties.registers.pages,
  fastFilters: state.counterparties.registers.fastFilters,
});

export default withRouter(
  connect(mapStateToProps, CONTAINER_ACTIONS)(
    CounterpartyRegisterContainer,
    // wrapRegister(CounterpartyRegisterContainer, 'counterparties', 'loadCounterparties'),
  ),
);
