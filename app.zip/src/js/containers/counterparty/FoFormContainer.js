import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import _debounce from 'lodash/debounce';

import { Form, Modal, Button, Tabs, Row, Col, Icon } from 'antd';

import Separator from '../../components/common/form/Separator';
import AddressList from '../common/address/AddressList';

import { mapFormItems } from '../../helpers/formHelpers/mapFormHelper';
import {
  foMainFields,
  foContactFields,
  getFoShort,
  getFoFull,
  parseFo,
} from '../../models/formFields/counterparty/foFields';

import * as RouteNames from '../../constants/RouteNames';
import * as classifiersActions from '../../actions/classifiersActions';
import * as counterpartiesFoFopActions from '../../actions/modules/counterparties/foFopActions';
import * as counterpartiesCommonActions from '../../actions/modules/counterparties/commonActions';
import * as addressActions from '../../actions/modules/addressActions';
import * as commonActions from '../../actions/index';

import { FO_FORM_CONTAINER } from '../../constants/ContainerNames';
import {
  PHONELIST,
  EMAILLIST,
  WEBSITELIST,
  REF_DOCUMENT_TYPE_GENERAL_DOC_CLASSNAME,
} from '../../constants/ClassifiersNames';
import { getFeDate } from '../../helpers/geters';
import { getFormEntityData } from '../../helpers/formHelpers/formHelpers';
import { IPN } from '../../constants/ValidationClasses';
import BankDetails from './BankDetails';
import BoundedDocumentsTab from '../../components/counterparties/BoundedDocumentsTab';

const confirm = Modal.confirm;
const CONTAINER_ACTIONS = {
  ...classifiersActions,
  ...commonActions,
  ...addressActions,
  ...counterpartiesFoFopActions,
  ...counterpartiesCommonActions,
};

const appealListData = [{ guid: 'Пан', name: 'Пан' }, { guid: 'Пані', name: 'Пані' }];

const ButtonGroup = Button.Group;
const TabPane = Tabs.TabPane;

const personType = 'personType';
const REGULAR = 'REGULAR';

class FoFormContainer extends Component {
  constructor(props) {
    super(props);

    const {
      match: {
        params: { mode, guid },
      },
    } = this.props;

    this.guid = guid;
    this.loaded = false;
    this.convertToFop = false;

    this.initialState = {
      mode: 'create',
      isOpenModal: false,
      lastNamesList: [],
      firstNamesList: [],
      middleNamesList: [],
      showAfterPersonValidationModal: false,
      findedByValidationPersons: [],
    };

    this.state = {
      ...this.initialState,
      mode: mode || 'create',
    };
    this.storeKey = props.storeKey || 'rootCounterpartyContainer';
    this.handleFirstNameChanged = _debounce(
      this.byPredicateSearch(props.loadLastNames, 'lastNamesList'),
      500,
    );
    this.handleLastNameChanged = _debounce(
      this.byPredicateSearch(props.loadFirstNames, 'firstNamesList'),
      500,
    );
    this.handleMiddleNameChanged = _debounce(
      this.byPredicateSearch(props.loadMiddleNames, 'middleNamesList'),
      500,
    );
    this.formFields = this.getFormFields();
  }

  componentDidMount() {
    const {
      loadClassifiersForContainer,
      getPersonByGuid,
      formHelpers: { phoneList, webSiteList, emailList },
    } = this.props;

    const { mode } = this.state;

    if (mode === 'view' || mode === 'edit') {
      getPersonByGuid(this.storeKey, this.guid);
    }

    loadClassifiersForContainer(FO_FORM_CONTAINER, {
      [PHONELIST]: { phoneRegistryParam: phoneList.requestParam },
      [EMAILLIST]: { emailRegistryParam: emailList.requestParam },
      [WEBSITELIST]: { webSiteRegistryParam: webSiteList.requestParam },
      [REF_DOCUMENT_TYPE_GENERAL_DOC_CLASSNAME]: { generalDocClassName: 'Document' },
    });
  }

  componentWillReceiveProps(nextProps) {
    const {
      foFormParam: nextfoFormParam,
      match: {
        params: { mode: nextMode },
      },
      form,
    } = nextProps;

    const { mode } = this.state;

    if (mode !== nextMode) {
      this.setState({ mode: nextMode });
      if (nextMode === 'create') this.props.form.resetFields(); // [BUG-1442]
    }

    if (
      nextfoFormParam.guid &&
      (nextMode === RouteNames.VIEW || nextMode === RouteNames.EDIT) &&
      !this.loaded
    ) {
      this.loaded = true;
      this.props.form.setFieldsValue(parseFo(nextfoFormParam));
    }

    if (form.getFieldValue(personType) !== REGULAR) {
      form.resetFields(IPN);
    }
  }

  componentWillUnmount() {
    if (!this.convertToFop) {
      this.props.resetCounterpartiesForm(this.storeKey);
    }
  }

  goToRegister = () => {
    const { history } = this.props;

    history.push(`/${RouteNames.COUNTERPARTIES}/${RouteNames.REGISTER}`);
  };

  clearForm = () => this.props.form.resetFields();

  goToFopForm = () => {
    this.convertToFop = true;

    if (this.props.inModal) {
      this.props.convertToFop();
    } else {
      this.props.history.push(
        `/${RouteNames.COUNTERPARTIES}/${RouteNames.FOP}/${RouteNames.CREATE}`,
      );
    }
  };

  showSavePersonConfirmDialog = (counterpatiesListToDisplay, onConfirmed) => {
    const getCounterpatyString = (counterparty) => {
      const {
        lastName = '',
        fistName = '',
        middleName = '',
        dateFrom = '',
        itn = '',
      } = counterparty;
      return `${lastName} ${fistName} ${middleName} ${
        dateFrom ? getFeDate(counterparty.dateFrom) : dateFrom
      } ${itn}`;
    };

    confirm({
      title: 'За введеними даними знайдено співпадіння',
      content: (
        <ul>{counterpatiesListToDisplay.map((item) => <li>{getCounterpatyString(item)}</li>)}</ul>
      ),
      okText: 'Зберегти',
      onOk() {
        onConfirmed();
      },
      onCancel() {},
      cancelText: 'Скасувати',
    });
  };

  validatePersonEntity = (personData, doSave) => {
    const {
      match: {
        params: { mode, guid },
      },
      getPersonsByPersonData,
    } = this.props;

    getPersonsByPersonData(personData).then((serverResponce) => {
      const findedPersons = (serverResponce && serverResponce.data) || [];
      if (findedPersons && findedPersons.length) {
        const counterpatiesListToDisplay =
          mode === RouteNames.EDIT && guid
            ? findedPersons.filter((item) => item.guid !== guid)
            : findedPersons;
        if (counterpatiesListToDisplay && counterpatiesListToDisplay.length) {
          this.showSavePersonConfirmDialog(counterpatiesListToDisplay, doSave);
        } else {
          doSave();
        }
      } else {
        doSave();
      }
    });
  };

  handleSubmit = (type = 'short') => {
    const { mode } = this.state;
    const { foFormParam, postNewPerson, putPersonByGuid, form, classifiers } = this.props;

    let curFields = Object.keys(foMainFields);
    if (type === 'full' || type === 'full+fop') {
      curFields = curFields.concat([...Object.keys(foMainFields), ...Object.keys(foContactFields)]);
    }

    const showError = (errors) =>
      Modal.error({
        title: 'Помилка!',
        content: (
          <div>
            {errors.map((err, i) => (
              <p key={i}>
                {i + 1}
                .
                {err.message}
              </p>
            ))}
          </div>
        ),
      });

    const readResponse = (res) => {
      if (res.statusCode === 200) {
        if (this.props.inModal) {
          this.props.onFoCreated(res.data);
          this.props.resetCounterpartiesForm(this.storeKey);
          this.clearForm();
        } else {
          this.setState(() => ({ isOpenModal: true }));
        }
      } else {
        showError(res.errors);
      }
    };

    form.validateFields(curFields, (err, values) => {
      if (!err) {
        const getDtoByType = {
          short: getFoShort,
          full: getFoFull,
          'full+fop': getFoFull,
        };
        const formFieldsTamplate = {
          ...foMainFields,
          ...foContactFields,
        };
        const normilizedValue = getFormEntityData(values, classifiers, formFieldsTamplate);
        const counterpartyData = getDtoByType[type](normilizedValue);
        const doSave = () => {
          if (mode === RouteNames.CREATE) {
            if (type === 'short' || type === 'full')
              postNewPerson(this.storeKey, counterpartyData).then(readResponse);
            if (type === 'full+fop') {
              postNewPerson(this.storeKey, counterpartyData).then((res) => {
                if (res.statusCode === 200) {
                  this.clearForm();
                  this.goToFopForm();
                } else {
                  showError(res.errors);
                }
              });
            }
          }

          if (mode === RouteNames.EDIT) {
            if (type === 'short' || type === 'full') {
              putPersonByGuid(this.storeKey, {
                ...foFormParam,
                ...counterpartyData,
              }).then(readResponse);
            }
            if (type === 'full+fop') {
              putPersonByGuid(this.storeKey, {
                ...foFormParam,
                ...counterpartyData,
              }).then((res) => {
                if (res.statusCode === 200) {
                  this.goToFopForm();
                } else {
                  showError(res.errors);
                }
              });
            }
          }
        };

        this.validatePersonEntity(counterpartyData, doSave);
      }
    });
  };

  editForm = () => {
    this.props.history.push(
      `/${RouteNames.COUNTERPARTIES}/${RouteNames.FO}/${RouteNames.VIEW}/${this.guid}`,
    );
  };

  handleCloseModal = () => {
    const { foFormParam, history } = this.props;

    this.guid = foFormParam.guid;
    history.push(`/${RouteNames.COUNTERPARTIES}/${RouteNames.FO}/${RouteNames.VIEW}/${this.guid}`);
    this.setState(() => ({ isOpenModal: false }));
  };

  createNewFo = () => {
    this.guid = '';
    this.setState(() => ({
      ...this.initialState,
    }));
    this.clearForm();
    this.props.resetCounterpartiesForm(this.storeKey);
    this.props.history.push(`/${RouteNames.COUNTERPARTIES}/${RouteNames.FO}/${RouteNames.CREATE}`);
  };

  handleAddDocuments = (docArr) => {
    this.handleSubmit('documents', docArr);
  };

  validateIpnUnique = (rule, value, callback) => {
    const { foFormParam } = this.props;
    const { mode } = this.state;

    if (value && value.length === 10) {
      if (mode === 'edit' && foFormParam.itn === value) {
        callback();
      } else {
        this.props.getFoByIpn(value).then((serverResponce) => {
          const findedLegalEntities = serverResponce.data;
          if (findedLegalEntities.length === 0) {
            callback();
          } else {
            callback(rule.message);
          }
        });
      }
    } else {
      callback();
    }
  };

  byPredicateSearch = (action, storegePlace) => (predicate) => {
    const regexpr = new RegExp("(^[A-Za-z-]+$)|(^[А-Яа-яёЁЇїІіЄєҐґ`'ʼ-]+$)");
    if (predicate && predicate.length > 1 && regexpr.test(predicate)) {
      action(predicate).then((serverResponce) =>
        this.setState(() => ({
          [storegePlace]:
            serverResponce && serverResponce.data && serverResponce.data.content
              ? serverResponce.data.content
              : [],
        })),
      );
    }
  };

  handlePersonTypeChanged = ({ target: { value } }) => {
    const isRegular = value === REGULAR;
    const requiredRule = this.formFields.foMainFields.IPN.rules.find((rule) =>
      // eslint-disable-next-line
      rule.hasOwnProperty('required'),
    );
    requiredRule.required = isRegular;
    this.formFields.foMainFields.IPN = {
      ...this.formFields.foMainFields.IPN,
      readOnly: !isRegular,
    };
  };

  getFormFields = () => {
    const res = {
      foMainFields: {
        ...foMainFields,
        lastName: {
          ...foMainFields.lastName,
          search: {
            handler: this.handleFirstNameChanged,
            result: this.state.lastNamesList,
          },
        },
        firstName: {
          ...foMainFields.firstName,
          search: {
            handler: this.handleLastNameChanged,
            result: this.state.firstNamesList,
          },
        },
        middleName: {
          ...foMainFields.middleName,
          search: {
            handler: this.handleMiddleNameChanged,
            result: this.state.middleNamesList,
          },
        },
        IPN: {
          ...foMainFields.IPN,
          rules: [
            ...foMainFields.IPN.rules,
            {
              validator: this.validateIpnUnique,
              message: 'Контрагент з таким ІПН вже існує',
            },
          ],
        },
        personType: {
          ...foMainFields.personType,
          onChange: this.handlePersonTypeChanged,
        },
      },
      foContactFields,
    };

    return res;
  };

  render() {
    const { mode, isOpenModal } = this.state;

    const {
      foFormParam: { selfEmployedDto },
      form,
      classifiers,
    } = this.props;

    const isViewMode = mode === 'view';
    const modalText = mode === 'edit' ? ' відредагована' : 'створена';
    const isCreateMode = mode === 'create';

    const classifiersWithMocks = {
      ...classifiers,
      appeal: appealListData,
    };

    const rows = () => (
      <Row>
        <Row type="flex" justify="center">
          <ButtonGroup>
            <Button onClick={() => (isViewMode ? this.editForm() : this.clearForm())}>
              <Icon type={isViewMode ? 'edit' : 'delete'} />
              {isViewMode ? 'Редагувати' : 'Очистити поля'}
            </Button>
            <Button
              onClick={() => {
                this.goToRegister();
              }}
            >
              <Icon type="logout" />
              Перейти до реєстру
            </Button>
          </ButtonGroup>
        </Row>
        <Row>
          <Form>
            <Row>
              <Separator text="Основна інформація" />
              {mapFormItems({
                formName: 'personForm',
                viewMode: mode,
                fields: this.formFields.foMainFields,
                classifiers: classifiersWithMocks,
                isViewMode,
                form,
              })}
              {mode === 'create' && (
                <Row type="flex" justify="end">
                  <Button
                    disabled={isViewMode}
                    style={{ marginRight: '1.5rem' }}
                    type="primary"
                    onClick={() => this.handleSubmit('short')}
                  >
                    Створити миттєво
                  </Button>
                </Row>
              )}
            </Row>
            <Row>
              <Separator text="Контакти" />
              {mapFormItems({
                viewMode: mode,
                fields: this.formFields.foContactFields,
                classifiers: classifiersWithMocks,
                isViewMode,
                form,
              })}
              <Row className="global_mb20">
                <Col span={24}>
                  <AddressList
                    allowEditFrom="region"
                    required
                    fieldName="addresses"
                    form={this.props.form}
                    isViewMode={isViewMode}
                  />
                </Col>
              </Row>
            </Row>
            <Row type="flex" justify="end">
              <ButtonGroup style={{ marginRight: '1.5rem' }}>
                <Button
                  disabled={isViewMode}
                  type="primary"
                  onClick={() => {
                    this.handleSubmit('full');
                  }}
                >
                  <Icon type="save" />
                  Зберегти
                </Button>
                {!(selfEmployedDto && selfEmployedDto.guid) ? (
                  <Button
                    disabled={isViewMode}
                    type="primary"
                    onClick={() => {
                      this.handleSubmit('full+fop');
                    }}
                  >
                    <Icon type="user-add" />
                    Перевести до ФОП
                  </Button>
                ) : null}
              </ButtonGroup>
            </Row>
          </Form>
        </Row>
      </Row>
    );

    return (
      <div>
        <Tabs>
          <TabPane tab="Поля форми ФО" key="0">
            {rows()}
          </TabPane>
          <TabPane tab="Зв'язані документи" disabled={isCreateMode} key="1">
            <BoundedDocumentsTab routeName={RouteNames.FO} curGuid={this.guid} form={form} />
          </TabPane>
          <TabPane tab="Банківські реквізити" disabled={isCreateMode} key="2">
            <BankDetails accountOwner={this.props.foFormParam} isViewMode={isViewMode} />
          </TabPane>
        </Tabs>
        <Modal
          visible={isOpenModal}
          title="Карта Фізичної особи"
          onCancel={this.handleCloseModal}
          footer={[
            <Button key="back" size="large" onClick={this.handleCloseModal}>
              Переглянути карту
            </Button>,
            <Button key="submit" type="primary" size="large" onClick={this.createNewFo}>
              Створити нову
            </Button>,
          ]}
        >
          <p>
            Карта успішно була
            {modalText}
            .
          </p>
        </Modal>
      </div>
    );
  }
}

FoFormContainer.propTypes = {
  formHelpers: PropTypes.objectOf(PropTypes.object).isRequired,
  foFormParam: PropTypes.objectOf(PropTypes.any).isRequired,
  getPersonByGuid: PropTypes.func.isRequired,
  postNewPerson: PropTypes.func.isRequired,
  putPersonByGuid: PropTypes.func.isRequired,
  getPersonsByPersonData: PropTypes.func.isRequired,
  resetCounterpartiesForm: PropTypes.func.isRequired,
  loadLastNames: PropTypes.func.isRequired,
  loadFirstNames: PropTypes.func.isRequired,
  loadMiddleNames: PropTypes.func.isRequired,
  history: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]),
  classifiers: PropTypes.objectOf(PropTypes.array).isRequired,
  match: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
  form: PropTypes.objectOf(PropTypes.any).isRequired,
  loadClassifiersForContainer: PropTypes.func.isRequired,
  getFoByIpn: PropTypes.func.isRequired,
  inModal: PropTypes.bool,
  storeKey: PropTypes.string,
  onFoCreated: PropTypes.func,
  convertToFop: PropTypes.func,
};

FoFormContainer.defaultProps = {
  history: null,
  inModal: false,
  onFoCreated: null,
  convertToFop: () => {
    console.log('convertToFop ran.'); // eslint-disable-line
  },
  storeKey: null,
};

const mapStateToProps = (state, props) => ({
  formHelpers: (
    state.counterparties.modals[props.storeKey || 'rootCounterpartyContainer'] || { forms: {} }
  ).forms.helpers,
  foFormParam: (
    state.counterparties.modals[props.storeKey || 'rootCounterpartyContainer'] || { forms: {} }
  ).forms.fo,
  classifiers: state.classifiers,
});

export default connect(mapStateToProps, CONTAINER_ACTIONS)(Form.create()(FoFormContainer));
