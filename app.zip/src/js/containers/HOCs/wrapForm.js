import React from 'react';
import PropTypes from 'prop-types';
import { Row, Modal, Button, Icon } from 'antd';

const ButtonGroup = Button.Group;

const wrapForm = (
  WrappedComponent,
  {
    containerName,
    additionalClassifier,
    titleText,
    parseToFE,
    routes: { moduleRoute, componentRoute, registerRoute },
    withoutClassifiers,

    // if we have chained forms
    parseDoubleToFE,
    doubleFieldName,
  },
) =>
  class extends React.Component {
    static propTypes = {
      match: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
      history: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any])
        .isRequired,

      form: PropTypes.objectOf(PropTypes.any).isRequired,

      loadClassifiersForContainer: PropTypes.func.isRequired,

      formParam: PropTypes.objectOf(PropTypes.any).isRequired,
      getForm: PropTypes.func.isRequired,
      resetForm: PropTypes.func.isRequired,
      resetDoneStatus: PropTypes.func.isRequired,
    };

    constructor(props) {
      super(props);

      const curMode = this.props.match.params.mode || 'create';
      this.curGuid = this.props.match.params.guid || '';

      this.state = {
        curMode,
        dialogOpen: false,
        dialogMessage: '',
      };

      this.loaded = false;
    }

    componentDidMount = () => {
      const { getForm, form } = this.props;
      const { curMode } = this.state;

      if (!withoutClassifiers) {
        this.props.loadClassifiersForContainer(containerName, additionalClassifier);
      }

      if (curMode === 'view' || curMode === 'edit') {
        getForm(this.curGuid).then((res) => {
          if (doubleFieldName) {
            const doubleData = (res.data || {})[doubleFieldName];
            form.setFieldsValue(parseDoubleToFE(doubleData));
          }
        });
      }
    };

    componentWillReceiveProps(nextProps) {
      const {
        formParam: { createdForm, status, errors },
        match: {
          params: { mode, guid },
        },
        resetForm,
        resetDoneStatus,
        getForm,
        form,
      } = nextProps;

      if (this.state.curMode !== mode) {
        this.setState({ curMode: mode });
        if (mode === 'create') {
          resetForm();
          form.resetFields();
        }
        if (mode === 'edit' || mode === 'view') {
          this.curGuid = guid;
          this.loaded = false;
          if (!createdForm.guid) getForm(this.curGuid);
        }
      }

      if (createdForm.guid && (mode === 'view' || mode === 'edit') && !this.loaded) {
        this.loaded = true;
        form.setFieldsValue(parseToFE(createdForm));
        if (doubleFieldName) form.setFieldsValue(parseDoubleToFE(createdForm[doubleFieldName]));
      }

      if (status.isDone) {
        this.loaded = true;
        this.curGuid = createdForm.guid;
        form.setFieldsValue(parseToFE(createdForm));
        if (doubleFieldName) form.setFieldsValue(parseDoubleToFE(createdForm[doubleFieldName]));
        this.handleToggleDialog();
        resetDoneStatus();
      }

      if (errors.length > 0) {
        const errorsText = errors.map((el) => el.message).join(', ');
        this.setState({ dialogMessage: errorsText, dialogOpen: true });
        resetForm();
      }
    }

    componentWillUnmount() {
      this.props.resetForm();
    }

    handleCreateNew = () => {
      this.changeRouteTo(`/${moduleRoute}/${componentRoute}/create`);
      this.curGuid = '';
      this.loaded = false;
      this.props.form.resetFields();
      this.props.resetForm();
      this.handleToggleDialog();
    };

    clearForm = () => {
      this.props.form.resetFields();
    };

    changeRouteTo = (route) => {
      this.props.history.push(route);
    };

    handleToggleDialog = (isOpened) => {
      if (isOpened !== undefined) this.setState({ dialogOpen: isOpened });
      else this.setState((prevState) => ({ dialogOpen: !prevState.dialogOpen }));
    };

    handleDialogCancel = () => {
      this.handleToggleDialog();
      this.switchToViewMode();
    };

    switchToEditMode = () => {
      this.changeRouteTo(`/${moduleRoute}/${componentRoute}/edit/${this.curGuid}`);
    };

    switchToViewMode = () => {
      this.changeRouteTo(`/${moduleRoute}/${componentRoute}/view/${this.curGuid}`);
    };

    renderButtons = (isViewMode) => (
      <Row type="flex" justify="center">
        <ButtonGroup>
          {isViewMode && (
            <Button
              onClick={() => {
                this.switchToEditMode();
              }}
            >
              <Icon type="edit" />
              Редагувати
            </Button>
          )}
          {!isViewMode && (
            <Button
              onClick={() => {
                this.clearForm();
              }}
            >
              <Icon type="delete" />
              Очистити поля
            </Button>
          )}
          <Button
            onClick={() => {
              this.changeRouteTo(`/${moduleRoute}/${registerRoute}`);
            }}
          >
            <Icon type="logout" />
            Перейти до реєстру
          </Button>
        </ButtonGroup>
      </Row>
    );

    render() {
      const { curMode, dialogMessage } = this.state;

      const dialogText = curMode === 'create' ? 'створено' : 'відредаговано';

      return (
        <Row>
          <Modal
            title={titleText}
            visible={this.state.dialogOpen}
            onOk={() => {
              this.handleCreateNew();
            }}
            onCancel={() => {
              this.handleDialogCancel();
            }}
            cancelText="Переглянути"
            okText="Перейти до створення"
          >
            {dialogMessage === '' ? (
              <p>{`Форму успішно ${dialogText}`}</p>
            ) : (
              <p>{`${dialogMessage}`}</p>
            )}
          </Modal>

          <WrappedComponent
            {...this.props}
            curGuid={this.curGuid}
            curMode={this.state.curMode}
            renderButtons={this.renderButtons}
          />
        </Row>
      );
    }
  };

export default wrapForm;
