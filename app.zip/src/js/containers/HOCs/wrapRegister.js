import React from 'react';
import PropTypes from 'prop-types';
import _isEqual from 'lodash/isEqual';

import { Pagination } from 'antd';
import Table from '../../components/common/table/Table';

const limitOption = ['25', '50', '100'];

const wrapRegister = (WrappedComponent, registerName, loadRegisterFuncName) =>
  class extends React.Component {
    static propTypes = {
      history: PropTypes.objectOf(PropTypes.any).isRequired,

      pages: PropTypes.shape({
        currentPage: PropTypes.number,
        totalPages: PropTypes.number,
        totalFinded: PropTypes.number,
      }).isRequired,
      requestBody: PropTypes.shape({
        limit: PropTypes.string,
        offset: PropTypes.string,
        page: PropTypes.string,
        counterparty_type: PropTypes.arrayOf(PropTypes.string),
        sortList: PropTypes.object,
      }),
      tableToolbar: PropTypes.objectOf(PropTypes.any),
      tableBody: PropTypes.objectOf(PropTypes.any).isRequired,
      registers: PropTypes.arrayOf(PropTypes.object).isRequired,

      setValueRequestBody: PropTypes.func.isRequired,
      setValueAppSettings: PropTypes.func.isRequired,
      setValuePages: PropTypes.func.isRequired,
    };

    static defaultProps = {
      requestBody: {},
      tableToolbar: {},
      // fastFilters: {},
    };

    componentDidMount() {
      const { requestBody } = this.props;
      this.props[loadRegisterFuncName](requestBody);
    }

    componentWillReceiveProps(nextProps) {
      const { requestBody } = this.props;
      const { requestBody: nextRequestBody } = nextProps;
      if (!_isEqual(requestBody, nextRequestBody)) {
        this.props[loadRegisterFuncName](nextRequestBody);
      }
    }

    // TableToolbar functions ---------------------
    handleToggleToolbarItem = (value) => {
      const toolbarItems = this.props.tableToolbar;
      const curSection = Object.keys(toolbarItems).find((key) =>
        Object.keys(toolbarItems[key]).includes(value),
      );
      const isVisible = toolbarItems[curSection][value].isVisible;
      this.props.setValueAppSettings(
        ['components', registerName, 'register', 'tableToolbar', curSection, value, 'isVisible'],
        !isVisible,
      );
    };

    handleChangeColumns = (obj) => {
      this.props.setValueAppSettings(
        ['components', registerName, 'register', 'tableBody', 'columns', 'fluid'],
        { ...this.props.tableBody.columns.fluid, ...obj },
      );
    };
    // --------------------------------------------

    // FastFiltersPanel functions -----------------
    handleSubmitFilters = () => {
      // TODO: handleSubmitFilters
    };

    handleCancelFilters = () => {
      // TODO: handleCancelFilters
    };
    //---------------------------------------------

    // Table functions-----------------------------
    checkedItems = [];

    synchronizeCheckedArr = (arr = [], rows) => {
      this.checkedItems = arr.map((key) => rows[key].guid);
    };

    handleSortColumn = (colName) => {
      const {
        setValueRequestBody,
        setValuePages,
        requestBody: { sortList },
      } = this.props;

      // const value = sortList[colName].value === '-' ? '+' : '-';
      let value;
      if (sortList[colName] && sortList[colName].value) {
        value = sortList[colName].value === '-' ? '+' : '-';
      } else {
        value = '+';
      }
      setValueRequestBody(['sortList'], {
        [colName]: {
          value,
        },
      });
      setValuePages('currentPage', 0);
    };

    saveTableSettings = () => {
      // TODO: saveTableSettings
    };
    // --------------------------------------------

    // Pagination functions -----------------------
    handleChangePage = (page, pageSize) => {
      const {
        pages: { currentPage },
      } = this.props;

      const newPage = page - 1;
      if (currentPage !== newPage) {
        const offset = (pageSize * page - pageSize).toString();
        this.props.setValueRequestBody('page', newPage);
        this.props.setValueRequestBody('offset', offset);
        this.props.setValuePages('currentPage', newPage);
      }
    };

    handleChangeLimit = (current, pageSize) => {
      this.props.setValueRequestBody('limit', pageSize);
      this.props.setValueRequestBody('page', 0);
      this.props.setValueRequestBody('offset', '0');
      this.props.setValuePages('currentPage', 0);
    };
    // ------------------------------------------

    render() {
      const {
        tableBody,
        registers,
        requestBody: { limit, sortList },
        pages: { totalFinded, currentPage },
        history,
      } = this.props;

      return (
        <div className="content__table-items">
          <div>
            <WrappedComponent
              {...this.props}
              handleChangeColumns={this.handleChangeColumns}
              handleToggleToolbarItem={this.handleToggleToolbarItem}
              handleSubmitFilters={this.handleSubmitFilters}
              handleCancelFilters={this.handleCancelFilters}
            />
          </div>

          <div className="content__table">
            <Table
              history={history}
              columnsData={tableBody.columns || {}}
              rows={registers}
              saveTableWidthSettings={this.saveTableSettings}
              sortList={sortList}
              handleSortColumn={this.handleSortColumn}
              syncronizeCheckedArr={this.synchronizeCheckedArr}
            />
          </div>

          <div className="content__pagination">
            <Pagination
              showSizeChanger
              pageSize={+limit}
              total={totalFinded}
              current={currentPage + 1}
              pageSizeOptions={limitOption}
              onChange={this.handleChangePage}
              onShowSizeChange={this.handleChangeLimit}
              showTotal={(total) => `Знайдено: ${total}`}
            />
          </div>
        </div>
      );
    }
  };

export default wrapRegister;
