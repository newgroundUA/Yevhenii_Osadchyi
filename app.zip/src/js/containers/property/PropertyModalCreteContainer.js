import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import PropTypes from 'prop-types';
import { Select, Button, Modal, Row, Alert } from 'antd';

import * as classifiersActions from '../../actions/classifiersActions';
import * as propertyModalActions from '../../actions/modules/property/propertyModalActions';

// import Modal from '../../components/common/Modal';
import * as routes from '../../constants/RouteNames';

import { STATE_PROPERTY_OF_ACCOUNTING_ITEM } from '../../constants/ClassifiersNames';

const Option = Select.Option;

// TODO: нахуй тут все пеперисать

class PropertyModalCreateContainer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      disable_quick_search: false,
      disable_detailed_search: false,
      // sectionName: '',
      // partitionName: '',
      // subPartitionName: '',
      selectedForm: undefined,
      selectedSection: undefined,
      selectedPartition: undefined,
      selectedSubPartition: undefined,
      selectedGroup: undefined,
      selectedClass: undefined,
      selectedSubClass: undefined,
    };
  }

  // ACTIONS

  componentDidMount() {
    this.props.loadSpecifiedClassifiers([STATE_PROPERTY_OF_ACCOUNTING_ITEM]);
  }

  componentWillUnmount() {
    this.clearSelectedValues();
  }

  handleConvertSelectData = (data) =>
    data.map((item) => (
      <Option key={item.guid} value={item.guid}>
        {item.name}
      </Option>
    ));

  handleChange = (value, name, data) => {
    let type = null;

    switch (name) {
      case 'selectedForm':
        [type] = data.filter((s) => s.guid === value);
        this.props.setStatePropertyType(type.statePropertyType, type.name, type.guid);
        this.setState({
          disable_detailed_search: true,
          selectedForm: value,
          selectedSection: undefined,
          selectedPartition: undefined,
          selectedSubPartition: undefined,
          selectedGroup: undefined,
          selectedClass: undefined,
          selectedSubClass: undefined,
        });
        break;

      case 'selectedSection':
        this.setState({
          disable_detailed_search: false,
          selectedForm: undefined,
          selectedSection: value,
          selectedPartition: undefined,
          selectedSubPartition: undefined,
          selectedGroup: undefined,
          selectedClass: undefined,
          selectedSubClass: undefined,
        });
        break;

      case 'selectedPartition':
        this.setState({
          selectedPartition: value,
          selectedSubPartition: undefined,
          selectedGroup: undefined,
          selectedClass: undefined,
          selectedSubClass: undefined,
        });
        break;

      case 'selectedSubPartition':
        this.setState({
          selectedSubPartition: value,
          selectedGroup: undefined,
          selectedClass: undefined,
          selectedSubClass: undefined,
        });
        break;

      case 'selectedGroup':
        this.setState({
          selectedGroup: value,
          selectedClass: undefined,
          selectedSubClass: undefined,
        });
        break;

      case 'selectedClass':
        this.setState({
          selectedClass: value,
          selectedSubClass: undefined,
        });
        break;

      case 'selectedSubClass':
        [type] = data.filter((s) => s.guid === value);
        this.props.setStatePropertyType(type.statePropertyType, type.name, type.guid);
        this.setState({
          selectedForm: value,
          selectedSubClass: type.subClassName,
        });
        break;

      default:
    }
  };

  clearSelectedValues = () => {
    this.setState({
      selectedForm: undefined,
      selectedSection: undefined,
      selectedPartition: undefined,
      selectedSubPartition: undefined,
      selectedGroup: undefined,
      selectedClass: undefined,
      selectedSubClass: undefined,
    });
  };

  handleBlur = () => {};

  handleFocus = () => {};

  // temporal!
  getPropFormName = (beType) => {
    const mappingObj = {
      Building: routes.BUILDINGS_FORM,
      Premise: routes.PREMISE_FORM,
      Stead: routes.STEAD_FORM,
      Field: routes.FIELD_FORM,
      Road: routes.ROAD_FORM,
      Pipeline: routes.PIPELINE_FORM,
      RailRoad: routes.RAILROAD_FORM,
      ElectricityCable: routes.ELECTRICITY_FORM,
      Construction: routes.CONSTRUCTION_FORM,
      Equipment: routes.EQUIPMENT_FORM,
      WhTransport: routes.WHTRANSPORT_FORM,
      Plant: routes.PLANT_FORM,
      Animal: routes.ANIMAL_FORM,
      IntellRight: routes.INTELLRIGHT_FORM,
    };
    return mappingObj[beType] || routes.BUILDINGS_FORM;
  };

  handleGoToForm = () => {
    const { selectedFormType } = this.props;
    this.props.changeCurAccountingType(this.state.selectedForm);
    this.props.history.push(`/${routes.PROPERTY}/${this.getPropFormName(selectedFormType)}/create`);
  };

  render() {
    const { forms } = this.props;

    const {
      selectedForm,
      selectedSection,
      selectedPartition,
      selectedSubPartition,
      selectedGroup,
      selectedClass,
      selectedSubClass,
    } = this.state;

    let sections = [];
    let partitions = [];
    let subPartitions = [];
    let groups = [];
    let classes = [];
    let subClasses = [];

    if (forms.length) {
      sections = forms
        .map((el) => el.sectionName)
        .reduce((acc, curr) => (acc.indexOf(curr) >= 0 ? acc : [...acc, curr]), []);
    }

    if (forms.length && selectedSection) {
      partitions = forms
        .filter((el) => el.sectionName === selectedSection)
        .map((el) => el.partitionName)
        .reduce((acc, curr) => (acc.indexOf(curr) >= 0 ? acc : [...acc, curr]), []);
    }

    if (forms.length && selectedPartition) {
      subPartitions = forms
        .filter(
          (el) => el.sectionName === selectedSection && el.partitionName === selectedPartition,
        )
        .map((el) => el.subPartitionName)
        .reduce((acc, curr) => (acc.indexOf(curr) >= 0 ? acc : [...acc, curr]), []);
    }

    if (forms.length && selectedSubPartition) {
      groups = forms
        .filter(
          (el) =>
            el.sectionName === selectedSection &&
            el.partitionName === selectedPartition &&
            el.subPartitionName === selectedSubPartition,
        )
        .map((el) => el.groupName)
        .reduce((acc, curr) => (acc.indexOf(curr) >= 0 ? acc : [...acc, curr]), []);
    }

    if (forms.length && selectedGroup) {
      classes = forms
        .filter(
          (el) =>
            el.sectionName === selectedSection &&
            el.partitionName === selectedPartition &&
            el.subPartitionName === selectedSubPartition &&
            el.groupName === selectedGroup,
        )
        .map((el) => el.className)
        .reduce((acc, curr) => (acc.indexOf(curr) >= 0 ? acc : [...acc, curr]), []);
    }

    if (forms.length && selectedClass) {
      subClasses = forms.filter(
        (el) =>
          el.sectionName === selectedSection &&
          el.partitionName === selectedPartition &&
          el.subPartitionName === selectedSubPartition &&
          el.groupName === selectedGroup &&
          el.className === selectedClass,
      );
    }

    const quickSearchClasses = this.state.disable_quick_search
      ? 'property-create-modal-section__quick_search disable'
      : 'property-create-modal-section__quick_search';
    const detailedSearchClasses = this.state.disable_detailed_search
      ? 'property-create-modal-section__detailed_search disable'
      : 'property-create-modal-section__detailed_search';

    // debugger;

    const PropertyModalSelect = ({ children, placeholder, name, disabled, value }) => (
      <Select
        getPopupContainer={() =>
          document.getElementsByClassName('property-create-modal-section')[0]
        }
        showSearch
        placeholder={placeholder}
        optionFilterProp="children"
        name="forms"
        dropdownStyle={{ zIndex: 9999 }}
        onChange={(e) => {
          this.handleChange(e, name, forms);
        }}
        disabled={disabled}
        onFocus={this.handleFocus}
        onBlur={this.handleBlur}
        value={value}
        filterOption={(input, option) =>
          option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
        }
      >
        {children}
      </Select>
    );

    const ExpandedPropertyModalSelect = ({
      children,
      placeholder,
      name,
      disabled,
      value,
      title,
    }) => (
      <div className="search-group">
        <h5>{title}</h5>
        <PropertyModalSelect
          placeholder={placeholder}
          name={name}
          value={value}
          disabled={disabled}
        >
          {children}
        </PropertyModalSelect>
      </div>
    );

    return (
      <Modal
        visible
        footer={false}
        onCancel={() => {
          this.clearSelectedValues();
          this.props.handleClose();
        }}
      >
        <div className="property-create-modal-section">
          <Row>
            <Alert message="Виберіть потрібний майновий об'єкт зі списку КДМ" />
          </Row>

          <div className={quickSearchClasses}>
            <h3>Швидкий пошук</h3>
            <PropertyModalSelect
              placeholder="Введіть секцію, розділ, підрозділ, групу, клас, підклас для пошуку"
              name="selectedForm"
              value={selectedForm}
            >
              {this.handleConvertSelectData(forms)}
            </PropertyModalSelect>
          </div>
          <div className={detailedSearchClasses}>
            <h3>Розгорнутий пошук</h3>
            {/* СЕКЦИЯ */}

            <ExpandedPropertyModalSelect
              placeholder={'Введіть назву типу об\'єкта для пошуку (напр. "Нерухоме майно")'}
              name="selectedSection"
              value={selectedSection}
              title="Секція"
            >
              {sections.map((val, idx) => (
                <Option key={idx} value={val}>
                  {val}
                </Option>
              ))}
            </ExpandedPropertyModalSelect>
            {/* РАЗДЕЛ */}
            <ExpandedPropertyModalSelect
              placeholder={'Введіть назву підтипу об\'єкта для пошуку (напр. "Будинок нежитловий")'}
              name="selectedPartition"
              disabled={this.state.disable_detailed_search || partitions.length === 0}
              value={selectedPartition}
              title="Розділ"
            >
              {partitions.map((val, idx) => (
                <Option key={idx} value={val}>
                  {val}
                </Option>
              ))}
            </ExpandedPropertyModalSelect>
            {/* ПОДРАЗДЕЛ */}
            <ExpandedPropertyModalSelect
              placeholder={'Введіть назву групи об\'єкта для пошуку (напр. "Будівлі торговельні")'}
              name="selectedSubPartition"
              disabled={this.state.disable_detailed_search || subPartitions.length === 0}
              value={selectedSubPartition}
              title="Підрозділ"
            >
              {subPartitions.map((val, idx) => (
                <Option key={idx} value={val}>
                  {val}
                </Option>
              ))}
            </ExpandedPropertyModalSelect>
            {/* ГРУППА */}
            <ExpandedPropertyModalSelect
              placeholder={'Введіть назву групи об\'єкта для пошуку (напр. "Будівлі торговельні")'}
              name="selectedGroup"
              disabled={this.state.disable_detailed_search || groups.length === 0}
              value={selectedGroup}
              title="Група"
            >
              {groups.map((val, idx) => (
                <Option key={idx} value={val}>
                  {val}
                </Option>
              ))}
            </ExpandedPropertyModalSelect>
            {/* КЛАСС */}
            <ExpandedPropertyModalSelect
              placeholder={'Введіть назву підтипу об\'єкта для пошуку (напр. "Будинок нежитловий")'}
              name="selectedClass"
              disabled={this.state.disable_detailed_search || classes.length === 0}
              value={selectedClass}
              title="Клас"
            >
              {classes.map((val, idx) => (
                <Option key={idx} value={val}>
                  {val}
                </Option>
              ))}
            </ExpandedPropertyModalSelect>
            {/* ПОДКЛАСС */}
            <ExpandedPropertyModalSelect
              placeholder={'Введіть назву групи об\'єкта для пошуку (напр. "Будівлі торговельні")'}
              name="selectedSubClass"
              value={selectedSubClass}
              disabled={this.state.disable_detailed_search || subClasses.length === 0}
              title="Підклас"
            >
              {subClasses.map((val, idx) => (
                <Option key={idx} value={val.guid}>
                  {val.subClassName}
                </Option>
              ))}
            </ExpandedPropertyModalSelect>
          </div>

          <div className="property-create-modal-section__buttons">
            <Button onClick={this.handleGoToForm} type="primary" disabled={!selectedForm}>
              {`Створити`}
            </Button>
            <Button
              onClick={() => {
                this.clearSelectedValues();
                this.props.handleClose();
              }}
            >
              {`Скасувати`}
            </Button>
          </div>
        </div>
      </Modal>
    );
  }
}

PropertyModalCreateContainer.propTypes = {
  handleClose: PropTypes.func.isRequired,
  selectedFormType: PropTypes.string.isRequired,
  setStatePropertyType: PropTypes.func.isRequired,
  changeCurAccountingType: PropTypes.func.isRequired,
  loadSpecifiedClassifiers: PropTypes.func.isRequired,
  forms: PropTypes.arrayOf(PropTypes.object).isRequired,
  history: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
};

export default withRouter(
  connect(
    (state) => ({
      selectedFormType: state.property.propertyCommon.forms.selectedForm.type,
      forms: state.classifiers[STATE_PROPERTY_OF_ACCOUNTING_ITEM],
    }),
    {
      ...classifiersActions,
      ...propertyModalActions,
    },
  )(PropertyModalCreateContainer),
);
