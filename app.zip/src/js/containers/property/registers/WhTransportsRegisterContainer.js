import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';

import { propertyWhTransportRegisterSelector } from '../../../selectors';

import * as commonActions from '../../../actions/modules/property/common';
import * as usersActions from '../../../actions/usersActions';
import * as appActions from '../../../actions/appActions';
import * as classifiersActions from '../../../actions/classifiersActions';

import CommonPropertyRegisterComponent from '../CommonPropertyRegisterComponent';

class WhTransportsRegisterContainer extends CommonPropertyRegisterComponent {
  registerName = 'WhTransport';

  columnsForFilter = [
    { value: 'transportVinCode', label: 'Ідентифікаційний номер VIN' },
    { value: 'transportStateNumber', label: 'Державний номер' },
    { value: 'transportEngineNumber', label: 'Номер двигуна' },
    { value: 'transportChasisNumber', label: 'Номер шасси' },
    { value: 'transportBodyNumber', label: 'Номер кузова' },
  ];
}

export default withRouter(
  connect(propertyWhTransportRegisterSelector, {
    ...classifiersActions,
    ...commonActions,
    ...usersActions,
    ...appActions,
  })(WhTransportsRegisterContainer),
);
