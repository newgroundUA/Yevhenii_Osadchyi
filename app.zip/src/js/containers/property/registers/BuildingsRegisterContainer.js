import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { propertyBuildingsRegisterSelector } from '../../../selectors';

import * as commonActions from '../../../actions/modules/property/common';
import * as usersActions from '../../../actions/usersActions';
import * as appActions from '../../../actions/appActions';
import * as classifiersActions from '../../../actions/classifiersActions';

import CommonPropertyRegisterComponent from '../CommonPropertyRegisterComponent';

class BuildingsRegisterContainer extends CommonPropertyRegisterComponent {
  registerName = 'Building';

  columnsForFilter = [
    { value: 'buildingCadastreNumber', label: 'Кадастровий номер будвлі' },
    { value: 'buildingBTILetter', label: 'Літера за БТІ' },
    { value: 'buildingDMALetter', label: 'Літера за ДМА' },
    { value: 'buildingAddressNote', label: 'Додатковий адресний опис' },
  ];
}

export default withRouter(
  connect(propertyBuildingsRegisterSelector, {
    ...classifiersActions,
    ...commonActions,
    ...usersActions,
    ...appActions,
  })(BuildingsRegisterContainer),
);
