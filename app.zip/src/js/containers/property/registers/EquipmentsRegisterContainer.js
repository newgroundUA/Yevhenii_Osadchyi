import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';

import { propertyEquipmentsRegisterSelector } from '../../../selectors';

import * as commonActions from '../../../actions/modules/property/common';
import * as usersActions from '../../../actions/usersActions';
import * as appActions from '../../../actions/appActions';
import * as classifiersActions from '../../../actions/classifiersActions';

import CommonPropertyRegisterComponent from '../CommonPropertyRegisterComponent';

class EquipmentsRegisterContainer extends CommonPropertyRegisterComponent {
  registerName = 'Equipment';

  columnsForFilter = [{ value: 'equipmentTechNote', label: 'Технічний опис' }];
}

export default withRouter(
  connect(propertyEquipmentsRegisterSelector, {
    ...classifiersActions,
    ...commonActions,
    ...usersActions,
    ...appActions,
  })(EquipmentsRegisterContainer),
);
