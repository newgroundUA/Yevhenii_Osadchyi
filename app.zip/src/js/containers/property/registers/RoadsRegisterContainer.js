import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';

import { propertyRoadsRegisterSelector } from '../../../selectors';

import * as commonActions from '../../../actions/modules/property/common';
import * as usersActions from '../../../actions/usersActions';
import * as appActions from '../../../actions/appActions';
import * as classifiersActions from '../../../actions/classifiersActions';

import CommonPropertyRegisterComponent from '../CommonPropertyRegisterComponent';

class RoadsRegisterContainer extends CommonPropertyRegisterComponent {
  registerName = 'Road';
}

export default withRouter(
  connect(propertyRoadsRegisterSelector, {
    ...classifiersActions,
    ...commonActions,
    ...usersActions,
    ...appActions,
  })(RoadsRegisterContainer),
);
