import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';

import wrapRegister from '../../HOCs/wrapRegister';
import * as commonActions from '../../../actions/index';
import * as realEstateRegisterActions from '../../../actions/modules/property/registers/realEstateRegisterActions';
import * as usersActions from '../../../actions/usersActions';
import * as appActions from '../../../actions/appActions';

import TableToolbar from '../../../components/common/toolbar/TableToolbar';

import { realEstateRegisterSelector } from '../../../selectors';
import { realEstateRegistryFiltersTemplate } from '../../../models/registers/filters/templates/realEstate';
import FastFiltersPanel from '../../../components/common/FastFiltersPanel';
import { Icon, Select } from '../../../../../node_modules/antd';

const Option = Select.Option;

const CONTAINER_ACTIONS = {
  ...appActions,
  ...usersActions,
  ...commonActions,
  ...realEstateRegisterActions,
};

class RealEstateRegistryContainer extends Component {
  handleClickToolbarItem = () => {};

  handleSubmitFilters = () => {
    const {
      setValueRequestBody,
      setValuePages,
      fastFilters: {
        accountingItemTypes: { selected },
      },
    } = this.props;

    setValueRequestBody('offset', '0');
    setValueRequestBody('accountingItemTypes', selected.length > 0 ? selected : undefined);
    setValuePages('currentPage', 0);
  };

  handleCancelFilters = () => {
    const { resetFilters } = this.props;

    resetFilters();
  };

  handleChangeFastFilters = (item) => (value) => {
    const { setValueFastFilters } = this.props;

    setValueFastFilters([item, 'selected'], value);
  };

  render() {
    const { sortedColumns, tableToolbar, fastFilters } = this.props;

    return (
      <div className="content__table-items">
        <div className="content__table-menu">
          <TableToolbar
            items={tableToolbar}
            requestBody={this.props.requestBody}
            setValueRequestBody={this.props.setValueRequestBody}
            handleToggleToolbarItem={this.props.handleToggleToolbarItem}
            isActive={false}
            columns={sortedColumns}
            handleChangeColumns={this.props.handleChangeColumns}
            handleClickToolbarItem={this.handleClickToolbarItem}
            registryFiltersTemplate={realEstateRegistryFiltersTemplate}
          />
        </div>
        <div className="content__fast-filters">
          {/* TODO: need to be moved out to separate component */}
          <FastFiltersPanel
            useAll={this.handleSubmitFilters}
            cancelAll={this.handleCancelFilters}
            filters={() => {}}
          >
            <div className="table-menu__icon">
              <Icon type="filter" />
            </div>
            {Object.values(fastFilters).map((el) => (
              <Select
                key={el.id}
                mode="multiple"
                style={{ minWidth: 250 }}
                value={el.selected}
                allowClear
                placeholder="Виберіть тип нерухомого майна"
                onChange={this.handleChangeFastFilters(el.id)}
              >
                {el.child.map((item) => (
                  <Option value={item.value} key={item.label}>
                    {item.label}
                  </Option>
                ))}
              </Select>
            ))}
          </FastFiltersPanel>
        </div>
      </div>
    );
  }
}

RealEstateRegistryContainer.propTypes = {
  // history: PropTypes.objectOf(PropTypes.any).isRequired,

  tableToolbar: PropTypes.objectOf(PropTypes.any).isRequired,
  sortedColumns: PropTypes.shape({
    fixed: PropTypes.object,
    fluid: PropTypes.object,
  }).isRequired,
  requestBody: PropTypes.objectOf(PropTypes.any).isRequired,
  setValueRequestBody: PropTypes.func.isRequired,
  setValueFastFilters: PropTypes.func.isRequired,

  handleChangeColumns: PropTypes.func.isRequired,
  handleToggleToolbarItem: PropTypes.func.isRequired,
  setValuePages: PropTypes.func.isRequired,
  resetFilters: PropTypes.func.isRequired,
  fastFilters: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default withRouter(
  connect(realEstateRegisterSelector, CONTAINER_ACTIONS)(
    wrapRegister(RealEstateRegistryContainer, 'realEstate', 'getRealEstateRegister'),
  ),
);
