import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';

import { propertyRegisterSelector } from '../../../selectors';

import * as commonActions from '../../../actions/modules/property/common';

import * as usersActions from '../../../actions/usersActions';
import * as appActions from '../../../actions/appActions';
import * as classifiersActions from '../../../actions/classifiersActions';

import CommonPropertyRegisterComponent from '../CommonPropertyRegisterComponent';

const CONTAINER_ACTIONS = {
  ...classifiersActions,
  ...commonActions,
  ...usersActions,
  ...appActions,
};

class PropertyRegisterContainer extends CommonPropertyRegisterComponent {
  registerName = 'AccountingItem';
}

export default withRouter(
  connect(propertyRegisterSelector, CONTAINER_ACTIONS)(PropertyRegisterContainer),
);
