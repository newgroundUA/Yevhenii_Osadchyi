import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';

import { propertySteadsRegisterSelector } from '../../../selectors';

import * as commonActions from '../../../actions/modules/property/common';
import * as usersActions from '../../../actions/usersActions';
import * as appActions from '../../../actions/appActions';
import * as classifiersActions from '../../../actions/classifiersActions';

import CommonPropertyRegisterComponent from '../CommonPropertyRegisterComponent';

class SteadsRegisterContainer extends CommonPropertyRegisterComponent {
  registerName = 'Stead';

  columnsForFilter = [{ value: 'steadCadastreNumber', label: 'Кадастровий номер будвлі' }];
}

export default withRouter(
  connect(propertySteadsRegisterSelector, {
    ...classifiersActions,
    ...commonActions,
    ...usersActions,
    ...appActions,
  })(SteadsRegisterContainer),
);
