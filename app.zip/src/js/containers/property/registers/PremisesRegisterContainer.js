import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';

import { propertyPremisesRegisterSelector } from '../../../selectors';

import * as commonActions from '../../../actions/modules/property/common';
import * as usersActions from '../../../actions/usersActions';
import * as appActions from '../../../actions/appActions';
import * as classifiersActions from '../../../actions/classifiersActions';

import CommonPropertyRegisterComponent from '../CommonPropertyRegisterComponent';

class PremisesRegisterContainer extends CommonPropertyRegisterComponent {
  registerName = 'Premise';
}

export default withRouter(
  connect(propertyPremisesRegisterSelector, {
    ...classifiersActions,
    ...commonActions,
    ...usersActions,
    ...appActions,
  })(PremisesRegisterContainer),
);
