import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';

import { propertyAnimalsRegisterSelector } from '../../../selectors';

import * as commonActions from '../../../actions/modules/property/common';
import * as usersActions from '../../../actions/usersActions';
import * as appActions from '../../../actions/appActions';
import * as classifiersActions from '../../../actions/classifiersActions';

import CommonPropertyRegisterComponent from '../CommonPropertyRegisterComponent';

class AnimalsRegisterContainer extends CommonPropertyRegisterComponent {
  registerName = 'Animal';
}

export default withRouter(
  connect(propertyAnimalsRegisterSelector, {
    ...classifiersActions,
    ...commonActions,
    ...usersActions,
    ...appActions,
  })(AnimalsRegisterContainer),
);
