import React from 'react';
import PropTypes from 'prop-types';
import { Row, Col } from 'antd';
import Separator from '../../../../components/common/form/Separator';
import AddressList from '../../../common/address/AddressList';
import { mapFormItems } from '../../../../helpers/formHelpers/mapFormHelper';

class GeneralFieldsFormItems extends React.PureComponent {
  render() {
    const {
      viewMode,
      classifiers,
      generalInfoFields,
      isViewMode,
      form,
      allowEditAddressFrom,
      allowCreateAddress,
      allowDeleteAddress,
      allowEditAddress,
      allowClearAddressFields,
    } = this.props;

    return (
      <div>
        <Row>
          <Separator text="Основна інформація" />
          {mapFormItems({
            viewMode,
            fields: generalInfoFields,
            classifiers,
            isViewMode,
            form,
          })}
        </Row>
        <Row>
          <Col span={12}>
            <AddressList
              allowClearAddressFields={allowClearAddressFields}
              allowCreating={allowCreateAddress}
              allowEditFrom={allowEditAddressFrom || 'region'}
              allowDeleteAddress={allowDeleteAddress}
              allowEditAddress={allowEditAddress}
              multy={false}
              noAddressType
              required
              fieldName="address"
              form={this.props.form}
              isViewMode={isViewMode}
            />
          </Col>
        </Row>
      </div>
    );
  }
}

GeneralFieldsFormItems.defaultProps = {
  allowEditAddressFrom: null,
  allowCreateAddress: true,
  allowDeleteAddress: true,
  allowEditAddress: true,
  allowClearAddressFields: true,
};

GeneralFieldsFormItems.propTypes = {
  classifiers: PropTypes.objectOf(PropTypes.array).isRequired,
  generalInfoFields: PropTypes.objectOf(PropTypes.object).isRequired,
  isViewMode: PropTypes.bool.isRequired,
  viewMode: PropTypes.string.isRequired,
  form: PropTypes.objectOf(PropTypes.any).isRequired,
  allowEditAddressFrom: PropTypes.bool,
  allowCreateAddress: PropTypes.bool,
  allowDeleteAddress: PropTypes.bool,
  allowEditAddress: PropTypes.bool,
  allowClearAddressFields: PropTypes.bool,
};

export default GeneralFieldsFormItems;
