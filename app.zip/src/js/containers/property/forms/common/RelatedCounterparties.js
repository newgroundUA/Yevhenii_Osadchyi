import React from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';

import { Form, Button, Row, Col, Icon, Collapse, Table, Select } from 'antd';

import * as classifiersActions from '../../../../actions/classifiersActions';
import * as relatedCounterpartiesActions from '../../../../actions/modules/property/relatedCounterparties';
import * as commonActions from '../../../../actions';

import { mapFormItems } from '../../../../helpers/formHelpers/mapFormHelper';
import { mapRowsToTable, getFormEntityData } from '../../../../helpers/formHelpers/formHelpers';

import {
  ownersOfPrimaryPRFields,
  getMappedForm as getMappedPrimaryForm,
  getParsedForm as getParsedPrimaryForm,
  getMappedLocal as getMappedLocalPrimary,
} from '../../../../models/formFields/property/common/ownersOfPrimaryPRFields';

import {
  ownersOfDerivativePRFields,
  getMappedForm as getMappedDerivativeForm,
  getParsedForm as getParsedDerivativeForm,
  getMappedLocal as getMappedLocalDerivative,
} from '../../../../models/formFields/property/common/ownersOfDerivativePRFields';

import Separator from '../../../../components/common/form/Separator';

import { RELATED_COUNTERPARTIES } from '../../../../constants/ContainerNames';
import {
  CL_PROPERTY_RIGHTS_TYPE,
  CL_PROPERTY_OWNERSHIP_TYPE,
  // KFV,
} from '../../../../constants/ClassifiersNames';
import { getTableColumns } from '../../../../helpers/table';

const RELATED_COUNTERPARTIES_ACTIONS = {
  ...classifiersActions,
  ...relatedCounterpartiesActions,
  ...commonActions,
};

const Panel = Collapse.Panel;
const Option = Select.Option;
const FormItem = Form.Item;

class RelatedCounterparties extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      curMode: props.curMode,
      registryExists: false,

      primaryOwners: {
        curIndex: -1,
        isAddingNewRow: false,
        activeKey: 0,
        collapsed: false,
      },
      derivativeOwners: {
        curIndex: -1,
        isAddingNewRow: false,
        activeKey: 0,
        collapsed: false,
      },

      primaryOwnersTableRows: [],
      derivativeOwnersTableRows: [],
    };

    this.primaryOwnersColumns = getTableColumns({
      formFields: ownersOfPrimaryPRFields,
      actionsData: {
        editParams: {
          handler: this.handleEditRow('primaryOwners'),
        },
        deleteParams: {
          handler: this.handleDeleteRow('primaryOwners'),
        },
      },
    });

    this.derivativeOwnersColumns = getTableColumns({
      formFields: ownersOfDerivativePRFields,
      actionsData: {
        editParams: {
          handler: this.handleEditRow('derivativeOwners'),
        },
        deleteParams: {
          handler: this.handleDeleteRow('derivativeOwners'),
        },
      },
    });

    this.primaryOwnerKey = `counterpatiesDropdown-${`${Math.random()}`.substring(2)}`;
    this.derivativeOwnerKey = `counterpatiesDropdown-${`${Math.random()}`.substring(2)}`;
  }

  static propTypes = {
    loadClassifiersForContainer: PropTypes.func.isRequired,
    loadSingleClassifier: PropTypes.func.isRequired,
    curMode: PropTypes.string.isRequired,

    loadPropertyOwnershipData: PropTypes.func.isRequired,
    postPropertyOwnershipData: PropTypes.func.isRequired,
    resetPropertyOwners: PropTypes.func.isRequired,
    postPrimaryOwner: PropTypes.func.isRequired,
    putPrimaryOwner: PropTypes.func.isRequired,
    deletePrimaryOwner: PropTypes.func.isRequired,
    postPrimaryOwnerLocal: PropTypes.func.isRequired,
    putPrimaryOwnerLocal: PropTypes.func.isRequired,
    deletePrimaryOwnerLocal: PropTypes.func.isRequired,
    postDerivativeOwner: PropTypes.func.isRequired,
    putDerivativeOwner: PropTypes.func.isRequired,
    deleteDerivativeOwner: PropTypes.func.isRequired,
    postDerivativeOwnerLocal: PropTypes.func.isRequired,
    putDerivativeOwnerLocal: PropTypes.func.isRequired,
    deleteDerivativeOwnerLocal: PropTypes.func.isRequired,

    classifiers: PropTypes.objectOf(PropTypes.array).isRequired,
    // status: PropTypes.objectOf(PropTypes.bool).isRequired,
    primaryOwners: PropTypes.arrayOf(PropTypes.any).isRequired,
    derivativeOwners: PropTypes.arrayOf(PropTypes.any).isRequired,
    // errors: PropTypes.arrayOf(PropTypes.any).isRequired,
    ownershipType: PropTypes.string,
    ownersRegistryData: PropTypes.objectOf(PropTypes.any).isRequired,

    form: PropTypes.objectOf(PropTypes.any).isRequired,

    propertyObjectData: PropTypes.objectOf(PropTypes.any),
  };

  static defaultProps = {
    propertyObjectData: null,
    ownershipType: null,
  };

  componentDidMount = () => {
    const { loadPropertyOwnershipData, propertyObjectData } = this.props;

    const { curMode } = this.state;
    const propertyObjGuid = propertyObjectData && propertyObjectData.guid;
    this.props.loadClassifiersForContainer(RELATED_COUNTERPARTIES);
    this.props.loadSingleClassifier(CL_PROPERTY_OWNERSHIP_TYPE);
    // this.props.loadSingleClassifier(KFV);

    if (propertyObjGuid && (curMode === 'view' || curMode === 'edit')) {
      loadPropertyOwnershipData(propertyObjGuid);
    }
  };

  componentWillReceiveProps(nextProps) {
    const {
      propertyObjectData,
      ownersRegistryData,
      loadPropertyOwnershipData,
      curMode,
      ownershipType,
      form,
      classifiers,
    } = nextProps;

    const propertyObjGuid = this.props.propertyObjectData && this.props.propertyObjectData.guid;
    const nextPropertyObjGuid = propertyObjectData && propertyObjectData.guid;

    const ownersRegistryGuid = this.props.ownersRegistryData && this.props.ownersRegistryData.guid;
    const nextOwnersRegistryGuid = ownersRegistryData && ownersRegistryData.guid;
    if (this.state.curMode !== curMode) this.setState({ curMode });

    if (nextPropertyObjGuid && propertyObjGuid !== nextPropertyObjGuid) {
      loadPropertyOwnershipData(nextPropertyObjGuid);
    }

    if (nextOwnersRegistryGuid && ownersRegistryGuid !== nextOwnersRegistryGuid) {
      form.setFieldsValue({ ownershipType });
      this.setState({ registryExists: true });
    }

    if (this.props.primaryOwners !== nextProps.primaryOwners) {
      this.setState({
        primaryOwnersTableRows: mapRowsToTable(
          nextProps.primaryOwners.map((el) => getParsedPrimaryForm(el)),
          ownersOfPrimaryPRFields,
          classifiers,
        ),
      });
    }

    if (this.props.derivativeOwners !== nextProps.derivativeOwners) {
      this.setState({
        derivativeOwnersTableRows: mapRowsToTable(
          nextProps.derivativeOwners.map((el) => getParsedDerivativeForm(el)),
          ownersOfDerivativePRFields,
          classifiers,
        ),
      });
    }
  }

  componentWillUnmount() {
    this.props.resetPropertyOwners();
  }

  handleCreateRegistry = () => {
    const {
      propertyObjectData,
      primaryOwners,
      derivativeOwners,
      form,
      postPropertyOwnershipData,
      classifiers,
    } = this.props;

    // const ownershipTypes = classifiers[KFV];
    const ownershipTypes = classifiers[CL_PROPERTY_OWNERSHIP_TYPE];

    form.validateFields(['ownershipType'], (err, values) => {
      if (!err) {
        const ownershipTypeGuid = values.ownershipType;
        const ownership = ownershipTypes.find((el) => el.guid === ownershipTypeGuid);
        postPropertyOwnershipData({
          propertyObject: propertyObjectData,
          ownersOfPrimaryPRs: primaryOwners.map((el) => {
            const normilizedValue = getFormEntityData(el, classifiers, ownersOfPrimaryPRFields);
            return getMappedPrimaryForm(normilizedValue);
          }),
          ownersOfDerivativePRs: derivativeOwners.map((el) => {
            const normilizedValue = getFormEntityData(el, classifiers, ownersOfDerivativePRFields);
            return getMappedDerivativeForm(normilizedValue);
          }),
          propertyOwnershipType: {
            guid: ownership.guid,
            type: ownership.type,
            versionId: ownership.versionId,
          },
        });
      }
    });
  };

  handleSaveTableForm = (tableName) => () => {
    const {
      postPrimaryOwner,
      putPrimaryOwner,
      postPrimaryOwnerLocal,
      putPrimaryOwnerLocal,
      postDerivativeOwner,
      putDerivativeOwner,
      postDerivativeOwnerLocal,
      putDerivativeOwnerLocal,
      classifiers,
      ownersRegistryData,
    } = this.props;

    const { registryExists } = this.state;

    const fieldsArr = Object.keys(
      tableName === 'primaryOwners' ? ownersOfPrimaryPRFields : ownersOfDerivativePRFields,
    );
    this.props.form.validateFields(fieldsArr, (err, values) => {
      if (!err) {
        const primaryOwnerNormilizedValue = getFormEntityData(
          values,
          classifiers,
          ownersOfPrimaryPRFields,
        );
        const derivativeOwnerNormilizedValue = getFormEntityData(
          values,
          classifiers,
          ownersOfDerivativePRFields,
        );
        if (this.state[tableName].isAddingNewRow) {
          if (!registryExists) {
            if (tableName === 'primaryOwners') {
              postPrimaryOwnerLocal(getMappedLocalPrimary(values));
            } else {
              postDerivativeOwnerLocal(
                getMappedLocalDerivative(values, classifiers[CL_PROPERTY_RIGHTS_TYPE]),
              );
            }
          } else if (tableName === 'primaryOwners') {
            postPrimaryOwner({
              ...getMappedPrimaryForm(primaryOwnerNormilizedValue),
              ownersRegistry: ownersRegistryData,
            });
          } else {
            postDerivativeOwner({
              ...getMappedDerivativeForm(derivativeOwnerNormilizedValue),
              ownersRegistry: ownersRegistryData,
            });
          }
        } else if (!registryExists) {
          const primaryOwner = this.props.primaryOwners[this.state.primaryOwners.curIndex];
          if (tableName === 'primaryOwners') {
            putPrimaryOwnerLocal({
              ...getMappedLocalPrimary(values),
              guid: primaryOwner.guid,
              versionId: primaryOwner.versionId,
              ownersRegistry: ownersRegistryData,
            });
          } else {
            const derivativeOwner = this.props.derivativeOwners[
              this.state.derivativeOwners.curIndex
            ];
            putDerivativeOwnerLocal({
              ...getMappedLocalDerivative(values, classifiers[CL_PROPERTY_RIGHTS_TYPE]),
              guid: derivativeOwner.guid,
              ownersRegistry: ownersRegistryData,
            });
          }
        } else if (tableName === 'primaryOwners') {
          const primaryOwner = this.props.primaryOwners[this.state.primaryOwners.curIndex];
          putPrimaryOwner({
            ...getMappedPrimaryForm(primaryOwnerNormilizedValue),
            guid: primaryOwner.guid,
            versionId: primaryOwner.versionId,
            ownersRegistry: ownersRegistryData,
          });
        } else {
          const derivativeOwner = this.props.primaryOwners[this.state.primaryOwners.curIndex];
          putDerivativeOwner({
            ...getMappedDerivativeForm(derivativeOwnerNormilizedValue),
            guid: derivativeOwner.guid,
            versionId: derivativeOwner.versionId,
            ownersRegistry: ownersRegistryData,
          });
        }

        this.setState((prevState) => ({
          [tableName]: {
            ...prevState[tableName],
            collapsed: false,
            activeKey: 0,
            isAddingNewRow: false,
            curIndex: -1,
          },
        }));
      }
    });
  };

  handleEditRow = (tableName) => (rowIndex) => {
    const getParsedForm =
      tableName === 'primaryOwners' ? getParsedPrimaryForm : getParsedDerivativeForm;

    this.setState(
      (prevState) => ({
        [tableName]: {
          ...prevState[tableName],
          collapsed: true,
          activeKey: tableName,
          curIndex: rowIndex,
        },
      }),
      () => {
        this.props.form.setFieldsValue(getParsedForm(this.props[tableName][rowIndex]));
      },
    );
  };

  handleDeleteRow = (tableName) => (rowIndex) => {
    const {
      deletePrimaryOwner,
      deletePrimaryOwnerLocal,
      deleteDerivativeOwner,
      deleteDerivativeOwnerLocal,
      primaryOwners,
      derivativeOwners,
    } = this.props;

    const { registryExists } = this.state;

    const actionMap = {
      primaryOwners: {
        remoteAction: deletePrimaryOwner,
        localAction: deletePrimaryOwnerLocal,
        rows: primaryOwners,
      },
      derivativeOwners: {
        remoteAction: deleteDerivativeOwner,
        localAction: deleteDerivativeOwnerLocal,
        rows: derivativeOwners,
      },
    };

    const { remoteAction, localAction, rows } = actionMap[tableName];

    if (!registryExists) {
      localAction(rows[rowIndex].guid);
    } else {
      remoteAction(rows[rowIndex].guid);
    }
  };

  handleAddTableRow = (tableName) => () => {
    this.props.form.resetFields(
      Object.keys(
        tableName === 'primaryOwners' ? ownersOfPrimaryPRFields : ownersOfDerivativePRFields,
      ),
    );
    this.setState((prevState) => ({
      [tableName]: {
        ...prevState[tableName],
        collapsed: true,
        isAddingNewRow: true,
        activeKey: tableName,
      },
    }));
  };

  handleCancelTableRow = (tableName) => () => {
    this.props.form.resetFields(
      Object.keys(
        tableName === 'primaryOwners' ? ownersOfPrimaryPRFields : ownersOfDerivativePRFields,
      ),
    );
    this.setState((prevState) => ({
      [tableName]: {
        ...prevState[tableName],
        collapsed: false,
        isAddingNewRow: false,
        activeKey: 0,
      },
    }));
  };

  clearForm = () => {
    this.props.form.resetFields();
  };

  render() {
    const {
      curMode,
      registryExists,
      primaryOwnersTableRows,
      derivativeOwnersTableRows,
    } = this.state;

    const {
      form: { getFieldDecorator },
      classifiers,
      primaryOwners,
    } = this.props;

    const isViewMode = curMode === 'view';

    const primaryPanelStyle = this.state.primaryOwners.collapsed
      ? { marginBottom: '1rem' }
      : { display: 'none' };
    const derivativePanelStyle = this.state.derivativeOwners.collapsed
      ? { marginBottom: '1rem' }
      : { display: 'none' };

    const formItemLayout = {
      labelCol: {
        xs: { span: 8 },
      },
      wrapperCol: {
        xs: { span: 16 },
      },
    };

    return (
      <Row>
        <Separator text="Форма власності" />
        <Row>
          <Col key="ownershipType" span={8}>
            <div style={{ padding: '0 1.5rem' }}>
              <FormItem label="Форма власності" key="ownershipType" {...formItemLayout}>
                {getFieldDecorator('ownershipType', {
                  rules: [{ required: true, message: "Поле обов'язкове для вибору!" }],
                })(
                  <Select disabled={isViewMode || registryExists}>
                    {(classifiers[CL_PROPERTY_OWNERSHIP_TYPE] || []).map((el) => (
                      <Option value={el.guid} key={el.guid}>
                        {el.name}
                      </Option>
                    ))}
                  </Select>,
                )}
              </FormItem>
            </div>
          </Col>
          {!registryExists ? (
            <Col span={4}>
              <Button
                style={{ marginRight: '1rem' }}
                onClick={this.handleCreateRegistry}
                type="primary"
                disabled={!primaryOwners.length}
              >
                <Icon type="save" />
                {`Створити реєстр власників`}
              </Button>
            </Col>
          ) : null}
        </Row>
        <Separator text="Власники майна за первинним правом" />
        <Row>
          <Button
            disabled={curMode === 'view' || this.state.primaryOwners.collapsed}
            onClick={this.handleAddTableRow('primaryOwners')}
          >
            <Icon type="plus" />
            {`Додати`}
          </Button>
          <Collapse
            style={primaryPanelStyle}
            bordered={false}
            activeKey={`${this.state.primaryOwners.activeKey}`}
            onChange={(key) => this.setState({ activeKey: key })}
          >
            <Panel
              header="Форма створення"
              key="primaryOwners"
              disabled={!this.state.primaryOwners.collapsed}
            >
              {mapFormItems({
                viewMode: curMode,
                fields: ownersOfPrimaryPRFields,
                classifiers,
                isViewMode,
                form: this.props.form,
              })}
              <Row>
                <Button
                  style={{ marginRight: '1rem' }}
                  onClick={this.handleSaveTableForm('primaryOwners')}
                  type="primary"
                >
                  <Icon type="save" />
                  {`Зберегти`}
                </Button>
                <Button onClick={this.handleCancelTableRow('primaryOwners')}>
                  <Icon type="close" />
                  {`Вiдмiнити`}
                </Button>
              </Row>
            </Panel>
          </Collapse>
          <Table
            style={{ margin: '1rem 0', background: '#fff' }}
            bordered
            pagination={false}
            columns={this.primaryOwnersColumns}
            dataSource={primaryOwnersTableRows}
          />
        </Row>
        <Separator text="Суб'єкти з іншими речовими правами" />
        <Row>
          <Button
            disabled={curMode === 'view' || this.state.derivativeOwners.collapsed}
            onClick={this.handleAddTableRow('derivativeOwners')}
          >
            <Icon type="plus" />
            {`Додати`}
          </Button>
          <Collapse
            style={derivativePanelStyle}
            bordered={false}
            activeKey={`${this.state.derivativeOwners.activeKey}`}
            onChange={(key) => this.setState({ activeKey: key })}
          >
            <Panel
              header="Форма створення"
              key="derivativeOwners"
              disabled={!this.state.derivativeOwners.collapsed}
            >
              {mapFormItems({
                viewMode: curMode,
                fields: ownersOfDerivativePRFields,
                classifiers,
                isViewMode,
                form: this.props.form,
              })}

              <Row>
                <Button
                  style={{ marginRight: '1rem' }}
                  onClick={this.handleSaveTableForm('derivativeOwners')}
                  type="primary"
                >
                  <Icon type="save" />
                  {`Зберегти`}
                </Button>
                <Button onClick={this.handleCancelTableRow('derivativeOwners')}>
                  <Icon type="close" />
                  {`Вiдмiнити`}
                </Button>
              </Row>
            </Panel>
          </Collapse>
          <Table
            style={{ margin: '1rem 0', background: '#fff' }}
            bordered
            pagination={false}
            columns={this.derivativeOwnersColumns}
            dataSource={derivativeOwnersTableRows}
          />
        </Row>
      </Row>
    );
  }
}

const mapStateToProps = (state) => ({
  classifiers: state.classifiers,
  primaryOwners: state.property.relatedCounterparties.primaryOwners,
  derivativeOwners: state.property.relatedCounterparties.derivativeOwners,
  status: state.property.relatedCounterparties.status,
  errors: state.property.relatedCounterparties.errors,
  ownershipType: state.property.relatedCounterparties.ownershipType,
  ownersRegistryData: state.property.relatedCounterparties.ownersRegistryData,
});

export default connect(mapStateToProps, RELATED_COUNTERPARTIES_ACTIONS)(
  Form.create()(RelatedCounterparties),
);
