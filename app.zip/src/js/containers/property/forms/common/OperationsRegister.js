import React from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';

import { Form, Button, Row, Icon, Collapse, Table } from 'antd';

import * as classifiersActions from '../../../../actions/classifiersActions';
import * as operationsRegistryActions from '../../../../actions/modules/property/registers/operationsRegister';
import * as commonActions from '../../../../actions';

import { mapFormItems } from '../../../../helpers/formHelpers/mapFormHelper';
import { mapRowsToTable, getFormEntityData } from '../../../../helpers/formHelpers/formHelpers';

import {
  operationFields,
  getMappedFormForOperations as getMappedForm,
  getParsedFormForOperations as getParsedForm,
} from '../../../../models/formFields/property/generalFields';

import { OPERATIONS_REGISTER } from '../../../../constants/ContainerNames';
import { getTableColumns } from '../../../../helpers/table';
import { disabledEndDate, disabledStartDate } from '../../../../services/validator/date';

const OPERATIONS_REGISTER_ACTIONS = {
  ...classifiersActions,
  ...operationsRegistryActions,
  ...commonActions,
};

const Panel = Collapse.Panel;

class OperationsRegister extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      curMode: props.curMode,

      operationsRegister: {
        curIndex: -1,
        isAddingNewRow: false,
        activeKey: 0,
        collapsed: false,
      },
    };

    this.formFields = this.getFormFields();

    this.columns = getTableColumns({
      formFields: operationFields,
      actionsData: {
        editParams: {
          handler: this.handleEditRow('operationsRegister'),
        },
        deleteParams: {
          handler: this.handleDeleteRow,
        },
      },
    });

    this.loaded = false;
    this.reasonDocsKey = `counterpatiesDropdown-${`${Math.random()}`.substring(2)}`;
  }

  static propTypes = {
    loadClassifiersForContainer: PropTypes.func.isRequired,
    curMode: PropTypes.string.isRequired,

    mountOperationsRegister: PropTypes.func.isRequired,
    unmountOperationsRegister: PropTypes.func.isRequired,

    loadPropertyOperationsRegister: PropTypes.func.isRequired,
    postOperation: PropTypes.func.isRequired,
    putOperation: PropTypes.func.isRequired,
    deleteOperation: PropTypes.func.isRequired,

    classifiers: PropTypes.objectOf(PropTypes.array).isRequired,
    resetOperationsRegister: PropTypes.func.isRequired,
    rows: PropTypes.arrayOf(PropTypes.any).isRequired,
    status: PropTypes.objectOf(PropTypes.bool).isRequired,

    form: PropTypes.objectOf(PropTypes.any).isRequired,

    storeKey: PropTypes.string.isRequired,
    propertyObject: PropTypes.objectOf(PropTypes.any),
  };

  static defaultProps = {
    propertyObject: {},
  };

  componentDidMount = () => {
    const {
      loadPropertyOperationsRegister,
      propertyObject,
      storeKey,
      mountOperationsRegister,
    } = this.props;
    const { curMode } = this.state;

    mountOperationsRegister(storeKey);
    this.props.loadClassifiersForContainer(OPERATIONS_REGISTER);

    if ((curMode === 'view' || curMode === 'edit') && propertyObject.guid) {
      loadPropertyOperationsRegister(storeKey, propertyObject.guid);
    }
  };

  componentWillReceiveProps(nextProps) {
    const {
      status,
      resetOperationsRegister,
      propertyObject,
      loadPropertyOperationsRegister,
      curMode,
      storeKey,
    } = nextProps;

    if (this.state.curMode !== curMode) this.setState({ curMode });

    if (this.props.propertyObject.guid !== propertyObject.guid && propertyObject.guid) {
      loadPropertyOperationsRegister(storeKey, propertyObject.guid);
    }

    if (status.isDone) {
      this.loaded = true;
      // this.curGuid = createdForm.guid;
      this.handleToggleDialog();
      resetOperationsRegister(storeKey);
    }

    if (this.props.propertyObject.fullName !== nextProps.propertyObject.fullName) {
      this.formFields.operationFields = {
        ...this.formFields.operationFields,
        propertyObject: {
          ...this.formFields.operationFields.propertyObject,
          value: nextProps.propertyObject,
        },
      };
    }
  }

  componentWillUnmount() {
    // this.props.resetOperationsRegister(this.props.storeKey);
    this.props.unmountOperationsRegister(this.props.storeKey);
  }

  handleSaveTableForm = (formName) => () => {
    const {
      postOperation,
      putOperation,
      propertyObject: { guid, versionId },
      classifiers,
      storeKey,
    } = this.props;
    const fieldsArr = Object.keys(operationFields);
    this.props.form.validateFields(fieldsArr, (err, values) => {
      if (!err) {
        const normilizedBuildingFormValues = getFormEntityData(
          values,
          classifiers,
          operationFields,
        );

        if (this.state[formName].isAddingNewRow) {
          postOperation(storeKey, {
            ...getMappedForm(normilizedBuildingFormValues),
            objects: { guid, versionId },
          });
        } else {
          putOperation(storeKey, {
            ...getMappedForm(normilizedBuildingFormValues),
            objects: { guid, versionId },
            guid: this.props.rows[this.state.operationsRegister.curIndex].guid,
          });
        }

        this.setState((prevState) => ({
          [formName]: {
            ...prevState[formName],
            collapsed: false,
            activeKey: 0,
            isAddingNewRow: false,
            curIndex: -1,
          },
        }));
      }
    });
  };

  handleEditRow = (formName) => (rowIndex) => {
    this.setState(
      (prevState) => ({
        [formName]: {
          ...prevState[formName],
          collapsed: true,
          activeKey: 1,
          curIndex: rowIndex,
        },
      }),
      () => {
        this.props.form.setFieldsValue(getParsedForm(this.props.rows[rowIndex]));
      },
    );
  };

  handleDeleteRow = (rowIndex) => {
    const { deleteOperation, rows, storeKey } = this.props;
    deleteOperation(storeKey, rows[rowIndex].guid);
  };

  handleAddTableRow = (formName) => () => {
    this.props.form.resetFields(Object.keys(operationFields));
    this.setState((prevState) => ({
      [formName]: {
        ...prevState[formName],
        collapsed: true,
        isAddingNewRow: true,
        activeKey: 1,
      },
    }));
  };

  handleCancelTableRow = (formName) => () => {
    this.props.form.resetFields(Object.keys(operationFields));
    this.setState((prevState) => ({
      [formName]: {
        ...prevState[formName],
        collapsed: false,
        isAddingNewRow: false,
        activeKey: 0,
      },
    }));
  };

  clearForm = () => {
    this.props.form.resetFields();
  };

  getFormFields = () => {
    const form = this.props.form;
    return {
      operationFields: {
        ...operationFields,
        propertyObject: {
          ...operationFields.propertyObject,
          displayMode: 'text',
          value: this.props.propertyObject,
        },
        dateFrom: {
          ...operationFields.dateFrom,
          disabledDate: disabledStartDate(form, 'dateTo'),
        },
        dateTo: {
          ...operationFields.dateTo,
          disabledDate: disabledEndDate(form, 'dateFrom'),
        },
      },
    };
  };

  render() {
    const { curMode } = this.state;

    const { classifiers, rows } = this.props;

    const propertyPanelStyle = this.state.operationsRegister.collapsed
      ? { marginBottom: '1rem' }
      : { display: 'none' };
    const isViewMode = curMode === 'view';
    const tableRows = mapRowsToTable(
      rows.map((el) => getParsedForm(el)),
      operationFields,
      classifiers,
    );

    return (
      <Form>
        <Row>
          <Button
            disabled={curMode === 'view' || this.state.operationsRegister.collapsed}
            onClick={this.handleAddTableRow('operationsRegister')}
          >
            <Icon type="plus" />
            Додати
          </Button>
          <Collapse
            style={propertyPanelStyle}
            bordered={false}
            activeKey={`${this.state.operationsRegister.activeKey}`}
            onChange={(key) => this.setState({ activeKey: key })}
          >
            <Panel
              header="Форма створення"
              key="1"
              disabled={!this.state.operationsRegister.collapsed}
            >
              {mapFormItems({
                viewMode: curMode,
                fields: this.formFields.operationFields,
                classifiers,
                isViewMode,
                form: this.props.form,
              })}
              <Row>
                <Button
                  style={{ marginRight: '1rem' }}
                  onClick={this.handleSaveTableForm('operationsRegister')}
                  type="primary"
                >
                  <Icon type="save" />
                  Зберегти
                </Button>
                <Button onClick={this.handleCancelTableRow('operationsRegister')}>
                  <Icon type="close" />
                  Вiдмiнити
                </Button>
              </Row>
            </Panel>
          </Collapse>
          <Table
            style={{ margin: '1rem 0', background: '#fff' }}
            bordered
            pagination={false}
            columns={this.columns}
            dataSource={tableRows}
          />
        </Row>
      </Form>
    );
  }
}

const mapStateToProps = (state, props) => ({
  classifiers: state.classifiers,
  rows: (state.property.operationsRegister[props.storeKey] || { rows: [] }).rows,
  status: (state.property.operationsRegister[props.storeKey] || { status: { isDone: false } })
    .status,
});

export default connect(mapStateToProps, OPERATIONS_REGISTER_ACTIONS)(
  Form.create()(OperationsRegister),
);
