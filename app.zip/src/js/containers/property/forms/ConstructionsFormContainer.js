import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';

import { Form, Modal, Button, Row, Tabs } from 'antd';

import Separator from '../../../components/common/form/Separator';
import { mapFormItems } from '../../../helpers/formHelpers/mapFormHelper';

import {
  constructionsFields,
  getConstructionsBEFields,
  parseConstruction,
} from '../../../models/formFields/property/constructionsFields';

import { generalInfoFields } from '../../../models/formFields/property/generalFields';

import * as commonActions from '../../../actions/modules/property/common';
import * as constructionsActions from '../../../actions/modules/property/forms/constructionForm';
import * as classifiersActions from '../../../actions/classifiersActions';

import * as RouteNames from '../../../constants/RouteNames';
import Documents from '../../common/Documents';

import GeneralFieldsFormItems from './common/GeneralFieldsFormItems';
import { PROPERTY_PARENT_OBJECTS } from '../../../constants/ClassifiersNames';
import { CONSTRUCTIONS_FORM_CONTAINER } from '../../../constants/ContainerNames';
import ControlButtons from '../../../components/common/form/ControllButtons';

const CONTAINER_ACTIONS = {
  ...constructionsActions,
  ...classifiersActions,
  ...commonActions,
};

const TabPane = Tabs.TabPane;

class ConstructionsFormContainer extends Component {
  constructor(props) {
    super(props);
    const {
      match: {
        params: { mode, guid },
      },
    } = this.props;

    this.guid = guid;
    this.loaded = false;

    this.initialState = {
      mode: RouteNames.CREATE,
      isOpenModal: false,
    };

    this.state = {
      ...this.initialState,
      mode: mode || RouteNames.CREATE,
    };
  }

  componentWillMount() {
    const { loadClassifiersForContainer, loadPropertyConstructions } = this.props;

    const { mode } = this.state;

    if (mode === RouteNames.VIEW || mode === RouteNames.EDIT) {
      loadPropertyConstructions(this.guid);
    }

    loadClassifiersForContainer(CONSTRUCTIONS_FORM_CONTAINER, {
      [PROPERTY_PARENT_OBJECTS]: { searchTerm: '%' },
    });
  }

  componentDidMount() {
    this.props.form.setFieldsValue({ clStateProperty: this.props.curAccountingType || undefined });
  }

  componentWillReceiveProps(nextProps) {
    const {
      constructionsFormParam,
      form: { setFieldsValue },
      match: {
        params: { mode: nextMode },
      },
    } = nextProps;

    const { mode } = this.state;

    if (mode !== nextMode) this.setState({ mode: nextMode });
    if (
      constructionsFormParam.guid &&
      (nextMode === RouteNames.VIEW || nextMode === RouteNames.EDIT) &&
      !this.loaded
    ) {
      this.loaded = true;
      setFieldsValue(parseConstruction(constructionsFormParam));
    }
  }

  clearForm = () => this.props.form.resetFields();

  handleSubmit = (modeDoc, docGuidsArr) => {
    const { mode } = this.state;
    const { constructionsFormParam, postConstructions, putConstructions, form } = this.props;

    const curFields = [...Object.keys(generalInfoFields), ...Object.keys(constructionsFields)];

    const showError = (errors) =>
      Modal.error({
        title: 'Помилка!',
        content: (
          <div>
            {errors.map((err, i) => (
              <p key={i}>
                {i + 1}
                {`.`}
                {err.message}
              </p>
            ))}
          </div>
        ),
      });

    const readResponse = (res) => {
      if (res.statusCode === 200) {
        this.guid = res.data.guid;
        this.setState(() => ({ isOpenModal: true }));
      } else {
        showError(res.errors);
      }
    };

    form.validateFields(curFields, (err, values) => {
      if (!err) {
        const post = getConstructionsBEFields(values);
        const put = { ...constructionsFormParam, ...post };

        if (mode === 'create') postConstructions(post).then(readResponse);
        if (mode === 'edit') {
          if (modeDoc === 'documents') {
            const documents = docGuidsArr.reduce((arr, guid) => [...arr, { guid }], []);

            putConstructions({
              ...constructionsFormParam,
              documents,
            });
          } else {
            putConstructions(put).then(readResponse);
          }
        }
      }
    });
  };

  editForm = () => {
    this.props.history.push(
      `/${RouteNames.PROPERTY}/${RouteNames.CONSTRUCTION_FORM}/${RouteNames.EDIT}/${this.guid}`,
    );
  };

  goToRegister = () => {
    const { history } = this.props;

    history.push(`/${RouteNames.PROPERTY}/${RouteNames.REGISTER}`);
  };

  handleCloseModal = () => {
    const { history } = this.props;

    history.push(
      `/${RouteNames.PROPERTY}/${RouteNames.CONSTRUCTION_FORM}/${RouteNames.VIEW}/${this.guid}`,
    );
    this.setState(() => ({ isOpenModal: false }));
  };

  createNewFo = () => {
    this.guid = '';
    this.setState(() => ({
      ...this.initialState,
    }));
    this.clearForm();
    this.props.resetConstructionsForm();
    this.props.history.push(
      `/${RouteNames.PROPERTY}/${RouteNames.CONSTRUCTION_FORM}/${RouteNames.CREATE}`,
    );
  };

  handleAddDocuments = (docArr) => {
    this.handleSubmit('documents', docArr);
  };

  render() {
    const { mode, isOpenModal } = this.state;

    const { classifiers, form, history } = this.props;

    const isViewMode = mode === 'view';
    const modalText = mode === 'edit' ? ' відредагована' : 'створена';

    const ControlButtonsComponent = ({ className }) => (
      <ControlButtons
        curMode={mode}
        clearForm={this.clearForm}
        history={history}
        urlToEditMode={`/${RouteNames.PROPERTY}/${RouteNames.CONSTRUCTION_FORM}/edit/${
          this.curGuid
        }`}
        urlToRegister={`/${RouteNames.PROPERTY}/${RouteNames.REGISTER}`}
        className={className}
      />
    );

    const rows = () => (
      <Row>
        <ControlButtonsComponent />
        <Row>
          <Form>
            <GeneralFieldsFormItems
              form={this.props.form}
              classifiers={classifiers}
              generalInfoFields={generalInfoFields}
              isViewMode={isViewMode}
              viewMode={mode}
            />
            <Row>
              <Separator text="Технічні характеристи" />
              {mapFormItems({
                viewMode: mode,
                fields: constructionsFields,
                classifiers,
                isViewMode,
                form,
              })}

              <Row type="flex" justify="end">
                <Button
                  disabled={isViewMode}
                  style={{ marginRight: '1.5rem' }}
                  type="primary"
                  onClick={() => {
                    this.handleSubmit();
                  }}
                >
                  {`Зберегти`}
                </Button>
              </Row>
            </Row>
          </Form>
        </Row>
      </Row>
    );

    return (
      <Row>
        <Tabs>
          <TabPane tab="Поля форми інша споруда" key="0">
            {rows()}
          </TabPane>
          {mode !== 'create' && (
            <TabPane tab="Документи" key="1">
              <ControlButtonsComponent className="global_mb20" />
              <Documents
                viewMode={mode}
                rows={this.props.constructionsFormParam.documents || []}
                classifiers={classifiers}
                isViewMode={isViewMode}
                onSave={this.handleAddDocuments}
              />
            </TabPane>
          )}
        </Tabs>

        <Modal
          visible={isOpenModal}
          title="Карта форми інша споруда"
          onCancel={this.handleCloseModal}
          footer={[
            <Button key="back" size="large" onClick={this.handleCloseModal}>
              {`Переглянути карту`}
            </Button>,
            <Button key="submit" type="primary" size="large" onClick={this.createNewFo}>
              {`Створити нову`}
            </Button>,
          ]}
        >
          <p>
            {`Карта успішно була`}
            {modalText}
            {`.`}
          </p>
        </Modal>
      </Row>
    );
  }
}

ConstructionsFormContainer.propTypes = {
  match: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
  history: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
  classifiers: PropTypes.objectOf(PropTypes.array).isRequired,
  loadClassifiersForContainer: PropTypes.func.isRequired,
  loadPropertyConstructions: PropTypes.func.isRequired,

  postConstructions: PropTypes.func.isRequired,
  putConstructions: PropTypes.func.isRequired,
  resetConstructionsForm: PropTypes.func.isRequired,
  constructionsFormParam: PropTypes.objectOf(PropTypes.any).isRequired,
  form: PropTypes.objectOf(PropTypes.any).isRequired,

  curAccountingType: PropTypes.string.isRequired,
};

const mapStateToProps = (state) => ({
  classifiers: state.classifiers,
  curAccountingType: state.property.propertyCommon.forms.curAccountingType,
  constructionsFormParam: state.property.propertyConstructions.form.constructions,
});

export default withRouter(
  connect(mapStateToProps, CONTAINER_ACTIONS)(Form.create()(ConstructionsFormContainer)),
);
