import React from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import PropTypes from 'prop-types';

import { Form, Modal, Button, Row, Icon, Tabs, Popconfirm } from 'antd';

import * as classifiersActions from '../../../actions/classifiersActions';
import * as animalsActions from '../../../actions/modules/property/forms/animalsForm';
import * as commonActions from '../../../actions';

import { mapFormItems } from '../../../helpers/formHelpers/mapFormHelper';

import {
  generalInfoFields,
  operationFields,
} from '../../../models/formFields/property/generalFields';
import {
  animalFields,
  getParsedForm,
  getMappedForm,
} from '../../../models/formFields/property/animalFields';

import { ANIMALS_FORM_CONTAINER } from '../../../constants/ContainerNames';
import { PROPERTY_PARENT_OBJECTS } from '../../../constants/ClassifiersNames';
import GeneralFieldsFormItems from './common/GeneralFieldsFormItems';

import Separator from '../../../components/common/form/Separator';
import SeparatorErrMsg from '../../../components/common/form/SeparatorErrMsg';
import * as RouteNames from '../../../constants/RouteNames';
import RelatedCounterparties from './common/RelatedCounterparties';
import OperationsRegister from './common/OperationsRegister';

const ANIMALS_ACTIONS = {
  ...classifiersActions,
  ...animalsActions,
  ...commonActions,
};

const ButtonGroup = Button.Group;
const TabPane = Tabs.TabPane;

class AnimalsFormContainer extends React.Component {
  constructor(props) {
    super(props);

    const curMode = this.props.match.params.mode || 'create';
    this.curGuid = this.props.match.params.guid || '';

    this.state = {
      curMode,
      dialogOpen: false,
      dialogMessage: '',

      curIndex: -1,
      activeKey: '0',
      isAddingNewRow: false,
      radioIndex: '1',
      collapsed: false,

      operations: {
        rows: [],
      },
    };

    this.columns = [
      {
        title: 'Дiя',
        width: 50,
        key: 'operation',
        render: (text, record, rowIndex) =>
          this.state.operations.rows.length > 0 ? (
            <span key={rowIndex}>
              <Icon
                onClick={() => {
                  this.handleEditRow('operations')(rowIndex);
                }}
                type="edit"
              />
              <Popconfirm
                title="Ви впевнені?"
                onConfirm={() => {
                  this.handleDeleteRow('operations')(rowIndex);
                }}
              >
                <Icon style={{ paddingLeft: '0.5rem' }} type="delete" />
              </Popconfirm>
            </span>
          ) : (
            ''
          ),
      },
      ...Object.values(operationFields).map((el, id) => ({
        title: el.name,
        dataIndex: el.field,
        key: id,
      })),
    ];

    this.loaded = false;
  }

  componentDidMount = () => {
    const { getAnimal } = this.props;
    const { curMode } = this.state;

    this.props.loadClassifiersForContainer(ANIMALS_FORM_CONTAINER, {
      [PROPERTY_PARENT_OBJECTS]: { searchTerm: '%' },
    });

    if (curMode === 'view' || curMode === 'edit') {
      getAnimal(this.curGuid);
    }

    this.props.form.setFieldsValue({ clStateProperty: this.props.curAccountingType || undefined });
  };

  componentWillReceiveProps(nextProps) {
    const {
      formParam: { createdForm, status, errors },
      match: {
        params: { mode },
      },
      resetAnimalForm,
      form,
    } = nextProps;

    if (this.state.curMode !== mode) this.setState({ curMode: mode });

    if (createdForm.fullName && (mode === 'view' || mode === 'edit') && !this.loaded) {
      this.loaded = true;
      form.setFieldsValue(getParsedForm(createdForm));
    }

    if (status.isDone) {
      this.loaded = true;
      this.curGuid = createdForm.guid;
      this.handleToggleDialog();
      resetAnimalForm();
    }

    if (errors.length > 0) {
      const errorsText = errors.map((el) => el.message).join(', ');
      this.setState({ dialogMessage: errorsText, dialogOpen: true });
      resetAnimalForm();
    }
  }

  componentWillUnmount() {
    this.props.resetAnimalForm();
  }

  handleCreateNew = () => {
    this.changeRouteTo(`/${RouteNames.PROPERTY}/${RouteNames.ANIMAL_FORM}/create`);
    this.curGuid = '';
    this.loaded = false;
    this.props.form.resetFields();
    this.props.resetAnimalForm();
    this.handleToggleDialog();
  };

  handleSaveTableForm = (formName) => () => {
    const fieldsArr = Object.keys(operationFields);
    this.props.form.validateFields(fieldsArr, (err, values) => {
      if (!err) {
        if (this.state.isAddingNewRow) {
          this.setState((prevState) => ({
            [formName]: {
              rows: prevState[formName].rows.concat([values]),
            },
          }));
        } else {
          this.setState((prevState) => {
            const curArr = prevState[formName].rows.slice();
            curArr[prevState.curIndex] = values;
            return {
              [formName]: {
                rows: curArr,
              },
            };
          });
        }

        this.setState(() => ({
          collapsed: false,
          isAddingNewRow: false,
          activeKey: 0,
        }));
      }
    });
  };

  handleEditRow = (formName) => (rowIndex) => {
    this.props.form.setFieldsValue(this.state[formName].rows[rowIndex]);
    this.setState({
      collapsed: true,
      activeKey: 1,
      curIndex: rowIndex,
    });
  };

  handleDeleteRow = (formName) => (rowIndex) => {
    this.setState((prevState) => {
      const curArr = prevState[formName].rows.slice();
      curArr.splice(rowIndex, 1);
      return {
        [formName]: {
          rows: curArr,
        },
      };
    });
  };

  handleAddTableRow = () => {
    this.props.form.resetFields(Object.keys(operationFields));
    this.setState({
      collapsed: true,
      isAddingNewRow: true,
      activeKey: 1,
    });
  };

  handleCancelTableRow = () => {
    this.props.form.resetFields(Object.keys(operationFields));
    this.setState({
      collapsed: false,
      isAddingNewRow: false,
      activeKey: 0,
    });
  };

  clearForm = () => {
    this.props.form.resetFields();
  };

  changeRouteTo = (route) => {
    this.props.history.push(route);
  };

  handleToggleDialog = (isOpened) => {
    if (isOpened !== undefined) this.setState({ dialogOpen: isOpened });
    else this.setState((prevState) => ({ dialogOpen: !prevState.dialogOpen }));
  };

  handleDialogCancel = () => {
    this.handleToggleDialog();
    this.switchToViewMode();
  };

  switchToEditMode = () => {
    this.changeRouteTo(`/${RouteNames.PROPERTY}/${RouteNames.ANIMAL_FORM}/edit/${this.curGuid}`);
  };

  switchToViewMode = () => {
    this.changeRouteTo(`/${RouteNames.PROPERTY}/${RouteNames.ANIMAL_FORM}/view/${this.curGuid}`);
  };

  handleSubmit = () => {
    const { curMode } = this.state;
    const { putAnimal, postAnimal, form } = this.props;

    const curFields = [...Object.keys(generalInfoFields), ...Object.keys(animalFields)];

    form.validateFields(curFields, (err, values) => {
      if (!err) {
        if (curMode === 'create') {
          postAnimal(getMappedForm(values));
        }

        if (curMode === 'edit') {
          putAnimal({
            ...getMappedForm(values),
            guid: this.curGuid,
          });
        }
      }
    });
  };

  render() {
    const { curMode, dialogMessage } = this.state;

    const { classifiers, form } = this.props;

    const dialogText = curMode === 'create' ? 'створено' : 'відредаговано';
    const isViewMode = curMode === 'view';

    return (
      <Row>
        <Modal
          title="Земельна ділянка"
          visible={this.state.dialogOpen}
          onOk={() => {
            this.handleCreateNew();
          }}
          onCancel={() => {
            this.handleDialogCancel();
          }}
          cancelText="Переглянути картку"
          okText="Створити нову"
        >
          {dialogMessage === '' ? (
            <p>{`Картку успішно ${dialogText}`}</p>
          ) : (
            <p>{`${dialogMessage}`}</p>
          )}
        </Modal>
        <Tabs>
          <TabPane tab="Форма земельної ділянки" key="0">
            <SeparatorErrMsg text="ЦЯ ФОРМА ЩЕ В РОЗРОБЦІ!" />
            <Row>
              <Row type="flex" justify="center">
                <ButtonGroup>
                  {isViewMode && (
                    <Button
                      onClick={() => {
                        this.switchToEditMode();
                      }}
                    >
                      <Icon type="edit" />
                      Редагувати
                    </Button>
                  )}
                  {!isViewMode && (
                    <Button
                      onClick={() => {
                        this.clearForm();
                      }}
                    >
                      <Icon type="delete" />
                      Очистити поля
                    </Button>
                  )}
                  <Button
                    onClick={() => {
                      this.changeRouteTo(`/${RouteNames.PROPERTY}/${RouteNames.REGISTER}`);
                    }}
                  >
                    <Icon type="logout" />
                    Перейти до реєстру
                  </Button>
                </ButtonGroup>
              </Row>
              <Row>
                <GeneralFieldsFormItems
                  form={this.props.form}
                  classifiers={classifiers}
                  generalInfoFields={generalInfoFields}
                  isViewMode={isViewMode}
                  viewMode={curMode}
                />
                {curMode !== 'create' && (
                  <Row>
                    <Separator text="Реєстр операцій по визначенню операційного стану майнового об'єкта" />
                    <OperationsRegister
                      storeKey={this.storeKey}
                      curMode={curMode}
                      objectGUID={this.curGuid}
                    />
                  </Row>
                )}
                <Row>
                  <Separator text="Технічні характеристики" />
                  {mapFormItems({
                    viewMode: curMode,
                    fields: animalFields,
                    classifiers,
                    isViewMode,
                    form,
                  })}
                  <Row type="flex" justify="end">
                    <Button
                      style={{ marginRight: '1.5rem' }}
                      type="primary"
                      onClick={() => {
                        this.handleSubmit();
                      }}
                      disabled={isViewMode}
                    >
                      Відправити
                    </Button>
                  </Row>
                </Row>
              </Row>
            </Row>
          </TabPane>
          {curMode !== 'create' && [
            <TabPane tab={"Контрагенти пов'язані з об'єктом"} key="1">
              <RelatedCounterparties curMode={curMode} objectGUID={this.curGuid} />
            </TabPane>,
            <TabPane tab="Документи" key="2">
              Документи
            </TabPane>,
          ]}
        </Tabs>
      </Row>
    );
  }
}

AnimalsFormContainer.propTypes = {
  loadClassifiersForContainer: PropTypes.func.isRequired,
  history: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
  match: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
  curAccountingType: PropTypes.string.isRequired,

  postAnimal: PropTypes.func.isRequired,
  putAnimal: PropTypes.func.isRequired,
  getAnimal: PropTypes.func.isRequired,

  classifiers: PropTypes.objectOf(PropTypes.array).isRequired,
  resetAnimalForm: PropTypes.func.isRequired,
  formParam: PropTypes.objectOf(PropTypes.any).isRequired,

  form: PropTypes.objectOf(PropTypes.any).isRequired,
};

const mapStateToProps = (state) => ({
  classifiers: state.classifiers,
  curAccountingType: state.property.propertyCommon.forms.curAccountingType,
  formParam: state.property.propertyAnimals.forms.animalForm,
});

export default withRouter(
  connect(mapStateToProps, ANIMALS_ACTIONS)(Form.create()(AnimalsFormContainer)),
);
