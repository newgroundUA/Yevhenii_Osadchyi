import React from 'react';
import PropTypes from 'prop-types';
import { remove } from 'lodash';

import { Row, Col, Tree } from 'antd';

import BuildingTables from '../../../../components/property/buildingStructure/BuildingTables';
import FloorTables from '../../../../components/property/buildingStructure/FloorTables';
import GroupTables from '../../../../components/property/buildingStructure/GroupTables';
import PremiseTables from '../../../../components/property/buildingStructure/PremiseTables';
import FieldTables from '../../../../components/property/buildingStructure/FieldTables';
import { getFEDate } from '../../../../helpers/commonUtils';

const TreeNode = Tree.TreeNode;
const types = {
  BUILDING: 'BUILDING',
  FLOOR: 'FLOOR',
  PREMISE: 'PREMISE',
  GROUP_OF_PREMISES: 'GROUP_OF_PREMISES',
  FIELD: 'FIELD',
};

class BuildingStructureContainer extends React.Component {
  constructor(props) {
    super(props);

    const { form } = this.props;
    this.buildingObjects = this.normalizeFloors(form);

    this.state = {
      expandedKeys: [],
      selectedKeys: [this.props.form.guid],
      autoExpandParent: false,
    };
  }

  buildingObjects = {};

  componentWillReceiveProps(nextProps) {
    const form = nextProps.form;
    this.buildingObjects = this.normalizeFloors(form);
    // if (form.floors !== undefined) {

    // }
  }

  normalizeFloors = (data) => {
    const objects = {};
    const { floors } = data;
    const premises = [];
    const groupsOfPremises = [];
    const fields = [];

    objects[data.guid] = {
      ...data,
      type: types.BUILDING,
      title: data.fullName,
      children: (floors || []).map((floor) => floor.guid),
    };

    (floors || []).forEach((el) => {
      premises.push(...(el.premises || []));
      groupsOfPremises.push(...(el.groupOfPremises || []));

      const curChildren = [
        ...(el.premises || []).map((premise) => premise.guid),
        ...(el.groupOfPremises || []).map((groupOfPremises) => groupOfPremises.guid),
      ];

      objects[el.guid] = {
        ...el,
        type: types.FLOOR,
        title: el.floorNumber,
        parent: el.building && el.building.guid,
        children: curChildren,
      };
    });

    premises.forEach((el) => {
      fields.push(...(el.fields || []));
      const curChildren = (el.fields || []).map((field) => field.guid);
      objects[el.guid] = {
        ...el,
        type: types.PREMISE,
        title: el.fullName,
        parent: el.floor && el.floor.guid,
        parentGroup: el.groupOfPremise && el.groupOfPremise.guid,
        children: curChildren,
      };
    });

    groupsOfPremises.forEach((el) => {
      const curChildren = (el.premises || []).map((field) => field.guid);
      objects[el.guid] = {
        ...el,
        type: types.GROUP_OF_PREMISES,
        title: el.groupName,
        parent: el.floor && el.floor.guid,
        children: curChildren,
      };
    });

    fields.forEach((el) => {
      objects[el.guid] = {
        ...el,
        type: types.FIELD,
        title: el.fullName,
        parent: el.premise && el.premise.guid,
        children: [],
      };
    });

    objects[data.guid] = {
      ...objects[data.guid],
      premisesCount: premises.length,
      groupsOfPremisesCount: groupsOfPremises.length,
      fieldsCount: fields.length,
    };

    return objects;
  };

  getTree = (parentGuid) => {
    const curEl = this.buildingObjects[parentGuid];
    if (!curEl) return false;
    return (
      <TreeNode key={curEl.guid} title={curEl.title}>
        {curEl.children &&
          curEl.children.length > 0 &&
          curEl.children.map((children) => this.getTree(children))}
      </TreeNode>
    );
  };

  onExpand = (expandedKeys) => {
    this.setState({
      expandedKeys,
      autoExpandParent: false,
    });
  };

  onSelect = (selectedKeys) => {
    if (!selectedKeys.length) {
      const expandedKeys = [].concat(this.state.expandedKeys);
      remove(expandedKeys, (id) => id === this.state.selectedKeys[0]);

      return this.onExpand(expandedKeys);
    }
    this.onExpand(this.state.expandedKeys.concat(selectedKeys));

    this.setState({
      selectedKeys,
    });
  };

  getTablePart = (item) => {
    const {
      guid,
      versionId,
      fullName,
      address,
      accountingItemId,
      clStateProperty,
      dateFrom,
      dateTo,
    } = this.props.form;
    const buildingData = {
      guid,
      versionId,
      fullName,
      address,
      accountingItemId,
      clStateProperty,
      dateFrom: getFEDate(dateFrom),
      dateTo: getFEDate(dateTo),
    };
    const curProps = {
      updateBuilding: this.props.updateBuilding,
      data: this.buildingObjects,
      item,
      isViewMode: this.props.isViewMode,
      buildingData,
    };

    if (!item) {
      // this.props.updateBuilding();
      return false;
    }

    if (item.type === types.BUILDING) {
      return <BuildingTables {...curProps} />;
    }
    if (item.type === types.FLOOR) {
      return <FloorTables {...curProps} />;
    }
    if (item.type === types.PREMISE) {
      return <PremiseTables {...curProps} />;
    }
    if (item.type === types.GROUP_OF_PREMISES) {
      return <GroupTables {...curProps} />;
    }
    if (item.type === types.FIELD) {
      return <FieldTables {...curProps} />;
    }
  };

  render() {
    const { expandedKeys, selectedKeys, autoExpandParent } = this.state;

    const treeData = this.getTree(this.props.form.guid);
    const selectedElement = selectedKeys.length > 0 && this.buildingObjects[selectedKeys[0]];

    const tablePart = this.getTablePart(selectedElement);

    return (
      <Row>
        <Col span={9}>
          <Row />
          <Row>
            {treeData && (
              <Tree
                expandedKeys={expandedKeys}
                autoExpandParent={autoExpandParent}
                onExpand={this.onExpand}
                onSelect={this.onSelect}
              >
                {treeData}
              </Tree>
            )}
          </Row>
        </Col>
        <Col span={15}>{tablePart}</Col>
      </Row>
    );
  }
}

BuildingStructureContainer.propTypes = {
  updateBuilding: PropTypes.func.isRequired,
  isViewMode: PropTypes.bool.isRequired,
  form: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default BuildingStructureContainer;
