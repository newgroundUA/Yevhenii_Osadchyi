import React from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';

import { Form, Modal, Button, Row, Tabs } from 'antd';

import * as classifiersActions from '../../../../actions/classifiersActions';
import * as fieldsActions from '../../../../actions/modules/property/forms/fieldsForm';
import * as commonActions from '../../../../actions/index';
import * as operationsRegisterActions from '../../../../actions/modules/property/registers/operationsRegister';

import { mapFormItems } from '../../../../helpers/formHelpers/mapFormHelper';

import { generalInfoFields } from '../../../../models/formFields/property/generalFields';
import {
  fieldFields,
  getParsedForm,
  getMappedForm,
} from '../../../../models/formFields/property/fieldFields';

import { FIELDS_FORM_CONTAINER } from '../../../../constants/ContainerNames';
import { PROPERTY_PARENT_OBJECTS } from '../../../../constants/ClassifiersNames';

import GeneralFieldsFormItems from '../common/GeneralFieldsFormItems';
import Separator from '../../../../components/common/form/Separator';
import * as RouteNames from '../../../../constants/RouteNames';
import RelatedCounterparties from '../common/RelatedCounterparties';
import ControlButtons from '../../../../components/common/form/ControllButtons';
import { getFormEntityData } from '../../../../helpers/formHelpers/formHelpers';
import OperationsRegister from '../common/OperationsRegister';
import { createAccountingItemValue } from '../../../../helpers/formHelpers/dropdownValueCreators';
import { getFEDate } from '../../../../helpers/commonUtils';
import { defStoreKey } from '../../../../helpers/reducers/documents/commonActionsHandlers';
import AccountingItemBindingDocTab from '../../../../components/accountingItems/AccountingItemBindingDocTab';

const FIELDS_ACTIONS = {
  ...classifiersActions,
  ...fieldsActions,
  ...commonActions,
  ...operationsRegisterActions,
};

const TabPane = Tabs.TabPane;

class FieldsFormContainer extends React.Component {
  constructor(props) {
    super(props);

    const curMode = this.props.match.params.mode || 'create';
    this.curGuid = this.props.match.params.guid || '';

    this.state = {
      curMode,
      dialogOpen: false,
      dialogMessage: '',
    };

    this.loaded = false;
    this.storeKey = `fieldsFormContainer-${`${Math.random()}`.substring(2)}`;
    this.formFields = this.getFormFields();
  }

  componentDidMount = () => {
    const {
      getField,
      premiseItem,
      form: { setFieldsValue },
      match: {
        params: { mode },
      },
    } = this.props;
    const { curMode } = this.state;

    if (this.props.inModal) {
      if (premiseItem.fullName !== undefined) {
        this.props.form.setFieldsValue({ premise: this.props.premiseItem.fullName });
      }
    }

    this.props.loadClassifiersForContainer(FIELDS_FORM_CONTAINER, {
      [PROPERTY_PARENT_OBJECTS]: { searchTerm: '%' },
    });

    if (curMode === 'view' || curMode === 'edit') {
      getField(this.curGuid);
    }

    // TODO: remove!!!
    const copy = { ...premiseItem };
    delete copy.children;
    if (mode === 'create') {
      setFieldsValue({
        address: premiseItem.address,
        parentAccountingItem: createAccountingItemValue(copy),
        dateFrom: getFEDate(premiseItem.dateFrom),
        dateTo: getFEDate(premiseItem.dateTo),
      });
    }
  };

  componentWillReceiveProps(nextProps) {
    const {
      formParam: { createdForm, status, errors },
      match: {
        params: { mode },
      },
      resetFieldForm,
      resetFieldDoneStatus,
      form,
    } = nextProps;

    if (this.state.curMode !== mode) this.setState({ curMode: mode });

    if (createdForm.fullName && (mode === 'view' || mode === 'edit') && !this.loaded) {
      this.loaded = true;
      form.setFieldsValue(getParsedForm(createdForm));
    }

    if (status.isDone) {
      this.loaded = true;
      this.curGuid = createdForm.guid;
      if (this.props.inModal) {
        this.props.onFieldCreated();
      } else {
        form.setFieldsValue(getParsedForm(createdForm));
        this.handleToggleDialog();
      }
      resetFieldDoneStatus();
    }

    if (errors.length > 0) {
      const errorsText = errors.map((el) => el.message).join(', ');
      this.setState({ dialogMessage: errorsText, dialogOpen: true });
      resetFieldForm();
    }
  }

  componentWillUnmount() {
    this.props.resetFieldForm();
  }

  handleCreateNew = () => {
    this.changeRouteTo(`/${RouteNames.PROPERTY}/${RouteNames.FIELD_FORM}/create`);
    this.curGuid = '';
    this.loaded = false;
    this.props.form.resetFields();
    this.props.resetFieldForm();
    this.handleToggleDialog();
  };

  clearForm = () => {
    this.props.form.resetFields();
  };

  changeRouteTo = (route) => {
    this.props.history.push(route);
  };

  handleToggleDialog = (isOpened) => {
    if (isOpened !== undefined) this.setState({ dialogOpen: isOpened });
    else this.setState((prevState) => ({ dialogOpen: !prevState.dialogOpen }));
  };

  handleDialogCancel = () => {
    this.handleToggleDialog();
    this.switchToViewMode();
  };

  switchToEditMode = () => {
    this.changeRouteTo(`/${RouteNames.PROPERTY}/${RouteNames.FIELD_FORM}/edit/${this.curGuid}`);
  };

  switchToViewMode = () => {
    this.changeRouteTo(`/${RouteNames.PROPERTY}/${RouteNames.FIELD_FORM}/view/${this.curGuid}`);
  };

  handleSubmit = (mode, docGuidsArr) => {
    const { curMode } = this.state;
    const {
      formParam: { createdForm },
      putField,
      postField,
      form,
      // operationsRegister,
      classifiers,
    } = this.props;

    // const operations = (operationsRegister[this.storeKey] || { rows: [] }).rows;

    const curFields = [...Object.keys(generalInfoFields), ...Object.keys(fieldFields)];
    const formFieldsTemplate = {
      ...generalInfoFields,
      ...fieldFields,
    };
    const premise = {
      guid: this.props.premiseItem.guid,
      versionId: this.props.premiseItem.versionId,
    };

    form.validateFields(curFields, (err, values) => {
      if (!err) {
        const normilizedFieldFormValues = getFormEntityData(
          values,
          classifiers,
          formFieldsTemplate,
        );
        if (curMode === 'create') {
          postField({
            ...getMappedForm(normilizedFieldFormValues),
            premise,
            parentAccountingItem: premise,
            // objectOperationStatusOperations: operations.length ? operations.map((operation) =>
            //   getMappedFormForOperations(getParsedFormForOperations(operation))) : null
          });
        }

        if (curMode === 'edit') {
          if (mode === 'documents') {
            const documents = docGuidsArr.reduce((arr, guid) => [...arr, { guid }], []);
            putField({
              ...createdForm,
              documents,
              parentAccountingItem: createdForm.parentAccountingItem,
            });
          } else {
            putField({
              ...createdForm,
              ...getMappedForm(normilizedFieldFormValues),
              parentAccountingItem: createdForm.parentAccountingItem,
            });
          }
        }
      }
    });
  };

  handleAddDocuments = (docArr) => {
    this.handleSubmit('documents', docArr);
  };

  getFormFields = () => {
    // TODO: think about it, man
    const res = {
      generalInfoFields: {
        ...generalInfoFields,
        // parentAccountingItem: {
        //   ...generalInfoFields.parentAccountingItem,
        //   displayMode: 'text',
        //   value: this.props.premiseItem,
        // },
      },
      fieldFields: {
        ...fieldFields,
      },
    };

    return res;
  };

  render() {
    const { curMode, dialogMessage } = this.state;
    const {
      classifiers,
      form,
      inModal,
      history,
      formParam: { createdForm },
    } = this.props;

    const dialogText = curMode === 'create' ? 'створено' : 'відредаговано';
    const isViewMode = curMode === 'view';

    const ControlButtonsComponent = ({ className }) => (
      <ControlButtons
        inModal={inModal}
        curMode={curMode}
        clearForm={this.clearForm}
        history={history}
        urlToEditMode={`/${RouteNames.PROPERTY}/${RouteNames.FIELD_FORM}/edit/${this.curGuid}`}
        urlToRegister={`/${RouteNames.PROPERTY}/${RouteNames.REGISTER}`}
        className={className}
      />
    );

    return (
      <Row>
        <Modal
          title="Частина приміщення"
          visible={this.state.dialogOpen}
          onOk={() => {
            this.handleCreateNew();
          }}
          onCancel={() => {
            this.handleDialogCancel();
          }}
          cancelText="Переглянути картку"
          okText="Створити нову"
        >
          {dialogMessage === '' ? (
            <p>{`Картку успішно ${dialogText}`}</p>
          ) : (
            <p>{`${dialogMessage}`}</p>
          )}
        </Modal>
        <Tabs>
          <TabPane tab="Форма частини приміщення" key="0">
            <Row>
              <ControlButtonsComponent />
              <Row>
                <GeneralFieldsFormItems
                  form={this.props.form}
                  classifiers={classifiers}
                  generalInfoFields={this.formFields.generalInfoFields}
                  isViewMode={isViewMode}
                  viewMode={curMode}
                  allowDeleteAddress={false}
                  allowEditAddress={false}
                  allowClearAddressFields={false}
                />
                {curMode !== 'create' && (
                  <Row>
                    <Separator text="Реєстр операцій по визначенню операційного стану майнового об'єкта" />
                    <OperationsRegister
                      storeKey={this.storeKey}
                      curMode={curMode}
                      propertyObjectData={{
                        guid: createdForm.guid,
                        versionId: createdForm.versionId,
                        fullName: createdForm.fullName,
                      }}
                    />
                  </Row>
                )}
                <Row>
                  <Separator text="Технічні характеристики" />
                  {mapFormItems({
                    viewMode: curMode,
                    fields: this.formFields.fieldFields,
                    classifiers,
                    isViewMode,
                    form,
                  })}

                  <Row type="flex" justify="end">
                    <Button
                      style={{ marginRight: '1.5rem' }}
                      type="primary"
                      onClick={() => {
                        this.handleSubmit();
                      }}
                      disabled={isViewMode}
                    >
                      Відправити
                    </Button>
                  </Row>
                </Row>
              </Row>
            </Row>
          </TabPane>
          {curMode !== 'create' && (
            <TabPane tab={"Контрагенти пов'язані з об'єктом"} key="2">
              <ControlButtonsComponent />
              <RelatedCounterparties
                curMode={curMode}
                propertyObjectData={{
                  guid: createdForm.guid,
                  versionId: createdForm.versionId,
                  fullName: createdForm.fullName,
                }}
              />
            </TabPane>
          )}
          <TabPane tab="Зв'язані документи" disabled={curMode === 'create'} key="4">
            <AccountingItemBindingDocTab
              routeName={RouteNames.FIELD_FORM}
              curGuid={this.curGuid}
              form={form}
            />
          </TabPane>
        </Tabs>
      </Row>
    );
  }
}

FieldsFormContainer.defaultProps = {
  premiseItem: {},
  history: {},
};

FieldsFormContainer.propTypes = {
  loadClassifiersForContainer: PropTypes.func.isRequired,
  history: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]),
  match: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
  premiseItem: PropTypes.objectOf(PropTypes.any),
  inModal: PropTypes.bool.isRequired,
  onFieldCreated: PropTypes.func.isRequired,

  postField: PropTypes.func.isRequired,
  putField: PropTypes.func.isRequired,
  getField: PropTypes.func.isRequired,

  classifiers: PropTypes.objectOf(PropTypes.array).isRequired,
  resetFieldForm: PropTypes.func.isRequired,
  resetFieldDoneStatus: PropTypes.func.isRequired,
  formParam: PropTypes.objectOf(PropTypes.any).isRequired,

  // operationsRegister: PropTypes.objectOf(PropTypes.any).isRequired,

  // setOperationsRegister: PropTypes.func.isRequired,
  form: PropTypes.objectOf(PropTypes.any).isRequired,
};

const mapStateToProps = (state, { stepGuid }) => ({
  classifiers: state.classifiers,
  // operationsRegister: state.property.operationsRegister,
  formParam: state.property.propertyFields.forms.fieldForm,
  cascaderValue: state.documentForms.documentCascader.selectedValue[stepGuid || defStoreKey],
});

export default connect(mapStateToProps, FIELDS_ACTIONS)(Form.create()(FieldsFormContainer));
