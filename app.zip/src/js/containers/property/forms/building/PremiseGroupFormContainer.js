import React from 'react';

import { connect } from 'react-redux';
import PropTypes from 'prop-types';

import { Form, Button, Row } from 'antd';

import * as classifiersActions from '../../../../actions/classifiersActions';
import * as premiseGroupActions from '../../../../actions/modules/property/forms/premiseGroupForm';
import * as commonActions from '../../../../actions/index';

import {
  premiseGroupFields,
  getMappedForm,
  getParsedForm,
} from '../../../../models/formFields/property/premiseGroupFields';

import { mapFormItems } from '../../../../helpers/formHelpers/mapFormHelper';
import { getFormEntityData } from '../../../../helpers/formHelpers/formHelpers';
import { PREMISE } from '../../../../constants/ClassifiersNames';

const CONTAINER_ACTIONS = {
  ...classifiersActions,
  ...premiseGroupActions,
  ...commonActions,
};

class PremiseGroupFormContainer extends React.Component {
  constructor(props) {
    super(props);

    const curMode = this.props.match.params.mode || 'create';
    this.curGuid = this.props.match.params.guid || '';
    this.floorItem = this.props.floorItem;

    this.state = {
      curMode,
      // dialogOpen: false,
      // dialogMessage: '',
    };
  }

  componentDidMount() {
    const { getPremiseGroup } = this.props;
    const { curMode } = this.state;

    this.props.form.setFieldsValue({ floor: this.props.floorItem.floorName });

    if (curMode === 'view' || curMode === 'edit') {
      getPremiseGroup(this.curGuid);
    }
  }

  componentWillReceiveProps(nextProps) {
    const {
      formParam: { createdForm, status, errors },
      match: {
        params: { mode },
      },
      resetPremiseGroupForm,
      resetResetPremiseGroupDoneStatus,
      form,
    } = nextProps;

    if (this.state.curMode !== mode) this.setState({ curMode: mode });

    if (createdForm.guid && (mode === 'view' || mode === 'edit') && !this.loaded) {
      this.loaded = true;
      form.setFieldsValue(getParsedForm(createdForm));
    }

    if (status.isDone) {
      this.loaded = true;
      this.curGuid = createdForm.guid;
      this.props.onPremiseGroupCreated();
      resetResetPremiseGroupDoneStatus();
    }

    if (errors.length > 0) {
      // const errorsText = errors.map((el) => el.message).join(', ');
      // this.setState({ dialogMessage: errorsText, dialogOpen: true });
      resetPremiseGroupForm();
    }
  }

  componentWillUnmount() {
    this.props.resetPremiseGroupForm();
  }

  handleSubmit = () => {
    const { curMode } = this.state;
    const {
      putPremiseGroup,
      postPremiseGroup,
      form,
      classifiers,
      formParam: { createdForm },
    } = this.props;

    const curFields = Object.keys(premiseGroupFields);

    form.validateFields(curFields, (err, values) => {
      if (!err) {
        const loadedPremises = createdForm.premises || [];

        const curClassifiers = {
          ...classifiers,
          [PREMISE]: [...this.props.availablePremises, ...loadedPremises],
        };

        const normilizedPremiseGroupFormValues = getFormEntityData(
          values,
          curClassifiers,
          premiseGroupFields,
        );
        if (curMode === 'create') {
          postPremiseGroup({
            ...getMappedForm(normilizedPremiseGroupFormValues),
            floor: {
              guid: this.floorItem.guid,
              versionId: this.floorItem.versionId,
            },
          });
        }
        if (curMode === 'edit') {
          putPremiseGroup({
            ...this.props.formParam.createdForm,
            ...getMappedForm(normilizedPremiseGroupFormValues),
            guid: this.curGuid,
            floor: {
              guid: this.floorItem.guid,
              versionId: this.floorItem.versionId,
            },
          });
        }
      }
    });
  };

  render() {
    const {
      formParam: { createdForm },
      form,
      classifiers,
    } = this.props;
    const { curMode } = this.state;

    const loadedPremises = createdForm.premises || [];

    const curClassifiers = {
      ...classifiers,
      [PREMISE]: [...this.props.availablePremises, ...loadedPremises],
    };

    const isViewMode = curMode === 'view';

    return (
      <Row>
        {mapFormItems({
          viewMode: curMode,
          fields: premiseGroupFields,
          classifiers: curClassifiers,
          isViewMode,
          form,
        })}

        <Row type="flex" justify="end">
          <Button
            style={{ marginRight: '1.5rem' }}
            type="primary"
            onClick={() => {
              this.handleSubmit();
            }}
            disabled={isViewMode}
          >
            {`Відправити`}
          </Button>
        </Row>
      </Row>
    );
  }
}

PremiseGroupFormContainer.propTypes = {
  // history: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
  match: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
  availablePremises: PropTypes.arrayOf(PropTypes.any).isRequired,
  onPremiseGroupCreated: PropTypes.func.isRequired,
  floorItem: PropTypes.objectOf(PropTypes.any).isRequired,

  postPremiseGroup: PropTypes.func.isRequired,
  putPremiseGroup: PropTypes.func.isRequired,
  getPremiseGroup: PropTypes.func.isRequired,
  resetPremiseGroupForm: PropTypes.func.isRequired,
  resetResetPremiseGroupDoneStatus: PropTypes.func.isRequired,

  classifiers: PropTypes.objectOf(PropTypes.array).isRequired,
  formParam: PropTypes.objectOf(PropTypes.any).isRequired,

  form: PropTypes.objectOf(PropTypes.any).isRequired,
};

const mapStateToProps = (state) => ({
  formParam: state.property.propertyPremiseGroup.forms.premiseGroupForm,
  classifiers: state.classifiers,
});

export default connect(mapStateToProps, CONTAINER_ACTIONS)(
  Form.create()(PremiseGroupFormContainer),
);
