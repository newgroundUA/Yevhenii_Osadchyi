import React from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';

import { Form, Modal, Button, Row, Tabs, Collapse } from 'antd';

import * as classifiersActions from '../../../../actions/classifiersActions';
import * as buildingsActions from '../../../../actions/modules/property/forms/buildingsForm';
import * as commonActions from '../../../../actions/index';
import * as operationsRegisterActions from '../../../../actions/modules/property/registers/operationsRegister';

import { mapFormItems } from '../../../../helpers/formHelpers/mapFormHelper';
import {
  readOnlySpecFields,
  getMappedForm,
  getParsedForm,
  specificationFields1,
  specificationFields2,
} from '../../../../models/formFields/property/buildingFields';

import { generalInfoFields } from '../../../../models/formFields/property/generalFields';

import GeneralFieldsFormItems from '../common/GeneralFieldsFormItems';
import Separator from '../../../../components/common/form/Separator';
import fakeClassifiers from '../../../../models/classifiers/classifiers';
import * as RouteNames from '../../../../constants/RouteNames';
import OperationsRegister from '../common/OperationsRegister';
import RelatedCounterparties from '../common/RelatedCounterparties';

import { PROPERTY_PARENT_OBJECTS } from '../../../../constants/ClassifiersNames';
import { BUILDING_FORM_CONTAINER } from '../../../../constants/ContainerNames';

import BuildingStructureContainer from './BuildingStructureContainer';
import ControlButtons from '../../../../components/common/form/ControllButtons';
import { getFormEntityData } from '../../../../helpers/formHelpers/formHelpers';
import { defStoreKey } from '../../../../helpers/reducers/documents/commonActionsHandlers';
import AccountingItemBindingDocTab from '../../../../components/accountingItems/AccountingItemBindingDocTab';

const CONTAINER_ACTIONS = {
  ...classifiersActions,
  ...buildingsActions,
  ...commonActions,
  ...operationsRegisterActions,
};

const TabPane = Tabs.TabPane;

class BuildingsFormContainer extends React.Component {
  constructor(props) {
    super(props);

    const curMode = this.props.match.params.mode || 'create';
    this.curGuid = this.props.match.params.guid || '';

    this.state = {
      curMode,
      dialogOpen: false,
      dialogMessage: '',
    };

    this.loaded = false;
    this.storeKey = `buildingsFormContainer-${`${Math.random()}`.substring(2)}`;

    generalInfoFields.fullName.rules = [];
    generalInfoFields.clStateProperty.readOnly = false;
    specificationFields1.inputTotalSpace.onChange = this.calcDifferenceTotalSpace;
  }

  componentDidMount() {
    const { getBuilding } = this.props;
    const { curMode } = this.state;

    this.props.loadClassifiersForContainer(BUILDING_FORM_CONTAINER, {
      [PROPERTY_PARENT_OBJECTS]: { searchTerm: '%' },
    });

    if (curMode === 'view' || curMode === 'edit') {
      getBuilding(this.curGuid);
    }

    this.props.form.setFieldsValue({ clStateProperty: this.props.curAccountingType || undefined });
  }

  componentWillReceiveProps(nextProps) {
    const {
      formParam: { createdForm: nextCreatedForm, status, errors },
      match: {
        params: { mode },
      },
      resetBuildingDoneStatus,
      form,
      // setOperationsRegister
    } = nextProps;

    const {
      formParam: { createdForm },
    } = this.props;
    if (this.state.curMode !== mode) this.setState({ curMode: mode });

    if (nextCreatedForm.guid && (mode === 'view' || mode === 'edit') && !this.loaded) {
      this.loaded = true;
      form.setFieldsValue(getParsedForm(nextCreatedForm));
      // setOperationsRegister(this.storeKey, createdForm.objectOperationStatusOperations || []);
    }

    if (status.isDone) {
      this.loaded = true;
      this.curGuid = nextCreatedForm.guid;
      form.setFieldsValue(getParsedForm(nextCreatedForm));
      const isDocumentsChanged =
        (nextCreatedForm.documents || []).length !== (createdForm.documents || []).length;
      this.handleToggleDialog(undefined, isDocumentsChanged);

      resetBuildingDoneStatus();
    }

    if (errors.length > 0) {
      const errorsText = errors.map((el) => el.message).join(', ');
      this.setState({ dialogMessage: errorsText, dialogOpen: true });
      resetBuildingDoneStatus();
    }
  }

  componentWillUnmount() {
    this.props.resetBuildingForm();
  }

  calcDifferenceTotalSpace = (e) => {
    const { form } = this.props;

    if (Number(e.target.value)) {
      const totalBuildingSpace = form.getFieldValue('totalBuildingSpace');
      form.setFieldsValue({
        differenceTotalSpace: (e.target.value - (totalBuildingSpace || 0)).toFixed(2),
      });
    }
  };

  updateBuilding = () => {
    this.loaded = false;
    this.props.getBuilding(this.curGuid);
  };

  handleSubmit = (mode, docGuidsArr) => {
    const { curMode } = this.state;
    const {
      putBuilding,
      postBuilding,
      form,
      formParam: { createdForm },
      classifiers,
    } = this.props;

    const curFields = [
      ...Object.keys(generalInfoFields),
      ...Object.keys(specificationFields1),
      ...Object.keys(specificationFields2),
    ];
    const formFieldsTemplate = {
      ...generalInfoFields,
      ...specificationFields1,
      ...specificationFields2,
    };

    const getDoc = (guid) => {
      const document = classifiers.documents.find((doc) => doc.guid === guid);
      if (!document) {
        return undefined;
      }
      return {
        guid: document.guid,
        versionId: document.versionId,
      };
    };

    form.validateFields(curFields, (err, values) => {
      if (!err) {
        const normilizedBuildingFormValues = getFormEntityData(
          values,
          classifiers,
          formFieldsTemplate,
        );

        if (curMode === 'create') {
          postBuilding({
            ...getMappedForm(normilizedBuildingFormValues),
          });
        }

        if (curMode === 'edit') {
          if (mode === 'documents') {
            putBuilding({
              ...createdForm,
              documents: docGuidsArr.map((guid) => {
                const doc = createdForm.documents.find((el) => el.guid === guid);
                if (doc) return doc;
                return getDoc(guid);
              }),
            });
          } else {
            putBuilding({
              ...createdForm,
              ...getMappedForm(normilizedBuildingFormValues),
              guid: this.curGuid,
            });
          }
        }
      }
    });
  };

  handleCreateNew = () => {
    this.changeRouteTo(`/${RouteNames.PROPERTY}/${RouteNames.BUILDINGS_FORM}/create`);
    this.curGuid = '';
    this.loaded = false;
    this.props.form.resetFields();
    this.props.resetBuildingForm();
    this.handleToggleDialog();
  };

  switchToEditMode = () => {
    this.changeRouteTo(`/${RouteNames.PROPERTY}/${RouteNames.BUILDINGS_FORM}/edit/${this.curGuid}`);
  };

  switchToViewMode = () => {
    this.changeRouteTo(`/${RouteNames.PROPERTY}/${RouteNames.BUILDINGS_FORM}/view/${this.curGuid}`);
  };

  handleDialogCancel = () => {
    this.handleToggleDialog();
    this.switchToViewMode();
  };

  handleToggleDialog = (isOpened, isDocumentsChanged = false) => {
    if (isOpened !== undefined) this.setState({ dialogOpen: isOpened });
    else if (!isDocumentsChanged) {
      this.setState((prevState) => ({ dialogOpen: !prevState.dialogOpen }));
    }
  };

  clearForm = () => {
    this.props.form.resetFields();
  };

  changeRouteTo = (route) => {
    this.props.history.push(route);
  };

  handleAddDocuments = (docArr, documentsMode) => {
    this.handleSubmit('documents', docArr, documentsMode);
  };

  render() {
    const { classifiers, form, history, formParam } = this.props;
    const { dialogMessage, curMode } = this.state;
    const { createdForm } = formParam;

    const classifiersWithMocks = {
      ...classifiers,
      ...fakeClassifiers,
    };

    const propertyObjectData = {
      guid: this.props.formParam.createdForm.guid,
      versionId: this.props.formParam.createdForm.versionId,
    };
    const isViewMode = curMode === 'view';
    const dialogText = curMode === 'create' ? 'створено' : 'відредаговано';

    const ControlButtonsComponent = ({ className }) => (
      <ControlButtons
        curMode={curMode}
        clearForm={this.clearForm}
        history={history}
        urlToEditMode={`/${RouteNames.PROPERTY}/${RouteNames.BUILDINGS_FORM}/edit/${this.curGuid}`}
        urlToRegister={`/${RouteNames.PROPERTY}/${RouteNames.REGISTER}`}
        className={className}
      />
    );

    return (
      <Row>
        <Modal
          title="Картка Будівлі"
          visible={this.state.dialogOpen}
          onOk={() => {
            this.handleCreateNew();
          }}
          onCancel={() => {
            this.handleDialogCancel();
          }}
          cancelText="Переглянути картку"
          okText="Створити нову"
        >
          {dialogMessage === '' ? (
            <p>{`Картку успішно ${dialogText}`}</p>
          ) : (
            <p>{`${dialogMessage}`}</p>
          )}
        </Modal>
        <Tabs>
          <TabPane tab="Поля форми" key="0">
            <Row>
              <ControlButtonsComponent />
              <Row>
                <GeneralFieldsFormItems
                  form={this.props.form}
                  classifiers={classifiers}
                  generalInfoFields={generalInfoFields}
                  isViewMode={isViewMode}
                  viewMode={curMode}
                />
                {curMode !== 'create' && (
                  <Row>
                    <Separator text="Реєстр операцій по визначенню операційного стану майнового об'єкта" />
                    <OperationsRegister
                      propertyObject={{
                        guid: createdForm.guid,
                        versionId: createdForm.versionId,
                        fullName: createdForm.fullName,
                      }}
                      storeKey={this.storeKey}
                      curMode={curMode}
                    />
                  </Row>
                )}
                <Row>
                  <Separator text="Технічні характеристики" />
                  {mapFormItems({
                    viewMode: curMode,
                    fields: specificationFields1,
                    classifiers: classifiersWithMocks,
                    isViewMode,
                    form,
                  })}
                  <Row>
                    <Collapse>
                      <Collapse.Panel header="Інші характеристики" key="1">
                        {mapFormItems({
                          viewMode: curMode,
                          fields: specificationFields2,
                          classifiers: classifiersWithMocks,
                          isViewMode,
                          form,
                        })}
                      </Collapse.Panel>
                    </Collapse>
                  </Row>

                  <Row type="flex" justify="end">
                    <Button
                      style={{ marginRight: '1.5rem', marginTop: '1.5rem' }}
                      type="primary"
                      onClick={() => {
                        this.handleSubmit();
                      }}
                      disabled={isViewMode}
                    >
                      Відправити
                    </Button>
                  </Row>
                </Row>
                <Row>
                  <Separator text="Вирахувані параметри будівлі" />
                  {mapFormItems({
                    viewMode: curMode,
                    fields: readOnlySpecFields,
                    classifiers: classifiersWithMocks,
                    isViewMode,
                    form,
                  })}
                </Row>
              </Row>
            </Row>
          </TabPane>
          {curMode !== 'create' && [
            <TabPane tab="Структура будівлі" key="2">
              <BuildingStructureContainer
                form={createdForm}
                updateBuilding={this.updateBuilding}
                isViewMode={isViewMode}
              />
            </TabPane>,
            <TabPane tab={"Контрагенти пов'язані з об'єктом"} key="3">
              <ControlButtonsComponent />
              <RelatedCounterparties curMode={curMode} propertyObjectData={propertyObjectData} />
            </TabPane>,
          ]}
          <TabPane tab="Зв'язані документи" disabled={curMode === 'create'} key="4">
            <AccountingItemBindingDocTab
              routeName={RouteNames.BUILDINGS_FORM}
              curGuid={this.curGuid}
              form={form}
            />
          </TabPane>
        </Tabs>
      </Row>
    );
  }
}

BuildingsFormContainer.propTypes = {
  history: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
  match: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
  curAccountingType: PropTypes.string.isRequired,

  postBuilding: PropTypes.func.isRequired,
  putBuilding: PropTypes.func.isRequired,
  getBuilding: PropTypes.func.isRequired,

  resetBuildingDoneStatus: PropTypes.func.isRequired,
  loadClassifiersForContainer: PropTypes.func.isRequired,
  classifiers: PropTypes.objectOf(PropTypes.array).isRequired,
  resetBuildingForm: PropTypes.func.isRequired,
  formParam: PropTypes.objectOf(PropTypes.any).isRequired,
  form: PropTypes.objectOf(PropTypes.any).isRequired,
};

const mapStateToProps = (state, { stepGuid }) => ({
  formParam: state.property.propertyBuildings.forms.buildingForm,
  curAccountingType: state.property.propertyCommon.forms.curAccountingType,
  operationsRegister: state.property.operationsRegister,
  classifiers: state.classifiers,
  cascaderValue: state.documentForms.documentCascader.selectedValue[stepGuid || defStoreKey],
});

export default connect(mapStateToProps, CONTAINER_ACTIONS)(Form.create()(BuildingsFormContainer));
