import React from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';

import { Form, Button, Row } from 'antd';

import * as classifiersActions from '../../../../actions/classifiersActions';
import * as floorActions from '../../../../actions/modules/property/forms/floorForm';
import * as commonActions from '../../../../actions/index';

import {
  floorFields,
  getMappedForm,
  getParsedForm,
} from '../../../../models/formFields/property/floorFields';

import { mapFormItems } from '../../../../helpers/formHelpers/mapFormHelper';

import { FLOOR_FORM_CONTAINER } from '../../../../constants/ContainerNames';
import { getFormEntityData } from '../../../../helpers/formHelpers/formHelpers';

const CONTAINER_ACTIONS = {
  ...classifiersActions,
  ...floorActions,
  ...commonActions,
};

class FloorFormContainer extends React.Component {
  constructor(props) {
    super(props);

    const curMode = this.props.match.params.mode || 'create';
    this.curGuid = this.props.match.params.guid || '';
    this.buildingData = this.props.buildingData;

    this.state = {
      curMode,
      // dialogOpen: false,
      // dialogMessage: '',
    };
  }

  componentDidMount() {
    const { getFloor } = this.props;
    const { curMode } = this.state;

    this.props.loadClassifiersForContainer(FLOOR_FORM_CONTAINER);

    if (curMode === 'view' || curMode === 'edit') {
      getFloor(this.curGuid);
    }
  }

  componentWillReceiveProps(nextProps) {
    const {
      formParam: { createdForm, status, errors },
      match: {
        params: { mode },
      },
      resetFloorForm,
      resetFloorDoneStatus,
      form,
    } = nextProps;

    if (this.state.curMode !== mode) this.setState({ curMode: mode });

    if (createdForm.guid && (mode === 'view' || mode === 'edit') && !this.loaded) {
      this.loaded = true;
      form.setFieldsValue(getParsedForm(createdForm));
    }

    if (status.isDone) {
      this.loaded = true;
      this.curGuid = createdForm.guid;
      // this.handleToggleDialog();
      this.props.onFloorCreated();
      resetFloorDoneStatus();
    }

    if (errors.length > 0) {
      // const errorsText = errors.map((el) => el.message).join(', ');
      // this.setState({ dialogMessage: errorsText, dialogOpen: true });
      resetFloorForm();
    }
  }

  componentWillUnmount() {
    this.props.resetFloorForm();
  }

  handleSubmit = () => {
    const { curMode } = this.state;
    const { putFloor, postFloor, form, classifiers } = this.props;

    const curFields = Object.keys(floorFields);

    form.validateFields(curFields, (err, values) => {
      if (!err) {
        const normilizedValue = getFormEntityData(values, classifiers, floorFields);
        if (curMode === 'create') {
          postFloor({
            ...getMappedForm(normilizedValue),
            building: this.buildingData,
          });
        }

        if (curMode === 'edit') {
          putFloor({
            ...this.props.formParam.createdForm,
            ...getMappedForm(normilizedValue),
            guid: this.curGuid,
            building: this.buildingData,
          });
        }
      }
    });
  };

  render() {
    const { classifiers, form } = this.props;
    const { curMode } = this.state;

    const isViewMode = curMode === 'view';

    return (
      <Row>
        {mapFormItems({
          viewMode: curMode,
          fields: floorFields,
          classifiers,
          isViewMode,
          form,
        })}

        <Row type="flex" justify="end">
          <Button
            style={{ marginRight: '1.5rem' }}
            type="primary"
            onClick={() => {
              this.handleSubmit();
            }}
            disabled={isViewMode}
          >
            {`Відправити`}
          </Button>
        </Row>
      </Row>
    );
  }
}

FloorFormContainer.propTypes = {
  // history: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
  match: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
  buildingData: PropTypes.string.isRequired,
  onFloorCreated: PropTypes.func.isRequired,

  postFloor: PropTypes.func.isRequired,
  putFloor: PropTypes.func.isRequired,
  getFloor: PropTypes.func.isRequired,
  resetFloorForm: PropTypes.func.isRequired,
  resetFloorDoneStatus: PropTypes.func.isRequired,

  loadClassifiersForContainer: PropTypes.func.isRequired,
  classifiers: PropTypes.objectOf(PropTypes.array).isRequired,
  formParam: PropTypes.objectOf(PropTypes.any).isRequired,

  form: PropTypes.objectOf(PropTypes.any).isRequired,
};

const mapStateToProps = (state) => ({
  formParam: state.property.propertyFloors.forms.floorForm,
  classifiers: state.classifiers,
});

export default connect(mapStateToProps, CONTAINER_ACTIONS)(Form.create()(FloorFormContainer));
