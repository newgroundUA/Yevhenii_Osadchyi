import React from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import PropTypes from 'prop-types';

import { Form, Modal, Button, Row, Tabs } from 'antd';

import * as classifiersActions from '../../../actions/classifiersActions';
import * as operationsRegisterActions from '../../../actions/modules/property/registers/operationsRegister';
import * as steadsActions from '../../../actions/modules/property/forms/steadsForm';
import * as commonActions from '../../../actions';

import { mapFormItems } from '../../../helpers/formHelpers/mapFormHelper';
// import { mapRowsToTable } from '../../../helpers/formHelpers/formHelpers';

import {
  generalInfoFields,
  getMappedFormForOperations,
  getParsedFormForOperations,
} from '../../../models/formFields/property/generalFields';
import {
  steadFields,
  getParsedForm,
  getMappedForm,
} from '../../../models/formFields/property/steadFields';

import { STEADS_FORM_CONTAINER } from '../../../constants/ContainerNames';
import { PROPERTY_PARENT_OBJECTS } from '../../../constants/ClassifiersNames';
import GeneralFieldsFormItems from './common/GeneralFieldsFormItems';

import Separator from '../../../components/common/form/Separator';
import SeparatorErrMsg from '../../../components/common/form/SeparatorErrMsg';
import OperationsRegister from './common/OperationsRegister';
import RelatedCounterparties from './common/RelatedCounterparties';
import * as RouteNames from '../../../constants/RouteNames';
import Documents from '../../common/Documents';
import ControlButtons from '../../../components/common/form/ControllButtons';

const STEADS_ACTIONS = {
  ...classifiersActions,
  ...steadsActions,
  ...commonActions,
  ...operationsRegisterActions,
};

const TabPane = Tabs.TabPane;

class SteadsFormContainer extends React.Component {
  constructor(props) {
    super(props);

    const curMode = this.props.match.params.mode || 'create';
    this.curGuid = this.props.match.params.guid || '';

    this.state = {
      curMode,
      dialogOpen: false,
      dialogMessage: '',

      // curIndex: -1,
      // activeKey: '0',
      // isAddingNewRow: false,
      // radioIndex: '1',
      // collapsed: false,
    };

    this.loaded = false;
    this.storeKey = `steadsFormContainer-${`${Math.random()}`.substring(2)}`;
  }

  componentDidMount = () => {
    const { getStead } = this.props;
    const { curMode } = this.state;

    this.props.loadClassifiersForContainer(STEADS_FORM_CONTAINER, {
      [PROPERTY_PARENT_OBJECTS]: { searchTerm: '%' },
    });

    if (curMode === 'view' || curMode === 'edit') {
      getStead(this.curGuid);
    }

    this.props.form.setFieldsValue({ clStateProperty: this.props.curAccountingType || undefined });
  };

  componentWillReceiveProps(nextProps) {
    const {
      formParam: { createdForm, status, errors },
      match: {
        params: { mode },
      },
      resetSteadForm,
      resetSteadFormIsDone,
      form,
    } = nextProps;

    if (this.state.curMode !== mode) this.setState({ curMode: mode });

    if (createdForm.fullName && (mode === 'view' || mode === 'edit') && !this.loaded) {
      this.loaded = true;
      form.setFieldsValue(getParsedForm(createdForm));
    }

    if (status.isDone) {
      this.loaded = true;
      this.curGuid = createdForm.guid;
      form.setFieldsValue(getParsedForm(createdForm));
      this.handleToggleDialog();
      resetSteadFormIsDone();
    }

    if (errors.length > 0) {
      const errorsText = errors.map((el) => el.message).join(', ');
      this.setState({ dialogMessage: errorsText, dialogOpen: true });
      resetSteadForm();
    }
  }

  componentWillUnmount() {
    this.props.resetSteadForm();
  }

  handleCreateNew = () => {
    this.changeRouteTo(`/${RouteNames.PROPERTY}/${RouteNames.STEAD_FORM}/create`);
    this.curGuid = '';
    this.loaded = false;
    this.props.form.resetFields();
    this.props.resetSteadForm();
    this.handleToggleDialog();
  };

  clearForm = () => {
    this.props.form.resetFields();
  };

  changeRouteTo = (route) => {
    this.props.history.push(route);
  };

  handleToggleDialog = (isOpened) => {
    if (isOpened !== undefined) this.setState({ dialogOpen: isOpened });
    else this.setState((prevState) => ({ dialogOpen: !prevState.dialogOpen }));
  };

  handleDialogCancel = () => {
    this.handleToggleDialog();
    this.switchToViewMode();
  };

  switchToEditMode = () => {
    this.changeRouteTo(`/${RouteNames.PROPERTY}/${RouteNames.STEAD_FORM}/edit/${this.curGuid}`);
  };

  switchToViewMode = () => {
    this.changeRouteTo(`/${RouteNames.PROPERTY}/${RouteNames.STEAD_FORM}/view/${this.curGuid}`);
  };

  handleSubmit = (mode, docGuidsArr) => {
    const { curMode } = this.state;
    const { putStead, postStead, form, formParam, operationsRegister } = this.props;

    const operations = (operationsRegister[this.storeKey] || { rows: [] }).rows;

    const curFields = [...Object.keys(generalInfoFields), ...Object.keys(steadFields)];

    form.validateFields(curFields, (err, values) => {
      if (!err) {
        if (curMode === 'create') {
          postStead({
            ...getMappedForm(values),
            objectOperationStatusOperations: operations.length
              ? operations.map((operation) =>
                  getMappedFormForOperations(getParsedFormForOperations(operation)),
                )
              : null,
          });
        }

        if (curMode === 'edit') {
          if (mode === 'documents') {
            const documents = docGuidsArr.reduce((arr, guid) => [...arr, { guid }], []);

            putStead({
              ...formParam.createdForm,
              documents,
            });
          } else {
            putStead({
              ...formParam.createdForm,
              ...getMappedForm(values),
            });
          }
        }
      }
    });
  };

  handleAddDocuments = (docArr) => {
    this.handleSubmit('documents', docArr);
  };

  render() {
    const { curMode, dialogMessage } = this.state;

    const { classifiers, form, history } = this.props;

    const dialogText = curMode === 'create' ? 'створено' : 'відредаговано';
    const isViewMode = curMode === 'view';

    const ControlButtonsComponent = ({ className }) => (
      <ControlButtons
        curMode={curMode}
        clearForm={this.clearForm}
        history={history}
        urlToEditMode={`/${RouteNames.PROPERTY}/${RouteNames.STEAD_FORM}/edit/${this.curGuid}`}
        urlToRegister={`/${RouteNames.PROPERTY}/${RouteNames.REGISTER}`}
        className={className}
      />
    );

    return (
      <Row>
        <Modal
          title="Земельна ділянка"
          visible={this.state.dialogOpen}
          onOk={() => {
            this.handleCreateNew();
          }}
          onCancel={() => {
            this.handleDialogCancel();
          }}
          cancelText="Переглянути картку"
          okText="Створити нову"
        >
          {dialogMessage === '' ? (
            <p>{`Картку успішно ${dialogText}`}</p>
          ) : (
            <p>{`${dialogMessage}`}</p>
          )}
        </Modal>
        <Tabs>
          <TabPane tab="Форма земельної ділянки" key="0">
            <SeparatorErrMsg text="ЦЯ ФОРМА ЩЕ В РОЗРОБЦІ!" />
            <Row>
              <ControlButtonsComponent />
              <Row>
                <GeneralFieldsFormItems
                  form={this.props.form}
                  classifiers={classifiers}
                  generalInfoFields={generalInfoFields}
                  isViewMode={isViewMode}
                  viewMode={curMode}
                />
                {curMode !== 'create' ? (
                  <Row>
                    <Separator text="Реєстр операцій по визначенню операційного стану майнового об'єкта" />
                    <OperationsRegister
                      storeKey={this.storeKey}
                      curMode={curMode}
                      objectGUID={this.curGuid}
                    />
                  </Row>
                ) : (
                  ''
                )}
                <Row>
                  <Separator text="Технічні характеристики" />
                  {mapFormItems({
                    viewMode: curMode,
                    fields: steadFields,
                    classifiers,
                    isViewMode,
                    form,
                  })}

                  <Row type="flex" justify="end">
                    <Button
                      style={{ marginRight: '1.5rem' }}
                      type="primary"
                      onClick={() => {
                        this.handleSubmit();
                      }}
                      disabled
                    >
                      {`Відправити`}
                    </Button>
                  </Row>
                </Row>
              </Row>
            </Row>
          </TabPane>
          {curMode !== 'create' && [
            <TabPane tab={"Контрагенти пов'язані з об'єктом"} key="1">
              <ControlButtonsComponent />
              <RelatedCounterparties curMode={curMode} objectGUID={this.curGuid} />
            </TabPane>,
            <TabPane tab="Документи" key="2">
              <ControlButtonsComponent className="global_mb20" />
              <Documents
                viewMode={curMode}
                rows={this.props.formParam.createdForm.documents || []}
                classifiers={classifiers}
                isViewMode={isViewMode}
                onSave={this.handleAddDocuments}
              />
            </TabPane>,
          ]}
        </Tabs>
      </Row>
    );
  }
}

SteadsFormContainer.propTypes = {
  loadClassifiersForContainer: PropTypes.func.isRequired,
  history: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
  match: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,

  postStead: PropTypes.func.isRequired,
  putStead: PropTypes.func.isRequired,
  getStead: PropTypes.func.isRequired,
  resetSteadForm: PropTypes.func.isRequired,
  resetSteadFormIsDone: PropTypes.func.isRequired,
  // setOperationsRegister: PropTypes.func.isRequired,

  classifiers: PropTypes.objectOf(PropTypes.array).isRequired,
  formParam: PropTypes.objectOf(PropTypes.any).isRequired,
  operationsRegister: PropTypes.objectOf(PropTypes.object).isRequired,

  form: PropTypes.objectOf(PropTypes.any).isRequired,
  curAccountingType: PropTypes.string.isRequired,
};

const mapStateToProps = (state) => ({
  classifiers: state.classifiers,
  operationsRegister: state.property.operationsRegister,
  curAccountingType: state.property.propertyCommon.forms.curAccountingType,
  formParam: state.property.propertySteads.forms.steadForm,
});

export default withRouter(
  connect(mapStateToProps, STEADS_ACTIONS)(Form.create()(SteadsFormContainer)),
);
