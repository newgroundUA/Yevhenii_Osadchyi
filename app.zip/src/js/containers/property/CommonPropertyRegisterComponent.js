import React, { Component } from 'react';
import PropTypes from 'prop-types';
import _isEqual from 'lodash/isEqual';
// import _get from 'lodash/get';

import { Pagination, Button } from 'antd';

import FastSelectFilter from '../../components/common/FastSelectFilter';
import TableToolbar from '../../components/common/toolbar/TableToolbar';
import Table from '../../components/common/table/Table';

import PropertyModalCreateContainer from './PropertyModalCreteContainer';
import * as routes from '../../constants/RouteNames';
import * as toolNames from '../../constants/TableToolNames';

const ButtonGroup = Button.Group;
const limitOption = ['25', '50', '100'];

// Required property 'registerName'

const commonColumnsForFilter = [
  // Общие поля
  { value: 'fullName', label: 'Повна назва' },
  { value: 'shortName', label: 'Скорочена назва' },
];

const constantsMap = {
  Animal: 'ANIMALS',
  Building: 'BUILDINGS',
  Construction: 'CONSTRUCTIONS',
  ElectricityCable: 'ELECTRICITIES',
  Equipment: 'EQUIPMENTS',
  Field: 'FIELDS',
  IntellRight: 'INREL_RIGHTS',
  Pipeline: 'PIPELINES',
  Plant: 'PLANTS',
  Premise: 'PREMISES',
  RailRoad: 'RAILS_ROADS',
  Road: 'ROADS',
  Stead: 'STEADS',
  WhTransport: 'WH_TRANSPORT',
};

const propertyNamesMap = {
  Animal: 'propertyAnimals',
  Building: 'propertyBuildings',
  Construction: 'propertyConstructions',
  ElectricityCable: 'propertyElectricities',
  Equipment: 'propertyEquipments',
  Field: 'propertyFields',
  IntellRight: 'propertyIntellRights',
  Pipeline: 'propertyPipelines',
  Plant: 'propertyPlants',
  Premise: 'propertyPremises',
  RailRoad: 'propertyRailRoads',
  Road: 'propertyRoads',
  Stead: 'propertySteads',
  WhTransport: 'propertyWhTransports',
  AccountingItem: 'propertyEstates',
};

class CommonPropertyRegisterComponent extends Component {
  static propTypes = {
    pages: PropTypes.shape({
      currentPage: PropTypes.number,
      totalFinded: PropTypes.number,
    }).isRequired,
    tableBody: PropTypes.objectOf(PropTypes.any).isRequired,
    history: PropTypes.objectOf(PropTypes.any).isRequired,
    tableToolbar: PropTypes.objectOf(PropTypes.any),
    requestBody: PropTypes.shape({
      limit: PropTypes.number,
      offset: PropTypes.string,
      sortList: PropTypes.object,
      accountingItemTypes: PropTypes.string,
      filter: PropTypes.arrayOf(PropTypes.object),
    }),
    fastFilters: PropTypes.arrayOf(PropTypes.object).isRequired,
    registers: PropTypes.arrayOf(PropTypes.object).isRequired,

    setValueRequestBody: PropTypes.func.isRequired,
    setValuePages: PropTypes.func.isRequired,

    setValueAppSettings: PropTypes.func.isRequired,
    // getUserAppSettings: PropTypes.func.isRequired,

    userInfo: PropTypes.shape({
      guid: PropTypes.string,
    }).isRequired,
    appSettings: PropTypes.objectOf(PropTypes.any).isRequired,
    sortedColumns: PropTypes.objectOf(PropTypes.any).isRequired,
    putUserAppSettings: PropTypes.func.isRequired,
    postUserAppSettings: PropTypes.func.isRequired,
    getPropertyRegister: PropTypes.func.isRequired,
    requestPropertyXLS: PropTypes.func.isRequired,
    resetFilters: PropTypes.func.isRequired,
  };

  static defaultProps = {
    tableToolbar: {},
    requestBody: {},
  };

  checkedItems = [];

  defState = {
    showModal: false,
  };

  state = {
    ...this.defState,
  };

  componentDidMount() {
    const {
      // getUserAppSettings,
      requestBody,
      getPropertyRegister,
      // userInfo: { guid },
    } = this.props;

    // getUserAppSettings(guid, [propertyNamesMap[this.registerName], 'register']);
    getPropertyRegister(
      {
        ...requestBody,
        accountingItemTypes: [this.registerName],
      },
      constantsMap[this.registerName],
    );
  }

  componentWillReceiveProps(nextProps) {
    const { requestBody, getPropertyRegister } = this.props;
    const { requestBody: nextRequestBody } = nextProps;

    if (!_isEqual(requestBody, nextRequestBody)) {
      const sorts = Object.keys(nextRequestBody.sortList).map(
        (key) => nextRequestBody.sortList[key].value + key,
      );

      getPropertyRegister(
        {
          ...nextRequestBody,
          sortList: sorts,
          accountingItemTypes: [this.registerName],
        },
        constantsMap[this.registerName],
      );
    }
  }

  componentWillUnmount() {
    const {
      putUserAppSettings,
      postUserAppSettings,
      setValueRequestBody,
      appSettings: { isDownloaded, settingsGuid, components },
      userInfo: { guid },
    } = this.props;

    const newSettings = components[propertyNamesMap[this.registerName]].register;
    const data = {
      createdBy: guid,
      keySettings: `${propertyNamesMap[this.registerName]}register`,
      settings: JSON.stringify(newSettings),
    };

    setValueRequestBody({
      key: 'filter',
      value: [],
      type: constantsMap[this.registerName],
    });

    if (isDownloaded) putUserAppSettings({ ...data, guid: settingsGuid });
    else postUserAppSettings(data);
  }

  handleShowModal = () => {
    this.setState({
      showModal: true,
    });
  };

  handleClose = () => {
    this.setState({
      showModal: false,
    });
  };

  handleChangeLimit = (current, pageSize) => {
    const { setValueRequestBody, setValuePages } = this.props;

    setValueRequestBody({ key: 'limit', value: pageSize, type: constantsMap[this.registerName] });
    setValueRequestBody({ key: 'offset', value: '0', type: constantsMap[this.registerName] });
    setValuePages({ key: 'currentPage', value: 1, type: constantsMap[this.registerName] });
  };

  handleToggleToolbarItem = (value) => {
    const toolbarItems = this.props.tableToolbar;
    const curSection = Object.keys(toolbarItems).find((key) =>
      Object.keys(toolbarItems[key]).includes(value),
    );
    const isVisible = toolbarItems[curSection][value].isVisible;
    this.props.setValueAppSettings(
      [
        'components',
        propertyNamesMap[this.registerName],
        'register',
        'tableToolbar',
        curSection,
        value,
        'isVisible',
      ],
      !isVisible,
    );
  };

  handleClickToolbarItem = (el) => {
    if (el.title === toolNames.XLS) {
      this.props.requestPropertyXLS();
    }
  };

  saveTableSettings = (obj) => {
    const { setValueAppSettings } = this.props;

    setValueAppSettings(
      ['components', propertyNamesMap[this.registerName], 'register', 'tableBody', 'columns'],
      { ...this.props.tableBody.columns, ...obj },
    );
  };

  handleChangeColumns = (obj) => {
    this.props.setValueAppSettings(
      [
        'components',
        propertyNamesMap[this.registerName],
        'register',
        'tableBody',
        'columns',
        'fluid',
      ],
      { ...this.props.tableBody.columns.fluid, ...obj },
    );
  };

  handleSubmitFilters = () => {
    const { setValueRequestBody, setValuePages } = this.props;

    setValueRequestBody({ key: 'offset', value: '0', type: constantsMap[this.registerName] });
    setValuePages({ key: 'currentPage', value: 1, type: constantsMap[this.registerName] });
  };

  handleCancelFilters = () => {
    const { resetFilters, history } = this.props;

    resetFilters(constantsMap[this.registerName]);
    history.push(`/${routes.PROPERTY}/${routes.REGISTER}`);
  };

  handleChangePage = (page, pageSize) => {
    const {
      setValueRequestBody,
      setValuePages,
      pages: { currentPage },
    } = this.props;

    if (currentPage !== page) {
      const offset = (pageSize * page - pageSize).toString();
      setValueRequestBody({ key: 'offset', value: offset, type: constantsMap[this.registerName] });
      setValuePages({ key: 'currentPage', value: page, type: constantsMap[this.registerName] });
    }
  };

  handleSortColumn = (colName) => {
    const { setValueRequestBody, setValuePages, requestBody } = this.props;

    const previousSortedElement = requestBody.sortList[colName];
    const value = previousSortedElement && previousSortedElement.value === '-' ? '+' : '-';

    setValueRequestBody({
      key: ['sortList'],
      value: { [colName]: { value } },
      type: constantsMap[this.registerName],
    });
    setValuePages({ key: 'currentPage', value: 1, type: constantsMap[this.registerName] });
  };

  handleChangeSelect = (data) => {
    const { setValueRequestBody, setValuePages, history, fastFilters } = this.props;
    setValueRequestBody({
      key: 'accountingItemTypes',
      value: data,
      type: constantsMap[this.registerName],
    });
    setValueRequestBody({ key: 'offset', value: '0', type: constantsMap[this.registerName] });

    setValuePages({ key: 'currentPage', value: 1, type: constantsMap[this.registerName] });
    history.push(fastFilters.filter((f) => f.key === data)[0].url);
  };

  syncronizeCheckedArr = (arr = [], rows) => {
    this.checkedItems = arr.map((key) => rows[key].guid);
  };

  handleFilterWithAttributes = (filterKey, filterValues) => {
    const { setValueRequestBody, setValuePages } = this.props;

    setValueRequestBody({
      key: filterKey,
      value: filterValues,
      type: constantsMap[this.registerName],
    });
    setValuePages({ key: 'currentPage', value: 1, type: constantsMap[this.registerName] });
  };

  render() {
    const {
      requestBody,
      tableToolbar,
      tableBody,
      sortedColumns,
      pages: { totalFinded, currentPage },
      registers,
      fastFilters,
      history,
    } = this.props;

    return (
      <div className="content__table-items">
        <div className="content__table-menu">
          <TableToolbar
            items={tableToolbar}
            columnsForFilter={
              this.columnsForFilter
                ? commonColumnsForFilter.concat(this.columnsForFilter)
                : commonColumnsForFilter
            }
            setValueRequestBody={this.handleFilterWithAttributes}
            handleToggleToolbarItem={this.handleToggleToolbarItem}
            handleClickToolbarItem={this.handleClickToolbarItem}
            isActive={false}
            columns={sortedColumns}
            handleChangeColumns={this.handleChangeColumns}
          >
            <ButtonGroup>
              <Button type="primary" size="large" onClick={this.handleShowModal}>
                {"+ Об'єкт"}
              </Button>
            </ButtonGroup>
          </TableToolbar>
        </div>

        <div className="content__fast-filters">
          <FastSelectFilter
            fastFilters={fastFilters}
            handleChangeSelect={this.handleChangeSelect}
            value={this.registerName}
          />
        </div>

        <div className="content__table">
          <Table
            history={history}
            columnsData={tableBody.columns || {}}
            syncronizeCheckedArr={this.syncronizeCheckedArr}
            rows={registers}
            fixedCount={() => {}}
            saveTableWidthSettings={this.saveTableSettings}
            sortList={requestBody.sortList}
            handleSortColumn={this.handleSortColumn}
          />
        </div>

        <div className="content__pagination">
          <Pagination
            showSizeChanger
            pageSize={+requestBody.limit}
            total={totalFinded}
            current={currentPage}
            pageSizeOptions={limitOption}
            onChange={this.handleChangePage}
            onShowSizeChange={this.handleChangeLimit}
            showTotal={(total) => `Знайдено: ${total}`}
          />
        </div>

        {this.state.showModal && <PropertyModalCreateContainer handleClose={this.handleClose} />}
      </div>
    );
  }
}

export default CommonPropertyRegisterComponent;
