import React from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
// import ReactNotify from 'react-notify';
import { notification } from 'antd';

import * as actions from '../actions';

export class NotificationContainer extends React.Component {
  componentWillReceiveProps(nextProps) {
    const { isSuccessMessage, isErrorMessage, isInfoMessage, closeMessage } = this.props;

    const {
      isSuccessMessage: nextIsSuccessMessage,
      isErrorMessage: nextIsErrorMessage,
      isInfoMessage: nextIsInfoMessage,
      messageData: { message, statusCode, statusMessage },
    } = nextProps;

    if (isSuccessMessage !== true && nextIsSuccessMessage) {
      notification.success({
        onClose: closeMessage,
        message: `${statusCode} ${statusMessage}`,
        description: message,
        // duration: 0
      });
    }

    if (isErrorMessage !== true && nextIsErrorMessage) {
      notification.error({
        onClose: closeMessage,
        message: `${statusCode} ${statusMessage}`,
        description: message,
        // duration: 0
      });
    }

    if (isInfoMessage !== true && nextIsInfoMessage) {
      notification.info({
        onClose: closeMessage,
        message: `${statusCode} ${statusMessage}`,
        description: message,
        // duration: 0
      });
    }
  }

  render() {
    return <div />;
  }
}

const mapStateToProps = (state) => ({
  isSuccessMessage: state.notifications.isSuccessMessage,
  isErrorMessage: state.notifications.isErrorMessage,
  isInfoMessage: state.notifications.isInfoMessage,
  messageData: state.notifications.messageData,
});

NotificationContainer.propTypes = {
  isSuccessMessage: PropTypes.bool.isRequired,
  isErrorMessage: PropTypes.bool.isRequired,
  isInfoMessage: PropTypes.bool.isRequired,
  closeMessage: PropTypes.func.isRequired,
  messageData: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default connect(mapStateToProps, actions)(NotificationContainer);
