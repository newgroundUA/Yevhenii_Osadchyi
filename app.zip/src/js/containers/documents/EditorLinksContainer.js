import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Row, Button, Table, Card, Form } from 'antd';

import * as documentsActions from '../../actions/modules/documents/documentsActions';
import { renderInput } from '../../helpers/formHelpers/mapFormHelper';

import { DOCUMENTS, DOCUMENT_EDITOR, CREATE, EDIT } from '../../constants/RouteNames';

const ButtonGroup = Button.Group;

class EditorLinksContainer extends React.Component {
  columns = [
    {
      title: 'Оригінал',
      dataIndex: 'original',
      key: 0,
    },
    {
      title: 'Похідний документ',
      dataIndex: 'copy',
      key: 1,
    },
    {
      title: 'Дія',
      key: 'operation',
      render: (text, record, rowIndex) => (
        <ButtonGroup key={rowIndex}>
          <Button onClick={() => this.handleEditClick(record)}>Редагувати</Button>
          <Button onClick={() => this.handleExportPDF(record.branch.original)}>
            Експортувати оригінал в PDF
          </Button>
          {record.branch.copy ? (
            <Button onClick={() => this.handleExportPDF(record.branch.copy)}>
              Експортувати похідний документ в PDF
            </Button>
          ) : null}
        </ButtonGroup>
      ),
    },
  ];

  componentDidMount = () => {
    const { documentGUID, loadFileLinks, documentTypeGUID, loadTemplateLinks } = this.props;

    loadFileLinks(documentGUID);
    loadTemplateLinks(documentTypeGUID);
  };

  handleExportPDF = ({ fileLink, version, fileExtension, fileName }) => {
    this.props.exportPDF({ fileLink, version, fileExtension, fileName });
  };

  handleEditClick = ({ branch }) => {
    const { history, documentGUID } = this.props;

    if (branch.copy) {
      history.push(
        `/${DOCUMENTS}/${DOCUMENT_EDITOR}/${EDIT}/${documentGUID}?originalGuid=${
          branch.original.guid
        }&copyLink=${branch.copy.fileLink}&version=${branch.copy.version.replace(
          '.',
          'dot',
        )}&fileName=${branch.original.fileName}`,
      );
    } else {
      history.push(
        `/${DOCUMENTS}/${DOCUMENT_EDITOR}/${CREATE}/${documentGUID}?originalGuid=${
          branch.original.guid
        }&originalLink=${branch.original.fileLink}&version=${branch.original.version.replace(
          '.',
          'dot',
        )}&fileName=${branch.original.fileName}`,
      );
    }
  };

  handleGenerateClick = (templateLink) => {
    const { documentGUID, postEditorDocumentFile, loadFileLinks, form } = this.props;

    form.validateFields([templateLink.fileLink], (err, values) => {
      if (!err) {
        postEditorDocumentFile(
          templateLink,
          `${values[templateLink.fileLink]}.htm`,
          documentGUID,
        ).then(() => loadFileLinks(documentGUID));
      }
    });
  };

  render() {
    const { branches, templates, form } = this.props;

    const rows = branches.map((branch) => ({
      key: branch.original.fileLink,
      original: branch.original.fileName,
      copy: branch.copy && `${branch.copy.fileName}.${branch.copy.fileExtension}`,
      branch,
    }));

    return (
      <Row>
        <Row>
          Documents:
          <div className="card-list">
            <Table
              style={{ margin: '1rem 0', background: '#fff' }}
              bordered
              pagination={false}
              columns={this.columns}
              dataSource={rows}
            />
          </div>
        </Row>
        <Row>
          Templates:
          <div className="card-list">
            {templates.map((template) => (
              <Card title={template.fileName} key={template.guid}>
                <div className="preview" />
                {renderInput({
                  key: template.guid,
                  item: {
                    field: template.fileLink,
                    rules: [{ required: true, message: "Введіть ім'я нового оригіналу!" }],
                  },
                  form,
                })}
                <Button type="primary" onClick={() => this.handleGenerateClick(template)}>
                  Згенерувати
                </Button>
              </Card>
            ))}
          </div>
        </Row>
      </Row>
    );
  }
}

EditorLinksContainer.propTypes = {
  history: PropTypes.objectOf(PropTypes.any).isRequired,
  form: PropTypes.objectOf(PropTypes.any).isRequired,
  documentGUID: PropTypes.string.isRequired,
  documentTypeGUID: PropTypes.string.isRequired,
  templates: PropTypes.arrayOf(
    PropTypes.shape({
      fileLink: PropTypes.string.isRequired,
      version: PropTypes.string,
    }),
  ).isRequired,
  branches: PropTypes.arrayOf(PropTypes.any).isRequired,
  loadFileLinks: PropTypes.func.isRequired,
  loadTemplateLinks: PropTypes.func.isRequired,
  postEditorDocumentFile: PropTypes.func.isRequired,
  exportPDF: PropTypes.func.isRequired,
};

const mapStateToProps = (state) => ({
  branches: state.documentForms.htmlEditor.branches,
  templates: state.documentForms.htmlEditor.templateLinks,
});

export default Form.create()(connect(mapStateToProps, documentsActions)(EditorLinksContainer));
