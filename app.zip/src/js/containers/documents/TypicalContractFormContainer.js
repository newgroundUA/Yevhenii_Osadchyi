import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import moment from 'moment';

import { Tabs, Modal, Row, Form, Icon, Button, Table } from 'antd';

import _get from 'lodash/get';
import _remove from 'lodash/remove';
import { withRouter } from 'react-router-dom';

import * as leaseContractActions from '../../actions/modules/documents/leaseContractActions';
import { loadLandlordsToLeaseObjects } from '../../actions/modules/documents/rentStatementActions';
import * as classifiersActions from '../../actions/classifiersActions';
import { createLeaseContractSelector } from '../../selectors/modules/documents';

import { TYPICAL_CONTRACT_FORM_CONTAINER } from '../../constants/ContainerNames';
import {
  WEBSITELIST,
  LEASE_RATE_DIRECTORY,
  LEASE_RATE_DISCOUNTBASE_TYPE,
  LAND_LORDS_TO_LEASE_OBJECTS,
  REF_DOCUMENT_TYPE_GENERAL_DOC_CLASSNAME,
} from '../../constants/ClassifiersNames';

import * as RouteNames from '../../constants/RouteNames';

import { generalFields } from '../../models/formFields/documents/generalFields';
import {
  typicalContractFields as typicalContractFieldsConfig,
  objectOfLeaseContractListFields,
  leaseBasePeriodinReportingPeriodFields,
  getMappedForm,
  getParsedForm,
  getMappedForObjects,
  getParsedForObjects,
  getLeaseBasePeriodsToBe,
  getLeaseBasePeriodsToFe,
  leaseObjectsLinkFields,
  getParsedForLeaseObjects,
} from '../../models/formFields/documents/typicalContractFields';

import GeneralControlButtons from './common/GeneralControlButtons';
import GeneralTabsContainer from './common/GeneralTabsContainer';
import LockDocumentModal from './common/modals/LockDocumentModal';
import Separator from '../../components/common/form/Separator';

import FormTable from '../../components/common/form/Table';
import CounterpartiesDropdownContainer from '../common/CounterpartiesDropdownContainer';
import ObjectsDropdownContainer from '../common/ObjectsDropdownContainer';

// TODO: Remove tab 'Documents' DKV-1968
// import EditorLinksContainer from './EditorLinksContainer';

import { mapFormItems } from '../../helpers/formHelpers/mapFormHelper';
import {
  failedValidationNotification,
  getFormEntityData,
  mapRowsToTable,
} from '../../helpers/formHelpers/formHelpers';
import { getObjGuidAndVersionId } from '../../helpers/commonUtils';
import { defStoreKey } from '../../helpers/reducers/documents/commonActionsHandlers';
import { getTableColumns } from '../../helpers/table';
import { isMonthBetween, isRequired, isYearBetween } from '../../services/validator/rules';
import { goToRegistry } from '../../helpers/entities/registry';
import { disabledEndDate, disabledStartDate } from '../../services/validator/date';

const TabPane = Tabs.TabPane;

const mapSectionsToFields = {
  sidesAndGrounds: [
    'landlord', // counterparty
    'landlordrepresenter', // counterparty Person
    'landlordbankdetail',
    'renter', // counterparty
    'renterrepresenter', // counterparty Person
    'renterbankdetail',
    'balancekeeper', // counterparty
    'balancekeeperrepresenter', // counterparty Person
    'balancekeepebankdetail',
    'cuObjectsleaserate',
    'leaseratecorrectivefactor',
    'landlordrepresenterreasondoc', // document
    'renterrepresenterreasondoc', // document
    'balancekeeperrepresenterreasondoc', // document
    'rentPriseCalcReasonDoc',
    'basementcontractdocs', // document
    'insurancedocs', // document
  ],
  registrationData: [
    'signdate',
    'stateregistrdate',
    'contracadditionalregistration',
    'autoprolongation',
  ],
  feeCalculationParams: [
    'shortpenaltypaymentrate',
    'shortpenaltypaymentratemax',
    'shortpenaltypaymentperiod',
    'longpenaltypaymentrate',
    'longpenaltypaymentratemax',
    'longpenaltypaymentperiod',
  ],
  controlDatesOfConditionExecution: [
    'stopusingperiod',
    'createterminsurancepolice',
    'endcontractreturnterm',
    'newinsurancepolicegiveterm',
    'rentpaymentallowedterm',
    'monthenumlist',
    'yearenumlist',
  ],
  avansPaymentParams: ['advancepaymentterm', 'baserentperiod', 'baserentperiodforadvance'],
  renterStartDateOfUsage: ['leasestartusingterm', 'committalperiod'],
};

class TypicalContractFormContainer extends React.Component {
  constructor(props) {
    super(props);
    const curMode = this.props.match.params.mode || 'create';

    this.initialState = {
      curMode,
      dialogMessage: '',
      lockDocumentModalIsOpen: false,
      dialogOpen: false,
      mltQuantityByPeriod: {},
      leaseObjects: [],
      currentLandlord: null,
    };

    this.state = { ...this.initialState };

    // handleSubmitLeaseObject required dvalidtill
    this.generalFieldsWithRequiredEndData = {
      ...generalFields,
      dvalidfrom: {
        ...generalFields.dvalidfrom,
        disabledDate: null,
      },
      dvalidtill: {
        ...generalFields.dvalidtill,
        disabledDate: null,
        rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
        readOnly: false,
      },
    };

    this.curGuid = this.props.match.params.guid || '';
    this.leaseObjectsColumns = getTableColumns({
      formFields: leaseObjectsLinkFields,
    });
  }

  getGeneralFields = () => {
    const form = this.props.form;

    return {
      ...this.generalFieldsWithRequiredEndData,
      dvalidfrom: {
        ...this.generalFieldsWithRequiredEndData.dvalidfrom,
        disabledDate: disabledStartDate(form, 'dvalidtill'),
      },
      dvalidtill: {
        ...this.generalFieldsWithRequiredEndData.dvalidtill,
        disabledDate: disabledEndDate(form, 'dvalidfrom'),
      },
    };
  };

  componentWillMount() {
    const { history } = this.props;
    if (this.state.curMode === 'create' && !this.getFormType()) {
      goToRegistry({
        name: 'documents',
        history,
      });
    }
  }

  componentDidMount = () => {
    const { getLeaseContractDocument, modalData, storeKey, isViewModal } = this.props;
    const { curMode } = this.state;

    this.props.loadLandlordsToLeaseObjects();
    this.props.loadClassifiersForContainer(TYPICAL_CONTRACT_FORM_CONTAINER, {
      [WEBSITELIST]: { webSiteRegistryParam: { offset: '0', limit: '100' } },
      [REF_DOCUMENT_TYPE_GENERAL_DOC_CLASSNAME]: { generalDocClassName: 'LeaseContract' },
    });

    if (isViewModal) {
      this.setState({ curMode: 'view' });
      getLeaseContractDocument(modalData.guid, storeKey);
    } else if (curMode === 'view' || curMode === 'edit') {
      getLeaseContractDocument(this.curGuid);
    }
  };

  getLeaseObjects = (landlordsToLeaseObjects) =>
    landlordsToLeaseObjects
      .filter(
        (r) => !!r.leaseObject, // fix this next time
        /* r.landlord.guid === (form.getFieldsValue(['landlord']).landlord || {}).key */
      )
      .map((r) => r.leaseObject);

  componentWillReceiveProps(nextProps) {
    const {
      formParam: { createdForm, status, errors },
      match: {
        params: { mode },
      },
      storeKey,
      isViewModal,
      resetLeaseContractDocumentForm,
      resetLeaseContractDocumentDoneStatus,
      form,
    } = nextProps;

    if (isViewModal && isViewModal !== this.props.isViewModal) {
      this.setState({ curMode: 'view' });
    } else if (this.state.curMode !== mode) {
      this.setState({ curMode: mode });
    }

    if (
      (createdForm.versionId || createdForm.versionId === 0) &&
      this.props.formParam.createdForm.versionId !== createdForm.versionId
    ) {
      form.setFieldsValue(getParsedForm(createdForm));
    } else if (createdForm.guid && (mode === 'view' || mode === 'edit') && !this.loaded) {
      this.loaded = true;
      form.setFieldsValue(getParsedForm(createdForm));
    }

    if (status.isDone) {
      this.loaded = true;
      this.curGuid = createdForm.guid;
      this.curVersionId = createdForm.versionId;
      this.handleToggleDialog();
      resetLeaseContractDocumentDoneStatus(storeKey);
    }

    if (this.state.curMode !== mode && mode === 'create') {
      form.resetFields();
      resetLeaseContractDocumentForm(storeKey);
    }

    if (errors.length > 0) {
      const errorsText = errors.map((el) => el.message).join(', ');
      this.setState({ dialogMessage: errorsText, dialogOpen: true });
      resetLeaseContractDocumentForm(storeKey);
    }
    const selectedLandlord = (form.getFieldsValue(['landlord']).landlord || {}).key;
    if (
      this.state.currentLandlord !== selectedLandlord ||
      this.props.landlordsToLeaseObjects !== nextProps.landlordsToLeaseObjects
    ) {
      const newLeaseObjects = this.getLeaseObjects(nextProps.landlordsToLeaseObjects);

      this.setState({
        currentLandlord: selectedLandlord,
        leaseObjects: newLeaseObjects,
      });
    }
  }

  componentWillUnmount() {
    this.props.resetLeaseContractDocumentForm(this.props.storeKey);
  }

  handleSubmit = ({ ignoreStatus, file = {}, delFileGuid = '', delDoc = {} }) => {
    const { curMode } = this.state;
    const {
      putLeaseContractDocument,
      postLeaseContractDocument,
      classifiers,
      form,
      storeKey,
      formParam: { createdForm },
    } = this.props;
    const typicalContractFields = this.getTypicalContractFields();
    const curFields = [...Object.keys(generalFields), ...Object.keys(typicalContractFields)];

    const fields = {
      ...generalFields,
      ...typicalContractFields,
    };

    form.validateFields(curFields, (err, values) => {
      if (!err) {
        const normilizedValues = getFormEntityData(values, classifiers, fields);
        const documents = this.props.classifiers.documents;

        if (curMode === 'create') {
          const data = {
            ...getMappedForm(normilizedValues),
            refDocumentType: this.getFormTypeData(),
            documentType: 'LeaseContract',
          };
          const getFullDocument = (selectedValues) => {
            if (selectedValues) {
              return selectedValues.map(({ guid }) => documents.find((doc) => doc.guid === guid));
            }
            return undefined;
          };

          postLeaseContractDocument(
            {
              ...data,
              balanceKeeperRepresenterReasonDocs: getFullDocument(
                data.balanceKeeperRepresenterReasonDocs,
              ),
              basementContractDocs: getFullDocument(data.balanceKeeperRepresenterReasonDocs),
              landlordRepresenterReasonDocs: getFullDocument(
                data.balanceKeeperRepresenterReasonDocs,
              ),
              renterRepresenterReasonDocs: getFullDocument(data.balanceKeeperRepresenterReasonDocs),
              rentPriseCalcReasonDocs: getFullDocument(data.balanceKeeperRepresenterReasonDocs),
              insuranceDocs: getFullDocument(data.insuranceDocs),
            },
            storeKey,
          );
        }

        if (curMode === 'edit') {
          const files = file.guid ? [...createdForm.fileStorage, file] : createdForm.fileStorage;

          if (delFileGuid) {
            _remove(files, (el) => el.guid === delFileGuid);
          }

          if (delDoc.guid) {
            if (Array.isArray(createdForm[delDoc.field])) {
              _remove(createdForm[delDoc.field], (el) => el.guid === delDoc.guid);
            } else {
              createdForm[delDoc.field] = undefined;
            }
          }
          putLeaseContractDocument(
            {
              ...createdForm,
              ...getMappedForm(normilizedValues),
              fileStorage: getObjGuidAndVersionId(files),
              linkedDocuments: getObjGuidAndVersionId(createdForm.linkedDocuments),
              parentDocument: getObjGuidAndVersionId(createdForm.parentDocument),
              childrenDocuments: getObjGuidAndVersionId(createdForm.childrenDocuments),
              leaseObjectsInLeaseContractList: createdForm.leaseObjectsInLeaseContractList,
              guid: this.curGuid,
              versionId: _get(createdForm, 'versionId', this.curVersionId),
            },
            storeKey,
            ignoreStatus,
          );
        }
      } else {
        failedValidationNotification(err, fields);
      }
    });
  };

  getFormType = () => {
    const {
      formTypeData,
      classifiers,
      formParam: {
        createdForm: { refDocumentType },
      },
    } = this.props;

    const documentTypeField = classifiers.refDocumentTypeGeneralDocClassName.find(
      (el) => el.guid === (refDocumentType || {}).guid,
    );

    if (documentTypeField) {
      return documentTypeField;
    }
    return formTypeData;
  };

  getFormTypeData = () => {
    const { guid, versionId, type } = this.getFormType();
    return {
      guid,
      versionId,
      type,
    };
  };

  getFormTypeLabel = () => {
    const obj = this.getFormType();
    return obj && `${obj.scopeOfApplication}/${obj.docCategory}/${obj.name}`;
  };

  extractFields = (fieldNames, formFields) =>
    fieldNames.reduce(
      (newFields, key) => ({
        ...newFields,
        [key]: formFields[key],
      }),
      {},
    );

  handleDialogOpen = () => {
    this.setState({ dialogOpen: true });
  };

  handleDialogClose = () => {
    this.setState({ dialogOpen: false });
  };

  switchToEditMode = () => {
    this.changeRouteTo(
      `/${RouteNames.DOCUMENTS}/${RouteNames.DOCUMENT_TYPICAL_CONTRACT}/edit/${this.curGuid}`,
    );
  };

  switchToViewMode = () => {
    this.changeRouteTo(
      `/${RouteNames.DOCUMENTS}/${RouteNames.DOCUMENT_TYPICAL_CONTRACT}/view/${this.curGuid}`,
    );
  };

  clearForm = () => {
    this.props.form.resetFields();
  };

  changeRouteTo = (route) => {
    this.props.history.push(route);
  };

  handleCreateNew = () => {
    this.changeRouteTo(`/${RouteNames.DOCUMENTS}/${RouteNames.DOCUMENT_GENERAL}/create`);
    this.curGuid = '';
    this.loaded = false;
    this.props.form.resetFields();
    this.props.resetLeaseContractDocumentForm(this.props.storeKey);
    this.handleToggleDialog();
  };

  handleToggleDialog = (isOpened) => {
    if (isOpened !== undefined) this.setState({ dialogOpen: isOpened });
    else this.setState((prevState) => ({ dialogOpen: !prevState.dialogOpen }));
  };

  handleDialogCancel = () => {
    this.handleToggleDialog();
    this.switchToViewMode();
  };

  handleSubmitPropertyObject = ({ obj }) => {
    const { storeKey } = this.props;

    const post = {
      ...getMappedForObjects(obj),
      leaseContract: {
        guid: this.curGuid,
        versionId: _get(this.props.formParam.createdForm, 'versionId', this.curVersionId),
      },
    };

    const put = {
      ...obj.beObj,
      ...post,
    };

    if (!put.guid) {
      this.props.postObjectInLeaseContract(post, storeKey).then((res) => {
        if (res.statusCode === 200) {
          this.props.getLeaseContractDocument(this.curGuid, storeKey);
        }
      });
    } else {
      this.props.putObjectInLeaseContract(put, storeKey).then((res) => {
        if (res.statusCode === 200) {
          this.props.getLeaseContractDocument(this.curGuid, storeKey);
        }
      });
    }
  };

  handleSubmitLeaseBasePeriod = (record) => ({ obj }) => {
    const { storeKey } = this.props;

    const post = {
      ...getLeaseBasePeriodsToBe(obj),
      objectOfLeaseContract: getObjGuidAndVersionId(record),
    };

    const put = { ...obj.beObj, ...post };

    this.props.form.validateFields(Object.keys(leaseBasePeriodinReportingPeriodFields), (err) => {
      if (err) {
        return err;
      }

      if (!put.guid) {
        this.props.postLeaseBasePeriod(post, storeKey).then((res) => {
          if (res.statusCode === 200) {
            this.props
              .getLeaseContractDocument(this.curGuid, storeKey)
              .then(() => this.loadMltQuantityByPeriod(record.guid));
          }
        });
      } else {
        this.props.putLeaseBasePeriod(put, storeKey).then((res) => {
          if (res.statusCode === 200) {
            this.props
              .getLeaseContractDocument(this.curGuid, storeKey)
              .then(() => this.loadMltQuantityByPeriod(record.guid));
          }
        });
      }
    });
  };

  handleSubmitLeaseObject = () => {
    const {
      form,
      putLeaseContractDocument,
      postObjectInLeaseContract,
      classifiers,
      storeKey,
      formParam: { createdForm },
    } = this.props;
    const typicalContractFields = this.getTypicalContractFields();
    const docFields = [...Object.keys(generalFields), ...Object.keys(typicalContractFields)];
    const fields = {
      ...generalFields,
      ...typicalContractFields,
      leaseObject: {
        valuableFields: ['guid', 'versionId'],
        classifier: LAND_LORDS_TO_LEASE_OBJECTS,
      },
    };

    form.validateFields(['leaseObject', ...docFields], (err, values) => {
      if (!err) {
        const normilizedValues = getFormEntityData(values, classifiers, fields);
        const { leaseObject, ...docValues } = normilizedValues;

        const propertyObjectsInLeaseObject =
          this.state.leaseObjects.find((el) => el.guid === leaseObject.guid).objectInLeaseObject ||
          [];

        Promise.all([
          putLeaseContractDocument(
            {
              ...getMappedForm(docValues),
              refDocumentType: this.getFormTypeData(),
              leaseObjectsInLeaseContractList: [
                ...(createdForm.leaseObjectsInLeaseContractList || []),
                leaseObject,
              ],
              guid: this.curGuid,
              versionId: _get(this.props.formParam.createdForm, 'versionId', this.curVersionId),
            },
            storeKey,
          ),
          ...propertyObjectsInLeaseObject.forEach((propertyObject) =>
            postObjectInLeaseContract(
              {
                objectInLease: { guid: propertyObject.guid, versionId: propertyObject.versionId },
                leaseContract: {
                  guid: this.curGuid,
                  versionId: _get(this.props.formParam.createdForm, 'versionId', this.curVersionId),
                },

                // default values
                objectListRecordStatus: 'DraftContract',
                objectListRecordStatusDate: moment().format(),
                objectInLeaseStartDate: createdForm.dateFrom,
                objectInLeaseEndDate: createdForm.dateTo,
                leaseRateDetectMethod: 'AccordingToTheMethodology',
                leaseRateDiscountBaseType: classifiers[LEASE_RATE_DISCOUNTBASE_TYPE][0],
                leaseRateDirectory: classifiers[LEASE_RATE_DIRECTORY][0],
                objectMarketValueDocs: [],
                leaseOperationMode: 'MONTHLY',
                leaseRateByFact: 0,
                legalYearRental: 0,
                factYearRental: 0,
                baseRental: 0,
                // objectInLeaseStartDateFact: '',
                // objectInLeaseEndDateFact: '',
                leaseObjectRecieptDocs: [],
                leaseObjectReturnDocs: [],
              },
              storeKey,
            ),
          ),
        ]).then((results) => {
          if (results.some((res) => res.statusCode === 200)) {
            form.resetFields(['leaseObject']);
            this.props.getLeaseContractDocument(this.curGuid);
          }
        });
      }
    });
  };

  handleDeletePropertyObject = (guid) => this.props.deleteObjectInLeaseContract(guid);

  handleDeleteLeaseBasePeriod = (guid) => this.props.deleteLeaseBasePeriod(guid);

  handleDeleteLeaseObject = () => {
    console.log('handleDeleteLeaseObject'); // eslint-disable-line
  };
  // TODO: Remove update schedule (DKV-1959)
  // updateLeaseContractPaymentSchedule = () => {
  //   this.props
  //     .putUpdateLeaseContractPaymentSchedule(this.curGuid, this.props.storeKey)
  //     .then((res) => {
  //       if (res.statusCode === 200) {
  //         message.success('Дані успішно оновлено.');
  //       }
  //     });
  // };

  handleLockDocumentModal = () => {
    this.setState((prevState) => ({
      lockDocumentModalIsOpen: !prevState.lockDocumentModalIsOpen,
    }));
  };

  getTypicalContractFields = () => {
    const { form } = this.props;

    function checkPaymentIsHigherThanRate({ paymentFieldName, rateFieldName }) {
      return function onChange(event) {
        const { value: payment } = event.target;
        const maxRate = form.getFieldValue(rateFieldName);
        setTimeout(() => {
          if (+payment > maxRate) {
            form.setFields({
              [paymentFieldName]: {
                value: payment,
                errors: [new Error(`Значення не повинно перевищувати ${maxRate}`)],
              },
            });
          }
        }, 100);
      };
    }

    function checkRateIsHigherThanPayment({ paymentFieldName }) {
      return function onChange(event) {
        const { value: maxRate } = event.target;
        const payment = form.getFieldValue(paymentFieldName);
        const paymentRateIsHigherMaxRate = payment > +maxRate;
        const errors = paymentRateIsHigherMaxRate
          ? [new Error(`Значення не повинно перевищувати ${maxRate}`)]
          : null;
        setTimeout(() => form.setFields({ [paymentFieldName]: { value: payment, errors } }), 0);
      };
    }

    return {
      ...typicalContractFieldsConfig,
      shortpenaltypaymentrate: {
        ...typicalContractFieldsConfig.shortpenaltypaymentrate,
        onChange: checkPaymentIsHigherThanRate({
          paymentFieldName: 'shortpenaltypaymentrate',
          rateFieldName: 'shortpenaltypaymentratemax',
        }),
      },
      shortpenaltypaymentratemax: {
        ...typicalContractFieldsConfig.shortpenaltypaymentratemax,
        onChange: checkRateIsHigherThanPayment({ paymentFieldName: 'shortpenaltypaymentrate' }),
      },
      longpenaltypaymentrate: {
        ...typicalContractFieldsConfig.longpenaltypaymentrate,
        onChange: checkPaymentIsHigherThanRate({
          paymentFieldName: 'longpenaltypaymentrate',
          rateFieldName: 'longpenaltypaymentratemax',
        }),
      },
      longpenaltypaymentratemax: {
        ...typicalContractFieldsConfig.longpenaltypaymentratemax,
        onChange: checkRateIsHigherThanPayment({ paymentFieldName: 'longpenaltypaymentrate' }),
      },
    };
  };

  validateObjectLeaseStartDate = (date = moment()) => {
    const { form } = this.props;
    const docEndDate = form.getFieldValue('dvalidtill');
    const docStartDate = form.getFieldValue('dvalidfrom');
    const leaseEndDate = form.getFieldValue('objectInLeaseEndDate') || docEndDate;
    const endDateToCheck = leaseEndDate || docEndDate;
    return date.valueOf() > endDateToCheck.valueOf() || date.valueOf() < docStartDate.valueOf();
  };

  validateObjectLeaseEndDate = (date = moment()) => {
    const { form } = this.props;
    const docEndDate = form.getFieldValue('dvalidtill');
    const docStartDate = form.getFieldValue('dvalidfrom');
    const leaseStartDate = form.getFieldValue('objectInLeaseStartDate') || docStartDate;
    const startDateToCheck = leaseStartDate || docStartDate;
    return date.valueOf() > docEndDate.valueOf() || date.valueOf() < startDateToCheck.valueOf();
  };

  getObjectOfLeaseContractListFields = () => {
    const { form } = this.props;
    return {
      ...objectOfLeaseContractListFields,
      leaseRateDiscountBaseType: {
        ...objectOfLeaseContractListFields.leaseRateDiscountBaseType,
        rules:
          form.getFieldValue('leaseRateDetectMethod') === 'PrivilegedOneHryvniaForYear'
            ? [isRequired()]
            : [],
      },
      objectInLeaseStartDate: {
        ...objectOfLeaseContractListFields.objectInLeaseStartDate,
        disabledDate: this.validateObjectLeaseStartDate,
      },
      objectInLeaseEndDate: {
        ...objectOfLeaseContractListFields.objectInLeaseEndDate,
        disabledDate: this.validateObjectLeaseEndDate,
      },
    };
  };

  loadMltQuantityByPeriod = (guid) => {
    this.props.getLeaseObjectOfLeaseContract(guid).then((res) => {
      this.setState((prev) => ({
        ...prev,
        mltQuantityByPeriod: {
          ...prev.mltQuantityByPeriod,
          [guid]: res.data,
        },
      }));
    });
  };

  loadMltQuantityByPeriodOnExpand = (isExpanded, record) => {
    if (isExpanded && !this.state.mltQuantityByPeriod[record.guid]) {
      this.loadMltQuantityByPeriod(record.guid);
    }
  };

  getLeaseBasePeriodinReportingPeriodFields = (record) => {
    const startDateYear = moment(record.objectInLeaseStartDate, 'DD/MM/YYYY').year();
    const endDateYear = moment(record.objectInLeaseEndDate, 'DD/MM/YYYY').year();
    const startDateMonth = moment(record.objectInLeaseEndDate, 'DD/MM/YYYY').month() + 1;
    const endDateMonth = moment(record.objectInLeaseEndDate, 'DD/MM/YYYY').month() + 1;

    return {
      ...leaseBasePeriodinReportingPeriodFields,
      planReportingYear: {
        ...leaseBasePeriodinReportingPeriodFields.planReportingYear,
        rules: [isRequired(), isYearBetween(startDateYear, endDateYear)],
      },
      planReportingMonth: {
        ...leaseBasePeriodinReportingPeriodFields.planReportingMonth,
        rules: [isRequired(), isMonthBetween(startDateMonth, endDateMonth)],
      },
    };
  };

  render() {
    const { curMode, dialogMessage, leaseObjects } = this.state;

    const {
      formParam: { createdForm },
      isViewModal,
      storeKey,
      bindDocToLeaseContractDocument,
      lockDocToLeaseContractDocument,
      form,
      formParam,
      landlords,
    } = this.props;

    const typicalContractFields = this.getTypicalContractFields();
    const { classifiers } = this.props;
    const isViewMode = isViewModal || curMode === 'view';
    const dialogText = curMode === 'create' ? 'створено' : 'відредаговано';

    const objectOfLeaseContractList = (createdForm || {}).objectOfLeaseContractList || [];
    const parsedLeaseObjects = mapRowsToTable(
      ((createdForm || {}).leaseObjectsInLeaseContractList || []).map(getParsedForLeaseObjects),
      leaseObjectsLinkFields,
      classifiers,
    );

    const mapFormItemsForFields = (fields) =>
      mapFormItems({
        viewMode: curMode,
        fields,
        classifiers,
        isViewMode,
        form: this.props.form,
      });

    const controlButtons = (
      <GeneralControlButtons
        form={form}
        guid={this.curGuid}
        handleLockDocument={this.handleLockDocumentModal}
        documentType="DOCUMENT_TYPICAL_CONTRACT"
      />
    );

    return (
      <div>
        <Modal
          title="Типовий договір на оренду"
          visible={this.state.dialogOpen}
          onOk={() => {
            this.handleCreateNew();
          }}
          onCancel={() => {
            this.handleDialogCancel();
          }}
          cancelText="Переглянути картку"
          okText="Створити нову"
        >
          {dialogMessage === '' ? (
            <p>{`Картку успішно ${dialogText}`}</p>
          ) : (
            <p>{`${dialogMessage}`}</p>
          )}
        </Modal>
        <Modal
          title="Блокування документа"
          visible={this.state.lockDocumentModalIsOpen}
          onCancel={this.handleLockDocumentModal}
          footer={null}
          width="1000px"
          maskClosable={false}
          destroyOnClose
        >
          <LockDocumentModal
            handleCloseModal={this.handleLockDocumentModal}
            childrenDocuments={formParam.createdForm.childrenDocuments}
            guid={this.curGuid}
            versionId={_get(formParam, ['createdForm', 'versionId'], this.curVersionId)}
            updateForm={lockDocToLeaseContractDocument}
            loadDocument={() => this.props.getLeaseContractDocument(this.curGuid)}
          />
        </Modal>
        <h1 key="formLabel">{this.getFormTypeLabel()}</h1>
        <GeneralTabsContainer
          ownerSide={{
            guid: this.curGuid,
            versionId: _get(formParam[storeKey], ['createdForm', 'versionId'], this.curVersionId),
          }}
          editAction={this.handleSubmit}
          controlButtons={controlButtons}
          bindDocAction={bindDocToLeaseContractDocument}
          isViewModal={isViewModal}
          createdForm={formParam.createdForm}
        >
          <TabPane disabled={false} tab="Типовий договір оренди" key="0">
            {!isViewModal && controlButtons}
            <Row>
              <Separator text="Основна інформація" />
              {mapFormItemsForFields(this.getGeneralFields())}
            </Row>
            <Row>
              <Separator text="Типовий договір оренди" />
              <Row>
                <Separator text="Сторони і підстави договору" pxSize="14" />
                <Row>
                  <CounterpartiesDropdownContainer
                    form={this.props.form}
                    isViewMode={isViewMode}
                    fieldSpec={typicalContractFields.landlord}
                    customOptions={landlords}
                    updater={{}}
                  />
                  <CounterpartiesDropdownContainer
                    form={this.props.form}
                    isViewMode={isViewMode}
                    fieldSpec={typicalContractFields.landlordrepresenter}
                    counterpartyType="Person"
                    updater={{}}
                  />
                </Row>
                {mapFormItemsForFields(
                  this.extractFields(mapSectionsToFields.sidesAndGrounds, typicalContractFields),
                )}
              </Row>
              <Row>
                <Separator text="Дані реєстрації договору оренди" pxSize="14" />
                {mapFormItemsForFields(
                  this.extractFields(mapSectionsToFields.registrationData, typicalContractFields),
                )}
              </Row>
              <Row>
                <Separator text="Параметри розрахунку штрафів" pxSize="14" />
                {mapFormItemsForFields(
                  this.extractFields(
                    mapSectionsToFields.feeCalculationParams,
                    typicalContractFields,
                  ),
                )}
              </Row>
              <Row>
                <Separator text="Контрольні терміни виконання умов договору" pxSize="14" />
                {mapFormItemsForFields(
                  this.extractFields(
                    mapSectionsToFields.controlDatesOfConditionExecution,
                    typicalContractFields,
                  ),
                )}
              </Row>
              <Row>
                <Separator text="Параметри авансового платежу" pxSize="14" />
                {mapFormItemsForFields(
                  this.extractFields(mapSectionsToFields.avansPaymentParams, typicalContractFields),
                )}
              </Row>
              <Row>
                <Separator text="Термін вступу орендарем в користування" pxSize="14" />
                {mapFormItemsForFields(
                  this.extractFields(
                    mapSectionsToFields.renterStartDateOfUsage,
                    typicalContractFields,
                  ),
                )}
              </Row>
            </Row>
            <Row type="flex" justify="end">
              <Button
                style={{ marginRight: '1.5rem' }}
                type="primary"
                onClick={this.handleSubmit}
                disabled={isViewMode}
              >
                Відправити
              </Button>
            </Row>
          </TabPane>
          <TabPane disabled={curMode === 'create'} tab="Майнові об'єкти у договорі" key="1">
            {!isViewModal && controlButtons}
            <Row>
              <Separator text="Об'єкти аренди у договорі" />
              <Row>
                <ObjectsDropdownContainer
                  customOptions={leaseObjects}
                  form={this.props.form}
                  fieldSpec={{
                    field: 'leaseObject',
                    name: "Об'єкт оренди",
                    placeholder: "Виберіть об'єкт оренди",
                    rules: [isRequired()],
                  }}
                  isViewMode={isViewMode}
                />
                <Button
                  disabled={isViewMode}
                  style={{ marginRight: '1rem' }}
                  onClick={this.handleSubmitLeaseObject}
                  type="primary"
                >
                  <Icon type="save" />
                  Зберегти
                </Button>
              </Row>
              <Table
                style={{ margin: '1rem 0', background: '#fff' }}
                bordered
                pagination={false}
                columns={this.leaseObjectsColumns}
                dataSource={parsedLeaseObjects}
              />
            </Row>
            <Row>
              <Separator text="Майнові об'єкти у договорі" />
              {/* TODO: Remove button (DKV-1959) */}
              {/*
              <Button onClick={this.updateLeaseContractPaymentSchedule}>
                Перерахувати графік платежів
              </Button>
              */}
              <FormTable
                classifiers={classifiers}
                fields={this.getObjectOfLeaseContractListFields()}
                viewMode={curMode}
                parserToFE={getParsedForObjects}
                rows={objectOfLeaseContractList}
                form={this.props.form}
                scroll={{ x: '100%' }}
                isViewMode={isViewMode}
                onSave={this.handleSubmitPropertyObject}
                onDelete={this.handleDeletePropertyObject}
                onExpand={this.loadMltQuantityByPeriodOnExpand}
                expandedRowRender={(record) => (
                  <FormTable
                    classifiers={classifiers}
                    viewMode={curMode}
                    fields={this.getLeaseBasePeriodinReportingPeriodFields(record)}
                    parserToFE={getLeaseBasePeriodsToFe}
                    rows={this.state.mltQuantityByPeriod[record.guid] || []}
                    form={this.props.form}
                    isViewMode={isViewMode}
                    onSave={this.handleSubmitLeaseBasePeriod(record)}
                    onDelete={this.handleDeleteLeaseBasePeriod}
                  />
                )}
              />
            </Row>
          </TabPane>
          {/* TODO: Remove tab DKV-1968 */}
          {/* <TabPane disabled={curMode === 'create'} tab="Документи" key="2">
            {!isViewModal && controlButtons}
            {curMode !== 'create' && [
              <EditorLinksContainer
                history={this.props.history}
                documentGUID={this.curGuid}
                documentTypeGUID={createdForm.refDocumentType}
              />,
            ]}
          </TabPane> */}
        </GeneralTabsContainer>
      </div>
    );
  }
}

TypicalContractFormContainer.defaultProps = {
  isViewModal: false,
  modalData: {},
  formParam: {
    createdForm: {},
    status: {},
  },
  storeKey: defStoreKey,
};

TypicalContractFormContainer.propTypes = {
  history: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
  match: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,

  loadClassifiersForContainer: PropTypes.func.isRequired,
  classifiers: PropTypes.objectOf(PropTypes.any).isRequired,
  formTypeData: PropTypes.objectOf(PropTypes.any).isRequired,
  landlords: PropTypes.arrayOf(PropTypes.any).isRequired,
  landlordsToLeaseObjects: PropTypes.arrayOf(PropTypes.any).isRequired,

  form: PropTypes.objectOf(PropTypes.any).isRequired,
  formParam: PropTypes.objectOf(PropTypes.any),

  // TODO: Remove prop type (DKV-1959)
  // putUpdateLeaseContractPaymentSchedule: PropTypes.func.isRequired,
  getLeaseContractDocument: PropTypes.func.isRequired,
  postLeaseContractDocument: PropTypes.func.isRequired,
  putLeaseContractDocument: PropTypes.func.isRequired,
  resetLeaseContractDocumentForm: PropTypes.func.isRequired,
  resetLeaseContractDocumentDoneStatus: PropTypes.func.isRequired,
  loadLandlordsToLeaseObjects: PropTypes.func.isRequired,

  postObjectInLeaseContract: PropTypes.func.isRequired,
  putObjectInLeaseContract: PropTypes.func.isRequired,
  deleteObjectInLeaseContract: PropTypes.func.isRequired,

  getLeaseObjectOfLeaseContract: PropTypes.func.isRequired,

  postLeaseBasePeriod: PropTypes.func.isRequired,
  putLeaseBasePeriod: PropTypes.func.isRequired,
  deleteLeaseBasePeriod: PropTypes.func.isRequired,

  bindDocToLeaseContractDocument: PropTypes.func.isRequired,
  lockDocToLeaseContractDocument: PropTypes.func.isRequired,

  isViewModal: PropTypes.bool,
  modalData: PropTypes.objectOf(PropTypes.string),
  storeKey: PropTypes.string,
};

export default withRouter(
  connect(createLeaseContractSelector, {
    ...leaseContractActions,
    ...classifiersActions,
    loadLandlordsToLeaseObjects,
  })(Form.create()(TypicalContractFormContainer)),
);
