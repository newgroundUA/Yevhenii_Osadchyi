import React from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import PropTypes from 'prop-types';

import { Form, Modal, Button, Row, Icon, Tabs, Collapse, Table, message } from 'antd';

import _get from 'lodash/get';
import _remove from 'lodash/remove';

import * as classifiersActions from '../../actions/classifiersActions';
import * as rentStatementActions from '../../actions/modules/documents/rentStatementActions';
import * as commonActions from '../../actions';

import { mapFormItems } from '../../helpers/formHelpers/mapFormHelper';
import {
  failedValidationNotification,
  getFormEntityData,
  mapRowsToTable,
} from '../../helpers/formHelpers/formHelpers';

import { createRentStatementSelector } from '../../selectors/modules/documents';

import { generalFields } from '../../models/formFields/documents/generalFields';

import {
  rentStatementFields,
  rentStatementFieldsTableProperty,
  rentStatementFieldsTableRent,
  getParsedForm,
  getMappedForm,
  getMappedFormForPropertyObjects,
  getParsedFormForPropertyObjects,
  getMappedFormForLeaseObjects,
  getParsedFormForLeaseObjects,
  planLeaseBasePeriodStringMap,
} from '../../models/formFields/documents/rentStatementFields';

import { RENT_STATEMENT_FORM_CONTAINER } from '../../constants/ContainerNames';
import {
  WEBSITELIST,
  REF_DOCUMENT_TYPE_GENERAL_DOC_CLASSNAME,
} from '../../constants/ClassifiersNames';

import Separator from '../../components/common/form/Separator';
import * as RouteNames from '../../constants/RouteNames';

import CounterpartiesDropdownContainer from '../common/CounterpartiesDropdownContainer';
import GeneralControlButtons from './common/GeneralControlButtons';
import GeneralTabsContainer from './common/GeneralTabsContainer';
import LockDocumentModal from './common/modals/LockDocumentModal';
import { defStoreKey } from '../../helpers/reducers/documents/commonActionsHandlers';
import { getObjGuidAndVersionId } from '../../helpers/commonUtils';
import { getTableColumns } from '../../helpers/table';
import { goToRegistry } from '../../helpers/entities/registry';

const RENT_STATEMENTS_ACTIONS = {
  ...classifiersActions,
  ...rentStatementActions,
  ...commonActions,
};

const TabPane = Tabs.TabPane;
const Panel = Collapse.Panel;

const formsMap = {
  general: {
    fields: generalFields,
  },
  rentStatement: {
    fields: rentStatementFields,
  },
  propertyTable: {
    fields: rentStatementFieldsTableProperty,
  },
  rentTable: {
    fields: rentStatementFieldsTableRent,
  },
};

class RentStatementFormContainer extends React.Component {
  constructor(props) {
    super(props);

    const curMode = this.props.match.params.mode || 'create';
    this.curGuid = this.props.match.params.guid || '';

    this.state = {
      curMode,
      dialogOpen: false,
      dialogMessage: '',

      leaseObjects: [],
      currentLandlord: null,

      propertyTable: {
        curIndex: -1,
        isAddingNewRow: false,
        activeKey: 0,
        collapsed: false,
      },
      lockDocumentModalIsOpen: false,
      rentTable: {
        curIndex: -1,
        isAddingNewRow: false,
        activeKey: 0,
        collapsed: false,
      },
    };

    this.propertyColumns = getTableColumns({
      formFields: rentStatementFieldsTableProperty,
      actionsData: {
        editParams: {
          handler: this.handleEditRow('propertyTable'),
        },
        deleteParams: {
          handler: this.handleDeleteRow('propertyTable'),
        },
      },
    });

    this.rentColumns = getTableColumns({
      formFields: rentStatementFieldsTableRent,
      actionsData: {
        editParams: {
          handler: this.handleEditRow('rentTable'),
        },
        deleteParams: {
          handler: this.handleDeleteRow('rentTable'),
        },
      },
    });

    this.loaded = false;
    this.mainRenterKey = `counterpatiesDropdown-${`${Math.random()}`.substring(2)}`;
  }

  componentWillMount() {
    const { history } = this.props;
    if (this.state.curMode === 'create' && !this.getFormType()) {
      goToRegistry({
        name: 'documents',
        history,
      });
    }
  }

  getLeaseObjects = (landlordsToLeaseObjects) =>
    landlordsToLeaseObjects
      .filter(
        (/* r */) => true, // fix this next time
        /* r.landlord.guid === (form.getFieldsValue(['landLord']).landLord || {}).key */
      )
      .map((r) => r.leaseObject);

  componentDidMount = () => {
    const { getRentStatement, storeKey, isViewModal, modalData } = this.props;
    const { curMode } = this.state;

    this.props.loadClassifiersForContainer(RENT_STATEMENT_FORM_CONTAINER, {
      [WEBSITELIST]: { webSiteRegistryParam: { offset: '0', limit: '100' } },
      [REF_DOCUMENT_TYPE_GENERAL_DOC_CLASSNAME]: { generalDocClassName: 'ApplicationToLease' },
    });
    this.props.loadLandlordsToLeaseObjects(storeKey);

    if (isViewModal) {
      this.setState({ curMode: 'view' });
      getRentStatement(modalData.guid, storeKey);
    } else if (curMode === 'view' || curMode === 'edit') {
      getRentStatement(this.curGuid, storeKey);
    }
  };

  componentWillReceiveProps(nextProps) {
    const {
      formParam: { createdForm, status, errors },
      match: {
        params: { mode },
      },
      storeKey,
      resetRentStatementForm,
      resetRentStatementDoneStatus,
      form,
      isViewModal,
      loadDocumentRentStatementPropertyObjects,
      loadDocumentRentStatementLeaseObjects,
    } = nextProps;

    if (isViewModal && isViewModal !== this.props.isViewModal) {
      this.setState({ curMode: 'view' });
    } else if (this.state.curMode !== mode) {
      this.setState({ curMode: mode });
    }

    if (
      (createdForm.versionId || createdForm.versionId === 0) &&
      this.props.formParam.createdForm.versionId !== createdForm.versionId
    ) {
      form.setFieldsValue(getParsedForm(createdForm));
    } else if (createdForm.applicant && (mode === 'view' || mode === 'edit') && !this.loaded) {
      this.loaded = true;
      form.setFieldsValue(getParsedForm(createdForm));
      if ((createdForm.objectsInApplicationToLeaseList || []).length) {
        loadDocumentRentStatementPropertyObjects(
          createdForm.objectsInApplicationToLeaseList,
          storeKey,
        );
      }

      if ((createdForm.leaseObjectsInAppToLeaseList || []).length) {
        loadDocumentRentStatementLeaseObjects(createdForm.leaseObjectsInAppToLeaseList, storeKey);
      }
    }

    if (status.isDone) {
      this.loaded = true;
      this.curGuid = createdForm.guid;
      this.curVersionId = createdForm.versionId;
      this.handleToggleDialog();
      resetRentStatementDoneStatus(storeKey);
    }

    if (this.state.curMode !== mode && mode === 'create') {
      form.resetFields();
      resetRentStatementForm(storeKey);
    }

    if (errors.length > 0) {
      const errorsText = errors.map((el) => el.message).join(', ');
      this.setState({ dialogMessage: errorsText, dialogOpen: true });
      resetRentStatementForm(storeKey);
    }

    if (
      this.state.currentLandlord !== (form.getFieldsValue(['landLord']).landLord || {}).key ||
      this.props.landlordsToLeaseObjects !== nextProps.landlordsToLeaseObjects
    ) {
      const newLeaseObjects = this.getLeaseObjects(nextProps.landlordsToLeaseObjects);

      this.setState(
        {
          currentLandlord: (form.getFieldsValue(['landLord']).landLord || {}).key,
          leaseObjects: newLeaseObjects,
        },
        () => {
          if (this.state.rentTable.collapsed) {
            form.setFieldsValue({ leaseObjects: null });
          }
        },
      );
    }
  }

  componentWillUnmount() {
    this.props.resetRentStatementForm(this.props.storeKey);
  }

  handleCreateNew = () => {
    this.changeRouteTo(`/${RouteNames.DOCUMENTS}/${RouteNames.DOCUMENT_RENT_STATEMENT}/create`);
    this.curGuid = '';
    this.loaded = false;
    this.props.form.resetFields();
    this.props.resetRentStatementForm(this.props.storeKey);
    this.handleToggleDialog();
  };

  handleSaveTableForm = (formName) => () => {
    const {
      postPropertyObject,
      postLeaseObject,
      putPropertyObject,
      classifiers,
      storeKey,
      form,
      putLeaseObject,
    } = this.props;

    const fieldsArr = Object.keys(formsMap[formName].fields);
    form.validateFields(fieldsArr, (err, values) => {
      const normilizedValues = getFormEntityData(values, classifiers, formsMap[formName].fields);

      if (!err) {
        const readResp = (res) => {
          if (res.statusCode === 200) {
            message.success('Форма успішно збережена.');
            form.resetFields(fieldsArr);
          }
        };
        const applicationToLease = {
          guid: this.curGuid,
          versionId: _get(this.props.formParam.createdForm, 'versionId', this.curVersionId),
        };

        if (this.state[formName].isAddingNewRow) {
          if (formName === 'propertyTable') {
            postPropertyObject(
              {
                ...getMappedFormForPropertyObjects(normilizedValues),
                applicationToLease,
              },
              storeKey,
            ).then(readResp);
          }

          if (formName === 'rentTable') {
            postLeaseObject(
              {
                ...getMappedFormForLeaseObjects(normilizedValues),
                applicationToLease,
              },
              storeKey,
            ).then(readResp);
          }
        } else {
          if (formName === 'propertyTable') {
            putPropertyObject(
              {
                ...getMappedFormForPropertyObjects(normilizedValues),
                guid: this.props.propertyObjectsRows[this.state.propertyTable.curIndex].guid,
                applicationToLease,
              },
              storeKey,
            ).then(readResp);
          }

          if (formName === 'rentTable') {
            putLeaseObject(
              {
                ...getMappedFormForLeaseObjects(normilizedValues),
                guid: this.props.leaseObjectsRows[this.state.rentTable.curIndex].guid,
                applicationToLease,
              },
              storeKey,
            ).then(readResp);
          }
        }

        this.setState((prevState) => ({
          [formName]: {
            ...prevState[formName],
            collapsed: false,
            activeKey: 0,
            isAddingNewRow: false,
            curIndex: -1,
          },
        }));
      }
    });
  };

  handleEditRow = (formName) => (rowIndex) => {
    const object =
      formName === 'propertyTable'
        ? getParsedFormForPropertyObjects(this.props.propertyObjectsRows[rowIndex])
        : getParsedFormForLeaseObjects(this.props.leaseObjectsRows[rowIndex]);

    this.setState(
      (prevState) => ({
        [formName]: {
          ...prevState[formName],
          collapsed: true,
          activeKey: 1,
          curIndex: rowIndex,
        },
      }),
      () => {
        this.props.form.setFieldsValue(object);
      },
    );
  };

  handleDeleteRow = (formName) => (rowIndex) => {
    const {
      deletePropertyObject,
      deleteLeaseObject,
      storeKey,
      propertyObjectsRows,
      leaseObjectsRows,
    } = this.props;

    if (formName === 'propertyTable') {
      deletePropertyObject(propertyObjectsRows[rowIndex].guid, storeKey);
    }

    if (formName === 'rentTable') {
      deleteLeaseObject(leaseObjectsRows[rowIndex].guid, storeKey);
    }
  };

  handleAddTableRow = (formName) => () => {
    this.props.form.resetFields(Object.keys(formsMap[formName].fields));
    this.setState((prevState) => ({
      [formName]: {
        ...prevState[formName],
        collapsed: true,
        isAddingNewRow: true,
        activeKey: 1,
      },
    }));
  };

  handleCancelTableRow = (formName) => () => {
    this.props.form.resetFields(Object.keys(formsMap[formName].fields));
    this.setState((prevState) => ({
      [formName]: {
        ...prevState[formName],
        collapsed: false,
        isAddingNewRow: false,
        activeKey: 0,
      },
    }));
  };

  clearForm = () => {
    this.props.form.resetFields();
  };

  changeRouteTo = (route) => {
    this.props.history.push(route);
  };

  handleToggleDialog = (isOpened) => {
    if (isOpened !== undefined) this.setState({ dialogOpen: isOpened });
    else this.setState((prevState) => ({ dialogOpen: !prevState.dialogOpen }));
  };

  handleDialogCancel = () => {
    this.handleToggleDialog();
    this.switchToViewMode();
  };

  switchToEditMode = () => {
    this.changeRouteTo(
      `/${RouteNames.DOCUMENTS}/${RouteNames.DOCUMENT_RENT_STATEMENT}/edit/${this.curGuid}`,
    );
  };

  switchToViewMode = () => {
    this.changeRouteTo(
      `/${RouteNames.DOCUMENTS}/${RouteNames.DOCUMENT_RENT_STATEMENT}/view/${this.curGuid}`,
    );
  };

  handleSubmit = ({ ignoreStatus, file = {}, delDoc = {}, delFileGuid = '' }) => {
    const { curMode } = this.state;
    const {
      putRentStatement,
      postRentStatement,
      classifiers,
      storeKey,
      formParam: { createdForm },
      form,
    } = this.props;

    const fields = {
      ...generalFields,
      ...rentStatementFields,
    };
    const curFields = [...Object.keys(generalFields), ...Object.keys(rentStatementFields)];

    form.validateFields(curFields, (err, values) => {
      if (!err) {
        const normilizedValues = getFormEntityData(values, classifiers, fields);

        if (curMode === 'create') {
          postRentStatement(
            {
              ...getMappedForm(normilizedValues),
              refDocumentType: this.getFormTypeData(),
              documentType: 'ApplicationToLease',
            },
            storeKey,
          );
        }

        if (curMode === 'edit') {
          const files = file.guid ? [...createdForm.fileStorage, file] : createdForm.fileStorage;

          if (delFileGuid) {
            _remove(files, (el) => el.guid === delFileGuid);
          }

          if (delDoc.guid) {
            if (Array.isArray(createdForm[delDoc.field])) {
              _remove(createdForm[delDoc.field], (el) => el.guid === delDoc.guid);
            } else {
              createdForm[delDoc.field] = undefined;
            }
          }

          putRentStatement(
            {
              ...createdForm,
              ...getMappedForm(normilizedValues),
              fileStorage: getObjGuidAndVersionId(files),
              linkedDocuments: getObjGuidAndVersionId(createdForm.linkedDocuments),
              parentDocument: getObjGuidAndVersionId(createdForm.parentDocument),
              childrenDocuments: getObjGuidAndVersionId(createdForm.childrenDocuments),
              guid: this.curGuid,
              versionId: _get(createdForm, 'versionId', this.curVersionId),
            },
            storeKey,
            ignoreStatus,
          );
        }
      } else {
        failedValidationNotification(err, fields);
      }
    });
  };

  getFormType = () => {
    const {
      formTypeData,
      classifiers,
      formParam: {
        createdForm: { refDocumentType },
      },
    } = this.props;

    const documentTypeField = classifiers.refDocumentTypeGeneralDocClassName.find(
      (el) => el.guid === (refDocumentType || {}).guid,
    );

    if (documentTypeField) {
      return documentTypeField;
    }
    return formTypeData;
  };

  getFormTypeData = () => {
    const { guid, versionId, type } = this.getFormType();
    return {
      guid,
      versionId,
      type,
    };
  };

  getFormTypeLabel = () => {
    const obj = this.getFormType();
    return obj && `${obj.scopeOfApplication}/${obj.docCategory}/${obj.name}`;
  };

  handleLockDocumentModal = () => {
    this.setState((prevState) => ({
      lockDocumentModalIsOpen: !prevState.lockDocumentModalIsOpen,
    }));
  };

  onChangePlanLeaseBasePeriod = (value) => {
    const { form } = this.props;

    form.setFieldsValue({
      planLeaseBasePeriodString: planLeaseBasePeriodStringMap[value],
    });
  };

  render() {
    const { curMode, dialogMessage } = this.state;

    const {
      classifiers,
      propertyObjectsRows,
      leaseObjectsRows,
      storeKey,
      formParam,
      form,
      isViewModal,
      bindDocToRentStatementDocument,
      lockDocToRentStatementDocument,
      landlords,
    } = this.props;

    const propertyPanelStyle = this.state.propertyTable.collapsed
      ? { marginBottom: '1rem' }
      : { display: 'none' };
    const rentPanelStyle = this.state.rentTable.collapsed
      ? { marginBottom: '1rem' }
      : { display: 'none' };
    const dialogText = curMode === 'create' ? 'створено' : 'відредаговано';
    const isViewMode = isViewModal || curMode === 'view';

    rentStatementFieldsTableProperty.planLeaseBasePeriod.onChange = this.onChangePlanLeaseBasePeriod;

    rentStatementFieldsTableRent.planLeaseBasePeriod.onChange = this.onChangePlanLeaseBasePeriod;

    const propertyTableRows = mapRowsToTable(
      propertyObjectsRows.map((el) => getParsedFormForPropertyObjects(el)),
      rentStatementFieldsTableProperty,
      classifiers,
    );
    const rentTableRows = mapRowsToTable(
      leaseObjectsRows.map((el) => getParsedFormForLeaseObjects(el)),
      rentStatementFieldsTableRent,
      classifiers,
    );
    const applicantField = rentStatementFields.applicant;
    const applicantRepresenterField = rentStatementFields.applicantRepresenter;
    const landLordField = rentStatementFields.landLord;

    const formItemLayout = {
      labelCol: {
        xs: { span: 8 },
      },
      wrapperCol: {
        xs: { span: 16 },
      },
    };

    const mapFormItemsForFields = (fields, customClassifiers = classifiers) =>
      mapFormItems({
        viewMode: curMode,
        fields,
        classifiers: customClassifiers,
        isViewMode,
        form: this.props.form,
      });

    const controlButtons = (
      <GeneralControlButtons
        form={form}
        guid={this.curGuid}
        handleLockDocument={this.handleLockDocumentModal}
        documentType="DOCUMENT_RENT_STATEMENT"
      />
    );

    return (
      <Row>
        <Modal
          title="Заява на оренду"
          visible={this.state.dialogOpen}
          onOk={() => {
            this.handleCreateNew();
          }}
          onCancel={() => {
            this.handleDialogCancel();
          }}
          cancelText="Переглянути картку"
          okText="Створити нову"
        >
          {dialogMessage === '' ? (
            <p>{`Картку успішно ${dialogText}`}</p>
          ) : (
            <p>{`${dialogMessage}`}</p>
          )}
        </Modal>
        <Modal
          title="Блокування документа"
          visible={this.state.lockDocumentModalIsOpen}
          onCancel={this.handleLockDocumentModal}
          footer={null}
          width="1000px"
          maskClosable={false}
          destroyOnClose
        >
          <LockDocumentModal
            handleCloseModal={this.handleLockDocumentModal}
            childrenDocuments={formParam.createdForm.childrenDocuments}
            guid={this.curGuid}
            versionId={_get(formParam, ['createdForm', 'versionId'], this.curVersionId)}
            updateForm={lockDocToRentStatementDocument}
            loadDocument={() => this.props.getRentStatement(this.curGuid, this.props.storeKey)}
          />
        </Modal>
        <h1 key="formLabel">{this.getFormTypeLabel()}</h1>
        <GeneralTabsContainer
          ownerSide={{
            guid: this.curGuid,
            versionId: _get(formParam[storeKey], ['createdForm', 'versionId'], this.curVersionId),
          }}
          editAction={this.handleSubmit}
          controlButtons={controlButtons}
          bindDocAction={bindDocToRentStatementDocument}
          isViewModal={isViewModal}
          createdForm={formParam.createdForm}
        >
          <TabPane tab="Форма заяви на оренду" key="0">
            <Row>
              {!isViewModal && controlButtons}
              <Row>
                <Form>
                  <Row>
                    <Separator text="Основна інформація" />
                    {mapFormItemsForFields(generalFields)}
                  </Row>
                  <Row>
                    <Separator text="Заява про оренду" />
                    <Row>
                      <CounterpartiesDropdownContainer
                        form={this.props.form}
                        isViewMode={isViewMode}
                        formItemLayout={formItemLayout}
                        fieldSpec={applicantField}
                      />
                      <CounterpartiesDropdownContainer
                        form={this.props.form}
                        isViewMode={isViewMode}
                        formItemLayout={formItemLayout}
                        fieldSpec={applicantRepresenterField}
                        counterpartyType="Person"
                      />
                      <CounterpartiesDropdownContainer
                        customOptions={landlords}
                        form={this.props.form}
                        isViewMode={isViewMode}
                        formItemLayout={formItemLayout}
                        fieldSpec={landLordField}
                      />
                    </Row>
                    {mapFormItemsForFields(rentStatementFields)}
                    <Row type="flex" justify="end">
                      <Button
                        style={{ marginRight: '1.5rem' }}
                        type="primary"
                        onClick={this.handleSubmit}
                        disabled={isViewMode}
                      >
                        Відправити
                      </Button>
                    </Row>
                  </Row>
                  <Row>
                    <Separator text="Перелік майнових об'єктів у заяві про оренду" />
                    <Button
                      disabled={
                        curMode === 'view' ||
                        this.state.propertyTable.collapsed ||
                        curMode === 'create'
                      }
                      onClick={this.handleAddTableRow('propertyTable')}
                    >
                      <Icon type="plus" />
                      Додати
                    </Button>
                    <Collapse
                      style={propertyPanelStyle}
                      bordered={false}
                      activeKey={`${this.state.propertyTable.activeKey}`}
                      onChange={(key) => this.setState({ activeKey: key })}
                    >
                      <Panel
                        header="Форма створення"
                        key="1"
                        disabled={!this.state.propertyTable.collapsed}
                      >
                        {mapFormItemsForFields(rentStatementFieldsTableProperty)}
                        <Row>
                          <Button
                            style={{ marginRight: '1rem' }}
                            onClick={this.handleSaveTableForm('propertyTable')}
                            type="primary"
                          >
                            <Icon type="save" />
                            Зберегти
                          </Button>
                          <Button onClick={this.handleCancelTableRow('propertyTable')}>
                            <Icon type="close" />
                            Вiдмiнити
                          </Button>
                        </Row>
                      </Panel>
                    </Collapse>
                    <Table
                      style={{ margin: '1rem 0', background: '#fff' }}
                      bordered
                      pagination={false}
                      columns={this.propertyColumns}
                      dataSource={propertyTableRows}
                    />
                  </Row>
                  <Row>
                    <Separator text="Перелік об'єктів оренди у заяві про оренду" />
                    <Button
                      disabled={
                        curMode === 'view' || this.state.rentTable.collapsed || curMode === 'create'
                      }
                      onClick={this.handleAddTableRow('rentTable')}
                    >
                      <Icon type="plus" />
                      Додати
                    </Button>
                    <Collapse
                      style={rentPanelStyle}
                      bordered={false}
                      activeKey={`${this.state.rentTable.activeKey}`}
                      onChange={(key) => this.setState({ activeKey: key })}
                    >
                      <Panel
                        header="Форма створення"
                        key="1"
                        disabled={!this.state.rentTable.collapsed}
                      >
                        {mapFormItemsForFields(rentStatementFieldsTableRent)}
                        <Row>
                          <Button
                            style={{ marginRight: '1rem' }}
                            onClick={this.handleSaveTableForm('rentTable')}
                            type="primary"
                          >
                            <Icon type="save" />
                            Зберегти
                          </Button>
                          <Button onClick={this.handleCancelTableRow('rentTable')}>
                            <Icon type="close" />
                            Вiдмiнити
                          </Button>
                        </Row>
                      </Panel>
                    </Collapse>
                    <Table
                      style={{ margin: '1rem 0', background: '#fff' }}
                      bordered
                      pagination={false}
                      columns={this.rentColumns}
                      dataSource={rentTableRows}
                    />
                  </Row>
                </Form>
              </Row>
            </Row>
          </TabPane>
        </GeneralTabsContainer>
      </Row>
    );
  }
}

RentStatementFormContainer.defaultProps = {
  isViewModal: false,
  modalData: {},
  formParam: {
    createdForm: {},
    status: {},
  },
  storeKey: defStoreKey,
};

RentStatementFormContainer.propTypes = {
  loadClassifiersForContainer: PropTypes.func.isRequired,
  history: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
  match: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,

  postRentStatement: PropTypes.func.isRequired,
  putRentStatement: PropTypes.func.isRequired,
  getRentStatement: PropTypes.func.isRequired,
  postPropertyObject: PropTypes.func.isRequired,
  putPropertyObject: PropTypes.func.isRequired,
  deletePropertyObject: PropTypes.func.isRequired,
  postLeaseObject: PropTypes.func.isRequired,
  putLeaseObject: PropTypes.func.isRequired,
  deleteLeaseObject: PropTypes.func.isRequired,
  loadLandlordsToLeaseObjects: PropTypes.func.isRequired,

  loadDocumentRentStatementPropertyObjects: PropTypes.func.isRequired,
  loadDocumentRentStatementLeaseObjects: PropTypes.func.isRequired,

  landlordsToLeaseObjects: PropTypes.arrayOf(PropTypes.any).isRequired,
  classifiers: PropTypes.objectOf(PropTypes.array).isRequired,
  formTypeData: PropTypes.objectOf(PropTypes.any).isRequired,
  resetRentStatementForm: PropTypes.func.isRequired,
  resetRentStatementDoneStatus: PropTypes.func.isRequired,
  formParam: PropTypes.objectOf(PropTypes.any),
  propertyObjectsRows: PropTypes.arrayOf(PropTypes.any).isRequired,
  leaseObjectsRows: PropTypes.arrayOf(PropTypes.any).isRequired,
  landlords: PropTypes.arrayOf(PropTypes.any).isRequired,

  form: PropTypes.objectOf(PropTypes.any).isRequired,

  bindDocToRentStatementDocument: PropTypes.func.isRequired,
  lockDocToRentStatementDocument: PropTypes.func.isRequired,

  isViewModal: PropTypes.bool,
  modalData: PropTypes.objectOf(PropTypes.string),
  storeKey: PropTypes.string,
};

export default withRouter(
  connect(createRentStatementSelector, RENT_STATEMENTS_ACTIONS)(
    Form.create()(RentStatementFormContainer),
  ),
);
