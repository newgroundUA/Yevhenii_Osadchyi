import React from 'react';
import PropTypes from 'prop-types';
import { Button, Row, Table, Collapse, Modal } from 'antd';

import _debounce from 'lodash/debounce';
import { withRouter } from 'react-router-dom';

const Panel = Collapse.Panel;

const LIMIT_SIZE_SEARCH = 10;

class LiveSearchFieldsWithTable extends React.Component {
  constructor() {
    super();
    this.dataForLiveSearch = {};
    this.state = {
      tableData: [],
      selectedItem: {},
      totalElements: 0,
      showModal: false,
      currentPage: 1,
      activePanelKey: undefined,
    };
    this.initialState = { ...this.state };
    this.runLiveSearch = _debounce(this.runLiveSearch, 700);
  }

  onSelectRow = (selectedRowKeys, selectedRowValues) => {
    this.setState({
      selectedItem: selectedRowValues[0],
    });
  };

  handleChange = (data) => {
    this.dataForLiveSearch = data;

    this.runLiveSearch();
  };

  runLiveSearch = () => {
    this.props.liveSearchAction(this.dataForLiveSearch).then((resp) => {
      if (!resp.data) {
        return;
      }
      this.setState((prevState) => ({
        totalElements: resp.data.totalElements,
        selectedItem: resp.data.content.find((el) => el.guid === prevState.selectedItem.guid)
          ? prevState.selectedItem
          : {},
        currentPage: resp.data.number + 1,
        tableData: resp.data.content.map((el) => ({
          ...this.props.parseToFE(el),
          key: el.guid,
        })),
      }));
    });
  };

  handlePaginationChange = (nextPage) => {
    this.dataForLiveSearch.page = nextPage - 1;
    this.setState({
      selectedItem: {},
    });
    this.runLiveSearch();
  };

  handleSubmit = () => {
    if (this.props.modal) {
      this.setState({
        showModal: true,
      });
    } else {
      this.handleActivePanelChanged(null);
      this.bindFile();
    }
  };

  bindFile = () => {
    this.props.bindAction(this.state.selectedItem);
  };

  bindDocument = (modalData = {}, callback) => {
    // TODO Rewrite it

    const { bindActionData } = this.props;
    const selectedItem = [
      {
        guid: this.state.selectedItem.guid,
        versionId: this.state.selectedItem.versionId,
      },
    ];

    const data = {
      ownerSide: bindActionData.ownerSide,
      relationshipType: modalData.relationshipType,

      inverseSide:
        modalData.relationshipType === 'Parent'
          ? selectedItem
          : selectedItem.concat(bindActionData[modalData.fieldName]),
    };
    this.props.bindAction(data).then((resp) => {
      this.closeModal();
      this.runLiveSearch();
      if (callback) {
        callback(resp.data);
      }
    });
  };

  closeModal = () => {
    this.setState({
      showModal: false,
    });
  };

  handleRefreshFields = () => {
    this.setState({ ...this.initialState });
  };

  handleActivePanelChanged = (key) => {
    this.setState({
      activePanelKey: key,
    });
  };

  render() {
    const {
      LiveSearchFormFields,
      modal,
      title,
      match: {
        params: { mode },
      },
      columns,
      isModal,
      isViewMode,
    } = this.props;

    const rowSelection = {
      selectedRowKeys: this.state.selectedItem.key,
      onChange: this.onSelectRow,
      type: 'radio',
    };

    return (
      <Collapse onChange={this.handleActivePanelChanged} activeKey={this.state.activePanelKey}>
        <Panel header={title} key="0">
          {modal && (
            <Modal
              title={modal.title}
              visible={this.state.showModal}
              onCancel={this.closeModal}
              footer={false}
              destroyOnClose
              maskClosable={false}
            >
              {modal.render({ onCancel: this.closeModal, onOk: this.bindDocument })}
            </Modal>
          )}

          <LiveSearchFormFields
            handleChange={this.handleChange}
            handleRefreshFields={this.handleRefreshFields}
            LIMIT_SIZE_SEARCH={LIMIT_SIZE_SEARCH}
            isModal={isModal}
          />
          <Table
            rowSelection={rowSelection}
            columns={columns}
            dataSource={this.state.tableData}
            pagination={
              this.state.totalElements && {
                total: this.state.totalElements,
                showTotal: () => `Знайдено: ${this.state.totalElements}`,
                onChange: this.handlePaginationChange,
                pageSize: LIMIT_SIZE_SEARCH,
                current: this.state.currentPage,
              }
            }
          />

          <Row type="flex" justify="end" className="global_mt20">
            <Button
              style={{ marginRight: '1.5rem' }}
              type="primary"
              onClick={this.handleSubmit}
              disabled={(mode && mode !== 'edit') || !this.state.selectedItem.key || isViewMode}
            >
              Зв`язати
            </Button>
          </Row>
        </Panel>
      </Collapse>
    );
  }
}

LiveSearchFieldsWithTable.defaultProps = {
  modal: undefined,
  parseToFE: (el) => el,
  isModal: false,
  isViewMode: false,
  bindActionData: {},
};

LiveSearchFieldsWithTable.propTypes = {
  LiveSearchFormFields: PropTypes.func.isRequired,
  columns: PropTypes.arrayOf(PropTypes.any).isRequired,
  liveSearchAction: PropTypes.func.isRequired,
  bindAction: PropTypes.func.isRequired,
  title: PropTypes.string.isRequired,
  bindActionData: PropTypes.objectOf(PropTypes.any),
  parseToFE: PropTypes.func,
  match: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
  modal: PropTypes.objectOf(PropTypes.any),
  isModal: PropTypes.bool,
  isViewMode: PropTypes.bool,
};

export default withRouter(LiveSearchFieldsWithTable);
