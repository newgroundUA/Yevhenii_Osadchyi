import React from 'react';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router-dom';
import { Button, Icon, Row } from 'antd';
import * as RouteNames from '../../../constants/RouteNames';

const ButtonGroup = Button.Group;

class GeneralControlButtons extends React.Component {
  switchToEditMode = () => {
    const { documentType, guid, urlToEditMode } = this.props;
    const url =
      urlToEditMode || `/${RouteNames.DOCUMENTS}/${RouteNames[documentType]}/edit/${guid}`;
    this.props.history.push(url);
  };

  clearForm = () => {
    this.props.form.resetFields();
  };

  goToRegister = () => {
    const url = this.props.urlToRegister || `/${RouteNames.DOCUMENTS}/${RouteNames.REGISTER}`;
    this.props.history.push(url);
  };

  render() {
    const {
      match: {
        params: { mode },
      },
      handleLockDocument,
    } = this.props;

    const isViewMode = mode === 'view';
    const isCreateMode = mode === 'create';

    return (
      <Row type="flex" justify="center">
        <ButtonGroup>
          {!isCreateMode &&
            handleLockDocument && <Button onClick={handleLockDocument}>Заблокувати</Button>}
          {isViewMode && (
            <Button onClick={this.switchToEditMode}>
              <Icon type="edit" />
              Редагувати
            </Button>
          )}
          {!isViewMode && (
            <Button onClick={this.clearForm}>
              <Icon type="delete" />
              Очистити поля
            </Button>
          )}
          <Button onClick={this.goToRegister}>
            <Icon type="logout" />
            Перейти до реєстру
          </Button>
        </ButtonGroup>
      </Row>
    );
  }
}

GeneralControlButtons.defaultProps = {
  handleLockDocument: false,
};

GeneralControlButtons.propTypes = {
  documentType: PropTypes.string.isRequired,
  handleLockDocument: PropTypes.oneOfType([PropTypes.bool, PropTypes.func]),
  guid: PropTypes.string.isRequired,
  form: PropTypes.objectOf(PropTypes.any).isRequired,
  history: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
  match: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
  urlToEditMode: PropTypes.string.isRequired,
  urlToRegister: PropTypes.string.isRequired,
};

export default withRouter(GeneralControlButtons);
