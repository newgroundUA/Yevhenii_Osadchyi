import React from 'react';
import { Select, Button } from 'antd';
import PropTypes from 'prop-types';

import { bindingDocumentMap } from './BindingDocumentTab';

const Option = Select.Option;

class BindingDocumentModal extends React.Component {
  state = {
    chosenType: null,
  };

  handleChange = (value) => {
    this.setState({
      chosenType: value,
    });
  };

  bindDocumentCallback = (data) => {
    const { chosenType } = this.state;
    const fieldName = bindingDocumentMap[chosenType.toLowerCase()];

    this.props.bindDocAction(fieldName, data);
  };

  handleSend = () => {
    const { chosenType } = this.state;
    const modalData = {
      relationshipType: chosenType,
      fieldName: bindingDocumentMap[chosenType.toLowerCase()],
    };

    this.props.onOk(modalData, this.bindDocumentCallback);
  };

  render() {
    return (
      <div>
        <Select style={{ width: '100%' }} placeholder="Не вибрано" onChange={this.handleChange}>
          <Option value="Parent" key="1" disabled={this.props.isParentExist}>
            {`Головний`}
          </Option>
          <Option value="Linked" key="2">
            {'Пов`язаний'}
          </Option>
          <Option value="Children" key="3">
            {`Підпорядкований`}
          </Option>
        </Select>
        <div className="document-create-modal-section__buttons">
          <Button onClick={this.props.onCancel}>Скасувати</Button>
          <Button type="primary" onClick={this.handleSend} disabled={!this.state.chosenType}>
            {'Зв`язати'}
          </Button>
        </div>
      </div>
    );
  }
}

BindingDocumentModal.defaultProps = {
  isParentExist: {},
};

BindingDocumentModal.propTypes = {
  onOk: PropTypes.func.isRequired,
  onCancel: PropTypes.func.isRequired,
  bindDocAction: PropTypes.func.isRequired,
  isParentExist: PropTypes.bool,
};

export default BindingDocumentModal;
