import React from 'react';
import PropTypes from 'prop-types';
import { Row, Button, Form, Radio } from 'antd';
import _get from 'lodash/get';

import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';

import Separator from '../../../../components/common/form/Separator';
import { mapFormItems } from '../../../../helpers/formHelpers/mapFormHelper';
import {
  bindingByDocumentInfoFields,
  bindingByFoCounterpartyFields,
  bindingByFopCounterpartyFields,
  bindingByLegalCounterpartyFields,
} from '../../../../models/formFields/documents/bindingDocumentFields';
import DocumentCascader from '../DocumentCascader';
import * as documentTypesCascaderActions from '../../../../actions/modules/documents/documentTypesCascaderActions';
import * as classifiersActions from '../../../../actions/classifiersActions';
import { BIND_DOCUMENT_CONTAINER } from '../../../../constants/ContainerNames';

const CONTAINER_ACTIONS = {
  ...documentTypesCascaderActions,
  ...classifiersActions,
};
const RadioGroup = Radio.Group;

const enumPublisherType = Object.freeze({
  fo: 1,
  fop: 2,
  legal: 3,
});

const formItemLayout = {
  wrapperCol: { span: 24 },
  labelCol: { span: 24 },
};

export const cascaderStoreKey = 'bindingDocument';

class BindingDocumentsFormFields extends React.Component {
  state = {
    publisherType: enumPublisherType.fo,
  };

  componentDidMount() {
    const { classifiers, loadClassifiersForContainer } = this.props;
    if (classifiers.documentValidityStatusEnum.length === 0) {
      loadClassifiersForContainer(BIND_DOCUMENT_CONTAINER);
    }
  }

  componentWillReceiveProps(nextProps) {
    const { bindingCascaderValue } = this.props;
    const nextCasscaderGuid = _get(nextProps.bindingCascaderValue, ['data', 'guid']);

    if (nextCasscaderGuid && nextCasscaderGuid !== _get(bindingCascaderValue, ['data', 'guid'])) {
      nextProps.handleChange(this.getRequestData(nextProps));
    }
  }

  changePublisherType = (e) => {
    this.setState({
      publisherType: e.target.value,
    });
  };

  handleResetForm = () => {
    this.props.form.resetFields();
    this.props.selectCascaderValue(null, cascaderStoreKey);
    this.props.handleRefreshFields();
  };

  handleOnChange = (e) => {
    if (e && e.target && e.target.value.length < 3) {
      return;
    }
    this.runAction();
  };

  onBlurOnEnter = (e) => {
    if (!e.target.value) {
      return;
    }
    this.runAction();
  };

  runAction = () => {
    setTimeout(() => {
      this.props.handleChange(this.getRequestData(this.props));
    }, 0);
  };

  getRequestData = (props) => {
    const formData = props.form.getFieldsValue();
    const { guid, versionId, type } = props.bindingCascaderValue.data;
    return {
      docDateFrom: formData.docDateFrom,
      docDateTo: formData.docDateTo,
      docDescription: formData.docDescription,
      docNumber: formData.docNumber,
      docSerialNumber: formData.docSerialNumber,
      validityStatus: formData.validityStatus || null,
      limit: props.LIMIT_SIZE_SEARCH,
      page: 0,
      // publisher: this.getPublisherData(formData),
      refDocumentType: {
        guid,
        versionId,
        type,
      },
    };
  };

  getPublisherData = (formData) => {
    const { publisherType } = this.state;

    if (publisherType === enumPublisherType.legal) {
      return {
        edrpou: formData.edrpou,
        fullName: formData.fullName,
        counterpartyType: 'LegalEntity',
      };
    }
    if (publisherType === enumPublisherType.fo) {
      return {
        lastName: formData.lastNameFo,
        fistName: formData.firstNameFo,
        itn: formData.itn,
        middleName: formData.middleName,
        counterpartyType: 'Person',
      };
    }

    return {
      lastName: formData.lastNameFo,
      fistName: formData.firstNameFo,
      itn: formData.itn,
      middleName: formData.middleName,
      counterpartyType: 'SelfEmployed',
    };
  };

  resetLiveSearchButton = () => ({
    render: () => (
      <Button
        onClick={this.handleResetForm}
        type="danger"
        className="global_full-width"
        disabled={!this.props.bindingCascaderValue.data}
      >
        Очистити фільтри
      </Button>
    ),
    className: 'global_full-width',
    colSpan: 6,
    key: 'resetButton',
  });

  render() {
    const {
      classifiers,
      form,
      bindingCascaderValue,
      match: {
        params: { mode },
      },
      isModal,
    } = this.props;

    const isViewMode = mode === 'view';

    const bindingInfoFields = {
      ...bindingByDocumentInfoFields,
      docSerialNumber: {
        ...bindingByDocumentInfoFields.docSerialNumber,
        onPressEnter: this.onBlurOnEnter,
        onBlur: this.onBlurOnEnter,
      },
      docNumber: {
        ...bindingByDocumentInfoFields.docNumber,
        onPressEnter: this.onBlurOnEnter,
        onBlur: this.onBlurOnEnter,
      },
    };

    return (
      <Form>
        <Row>
          Тип документа
          <DocumentCascader
            storeKey={cascaderStoreKey}
            // resultAfterStep="1"
            disabled={isViewMode}
            isModal={isModal}
          />
        </Row>

        <Separator color="#666666" text="Видавач" />
        <RadioGroup
          value={this.state.publisherType}
          onChange={this.changePublisherType}
          style={{ display: 'flex', flexDirection: 'column' }}
        >
          <Row className="df aic">
            <Radio
              value={enumPublisherType.fo}
              className="global_mb20"
              style={{ width: '100px' }}
              disabled={!bindingCascaderValue.data}
            >
              ФО
            </Radio>
            {mapFormItems({
              viewMode: mode,
              fields: bindingByFoCounterpartyFields,
              classifiers,
              isViewMode,
              formItemLayout,
              onChange: this.handleOnChange,
              disabled:
                !bindingCascaderValue.data || this.state.publisherType !== enumPublisherType.fo,
              form,
            })}
          </Row>
          <Row className="df aic">
            <Radio
              value={enumPublisherType.fop}
              className="global_mb20"
              style={{ width: '100px' }}
              disabled={!bindingCascaderValue.data}
            >
              ФОП
            </Radio>
            {mapFormItems({
              viewMode: mode,
              fields: bindingByFopCounterpartyFields,
              classifiers,
              isViewMode,
              formItemLayout,
              onChange: this.handleOnChange,
              disabled:
                !bindingCascaderValue.data || this.state.publisherType !== enumPublisherType.fop,
              form,
            })}
          </Row>
          <Row className="df aic">
            <Radio
              value={enumPublisherType.legal}
              style={{ width: '100px' }}
              disabled={!bindingCascaderValue.data}
            >
              ЮО
            </Radio>
            {mapFormItems({
              viewMode: mode,
              fields: bindingByLegalCounterpartyFields,
              classifiers,
              isViewMode,
              formItemLayout,
              onChange: this.handleOnChange,
              disabled:
                !bindingCascaderValue.data || this.state.publisherType !== enumPublisherType.legal,
              form,
            })}
          </Row>
        </RadioGroup>
        <Separator color="#666666" />
        {mapFormItems({
          viewMode: mode,
          fields: bindingInfoFields,
          classifiers,
          isViewMode,
          formItemLayout,
          onChange: this.handleOnChange,
          disabled: !bindingCascaderValue.data,
          form,
          customFields: [this.resetLiveSearchButton()],
        })}
      </Form>
    );
  }
}

BindingDocumentsFormFields.defaultProps = {
  bindingCascaderValue: {},
};

BindingDocumentsFormFields.propTypes = {
  classifiers: PropTypes.objectOf(PropTypes.array).isRequired,
  form: PropTypes.objectOf(PropTypes.any).isRequired,
  handleChange: PropTypes.func.isRequired,
  loadClassifiersForContainer: PropTypes.func.isRequired,
  selectCascaderValue: PropTypes.func.isRequired,
  handleRefreshFields: PropTypes.func.isRequired,
  LIMIT_SIZE_SEARCH: PropTypes.number.isRequired, // eslint-disable-line
  match: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
  bindingCascaderValue: PropTypes.objectOf(PropTypes.any),
  isModal: PropTypes.bool.isRequired,
};

const mapStateToProps = (state) => ({
  classifiers: state.classifiers,
  bindingCascaderValue: state.documentForms.documentCascader.selectedValue[cascaderStoreKey],
});

export default withRouter(
  connect(mapStateToProps, CONTAINER_ACTIONS)(Form.create()(BindingDocumentsFormFields)),
);
