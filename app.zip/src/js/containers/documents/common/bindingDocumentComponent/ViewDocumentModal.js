import React from 'react';
import PropTypes from 'prop-types';
import GeneralDocumentFormContainer from '../../GeneralDocumentFormContainer';
import AppealsFormContainer from '../../AppealsFormContainer';
import BalanceFormContainer from '../../BalanceFormContainer';
import BankStatementFormContainer from '../../BankStatementFormContainer';
import ContestsFormContariner from '../../ContestsFormContariner';
import JudicialDecisionFormContainer from '../../JudicialDecisionFormContainer';
import MarketValueFormContainer from '../../MarketValueFormContainer';
import RentStatementFormContariner from '../../RentStatementFormContariner';
import TypicalContractFormContainer from '../../TypicalContractFormContainer';
import PassportFormContainer from '../../PassportFormContainer';

class ViewDocumentModal extends React.Component {
  constructor() {
    super();
    this.formContainerMap = {
      PersonPassport: PassportFormContainer,
      Document: GeneralDocumentFormContainer,
      ApplicationToLease: RentStatementFormContariner,
      CompetitionProtocol: ContestsFormContariner,
      DocJudicialDecision: JudicialDecisionFormContainer,
      DocAppeals: AppealsFormContainer,
      AccountItemReceiptAct: BalanceFormContainer,
      BankStatement: BankStatementFormContainer,
      LeaseContract: TypicalContractFormContainer,
      MarketPriceDetect: MarketValueFormContainer,
    };
  }

  render() {
    const data = {
      isViewModal: true,
      modalData: { mode: 'view', guid: this.props.guid },
      storeKey: this.props.storeKey || this.props.guid,
    };
    const Component = this.formContainerMap[this.props.documentType];
    return (
      <div>
        <Component {...data} />
      </div>
    );
  }
}

ViewDocumentModal.defaultProps = {
  storeKey: undefined,
};

ViewDocumentModal.propTypes = {
  documentType: PropTypes.string.isRequired,
  storeKey: PropTypes.string,
  guid: PropTypes.string.isRequired,
};

export default ViewDocumentModal;
