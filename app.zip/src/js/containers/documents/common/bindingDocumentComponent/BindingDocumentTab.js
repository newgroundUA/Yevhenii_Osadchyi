import React from 'react';
import PropTypes from 'prop-types';
import { Row, Table, Icon, Modal, Button } from 'antd';

import _get from 'lodash/get';

import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';

import * as bindingDocumentsActions from '../../../../actions/modules/documents/bindingDocumentsActions';
import Separator from '../../../../components/common/form/Separator';

import LiveSearchFieldsWithTable from '../LiveSearchFieldsWithTable';
import BindingDocumentsFormFields, { cascaderStoreKey } from './BindingDocumentFormFields';
import DocumentCascader from '../DocumentCascader';
import * as routeNames from '../../../../constants/RouteNames';
import BindingDocumentModal from './BindingDocumentModal';
import ViewDocumentModal from './ViewDocumentModal';

import {
  getLiveSearchedDocumentToFE,
  getBoundDocumentToFE,
  liveSearchColumns,
  expandableColumns,
} from '../../../../models/formFields/documents/bindingDocumentFields';
import { defStoreKey } from '../../../../helpers/reducers/documents/commonActionsHandlers';

const getNewDocForm = (typeOfNewDoc) =>
  ({
    Document: routeNames.DOCUMENT_GENERAL,
    PersonPassport: routeNames.DOCUMENT_PASSPORT,
    ApplicationToLease: routeNames.DOCUMENT_RENT_STATEMENT,
    CompetitionProtocol: routeNames.DOCUMENT_CONTESTS,
    DocJudicialDecision: routeNames.DOCUMENT_JUDICIAL_DECISION,
    DocAppeals: routeNames.DOCUMENT_APPEALS,
    AccountItemReceiptAct: routeNames.DOCUMENT_BALANCE,
    LeaseContract: routeNames.DOCUMENT_TYPICAL_CONTRACT,
    // ApplicationToPrivatization: routeNames.,
    // AccountingDocs: routeNames.,
    // AccountItemWriteOff: routeNames.,
    MarketPriceDetect: routeNames.DOCUMENT_MARKET,
    BankStatement: routeNames.DOCUMENT_BANK_STATEMENT,
  }[typeOfNewDoc] || routeNames.DOCUMENT_GENERAL);

export const bindingDocumentMap = {
  children: 'childrenDocuments',
  linked: 'linkedDocuments',
  parent: 'parentDocument',
};

class BindingDocumentTab extends React.Component {
  state = {
    viewDocumentModal: false,
    modalData: {},
  };

  boundDocumentsColumns = () => [
    {
      title: "Тип зв'язку",
      dataIndex: 'relationshipType',
    },
    {
      title: 'Тип документа',
      dataIndex: 'documentType',
    },
    {
      title: 'Серія та номер',
      dataIndex: 'docNumber',
    },
    {
      title: 'Чинність',
      dataIndex: 'validityStatus',
    },
    {
      title: 'Короткий опис',
      dataIndex: 'docDescription',
      width: 300,
    },
    {
      title: 'Видавач',
      dataIndex: 'publisher', // TODO
    },
    {
      title: 'Дата',
      dataIndex: 'docDate',
    },
    {
      title: 'Дія',
      dataIndex: 'dataForActions',
      render: this.getOperationButtons,
    },
  ];

  relationshipTypeModal = () => ({
    title: "Встановлення типу зв'язку",
    render: ({ onOk, onCancel }) => (
      <BindingDocumentModal
        onOk={onOk}
        onCancel={onCancel}
        bindDocAction={this.props.bindDocAction}
        isParentExist={!!this.props.parentDocument.guid}
      />
    ),
  });

  handleCreate = () => {
    const typeOfNewDoc = this.props.cascaderValue.generalDocClassName;

    this.props.history.push(`/documents/${getNewDocForm(typeOfNewDoc)}/create`);
  };

  getTable = (relationshipType) => {
    const { childrenDocuments, linkedDocuments, parentDocument } = this.props;

    const dataMap = {
      Children: childrenDocuments.map((el) => getBoundDocumentToFE(el, 'children')),
      Linked: linkedDocuments.map((el) => getBoundDocumentToFE(el, 'linked')),
      Parent: parentDocument.guid ? [getBoundDocumentToFE(parentDocument, 'parent')] : [],
    };

    const data = dataMap[relationshipType];
    const documentsLength = data.length;

    return (
      <Table
        columns={this.boundDocumentsColumns()}
        dataSource={data}
        key={relationshipType}
        pagination={
          documentsLength && {
            total: documentsLength,
            showTotal: (total) => `Знайдено: ${total}`,
            pageSize: 10,
          }
        }
      />
    );
  };

  openDocumentInModal = (modalData) => () => {
    this.setState({
      viewDocumentModal: true,
      modalData,
    });
  };

  handleCloseModal = () => {
    this.setState({
      viewDocumentModal: false,
    });
  };

  handleUnBind = (actionData) => () => {
    this.props.editAction({
      ignoreStatus: true,
      delDoc: {
        field: bindingDocumentMap[actionData.relationshipType.toLowerCase()],
        guid: actionData.guid,
      },
    });
  };

  getOperationButtons = (actionData) => (
    <span style={{ whiteSpace: 'nowrap' }} key={actionData.guid}>
      <Icon
        type="eye"
        style={{ fontSize: '20px', marginRight: '10px', cursor: 'pointer' }}
        onClick={this.openDocumentInModal(actionData)}
      />
      <Button onClick={this.handleUnBind(actionData)} disabled={this.props.isViewModal}>
        <Icon
          type="close"
          style={{ fontSize: '20px', color: '#e31b1c', fontWeight: '1000', cursor: 'pointer' }}
        />
      </Button>
    </span>
  );

  render() {
    const {
      liveSearchDocuments,
      bindDocument,
      cascaderValue,
      childrenDocuments,
      linkedDocuments,
      parentDocument,
      controlButtons,
      isViewModal,
      match: {
        params: { mode },
      },
      ownerSide,
    } = this.props;

    const isViewMode = mode === 'view';

    const expandableData = [
      {
        header: `Головні (${parentDocument.guid ? 1 : 0})`,
        relationshipType: 'Parent',
        key: 1,
      },
      {
        header: `Підпорядковані (${_get(childrenDocuments, 'length', 0)})`,
        relationshipType: 'Children',
        key: 2,
      },
      {
        header: `Пов'язані (${_get(linkedDocuments, 'length', 0)})`,
        relationshipType: 'Linked',
        key: 3,
      },
    ];

    return (
      <Row>
        {!isViewModal && (
          <div>
            <Row>{controlButtons}</Row>
            {`Тип документа`}
            <div className="global_mb20 df">
              <div style={{ width: '100%' }} className="global_mr20">
                <DocumentCascader resultAfterStep="2" disabled={isViewMode} />
              </div>

              <Button
                style={{ marginRight: '1.5rem' }}
                type="primary"
                onClick={this.handleCreate}
                disabled={!cascaderValue.data}
              >
                {`Новий документ`}
              </Button>
            </div>
            <LiveSearchFieldsWithTable
              LiveSearchFormFields={BindingDocumentsFormFields}
              liveSearchAction={liveSearchDocuments}
              bindAction={bindDocument}
              bindActionData={{ ownerSide, childrenDocuments, linkedDocuments }}
              parseToFE={getLiveSearchedDocumentToFE}
              modal={this.relationshipTypeModal()}
              title="Пошук документів"
              columns={liveSearchColumns}
            />
          </div>
        )}
        <Row className="global_mt20">
          <Separator text="Зв'язані документи" />
          <Table
            className="ant-table-nested"
            rowKey="guid"
            columns={expandableColumns}
            expandedRowRender={(record) => this.getTable(record.relationshipType)}
            dataSource={expandableData}
            pagination={false}
          />
        </Row>
        <Modal
          visible={this.state.viewDocumentModal}
          footer={false}
          onCancel={this.handleCloseModal}
          width="95%"
          maskClosable={false}
          destroyOnClose
        >
          {this.state.modalData.documentType && (
            <ViewDocumentModal
              documentType={this.state.modalData.documentType}
              storeKey={cascaderStoreKey}
              guid={this.state.modalData.guid}
            />
          )}
        </Modal>
      </Row>
    );
  }
}

BindingDocumentTab.defaultProps = {
  cascaderValue: {},
};

BindingDocumentTab.propTypes = {
  liveSearchDocuments: PropTypes.func.isRequired,
  bindDocument: PropTypes.func.isRequired,
  ownerSide: PropTypes.objectOf(PropTypes.any).isRequired,
  cascaderValue: PropTypes.objectOf(PropTypes.any),
  history: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
  editAction: PropTypes.func.isRequired,
  bindDocAction: PropTypes.func.isRequired,
  isViewModal: PropTypes.bool.isRequired,
  childrenDocuments: PropTypes.arrayOf(PropTypes.any).isRequired,
  controlButtons: PropTypes.objectOf(PropTypes.any).isRequired,
  linkedDocuments: PropTypes.arrayOf(PropTypes.any).isRequired,
  parentDocument: PropTypes.objectOf(PropTypes.any).isRequired,
  match: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
};

const mapStateToProps = (state, { createdForm }) => ({
  cascaderValue: state.documentForms.documentCascader.selectedValue[defStoreKey],
  childrenDocuments: createdForm.childrenDocuments || [],
  linkedDocuments: createdForm.linkedDocuments || [],
  parentDocument: createdForm.parentDocument || {},
});

export default withRouter(connect(mapStateToProps, bindingDocumentsActions)(BindingDocumentTab));
