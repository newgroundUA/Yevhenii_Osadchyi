import React from 'react';
import { Cascader } from 'antd';
import { connect } from 'react-redux';
import { PropTypes } from 'prop-types';

import * as documentTypesCascaderActions from '../../../actions/modules/documents/documentTypesCascaderActions';
import { defStoreKey } from '../../../helpers/reducers/documents/commonActionsHandlers';

class DocumentCascader extends React.Component {
  componentDidMount = () => {
    if (!this.props.options.length) {
      this.props.loadScopeOfApp();
    }
    this.props.selectCascaderValue(null, this.props.storeKey);
  };

  onChange = (value, selectedOptions) => {
    if (value[this.props.resultAfterStep]) {
      this.props.selectCascaderValue(
        {
          list: value,
          generalDocClassName: selectedOptions[2] && selectedOptions[2].generalDocClassName,
          data: selectedOptions[selectedOptions.length - 1],
        },
        this.props.storeKey,
      );
    } else {
      this.props.selectCascaderValue(null, this.props.storeKey);
    }
  };

  loadData = (selectedOptions) => {
    const targetOption = selectedOptions[selectedOptions.length - 1];
    targetOption.loading = true;

    if (targetOption.loadAction === 'loadCategory') {
      this.props.loadDocCategory(targetOption.value);
    } else {
      this.props.loadDocView(selectedOptions[0].value, targetOption.value);
    }
  };

  render() {
    return (
      <Cascader
        options={this.props.options}
        loadData={this.loadData}
        onChange={this.onChange}
        value={this.props.selectedData.list}
        getPopupContainer={() => {
          if (this.props.isModal) {
            return document.getElementsByClassName('ant-modal-wrap')[0];
          }
          return document.body;
        }}
        placeholder="Оберіть тип документу"
        changeOnSelect
        style={{ width: '100%' }}
        title="Виберіть тип документу."
        disabled={this.props.disabled}
      />
    );
  }
}

DocumentCascader.defaultProps = {
  selectedData: {
    list: [],
  },
  resultAfterStep: '2',
  storeKey: defStoreKey,
  disabled: false,
  isModal: false,
};

DocumentCascader.propTypes = {
  loadScopeOfApp: PropTypes.func.isRequired,
  loadDocCategory: PropTypes.func.isRequired,
  loadDocView: PropTypes.func.isRequired,
  selectCascaderValue: PropTypes.func.isRequired,
  options: PropTypes.arrayOf(PropTypes.any).isRequired,
  resultAfterStep: PropTypes.string,
  storeKey: PropTypes.string,
  selectedData: PropTypes.objectOf(PropTypes.any),
  isModal: PropTypes.bool,
  disabled: PropTypes.any, // eslint-disable-line
};

const mapStateToProps = (state, { storeKey }) => ({
  options: state.documentForms.documentCascader.options,
  selectedData: state.documentForms.documentCascader.selectedValue[storeKey || defStoreKey],
});

export default connect(mapStateToProps, documentTypesCascaderActions)(DocumentCascader);
