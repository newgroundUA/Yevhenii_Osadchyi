import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Tabs } from 'antd';
import { withRouter } from 'react-router-dom';

import BindingDocumentTab from './bindingDocumentComponent/BindingDocumentTab';
import BindingFilesTab from './bindingFilesComponent/BindingFilesTab';

const TabPane = Tabs.TabPane;

class GeneralTabsContainer extends Component {
  state = {
    activeKey: '0',
  };

  componentWillReceiveProps = (nextProps) => {
    const {
      match: {
        params: { mode },
      },
    } = this.props;

    const {
      match: {
        params: { mode: nextMode },
      },
    } = nextProps;

    if (mode !== nextMode && nextMode === 'create') {
      this.setState({ activeKey: '0' });
    }
  };

  handleChangeTabs = (activeKey) => this.setState({ activeKey });

  render() {
    const {
      children,
      ownerSide,
      editAction,
      createdForm,
      bindDocAction,
      isViewModal,
      controlButtons,
      match: {
        params: { mode },
      },
    } = this.props;

    const isCreateMode = mode === 'create';

    return (
      <Tabs activeKey={this.state.activeKey} onChange={this.handleChangeTabs}>
        {children}
        <TabPane tab="Зв'язані документи" key="general1" disabled={isCreateMode}>
          <BindingDocumentTab
            controlButtons={controlButtons}
            ownerSide={ownerSide}
            editAction={editAction}
            createdForm={createdForm}
            bindDocAction={bindDocAction}
            isViewModal={isViewModal}
          />
        </TabPane>
        <TabPane tab="Файли" key="general2" disabled={isCreateMode}>
          <BindingFilesTab
            controlButtons={controlButtons}
            ownerSide={ownerSide}
            editAction={editAction}
            createdForm={createdForm}
            isViewModal={isViewModal}
          />
        </TabPane>
      </Tabs>
    );
  }
}

GeneralTabsContainer.defaultProps = {
  // formData: {
  //   childrenDocuments: [],
  //   linkedDocuments: [],
  //   parentDocument: {},
  // },
};

GeneralTabsContainer.propTypes = {
  children: PropTypes.objectOf(PropTypes.any).isRequired,
  ownerSide: PropTypes.objectOf(PropTypes.any).isRequired,
  createdForm: PropTypes.shape().isRequired,
  bindDocAction: PropTypes.func.isRequired,
  editAction: PropTypes.func.isRequired,
  isViewModal: PropTypes.bool.isRequired,
  controlButtons: PropTypes.objectOf(PropTypes.any).isRequired,
  match: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
};

export default withRouter(GeneralTabsContainer);
