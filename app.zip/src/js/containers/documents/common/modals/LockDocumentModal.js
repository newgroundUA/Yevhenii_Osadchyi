import React from 'react';
import PropTypes from 'prop-types';
import { Form, Button, Icon, Menu, Dropdown, Table } from 'antd';
import { connect } from 'react-redux';
import { mapFormItems } from '../../../../helpers/formHelpers/mapFormHelper';
import {
  lockDocumentColumns,
  lockDocumentFields,
  lockDocumentParseToFE,
} from '../../../../models/formFields/documents/lockDocumentModal';
import * as lockDocumentActions from '../../../../actions/modules/documents/lockDocumentActions';

const enumMenu = {
  parent: 1,
  all: 2,
};

const formItemLayout = {
  wrapperCol: { span: 24 },
  labelCol: { span: 24 },
};

class LockDocumentModal extends React.Component {
  handleSend = (item) => {
    const { form, lockDocument, guid, versionId, handleCloseModal, updateForm } = this.props;

    form.validateFields(Object.keys(lockDocumentFields), (err, values) => {
      if (!err) {
        lockDocument({
          ...values,
          lockChildren: +item.key === enumMenu.all,
          guid,
          versionId,
        }).then((resp) => {
          updateForm({
            versionId: resp.data.versionId,
            validityStatus: resp.data.validityStatus,
            reason: resp.data.reason,
            dateTo: resp.data.dateTo,
          });
          handleCloseModal();
          this.props.loadDocument();
        });
      }
    });
  };

  render() {
    const { handleCloseModal, form, childrenDocuments } = this.props;

    const dropDownMenu = (
      <Menu onClick={this.handleSend}>
        <Menu.Item key={enumMenu.parent}>Тільки поточний документ</Menu.Item>
        <Menu.Item key={enumMenu.all} disabled={!childrenDocuments.length}>
          Поточний та підпорядковані документи
        </Menu.Item>
      </Menu>
    );

    const dataSource = childrenDocuments.map((el) => lockDocumentParseToFE(el));

    return (
      <div>
        <Form>
          {mapFormItems({
            fields: lockDocumentFields,
            formItemLayout,
            form,
          })}
        </Form>

        {!!childrenDocuments.length && (
          <Table
            columns={lockDocumentColumns}
            dataSource={dataSource}
            pagination={{
              total: childrenDocuments.length,
              showTotal: (total) => `Знайдено: ${total}`,
              pageSize: 10,
            }}
          />
        )}

        <div className="document-create-modal-section__buttons">
          <Button onClick={handleCloseModal}>Скасувати</Button>
          <Dropdown overlay={dropDownMenu}>
            <Button type="primary">
              Заблокувати
              <Icon type="down" />
            </Button>
          </Dropdown>
        </div>
      </div>
    );
  }
}

LockDocumentModal.defaultProps = {
  childrenDocuments: [],
};

LockDocumentModal.propTypes = {
  lockDocument: PropTypes.func.isRequired,
  updateForm: PropTypes.func.isRequired,
  loadDocument: PropTypes.func.isRequired,
  handleCloseModal: PropTypes.func.isRequired,
  form: PropTypes.objectOf(PropTypes.any).isRequired,
  guid: PropTypes.string.isRequired,
  versionId: PropTypes.number.isRequired,
  childrenDocuments: PropTypes.arrayOf(PropTypes.any),
};

export default connect(null, lockDocumentActions)(Form.create()(LockDocumentModal));
