import React from 'react';
import { Form, Button } from 'antd';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { mapFormItems } from '../../../../helpers/formHelpers/mapFormHelper';
import { bindingFilesLiveSerchFields } from '../../../../models/formFields/documents/bindingFilesFields';

const formItemLayout = {
  wrapperCol: { span: 24 },
  labelCol: { span: 24 },
};

class BindingFilesFormFields extends React.Component {
  handleOnChange = (e) => {
    if (e.target && e.target.value.length < 3) {
      return;
    }

    setTimeout(() => {
      this.props.handleChange(this.getRequestData());
    }, 0);
  };

  handleResetForm = () => {
    this.props.form.resetFields();
    this.props.handleRefreshFields();
  };

  getRequestData = () => {
    const dataForFilter = this.props.form.getFieldsValue();

    return {
      filter: this.getFilter(dataForFilter),
      limit: this.props.LIMIT_SIZE_SEARCH,
      page: 0,
    };
  };

  getFilter = (formData) =>
    Object.keys(formData).reduce((result, key) => {
      if (!formData[key]) {
        return result;
      }

      // TODO write specific rules
      return result.concat([
        {
          action: 'contains',
          value: formData[key],
          key,
        },
      ]);
    }, []);

  resetLiveSearchButton = () => ({
    render: () => (
      <Button onClick={this.handleResetForm} type="danger" className="global_full-width">
        Очистити фільтри
      </Button>
    ),
    className: 'global_full-width',
    colSpan: 6,
    key: 'resetButton',
  });

  render() {
    const {
      form,
      classifiers,
      match: {
        params: { mode },
      },
    } = this.props;

    const isViewMode = mode === 'view';

    return (
      <Form>
        {mapFormItems({
          viewMode: mode,
          fields: bindingFilesLiveSerchFields,
          classifiers,
          isViewMode,
          formItemLayout,
          onChange: this.handleOnChange,
          form,
          customFields: [this.resetLiveSearchButton()],
        })}
      </Form>
    );
  }
}

BindingFilesFormFields.propTypes = {
  classifiers: PropTypes.objectOf(PropTypes.array).isRequired,
  form: PropTypes.objectOf(PropTypes.any).isRequired,
  handleChange: PropTypes.func.isRequired,
  handleRefreshFields: PropTypes.func.isRequired,
  LIMIT_SIZE_SEARCH: PropTypes.number.isRequired,
  match: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
};

const mapStateToProps = (state) => ({
  classifiers: state.classifiers,
});

export default withRouter(connect(mapStateToProps)(Form.create()(BindingFilesFormFields)));
