import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';

import { Row, Table, Icon, Tag, Modal, Button } from 'antd';

import * as bindingDocumentsActions from '../../../../actions/modules/documents/bindingDocumentsActions';
import * as fileStorageActions from '../../../../actions/modules/documents/fileStorageActions';
import {
  getBoundFileToFE,
  getLiveSearchedFileToFE,
} from '../../../../models/formFields/documents/bindingFilesFields';
import LiveSearchFieldsWithTable from '../LiveSearchFieldsWithTable';
import BindingFilesFormFields from './BindingFilesFormFields';
import Separator from '../../../../components/common/form/Separator';
import BindingFilesModal from './BindingFilesModal';

const CONTAINER_ACTIONS = {
  ...bindingDocumentsActions,
  ...fileStorageActions,
};

class BindingFilesTab extends React.Component {
  state = {
    isModalCreateFileOpen: false,
  };

  handleCloseModal = () => {
    this.setState({
      isModalCreateFileOpen: false,
    });
  };

  handleResolveModal = (data) => {
    this.bindAction(data);
    this.handleCloseModal();
  };

  openCreateFileModal = () => {
    this.setState({
      isModalCreateFileOpen: true,
    });
  };

  liveSearchFilestorageColumns = () => [
    {
      title: 'Файл',
      dataIndex: 'fileName',
    },
    {
      title: 'Назва',
      dataIndex: 'fileAlias',
    },
    {
      title: 'Опис',
      dataIndex: 'fileNotes',
      width: 400,
    },
    {
      title: 'Завантажив',
      dataIndex: 'docUser',
    },
    {
      title: 'Теги',
      dataIndex: 'fileTags',
      render: this.getTagElement,
    },
    {
      title: 'Розмір',
      dataIndex: 'fileSize',
      render: this.preventLineBreak,
    },
    {
      title: 'Дата',
      dataIndex: 'date',
    },
    {
      title: 'Дія',
      dataIndex: 'dataForActions',
      render: this.getDownloadButton,
    },
  ];

  boundDocumentsColumns = () => [
    {
      title: 'Файл',
      dataIndex: 'fileName',
    },
    {
      title: 'Назва',
      dataIndex: 'fileAlias',
    },
    {
      title: 'Опис',
      dataIndex: 'fileNotes',
      width: 400,
    },
    {
      title: 'Видавач',
      dataIndex: 'docUser',
    },
    {
      title: 'Теги',
      dataIndex: 'fileTags',
      render: this.getTagElement,
    },
    {
      title: 'Розмір',
      dataIndex: 'fileSize',
      render: this.preventLineBreak,
    },
    {
      title: 'Дата',
      dataIndex: 'date',
    },
    {
      title: 'Дія',
      dataIndex: 'dataForActions',
      render: this.getOperationButtons,
    },
  ];

  preventLineBreak = (value) => <span style={{ whiteSpace: 'nowrap' }}>{value}</span>;

  getTagElement = (fileTags) => fileTags && fileTags.map((el) => <Tag key={el.guid}>{el.tag}</Tag>);

  getDownloadButton = (downloadData) => (
    <span>
      <Icon
        type="download"
        style={{ fontSize: '20px', marginRight: '10px', cursor: 'pointer' }}
        onClick={this.downloadFile(downloadData)}
      />
    </span>
  );

  getOperationButtons = (actionData) => (
    <span style={{ whiteSpace: 'nowrap' }}>
      <Icon
        type="download"
        style={{ fontSize: '20px', marginRight: '10px', cursor: 'pointer' }}
        onClick={this.downloadFile(actionData)}
      />
      <Button
        onClick={this.unbindFile(actionData.guid)}
        disabled={this.props.match.params.mode === 'view'}
      >
        <Icon
          type="close"
          style={{ fontSize: '20px', color: '#e31b1c', fontWeight: '1000', cursor: 'pointer' }}
        />
      </Button>
    </span>
  );

  downloadFile = (downloadData) => () => {
    this.props.downloadFile(downloadData.fileLink, downloadData.fileName);
  };

  bindAction = (data) => {
    this.props.editAction({
      ignoreStatus: true,
      file: data,
    });
  };

  unbindFile = (guid) => () => {
    this.props.editAction({
      ignoreStatus: true,
      delFileGuid: guid,
    });
  };

  render() {
    const {
      ownerSide,
      liveSearchFilestorage,
      controlButtons,
      fileStorage,
      isViewModal,
      match: {
        params: { mode },
      },
    } = this.props;

    const isViewMode = mode === 'view';

    return (
      <Row>
        {!isViewModal && (
          <div>
            {controlButtons}
            <Button
              className="global_mb20"
              size="large"
              type="primary"
              onClick={this.openCreateFileModal}
              disabled={isViewMode}
            >
              {`Новий файл`}
            </Button>
            <LiveSearchFieldsWithTable
              LiveSearchFormFields={BindingFilesFormFields}
              liveSearchAction={liveSearchFilestorage}
              title="Пошук файлів"
              bindAction={this.bindAction}
              bindActionData={{ ownerSide }}
              parseToFE={getLiveSearchedFileToFE}
              columns={this.liveSearchFilestorageColumns()}
            />
          </div>
        )}
        <Row className="global_mt20">
          <Separator text="Додані файли" />
          <Table
            columns={this.boundDocumentsColumns()}
            dataSource={getBoundFileToFE(fileStorage)}
            pagination={false}
          />
        </Row>
        <Modal
          visible={this.state.isModalCreateFileOpen}
          footer={false}
          title="Новий файл"
          width="830px"
          onCancel={this.handleCloseModal}
          destroyOnClose
          maskClosable={false}
        >
          <BindingFilesModal onCancel={this.handleCloseModal} onOk={this.handleResolveModal} />
        </Modal>
      </Row>
    );
  }
}

BindingFilesTab.propTypes = {
  fileStorage: PropTypes.arrayOf(PropTypes.any).isRequired,
  ownerSide: PropTypes.objectOf(PropTypes.any).isRequired,
  liveSearchFilestorage: PropTypes.func.isRequired,
  downloadFile: PropTypes.func.isRequired,
  controlButtons: PropTypes.objectOf(PropTypes.any).isRequired,
  editAction: PropTypes.func.isRequired,
  isViewModal: PropTypes.bool.isRequired,
  match: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
};

const mapStateToProps = (state, { createdForm }) => ({
  fileStorage: createdForm.fileStorage || [],
});

export default withRouter(connect(mapStateToProps, CONTAINER_ACTIONS)(BindingFilesTab));
