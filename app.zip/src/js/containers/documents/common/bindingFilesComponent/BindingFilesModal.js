import React from 'react';
import { Row, Form, Col, Icon, Upload, Button } from 'antd';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';

import { renderInput, renderTextarea } from '../../../../helpers/formHelpers/mapFormHelper';
// TODO: Remove tags field (DKV-2103)
// import LiveSearchSelect from '../../../../components/common/form/liveSearchSelect';

import * as fileTagsActions from '../../../../actions/modules/documents/fileTagsActions';
import * as fileStorageActions from '../../../../actions/modules/documents/fileStorageActions';

const FormItem = Form.Item;

const formItemLayout = {
  wrapperCol: { span: 24 },
  labelCol: { span: 24 },
};

const tagFieldName = 'fileTags';
const fileFieldName = 'file';

// TODO: Remove tags field (DKV-2103)
// const parseFileTagSelectToFe = (array) =>
//   array.map((el) => ({
//     ...el,
//     text: el.tag,
//     value: JSON.stringify({
//       guid: el.guid,
//       versionId: el.versionId,
//     }),
//   }));

class BindingFilesModal extends React.Component {
  state = {
    // inputVisible: false,
    uploadError: {},
    inputValue: '',
  };

  componentDidMount() {}

  handleSend = () => {
    const { form, uploadFile } = this.props;

    form.validateFields({}, (err, values) => {
      if (!err) {
        const file = values.file.file;
        const metaData = values;

        uploadFile(file, metaData).then((response) => {
          form.resetFields();
          this.props.onOk(response.data);
        });
      }
    });
  };

  showInput = () => {
    this.setState(
      {
        // inputVisible: true,
        inputValue: '',
      },
      () => {
        this.input.focus();
      },
    );
  };

  saveInputRef = (input) => {
    this.input = input;
  };

  handleInputChange = (e) => {
    this.setState({
      inputValue: e.target.value,
    });
  };

  handleInputConfirm = () => {
    const { inputValue } = this.state;
    const { form, createFileTag } = this.props;

    if (inputValue) {
      createFileTag([{ tag: inputValue }]).then((response) => {
        const [content] = response.data;
        const prevValue = form.getFieldValue(tagFieldName);

        const nextValue = {
          key: JSON.stringify({
            guid: content.guid,
            versionId: content.versionId,
          }),
          label: content.tag,
        };

        form.setFieldsValue({
          [tagFieldName]: prevValue ? prevValue.concat(nextValue) : [nextValue],
        });
      });
    }

    // this.setState({
    //   inputVisible: false,
    // });
  };

  handleChangeUploading = (data) => {
    const { config } = this.props;
    const maxSizeParsedInt = parseInt(config.docSize || 0, 10);

    const maxSize = maxSizeParsedInt * 1024 * 1024;
    if (data.file.size >= maxSize) {
      this.setState(
        {
          uploadError: {
            validateStatus: 'error',
            help: 'Розмір файлу перевищує допустимий',
          },
        },
        this.handleRemove,
      );
    } else if (this.state.uploadError.help) {
      this.setState({
        uploadError: {},
      });
    }
  };

  handleRemove = () => {
    this.props.form.resetFields(fileFieldName);
  };

  render() {
    const { form, config } = this.props;
    return (
      <div>
        <Form>
          <Row gutter={16}>
            <Col span="12" key="0">
              <FormItem
                label="Завантаження файлу"
                {...formItemLayout}
                className=" labelOneRow"
                style={{ marginBottom: '20px' }}
                {...this.state.uploadError}
              >
                <div className="file-uploader_note">
                  {`Об'єм файлу не має перевищувати ${parseInt(config.docSize || 0, 10)} MB`}
                </div>
                {form.getFieldDecorator(fileFieldName, {
                  rules: [{ required: true, message: 'Потрібен файл' }],
                })(
                  <Upload.Dragger
                    multiple={false}
                    fileList={
                      form.getFieldValue(fileFieldName)
                        ? [form.getFieldValue(fileFieldName).file]
                        : []
                    }
                    beforeUpload={() => false}
                    onChange={this.handleChangeUploading}
                    onRemove={this.handleRemove}
                  >
                    {`Натисніть для вибору файлу`}
                    <Icon type="upload" style={{ margin: '0 5px' }} />
                    {`або перетягніть його сюди`}
                  </Upload.Dragger>,
                )}
              </FormItem>

              {renderInput({
                key: '0',
                item: {
                  name: 'Назва',
                  field: 'fileAlias',
                  placeholder: 'Введіть назву файл',
                  className: 'labelOneRow',
                  rules: [{ required: true, message: 'Поле обов`язкове для вибору!' }],
                },
                form,
              })}
            </Col>
            <Col span="12" key="1">
              {renderTextarea({
                item: {
                  name: 'Опис',
                  field: 'fileNotes',
                  className: 'labelOneRow',
                  placeholder: 'Введіть інформацію про файл',
                },
                form,
              })}
            </Col>
          </Row>
          {/* TODO: Remove tags field (DKV-2103)
          <Row>
            {this.state.inputVisible && <Input className="file-tag_input" ref={this.saveInputRef} type="text" size="small" value={this.state.inputValue} onChange={this.handleInputChange} onBlur={this.handleInputConfirm} onPressEnter={this.handleInputConfirm} />}
            <Button onClick={this.showInput} type="dashed" className="file-tag_button">
              <Icon type="plus" /> новий
            </Button>

            <LiveSearchSelect
              className="tag-file_selector"
              type="multiple"
              form={form}
              fetchAction={this.props.liveSearchFileTags}
              parseToFe={parseFileTagSelectToFe}
              params={{
                formItemLayout,
                fieldName: tagFieldName,
                placeholder: 'Введіть назву тега для пошуку',
                label: 'Теги',
                className: 'labelOneRow',
              }}
              minCountSymbolsSearch={2}
            />
          </Row>
          */}
        </Form>
        <div className="document-create-modal-section__buttons">
          <Button onClick={this.props.onCancel}>Повернутись</Button>
          <Button type="primary" onClick={this.handleSend}>
            {`Додати`}
          </Button>
        </div>
      </div>
    );
  }
}

BindingFilesModal.propTypes = {
  onOk: PropTypes.func.isRequired,
  uploadFile: PropTypes.func.isRequired,
  onCancel: PropTypes.func.isRequired,
  form: PropTypes.objectOf(PropTypes.any).isRequired,
  // TODO: Remove tags field (DKV-2103)
  // liveSearchFileTags: PropTypes.func.isRequired,
  config: PropTypes.objectOf(PropTypes.any).isRequired,
  createFileTag: PropTypes.func.isRequired,
};

const mapStateToProps = (state) => ({
  config: state.app.config,
});

export default connect(mapStateToProps, { ...fileTagsActions, ...fileStorageActions })(
  Form.create()(BindingFilesModal),
);
