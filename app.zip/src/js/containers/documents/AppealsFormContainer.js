import React from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import PropTypes from 'prop-types';

import { Form, Modal, Button, Row, Tabs } from 'antd';
import _get from 'lodash/get';
import _remove from 'lodash/remove';

import * as classifiersActions from '../../actions/classifiersActions';
import * as generalDocumentActions from '../../actions/modules/documents/generalDocumentActions';
import * as appealsDocumentActions from '../../actions/modules/documents/appealsDocumentActions';
import * as commonActions from '../../actions';
import * as fileActions from '../../actions/modules/documents/fileTableActions';

import { mapFormItems } from '../../helpers/formHelpers/mapFormHelper';

import {
  generalFields,
  getParsedForm,
  getMappedForm,
} from '../../models/formFields/documents/generalFields';

import {
  appealsFields,
  getParsedForm as getAppealsParsedForm,
  getMappedForm as getAppealsMappedForm,
} from '../../models/formFields/documents/appealsFields';

import { APPEALS_FORM_CONTAINER } from '../../constants/ContainerNames';
import {
  WEBSITELIST,
  REF_DOCUMENT_TYPE_GENERAL_DOC_CLASSNAME,
} from '../../constants/ClassifiersNames';

import Separator from '../../components/common/form/Separator';
import * as RouteNames from '../../constants/RouteNames';

import {
  failedValidationNotification,
  getFormEntityData,
} from '../../helpers/formHelpers/formHelpers';
import GeneralControlButtons from './common/GeneralControlButtons';
import GeneralTabsContainer from './common/GeneralTabsContainer';
import LockDocumentModal from './common/modals/LockDocumentModal';
import { defaultStoreKey } from '../../reducers/modules/documents/generalDocumentReducer';
import { getObjGuidAndVersionId } from '../../helpers/commonUtils';
import { defStoreKey } from '../../helpers/reducers/documents/commonActionsHandlers';
import { goToRegistry } from '../../helpers/entities/registry';

const APPEALS_FORM_CONTAINER_ACTIONS = {
  ...classifiersActions,
  ...generalDocumentActions,
  ...appealsDocumentActions,
  ...commonActions,
  ...fileActions,
};

const TabPane = Tabs.TabPane;

class AppealsFormContainer extends React.Component {
  constructor(props) {
    super(props);

    const curMode = this.props.match.params.mode || 'create';
    this.curGuid = this.props.match.params.guid || '';

    this.state = {
      curMode,
      dialogOpen: false,
      lockDocumentModalIsOpen: false,
      dialogMessage: '',
    };

    this.loaded = false;
  }

  componentWillMount() {
    const { history } = this.props;
    if (this.state.curMode === 'create' && !this.getFormType()) {
      goToRegistry({
        name: 'documents',
        history,
      });
    }
  }

  componentDidMount = () => {
    const { getAppealsDocument, isViewModal, modalData, storeKey } = this.props;
    const { curMode } = this.state;

    this.props.loadClassifiersForContainer(APPEALS_FORM_CONTAINER, {
      [WEBSITELIST]: { webSiteRegistryParam: { offset: '0', limit: '100' } },
      [REF_DOCUMENT_TYPE_GENERAL_DOC_CLASSNAME]: { generalDocClassName: 'DocAppeals' },
    });
    if (isViewModal) {
      this.setState({ curMode: 'view' });
      getAppealsDocument(modalData.guid, storeKey);
    } else if (curMode === 'view' || curMode === 'edit') {
      getAppealsDocument(this.curGuid, storeKey);
    }
  };

  componentWillReceiveProps(nextProps) {
    const {
      formParam: { createdForm },
      isViewModal,
      match: {
        params: { mode },
      },
      resetAppealsForm,
      form,
      storeKey,
      setFileTable,
    } = nextProps;

    if (isViewModal && isViewModal !== this.props.isViewModal) {
      this.setState({ curMode: 'view' });
    } else if (this.state.curMode !== mode) {
      this.setState({ curMode: mode });
    }

    if (this.state.curMode !== mode && mode === 'create') {
      form.resetFields();
      resetAppealsForm(storeKey);
    }

    if (
      (createdForm.versionId || createdForm.versionId === 0) &&
      this.props.formParam.createdForm.versionId !== createdForm.versionId
    ) {
      form.setFieldsValue({
        ...getParsedForm(createdForm),
        ...getAppealsParsedForm(createdForm),
      });
    } else if (createdForm.guid && (mode === 'view' || mode === 'edit') && !this.loaded) {
      this.loaded = true;
      form.setFieldsValue({
        ...getParsedForm(createdForm),
        ...getAppealsParsedForm(createdForm),
      });
      setFileTable(createdForm.fileStorage); // TODO: investigate: is use fileStorage anywhere
    }
  }

  componentWillUnmount() {
    this.props.resetAppealsForm();
  }

  handleCreateNew = () => {
    this.changeRouteTo(
      `/${RouteNames.DOCUMENTS}/${RouteNames.DOCUMENT_APPEALS}/${RouteNames.CREATE}`,
    );
    this.curGuid = '';
    this.loaded = false;
    this.props.form.resetFields();
    this.props.resetAppealsForm(this.props.storeKey);
    this.handleToggleDialog();
  };

  clearForm = () => {
    this.props.form.resetFields();
  };

  changeRouteTo = (route) => {
    this.props.history.push(route);
  };

  handleToggleDialog = (isOpened) => {
    if (isOpened !== undefined) this.setState({ dialogOpen: isOpened });
    else this.setState((prevState) => ({ dialogOpen: !prevState.dialogOpen }));
  };

  handleDialogCancel = () => {
    this.handleToggleDialog();
    this.switchToViewMode();
  };

  switchToEditMode = () => {
    this.changeRouteTo(
      `/${RouteNames.DOCUMENTS}/${RouteNames.DOCUMENT_APPEALS}/${RouteNames.EDIT}/${this.curGuid}`,
    );
  };

  switchToViewMode = () => {
    this.changeRouteTo(
      `/${RouteNames.DOCUMENTS}/${RouteNames.DOCUMENT_APPEALS}/${RouteNames.VIEW}/${this.curGuid}`,
    );
  };

  handleLockDocumentModal = () => {
    this.setState((prevState) => ({
      lockDocumentModalIsOpen: !prevState.lockDocumentModalIsOpen,
    }));
  };

  handleSubmit = ({ ignoreStatus, file = {}, delDoc = {}, delFileGuid = '' }) => {
    const { curMode } = this.state;
    const {
      putAppealsDocument,
      classifiers,
      postAppealsDocument,
      storeKey,
      formParam: { createdForm },
      form,
    } = this.props;

    const showError = (errors) =>
      Modal.error({
        title: 'Помилка!',
        content: (
          <div>
            {errors.map((err, i) => (
              <p key={i}>
                {i + 1}
                .
                {err.message}
              </p>
            ))}
          </div>
        ),
      });

    const readResponse = (res) => {
      if (res.statusCode === 200) {
        this.curGuid = res.data.guid;
        this.setState(() => ({ dialogOpen: true }));
      } else {
        showError(res.errors);
      }
    };

    const fields = {
      ...generalFields,
      ...appealsFields,
    };

    const curFields = [...Object.keys(generalFields), ...Object.keys(appealsFields)];

    form.validateFields(curFields, (err, values) => {
      if (!err) {
        const normilizedValues = getFormEntityData(values, classifiers, fields);

        if (curMode === 'create') {
          postAppealsDocument(
            {
              ...getMappedForm(normilizedValues),
              ...getAppealsMappedForm(normilizedValues),
              refDocumentType: this.getFormTypeData(),
              documentType: 'DocAppeals',
            },
            storeKey,
          ).then(readResponse);
        }

        if (curMode === 'edit') {
          const files = file.guid ? [...createdForm.fileStorage, file] : createdForm.fileStorage;

          if (delFileGuid) {
            _remove(files, (el) => el.guid === delFileGuid);
          }

          if (delDoc.guid) {
            if (Array.isArray(createdForm[delDoc.field])) {
              _remove(createdForm[delDoc.field], (el) => el.guid === delDoc.guid);
            } else {
              createdForm[delDoc.field] = undefined;
            }
          }

          putAppealsDocument(
            {
              ...createdForm,
              ...getMappedForm(normilizedValues),
              ...getAppealsMappedForm(normilizedValues),
              guid: this.curGuid,
              fileStorage: getObjGuidAndVersionId(files),
              linkedDocuments: getObjGuidAndVersionId(createdForm.linkedDocuments),
              parentDocument: getObjGuidAndVersionId(createdForm.parentDocument),
              childrenDocuments: getObjGuidAndVersionId(createdForm.childrenDocuments),
              versionId: this.props.formParam.createdForm.versionId,
            },
            storeKey,
            ignoreStatus,
          ).then((res) => {
            if (!ignoreStatus) {
              readResponse(res);
            }
          });
        }
      } else {
        failedValidationNotification(err, fields);
      }
    });
  };

  getFormType = () => {
    const {
      formTypeData,
      classifiers,
      formParam: {
        createdForm: { refDocumentType },
      },
    } = this.props;

    const documentTypeField = classifiers.refDocumentTypeGeneralDocClassName.find(
      (el) => el.guid === (refDocumentType || {}).guid,
    );

    if (documentTypeField) {
      return documentTypeField;
    }
    return formTypeData;
  };

  getFormTypeData = () => {
    const { guid, versionId, type } = this.getFormType();
    return {
      guid,
      versionId,
      type,
    };
  };

  getFormTypeLabel = () => {
    const obj = this.getFormType();
    return obj && `${obj.scopeOfApplication}/${obj.docCategory}/${obj.name}`;
  };

  render() {
    const { curMode, dialogMessage } = this.state;

    const {
      classifiers,
      isViewModal,
      formParam: { createdForm },
      form,
      lockDocToAppealsDocument,
      bindDocToAppealsDocument,
    } = this.props;

    const dialogText = curMode === 'create' ? 'створено' : 'відредаговано';
    const isViewMode = isViewModal || curMode === 'view';

    const controlButtons = (
      <GeneralControlButtons
        form={form}
        guid={this.curGuid}
        handleLockDocument={this.handleLockDocumentModal}
        documentType="DOCUMENT_APPEALS"
      />
    );

    return (
      <Row>
        <Modal
          title="Форма документа виду позов та скарга"
          visible={this.state.dialogOpen}
          onOk={() => {
            this.handleCreateNew();
          }}
          onCancel={() => {
            this.handleDialogCancel();
          }}
          cancelText="Переглянути картку"
          okText="Створити нову"
        >
          {dialogMessage === '' ? (
            <p>{`Картку успішно ${dialogText}`}</p>
          ) : (
            <p>{`${dialogMessage}`}</p>
          )}
        </Modal>
        <Modal
          title="Блокування документа"
          visible={this.state.lockDocumentModalIsOpen}
          onCancel={this.handleLockDocumentModal}
          footer={null}
          width="1000px"
          maskClosable={false}
          destroyOnClose
        >
          <LockDocumentModal
            handleCloseModal={this.handleLockDocumentModal}
            childrenDocuments={createdForm.childrenDocuments}
            guid={this.curGuid}
            versionId={_get(createdForm, ['versionId'], this.curVersionId)}
            updateForm={lockDocToAppealsDocument}
            loadDocument={() => this.props.getAppealsDocument(this.curGuid, this.props.storeKey)}
          />
        </Modal>
        <h1 key="formLabel">{this.getFormTypeLabel()}</h1>
        <GeneralTabsContainer
          ownerSide={{
            guid: this.curGuid,
            versionId: _get(createdForm, ['versionId'], this.curVersionId),
          }}
          editAction={this.handleSubmit}
          controlButtons={controlButtons}
          bindDocAction={bindDocToAppealsDocument}
          isViewModal={isViewModal}
          createdForm={createdForm}
        >
          <TabPane tab="Форма документа виду позов та скарга" key="0">
            <Row>
              {!isViewModal && controlButtons}
              <Row>
                <Form>
                  <Row>
                    <Separator text="Основна інформація" />
                    {mapFormItems({
                      viewMode: curMode,
                      fields: generalFields,
                      classifiers,
                      isViewMode,
                      form: this.props.form,
                    })}
                    <Separator text="Інформація щодо виду позову та скарги" />
                    {mapFormItems({
                      viewMode: curMode,
                      fields: appealsFields,
                      classifiers,
                      isViewMode,
                      form: this.props.form,
                    })}
                    <Row type="flex" justify="end">
                      <Button
                        style={{ marginRight: '1.5rem' }}
                        type="primary"
                        onClick={this.handleSubmit}
                        disabled={isViewMode}
                      >
                        Відправити
                      </Button>
                    </Row>
                  </Row>
                  <Row />
                </Form>
              </Row>
            </Row>
          </TabPane>
        </GeneralTabsContainer>
      </Row>
    );
  }
}

AppealsFormContainer.defaultProps = {
  isViewModal: false,
  modalData: {},
  formParam: {},
  storeKey: defaultStoreKey,
};

AppealsFormContainer.propTypes = {
  loadClassifiersForContainer: PropTypes.func.isRequired,
  history: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
  match: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,

  postAppealsDocument: PropTypes.func.isRequired,
  putAppealsDocument: PropTypes.func.isRequired,
  getAppealsDocument: PropTypes.func.isRequired,

  setFileTable: PropTypes.func.isRequired,

  classifiers: PropTypes.objectOf(PropTypes.array).isRequired,
  formTypeData: PropTypes.objectOf(PropTypes.any).isRequired,
  resetAppealsForm: PropTypes.func.isRequired,
  formParam: PropTypes.objectOf(PropTypes.any),

  form: PropTypes.objectOf(PropTypes.any).isRequired,

  bindDocToAppealsDocument: PropTypes.func.isRequired,
  lockDocToAppealsDocument: PropTypes.func.isRequired,

  isViewModal: PropTypes.bool,
  modalData: PropTypes.objectOf(PropTypes.string),
  storeKey: PropTypes.string,
};

const mapStateToProps = (state, { storeKey }) => ({
  classifiers: state.classifiers,
  formTypeData: state.documentForms.documentCascader.selectedValue[storeKey || defStoreKey].data, // eslint-disable-line
  formParam: state.documentForms.appeals.forms[storeKey || defStoreKey],
});

export default withRouter(
  connect(mapStateToProps, APPEALS_FORM_CONTAINER_ACTIONS)(Form.create()(AppealsFormContainer)),
);
