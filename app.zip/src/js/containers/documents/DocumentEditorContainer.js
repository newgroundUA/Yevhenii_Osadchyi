import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import FroalaEditor from 'react-froala-wysiwyg';
import { Button } from 'antd';

import * as documentsActions from '../../actions/modules/documents/documentsActions';
import { DOCUMENTS, DOCUMENT_TYPICAL_CONTRACT, VIEW } from '../../constants/RouteNames';

class DocumentEditorContainer extends React.Component {
  state = { model: '' };

  constructor(props) {
    super(props);

    this.mode = this.props.match.params.mode;
    this.documentGuid = this.props.match.params.documentGuid;

    const queryParams = new URLSearchParams(this.props.location.search);

    this.originalGuid = queryParams.get('originalGuid');
    this.originalLink = queryParams.get('originalLink');
    this.copyLink = queryParams.get('copyLink');
    this.fileName = queryParams.get('fileName');
    this.version = queryParams.get('version');
  }

  static propTypes = {
    htmlDocument: PropTypes.string,
    match: PropTypes.shape({
      params: PropTypes.shape({
        mode: PropTypes.string.isRequired,
        documentGuid: PropTypes.string,
      }),
    }).isRequired,
    location: PropTypes.objectOf(PropTypes.any).isRequired,
    history: PropTypes.objectOf(PropTypes.any).isRequired,
    putEditorDocumentFile: PropTypes.func.isRequired,
    loadEditorDocumentFile: PropTypes.func.isRequired,
    resetHtmlDocument: PropTypes.func.isRequired,
  };

  static defaultProps = {
    htmlDocument: null,
  };

  componentDidMount = () => {
    this.props.loadEditorDocumentFile(
      this.mode === 'create' ? this.originalLink : this.copyLink,
      this.version.replace('dot', '.'),
    );
  };

  componentWillReceiveProps = (nextProps) => {
    const {
      loadEditorDocumentFile,
      htmlDocument,
      match: {
        params: { documentGuid },
      },
    } = this.props;

    const queryParams = new URLSearchParams(this.props.location.search);
    const nextQueryParams = new URLSearchParams(nextProps.location.search);

    if (
      queryParams.get('originalGuid') !== nextQueryParams.get('originalGuid') ||
      queryParams.get('originalLink') !== nextQueryParams.get('originalLink') ||
      queryParams.get('copyLink') !== nextQueryParams.get('copyLink') ||
      queryParams.get('version') !== nextQueryParams.get('version') ||
      queryParams.get('fileName') !== nextQueryParams.get('fileName') ||
      documentGuid !== nextProps.match.params.documentGuid
    ) {
      loadEditorDocumentFile(
        this.mode === 'create'
          ? nextQueryParams.get('originalLink')
          : nextQueryParams.get('copyLink'),
        nextQueryParams.get('version').replace('dot', '.'),
      );

      this.mode = nextProps.match.params.mode;
      this.documentGuid = nextProps.match.params.documentGuid;
      this.originalGuid = nextQueryParams.get('originalGuid');
      this.originalLink = nextQueryParams.get('originalLink');
      this.copyLink = nextQueryParams.get('copyLink');
      this.fileName = nextQueryParams.get('fileName');
      this.version = nextQueryParams.get('version');
    }

    if (htmlDocument !== nextProps.htmlDocument) {
      this.setState({
        model: nextProps.htmlDocument,
      });
    }
  };

  componentWillUnmount = () => {
    this.props.resetHtmlDocument();
  };

  handleModelChange = (model) => {
    this.setState({ model });
  };

  handleSaveClick = () => {
    const { putEditorDocumentFile, history } = this.props;

    const data = {
      primaryFileStorageGuid: this.originalGuid,
      fileName: this.fileName,
    };

    if (this.mode === 'edit') {
      data.fileLink = this.copyLink;
      data.version = this.version.replace('dot', '.');
    }

    putEditorDocumentFile(data, this.state.model).then(() =>
      history.push(`/${DOCUMENTS}/${DOCUMENT_TYPICAL_CONTRACT}/${VIEW}/${this.documentGuid}`),
    );
  };

  render() {
    if (!this.props.htmlDocument) {
      return <div>Loading...</div>;
    }

    return (
      <div>
        <FroalaEditor
          model={this.state.model}
          onModelChange={this.handleModelChange}
          config={{
            placeholderText: '',
          }}
        />
        <Button type="primary" onClick={this.handleSaveClick}>
          Зберегти
        </Button>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  htmlDocument: state.documentForms.htmlEditor.htmlDocument,
});

export default withRouter(connect(mapStateToProps, documentsActions)(DocumentEditorContainer));
