import React from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import PropTypes from 'prop-types';

import { Form, Modal, Button, Row, Tabs } from 'antd';

import _get from 'lodash/get';
import _remove from 'lodash/remove';

import * as fileActions from '../../actions/modules/documents/fileTableActions';
import * as classifiersActions from '../../actions/classifiersActions';
import * as passportActions from '../../actions/modules/documents/passportActions';
import * as commonActions from '../../actions';

import * as RouteNames from '../../constants/RouteNames';
import {
  WEBSITELIST,
  REF_DOCUMENT_TYPE_GENERAL_DOC_CLASSNAME,
} from '../../constants/ClassifiersNames';

import { mapFormItems } from '../../helpers/formHelpers/mapFormHelper';

import { generalFields } from '../../models/formFields/documents/generalFields';
import {
  passportFields,
  getParsedForm,
  getMappedForm,
} from '../../models/formFields/documents/passportFields'; // HERE

import { PASSPORT_FORM_CONTAINER } from '../../constants/ContainerNames';

import Separator from '../../components/common/form/Separator';
import {
  failedValidationNotification,
  getFormEntityData,
} from '../../helpers/formHelpers/formHelpers';
import { defaultStoreKey } from '../../reducers/modules/documents/generalDocumentReducer';
import GeneralTabsContainer from './common/GeneralTabsContainer';
import GeneralControlButtons from './common/GeneralControlButtons';
import LockDocumentModal from './common/modals/LockDocumentModal';
import { getObjGuidAndVersionId } from '../../helpers/commonUtils';
import { goToRegistry } from '../../helpers/entities/registry';

const PASSPORT_DOCUMENT_ACTIONS = {
  ...classifiersActions,
  ...passportActions,
  ...commonActions,
  ...fileActions,
};
const TabPane = Tabs.TabPane;

class PassportFormContainer extends React.Component {
  constructor(props) {
    super(props);

    const curMode = this.props.match.params.mode || 'create';
    this.curGuid = this.props.match.params.guid || '';

    this.state = {
      curMode,
      dialogOpen: false,
      lockDocumentModalIsOpen: false,
      dialogMessage: '',
    };

    this.loaded = false;
  }

  redirectToRegister = () => {
    this.props.history.push(`/${RouteNames.DOCUMENTS}/${RouteNames.REGISTER}`);
  };

  componentWillMount() {
    const { history } = this.props;
    if (this.state.curMode === 'create' && !this.getFormType()) {
      goToRegistry({
        name: 'documents',
        history,
      });
    }
  }

  componentDidMount = () => {
    const { getPassportDocument, isViewModal, modalData, storeKey } = this.props;
    const { curMode } = this.state;

    this.props.loadClassifiersForContainer(PASSPORT_FORM_CONTAINER, {
      [WEBSITELIST]: {
        webSiteRegistryParam: {
          limit: '100',
          offset: '0',
        },
      },
      [REF_DOCUMENT_TYPE_GENERAL_DOC_CLASSNAME]: {
        generalDocClassName: 'PersonPassport',
      },
    });

    if (isViewModal) {
      this.setState({ curMode: 'view' });
      getPassportDocument(modalData.guid, storeKey);
    } else if (!isViewModal && (curMode === 'view' || curMode === 'edit')) {
      getPassportDocument(this.curGuid, storeKey);
    }
  };

  componentWillReceiveProps(nextProps) {
    const {
      formParam,
      storeKey,
      isViewModal,
      match: {
        params: { mode },
      },
      resetPassportDocumentForm,
      resetPassportDocumentDoneStatus,
      form,
      setFileTable,
    } = nextProps;

    const { createdForm, status, errors } = formParam;

    if (isViewModal && isViewModal !== this.props.isViewModal) {
      this.setState({ curMode: 'view' });
    } else if (this.state.curMode !== mode) {
      this.setState({ curMode: mode });
    }

    if (
      (createdForm.versionId || createdForm.versionId === 0) &&
      this.props.formParam.createdForm.versionId !== createdForm.versionId
    ) {
      form.setFieldsValue(getParsedForm(createdForm));
    } else if (createdForm.guid && (mode === 'view' || mode === 'edit') && !this.loaded) {
      this.loaded = true;
      form.setFieldsValue(getParsedForm(createdForm));
      setFileTable(createdForm.fileStorage);
    }

    if (this.state.curMode !== mode && mode === 'create') {
      form.resetFields();
      resetPassportDocumentForm(storeKey);
    }

    if (status.isDone) {
      this.loaded = true;
      this.curGuid = createdForm.guid;
      this.curVersionId = createdForm.versionId;
      this.handleToggleDialog();
      resetPassportDocumentDoneStatus(storeKey);
    }

    if (errors.length > 0) {
      const errorsText = errors.map((el) => el.message).join(', ');
      this.setState({ dialogMessage: errorsText, dialogOpen: true });
      resetPassportDocumentForm(storeKey);
    }
  }

  componentWillUnmount() {
    this.props.resetPassportDocumentForm(this.props.storeKey);
  }

  handleCreateNew = () => {
    this.changeRouteTo(`/${RouteNames.DOCUMENTS}/${RouteNames.DOCUMENT_PASSPORT}/create`);
    this.curGuid = '';
    this.loaded = false;
    this.props.form.resetFields();
    this.props.resetPassportDocumentForm(this.props.storeKey);
    this.handleToggleDialog();
  };

  clearForm = () => {
    this.props.form.resetFields();
  };

  changeRouteTo = (route) => {
    this.props.history.push(route);
  };

  handleToggleDialog = (isOpened) => {
    if (isOpened !== undefined) this.setState({ dialogOpen: isOpened });
    else this.setState((prevState) => ({ dialogOpen: !prevState.dialogOpen }));
  };

  handleDialogCancel = () => {
    this.handleToggleDialog();
    this.switchToViewMode();
  };

  switchToEditMode = () => {
    this.changeRouteTo(
      `/${RouteNames.DOCUMENTS}/${RouteNames.DOCUMENT_PASSPORT}/edit/${this.curGuid}`,
    );
  };

  switchToViewMode = () => {
    this.changeRouteTo(
      `/${RouteNames.DOCUMENTS}/${RouteNames.DOCUMENT_PASSPORT}/view/${this.curGuid}`,
    );
  };

  handleSubmit = ({ ignoreStatus, file = {}, delDoc = {}, delFileGuid = '' }) => {
    const { curMode } = this.state;
    const {
      putPassportDocument,
      postPassportDocument,
      classifiers,
      form,
      formParam: { createdForm },
      storeKey,
    } = this.props;

    const fields = {
      ...generalFields,
      ...passportFields,
    };

    const curFields = [...Object.keys(generalFields), ...Object.keys(passportFields)];

    form.validateFields(curFields, (err, values) => {
      if (!err) {
        const normilizedValues = getFormEntityData(values, classifiers, fields);

        if (curMode === 'create') {
          postPassportDocument(
            {
              ...getMappedForm({ ...normilizedValues }),
              refDocumentType: this.getFormTypeData(),
              documentType: 'PersonPassport',
            },
            storeKey,
          );
        }

        if (curMode === 'edit') {
          const files = file.guid ? [...createdForm.fileStorage, file] : createdForm.fileStorage;

          if (delFileGuid) {
            _remove(files, (el) => el.guid === delFileGuid);
          }

          if (delDoc.guid) {
            if (Array.isArray(createdForm[delDoc.field])) {
              _remove(createdForm[delDoc.field], (el) => el.guid === delDoc.guid);
            } else {
              createdForm[delDoc.field] = undefined;
            }
          }

          putPassportDocument(
            {
              ...createdForm,
              ...getMappedForm({ ...normilizedValues }),
              linkedDocuments: getObjGuidAndVersionId(createdForm.linkedDocuments),
              parentDocument: getObjGuidAndVersionId(createdForm.parentDocument),
              childrenDocuments: getObjGuidAndVersionId(createdForm.childrenDocuments),
              fileStorage: getObjGuidAndVersionId(files),
              guid: this.curGuid,
              versionId: _get(createdForm, 'versionId', this.curVersionId),
            },
            storeKey,
            ignoreStatus,
          );
        }
      } else {
        failedValidationNotification(err, fields);
      }
    });
  };

  getFormType = () => {
    const {
      formTypeData,
      classifiers,
      formParam: {
        createdForm: { refDocumentType },
      },
    } = this.props;

    const documentTypeField = classifiers.refDocumentTypeGeneralDocClassName.find(
      (el) => el.guid === (refDocumentType || {}).guid,
    );

    if (documentTypeField) {
      return documentTypeField;
    }
    return formTypeData;
  };

  getFormTypeData = () => {
    const { guid, versionId, type } = this.getFormType();
    return {
      guid,
      versionId,
      type,
    };
  };

  getFormTypeLabel = () => {
    const obj = this.getFormType();
    return obj && `${obj.scopeOfApplication}/${obj.docCategory}/${obj.name}`;
  };

  handleLockDocumentModal = () => {
    this.setState((prevState) => ({
      lockDocumentModalIsOpen: !prevState.lockDocumentModalIsOpen,
    }));
  };

  render() {
    const { curMode, dialogMessage } = this.state;

    const {
      classifiers,
      form,
      formParam,
      bindDocToPassportDocument,
      lockDocToPassportDocument,
      isViewModal,
    } = this.props;
    const dialogText = curMode === 'create' ? 'створено' : 'відредаговано';
    const isViewMode = isViewModal || curMode === 'view';

    const controlButtons = (
      <GeneralControlButtons
        form={form}
        guid={this.curGuid}
        handleLockDocument={this.handleLockDocumentModal}
        documentType="DOCUMENT_PASSPORT"
      />
    );

    return (
      <Row>
        <Modal
          title="Паспортний документ"
          visible={this.state.dialogOpen}
          onOk={this.handleCreateNew}
          onCancel={this.handleDialogCancel}
          cancelText="Переглянути документ"
          okText="Створити новий"
        >
          {dialogMessage === '' ? (
            <p>{`Картку успішно ${dialogText}`}</p>
          ) : (
            <p>{`${dialogMessage}`}</p>
          )}
        </Modal>
        <Modal
          title="Блокування документа"
          visible={this.state.lockDocumentModalIsOpen}
          onCancel={this.handleLockDocumentModal}
          footer={null}
          width="1000px"
          maskClosable={false}
          destroyOnClose
        >
          <LockDocumentModal
            handleCloseModal={this.handleLockDocumentModal}
            childrenDocuments={formParam.createdForm.childrenDocuments}
            guid={this.curGuid}
            versionId={_get(formParam, ['createdForm', 'versionId'], this.curVersionId)}
            updateForm={lockDocToPassportDocument}
            loadDocument={() => this.props.getPassportDocument(this.curGuid, this.props.storeKey)}
          />
        </Modal>
        <h1 key="formLabel">{this.getFormTypeLabel()}</h1>
        <GeneralTabsContainer
          ownerSide={{
            guid: this.curGuid,
            versionId: _get(formParam, ['createdForm', 'versionId'], this.curVersionId),
          }}
          editAction={this.handleSubmit}
          controlButtons={controlButtons}
          bindDocAction={bindDocToPassportDocument}
          isViewModal={isViewModal}
          createdForm={formParam.createdForm}
        >
          <TabPane tab="Основна інформація" key="0">
            <Row>
              {!isViewModal && controlButtons}
              <Row>
                <Form>
                  <Row>
                    <Separator text="Основна інформація" />
                    {mapFormItems({
                      viewMode: curMode,
                      fields: generalFields,
                      classifiers,
                      isViewMode,
                      form: this.props.form,
                    })}
                  </Row>
                  <Row>
                    <Separator text="Паспортний документ громадянина" />
                    {mapFormItems({
                      viewMode: curMode,
                      fields: passportFields,
                      classifiers,
                      isViewMode,
                      form: this.props.form,
                    })}
                  </Row>
                  <Row type="flex" justify="end">
                    <Button
                      style={{ marginRight: '1.5rem' }}
                      type="primary"
                      onClick={this.handleSubmit}
                      disabled={isViewMode}
                    >
                      Відправити
                    </Button>
                  </Row>
                </Form>
              </Row>
            </Row>
          </TabPane>
        </GeneralTabsContainer>
      </Row>
    );
  }
}

PassportFormContainer.defaultProps = {
  isViewModal: false,
  modalData: {},
  formParam: {
    createdForm: {},
    status: {},
  },
  storeKey: defaultStoreKey,
};

PassportFormContainer.propTypes = {
  loadClassifiersForContainer: PropTypes.func.isRequired,
  history: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
  match: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,

  postPassportDocument: PropTypes.func.isRequired,
  putPassportDocument: PropTypes.func.isRequired,
  getPassportDocument: PropTypes.func.isRequired,

  setFileTable: PropTypes.func.isRequired,

  classifiers: PropTypes.objectOf(PropTypes.array).isRequired,
  formTypeData: PropTypes.objectOf(PropTypes.any).isRequired,
  // TODO: check work with files
  resetPassportDocumentForm: PropTypes.func.isRequired,
  resetPassportDocumentDoneStatus: PropTypes.func.isRequired,
  formParam: PropTypes.objectOf(PropTypes.any),

  form: PropTypes.objectOf(PropTypes.any).isRequired,
  isViewModal: PropTypes.bool,
  modalData: PropTypes.objectOf(PropTypes.string),
  storeKey: PropTypes.string,
  lockDocToPassportDocument: PropTypes.func.isRequired,
  bindDocToPassportDocument: PropTypes.func.isRequired,
};

const mapStateToProps = (state, props) => ({
  classifiers: state.classifiers,
  formTypeData:
    state.documentForms.documentCascader.selectedValue[props.storeKey || defaultStoreKey].data, // eslint-disable-line
  formParam: state.documentForms.passportDocument.forms[props.storeKey || defaultStoreKey],
});

export default withRouter(
  connect(mapStateToProps, PASSPORT_DOCUMENT_ACTIONS)(Form.create()(PassportFormContainer)),
);
