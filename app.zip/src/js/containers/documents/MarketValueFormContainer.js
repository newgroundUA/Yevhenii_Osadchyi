import React from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import PropTypes from 'prop-types';
import debounce from 'lodash/debounce';

import { Form, Modal, Button, Row, Tabs } from 'antd';

import _get from 'lodash/get';
import _remove from 'lodash/remove';

import * as classifiersActions from '../../actions/classifiersActions';
import * as marketValueDocumentActions from '../../actions/modules/documents/marketValueDocumentActions';
import * as commonActions from '../../actions';
import * as fileActions from '../../actions/modules/documents/fileTableActions';
import * as leaseActions from '../../actions/modules/lease/objectsRegisters';
import * as privatizationActions from '../../actions/modules/privatisation/privatisationRegisterActions';

import { mapFormItems } from '../../helpers/formHelpers/mapFormHelper';
import FormTable from '../../components/common/form/Table';

import { generalFields } from '../../models/formFields/documents/generalFields';

import {
  parseAcountingItemWithMarketPriceListToFE,
  parseAcountingItemWithMarketPriceListToBE,
  marketValueOOMTableFields,
  marketValueInformationFields,
  getParsedForm,
  getMappedForm,
  getLeaseObjectName,
  getPrivatizationObjectName,
} from '../../models/formFields/documents/marketValueFields';

import GeneralControlButtons from './common/GeneralControlButtons';
import GeneralTabsContainer from './common/GeneralTabsContainer';
import LockDocumentModal from './common/modals/LockDocumentModal';

import { MARKET_VALUE_FORM_CONTAINER } from '../../constants/ContainerNames';
import {
  WEBSITELIST,
  REF_DOCUMENT_TYPE_GENERAL_DOC_CLASSNAME,
} from '../../constants/ClassifiersNames';

import Separator from '../../components/common/form/Separator';
import * as RouteNames from '../../constants/RouteNames';

import FileTable from './FileTable';
import {
  failedValidationNotification,
  getFormEntityData,
} from '../../helpers/formHelpers/formHelpers';
import { getObjGuidAndVersionId } from '../../helpers/commonUtils';
import { defStoreKey } from '../../helpers/reducers/documents/commonActionsHandlers';
import * as landlordToObjectActions from '../../actions/modules/lease/landlordToObjectActions';
import { goToRegistry } from '../../helpers/entities/registry';
import * as privatisationFormActions from '../../actions/modules/privatisation/privatisationFormActions';
import {
  LEASE_OBJECTS,
  PRIVATIZATION_OBJECTS,
} from '../../constants/actionTypes/documents/DocumentsConstants';
// import { getGroupOfPremise } from '../../actions/modules/accountingItem/groupOfPremise';

const MARKET_VALUE_DOCUMENT_ACTIONS = {
  ...classifiersActions,
  ...marketValueDocumentActions,
  ...commonActions,
  ...fileActions,
  ...leaseActions, // getLeaseObjectsRegister
  ...privatizationActions, // getPrivatizationRegister
  getLeaseObjectsLiveSearch: landlordToObjectActions.getLeaseObjectsLiveSearch,
  getPrivatizationObjectsLiveSearch: privatisationFormActions.getPrivatizationObjectsLiveSearch,
};

const TabPane = Tabs.TabPane;

class MarketValueFormContainer extends React.Component {
  constructor(props) {
    super(props);
    const curMode = this.props.match.params.mode || 'create';
    this.curGuid = this.props.match.params.guid || '';

    this.state = {
      curMode,
      dialogOpen: false,
      dialogMessage: '',
      lockDocumentModalIsOpen: false,
      assessObject: [],
      selectedGroupedObjectsType: LEASE_OBJECTS,
    };

    this.loaded = false;

    this.fetchAssessmentObjects = debounce(this.fetchAssessmentObjects.bind(this), 800);
  }

  componentWillMount() {
    const { history } = this.props;
    if (this.state.curMode === 'create' && !this.getFormType()) {
      goToRegistry({
        name: 'documents',
        history,
      });
    }
  }

  componentDidMount = () => {
    const { getMarketValueDocument, isViewModal, modalData, storeKey } = this.props;
    const { curMode } = this.state;

    this.props.loadClassifiersForContainer(MARKET_VALUE_FORM_CONTAINER, {
      [WEBSITELIST]: { webSiteRegistryParam: { offset: '0', limit: '100' } },
      [REF_DOCUMENT_TYPE_GENERAL_DOC_CLASSNAME]: { generalDocClassName: 'MarketPriceDetect' },
    });

    if (isViewModal) {
      this.setState({ curMode: 'view' });
      getMarketValueDocument(modalData.guid, storeKey);
    } else if (curMode === 'view' || curMode === 'edit') {
      getMarketValueDocument(this.curGuid, storeKey);
    }
  };

  fetchAssessmentObjects(value) {
    const { getLeaseObjectsLiveSearch, getPrivatizationObjectsLiveSearch } = this.props;
    const { selectedGroupedObjectsType } = this.state;

    if (selectedGroupedObjectsType === LEASE_OBJECTS) {
      return getLeaseObjectsLiveSearch({ predicate: value }).then((res) =>
        this.setState(() => ({
          assessObject: res ? this.mapObjectsToLiveSearch(res.data.content) : [],
        })),
      );
    }
    if (selectedGroupedObjectsType === PRIVATIZATION_OBJECTS) {
      return getPrivatizationObjectsLiveSearch({ predicate: value }).then((res) =>
        this.setState(() => ({
          assessObject: res ? this.mapObjectsToLiveSearch(res.data.content) : [],
        })),
      );
    }
  }

  mapObjectsToLiveSearch = (content) => {
    const { selectedGroupedObjectsType } = this.state;

    if (selectedGroupedObjectsType === LEASE_OBJECTS) {
      return content.map((obj) => ({
        name: getLeaseObjectName(obj),
        guid: obj.guid,
        versionId: obj.versionId,
      }));
    }

    if (selectedGroupedObjectsType === PRIVATIZATION_OBJECTS) {
      return content.map((obj) => ({
        name: getPrivatizationObjectName(obj),
        guid: obj.guid,
        versionId: obj.versionId,
      }));
    }
  };

  componentWillReceiveProps(nextProps) {
    const {
      formParam: { createdForm, status, errors },
      match: {
        params: { mode },
      },
      resetMarketValueDocumentForm,
      resetMarketValueDocumentDoneStatus,
      form,
      storeKey,
      isViewModal,
      setFileTable,
    } = nextProps;

    if (isViewModal && isViewModal !== this.props.isViewModal) {
      this.setState({ curMode: 'view' });
    } else if (this.state.curMode !== mode) {
      this.setState({ curMode: mode });
    }

    if (
      (createdForm.versionId || createdForm.versionId === 0) &&
      this.props.formParam.createdForm.versionId !== createdForm.versionId
    ) {
      form.setFieldsValue(getParsedForm(createdForm));
    } else if (createdForm.guid && (mode === 'view' || mode === 'edit') && !this.loaded) {
      this.loaded = true;
      form.setFieldsValue(getParsedForm(createdForm));
      setFileTable(createdForm.fileStorage);
    }

    if (this.state.curMode !== mode && mode === 'create') {
      form.resetFields();
      resetMarketValueDocumentForm(storeKey);
    }

    if (status.isDone) {
      this.loaded = true;
      this.curGuid = createdForm.guid;
      this.curVersionId = createdForm.versionId;
      this.handleToggleDialog();
      resetMarketValueDocumentDoneStatus(storeKey);
    }

    if (errors.length > 0) {
      const errorsText = errors.map((el) => el.message).join(', ');
      this.setState({ dialogMessage: errorsText, dialogOpen: true });
      resetMarketValueDocumentForm(storeKey);
    }
  }

  componentWillUnmount() {
    this.props.resetMarketValueDocumentForm(this.props.storeKey);
  }

  handleCreateNew = () => {
    this.changeRouteTo(`/${RouteNames.DOCUMENTS}/${RouteNames.DOCUMENT_MARKET}/create`);
    this.curGuid = '';
    this.loaded = false;
    this.props.form.resetFields();
    this.props.resetMarketValueDocumentForm(this.props.storeKey);
    this.handleToggleDialog();
  };

  clearForm = () => {
    this.props.form.resetFields();
  };

  changeRouteTo = (route) => {
    this.props.history.push(route);
  };

  handleToggleDialog = (isOpened) => {
    if (isOpened !== undefined) this.setState({ dialogOpen: isOpened });
    else this.setState((prevState) => ({ dialogOpen: !prevState.dialogOpen }));
  };

  handleDialogCancel = () => {
    this.handleToggleDialog();
    this.switchToViewMode();
  };

  switchToEditMode = () => {
    this.changeRouteTo(
      `/${RouteNames.DOCUMENTS}/${RouteNames.DOCUMENT_MARKET}/edit/${this.curGuid}`,
    );
  };

  switchToViewMode = () => {
    this.changeRouteTo(
      `/${RouteNames.DOCUMENTS}/${RouteNames.DOCUMENT_MARKET}/view/${this.curGuid}`,
    );
  };

  handleSubmitAccountingItemWithMarketPrice = ({ obj }) => {
    const { storeKey } = this.props;
    const post = {
      ...parseAcountingItemWithMarketPriceListToBE(obj),
      marketPriceDetect: {
        guid: this.curGuid,
        versionId: _get(this.props.formParam.createdForm, 'versionId', this.curVersionId),
      },
    };

    const put = {
      ...obj.beObj,
      ...post,
    };

    if (!put.guid) {
      this.props.postAccountingItemWithMarketPrice(post, storeKey).then((res) => {
        if (res.statusCode === 200) {
          this.props.getMarketValueDocument(this.curGuid, storeKey);
        }
      });
    } else {
      this.props.putAccountingItemWithMarketPrice(put, storeKey).then((res) => {
        if (res.statusCode === 200) {
          this.props.getMarketValueDocument(this.curGuid, storeKey);
        }
      });
    }
  };

  handleDeleteAccountingItemWithMarketPrice = (guid) => {
    this.props.deleteAccountingItemWithMarketPrice(guid, this.props.storeKey).then((res) => {
      if (res.statusCode === 200) {
        this.props.getMarketValueDocument(this.curGuid, this.props.storeKey);
      }
    });
  };

  handleSubmit = ({ ignoreStatus, file = {}, delDoc = {}, delFileGuid = '' }) => {
    const { curMode } = this.state;
    const {
      putMarketValueDocument,
      postMarketValueDocument,
      form,
      formParam: { createdForm },
      storeKey,
      classifiers,
      postAccountingItemWithMarketPrice,
    } = this.props;

    const fields = {
      ...generalFields,
      ...marketValueInformationFields,
    };
    const curFields = [...Object.keys(generalFields), ...Object.keys(marketValueInformationFields)];

    form.validateFields(curFields, (err, values) => {
      if (!err) {
        const normilizedValues = getFormEntityData(values, classifiers, fields);
        const assessObject = this.state.assessObject.find(
          (ao) => ao.guid === normilizedValues.assessObject.key,
        );

        if (curMode === 'create') {
          postMarketValueDocument(
            {
              ...getMappedForm(normilizedValues),
              refDocumentType: this.getFormTypeData(),
              documentType: 'MarketPriceDetect',
              assessObject: {
                guid: assessObject.guid,
                versionId: assessObject.versionId,
                groupedObjectsType: this.state.selectedGroupedObjectsType,
              },
            },
            storeKey,
          )
            // TODO WTF: далее гавнокод, который нужно будет переписать
            .then((res) => {
              if (res.statusCode === 200) {
                const createdMarketValueDocument = res.data;
                const assessObjectId =
                  createdMarketValueDocument && createdMarketValueDocument.assessObjectGuid;

                if (assessObjectId) {
                  const assessObjectData = (this.state.assessObject || []).find(
                    (item) => item && item.guid === assessObjectId,
                  );

                  const accountingItems = assessObjectData && assessObjectData.accountingItems;
                  if (accountingItems) {
                    const postAccountingItemsWithMarketPriceActions = [];
                    const mostEffectiveUseGuid =
                      classifiers.leaseRateDirectory &&
                      classifiers.leaseRateDirectory[0] &&
                      classifiers.leaseRateDirectory[0].guid;

                    accountingItems.forEach((accountingItem) => {
                      const dataToSave = {
                        marketPriceDetectGuid: createdMarketValueDocument.guid,
                        accountingItem: { guid: accountingItem.guid },
                        accountingItemMarketPrice: 0,
                        accountItemMarketPriceForOneSqm: 0,
                        mostEffectiveUse: { guid: mostEffectiveUseGuid },
                        notes: '',
                      };
                      postAccountingItemsWithMarketPriceActions.push(
                        postAccountingItemWithMarketPrice(dataToSave),
                      );
                    });
                    Promise.all(postAccountingItemsWithMarketPriceActions).then(() => {
                      this.props.getMarketValueDocument(this.curGuid);
                    });
                  }
                }
              }
            });
        }

        if (curMode === 'edit') {
          const files = file.guid ? [...createdForm.fileStorage, file] : createdForm.fileStorage;

          if (delFileGuid) {
            _remove(files, (el) => el.guid === delFileGuid);
          }

          if (delDoc.guid) {
            if (Array.isArray(createdForm[delDoc.field])) {
              _remove(createdForm[delDoc.field], (el) => el.guid === delDoc.guid);
            } else {
              createdForm[delDoc.field] = undefined;
            }
          }

          putMarketValueDocument(
            {
              ...createdForm,
              ...getMappedForm(normilizedValues),
              accountItemWithMarketPrices: createdForm.accountItemWithMarketPrices,
              fileStorage: getObjGuidAndVersionId(files),
              linkedDocuments: getObjGuidAndVersionId(createdForm.linkedDocuments),
              parentDocument: getObjGuidAndVersionId(createdForm.parentDocument),
              childrenDocuments: getObjGuidAndVersionId(createdForm.childrenDocuments),
              guid: this.curGuid,
              versionId: _get(createdForm, 'versionId', this.curVersionId),
            },
            storeKey,
            ignoreStatus,
          );
        }
      } else {
        failedValidationNotification(err, fields);
      }
    });
  };

  getFormType = () => {
    const {
      formTypeData,
      classifiers,
      formParam: {
        createdForm: { refDocumentType },
      },
    } = this.props;

    const documentTypeField = classifiers.refDocumentTypeGeneralDocClassName.find(
      (el) => el.guid === (refDocumentType || {}).guid,
    );

    if (documentTypeField) {
      return documentTypeField;
    }
    return formTypeData;
  };

  getFormTypeData = () => {
    const { guid, versionId, type } = this.getFormType();
    return {
      guid,
      versionId,
      type,
    };
  };

  getFormTypeLabel = () => {
    const obj = this.getFormType();
    return obj && `${obj.scopeOfApplication}/${obj.docCategory}/${obj.name}`;
  };

  handleLockDocumentModal = () => {
    this.setState((prevState) => ({
      lockDocumentModalIsOpen: !prevState.lockDocumentModalIsOpen,
    }));
  };

  setObjectTypeData(event) {
    const { value: groupedObjectsType } = event.target;
    if (groupedObjectsType === 'PrivatizationObjects') {
      this.setState({ selectedGroupedObjectsType: PRIVATIZATION_OBJECTS });
    }
    if (groupedObjectsType === 'LeaseObjects') {
      this.setState({ selectedGroupedObjectsType: LEASE_OBJECTS });
    }

    this.props.form.resetFields(['assessObject']);

    this.setState(() => ({ assessObject: [] }));
  }

  getMarketValueInformationFields = () => ({
    ...marketValueInformationFields,
    groupedObjectsType: {
      ...marketValueInformationFields.groupedObjectsType,
      onChange: this.setObjectTypeData.bind(this),
    },
    assessObject: {
      ...marketValueInformationFields.assessObject,
      search: {
        handler: (value) => value.length >= 2 && this.fetchAssessmentObjects(value),
        result: this.props.formParam.createdForm.assessObject
          ? this.mapObjectsToLiveSearch([this.props.formParam.createdForm.assessObject])
          : this.state.assessObject,
      },
    },
  });

  render() {
    const { curMode, dialogMessage } = this.state;

    const {
      formParam: { createdForm },
      formParam,
      form: { getFieldDecorator },
      isViewModal,
      storeKey,
      form,
      bindDocToMarketValueDocument,
      lockDocToMarketValueDocument,
      classifiers,
    } = this.props;

    const dialogText = curMode === 'create' ? 'створено' : 'відредаговано';
    const isViewMode = isViewModal || curMode === 'view';

    const controlButtons = (
      <GeneralControlButtons
        form={form}
        guid={this.curGuid}
        handleLockDocument={this.handleLockDocumentModal}
        documentType="DOCUMENT_MARKET"
      />
    );

    return (
      <Row>
        <Modal
          title="Документ"
          visible={this.state.dialogOpen}
          onOk={this.handleCreateNew}
          onCancel={this.handleDialogCancel}
          cancelText="Переглянути картку"
          okText="Створити нову"
        >
          {dialogMessage === '' ? (
            <p>{`Картку успішно ${dialogText}`}</p>
          ) : (
            <p>{`${dialogMessage}`}</p>
          )}
        </Modal>
        <Modal
          title="Блокування документа"
          visible={this.state.lockDocumentModalIsOpen}
          onCancel={this.handleLockDocumentModal}
          footer={null}
          width="1000px"
          maskClosable={false}
          destroyOnClose
        >
          <LockDocumentModal
            handleCloseModal={this.handleLockDocumentModal}
            childrenDocuments={formParam.createdForm.childrenDocuments}
            guid={this.curGuid}
            versionId={_get(formParam, ['createdForm', 'versionId'], this.curVersionId)}
            updateForm={lockDocToMarketValueDocument}
            loadDocument={() =>
              this.props.getMarketValueDocument(this.curGuid, this.props.storeKey)
            }
          />
        </Modal>
        <h1 key="formLabel">{this.getFormTypeLabel()}</h1>
        <GeneralTabsContainer
          ownerSide={{
            guid: this.curGuid,
            versionId: _get(formParam[storeKey], ['createdForm', 'versionId'], this.curVersionId),
          }}
          editAction={this.handleSubmit}
          controlButtons={controlButtons}
          bindDocAction={bindDocToMarketValueDocument}
          isViewModal={isViewModal}
          createdForm={formParam.createdForm}
        >
          <TabPane tab="Форма загального документа" key="0">
            <Row>
              {!isViewModal && controlButtons}
              <Row>
                <Row>
                  <Row>
                    <Separator text="Основна інформація" />
                    {mapFormItems({
                      viewMode: getFieldDecorator,
                      fields: generalFields,
                      classifiers,
                      isViewMode,
                      form: this.props.form,
                    })}
                  </Row>
                  {curMode !== 'create' ? (
                    <Row>
                      <Separator text="Файли" />
                      <FileTable curMode={curMode} />
                    </Row>
                  ) : (
                    ''
                  )}
                  <Row>
                    <Separator text="Визначення оціночної вартості" />
                    {mapFormItems({
                      viewMode: getFieldDecorator,
                      fields: this.getMarketValueInformationFields(),
                      classifiers,
                      isViewMode,
                      form: this.props.form,
                    })}
                  </Row>
                  {curMode !== 'create' ? (
                    <Row>
                      <Separator text="Перелік ООМ для з визначеною справедливою вартістю" />
                      <FormTable
                        classifiers={classifiers}
                        fields={marketValueOOMTableFields}
                        parserToFE={parseAcountingItemWithMarketPriceListToFE}
                        rows={(createdForm || {}).accountItemWithMarketPrices || []}
                        form={this.props.form}
                        isViewMode={isViewMode}
                        viewMode={curMode}
                        onSave={this.handleSubmitAccountingItemWithMarketPrice}
                        onDelete={this.handleDeleteAccountingItemWithMarketPrice}
                      />
                    </Row>
                  ) : (
                    ''
                  )}

                  <Row type="flex" justify="end">
                    <Button
                      style={{ marginRight: '1.5rem' }}
                      type="primary"
                      onClick={this.handleSubmit}
                      disabled={isViewMode}
                    >
                      {`Відправити`}
                    </Button>
                  </Row>
                </Row>
              </Row>
            </Row>
          </TabPane>
        </GeneralTabsContainer>
      </Row>
    );
  }
}

MarketValueFormContainer.defaultProps = {
  isViewModal: false,
  modalData: {},
  formParam: {
    createdForm: {},
    status: {},
  },
  storeKey: defStoreKey,
};

MarketValueFormContainer.propTypes = {
  loadClassifiersForContainer: PropTypes.func.isRequired,
  history: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
  match: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,

  postMarketValueDocument: PropTypes.func.isRequired,
  putMarketValueDocument: PropTypes.func.isRequired,
  getMarketValueDocument: PropTypes.func.isRequired,

  getLeaseObjectsLiveSearch: PropTypes.func.isRequired,
  getPrivatizationObjectsLiveSearch: PropTypes.func.isRequired,

  postAccountingItemWithMarketPrice: PropTypes.func.isRequired,
  putAccountingItemWithMarketPrice: PropTypes.func.isRequired,
  deleteAccountingItemWithMarketPrice: PropTypes.func.isRequired,

  setFileTable: PropTypes.func.isRequired,

  storeKey: PropTypes.string,
  classifiers: PropTypes.objectOf(PropTypes.array).isRequired,
  formTypeData: PropTypes.objectOf(PropTypes.any).isRequired,
  resetMarketValueDocumentForm: PropTypes.func.isRequired,
  resetMarketValueDocumentDoneStatus: PropTypes.func.isRequired,
  // getGroupOfPremise: PropTypes.func.isRequired,
  formParam: PropTypes.objectOf(PropTypes.any),

  form: PropTypes.objectOf(PropTypes.any).isRequired,

  bindDocToMarketValueDocument: PropTypes.func.isRequired,
  lockDocToMarketValueDocument: PropTypes.func.isRequired,

  isViewModal: PropTypes.bool,
  modalData: PropTypes.objectOf(PropTypes.string),
};

const mapStateToProps = (state, { storeKey }) => ({
  classifiers: state.classifiers,
  formTypeData: state.documentForms.documentCascader.selectedValue[storeKey || defStoreKey].data, // eslint-disable-line
  formParam: state.documentForms.marketValueDocument.forms[storeKey || defStoreKey],
});

export default withRouter(
  connect(mapStateToProps, MARKET_VALUE_DOCUMENT_ACTIONS)(Form.create()(MarketValueFormContainer)),
);
