import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import update from 'immutability-helper';
import { Form, Modal, Button, Row, Tabs } from 'antd';
import { withRouter } from 'react-router-dom';

import _get from 'lodash/get';
import _remove from 'lodash/remove';

import * as documentsActions from '../../actions/modules/documents/documentsActions';
import * as classifiersActions from '../../actions/classifiersActions';
import * as contestsActions from '../../actions/modules/documents/contestsActions';

import * as RouteNames from '../../constants/RouteNames';

import { CONTESTS_FORM_CONTAINER } from '../../constants/ContainerNames';
import {
  WEBSITELIST,
  REF_DOCUMENT_TYPE_GENERAL_DOC_CLASSNAME,
} from '../../constants/ClassifiersNames';

import { mapFormItems } from '../../helpers/formHelpers/mapFormHelper';
import { generalFields } from '../../models/formFields/documents/generalFields';
import {
  contestsFields,
  contestsTableFields,
  parseContestMembers,
  mapContestMembers,
  getParsedForm,
  getMappedForm,
} from '../../models/formFields/documents/contestsFields';

import FormTable from '../../components/common/form/Table';
import Separator from '../../components/common/form/Separator';
import {
  failedValidationNotification,
  getFormEntityData,
} from '../../helpers/formHelpers/formHelpers';
import GeneralTabsContainer from './common/GeneralTabsContainer';
import GeneralControlButtons from './common/GeneralControlButtons';
import LockDocumentModal from './common/modals/LockDocumentModal';
import { getObjGuidAndVersionId } from '../../helpers/commonUtils';
import { defStoreKey } from '../../helpers/reducers/documents/commonActionsHandlers';
import { goToRegistry } from '../../helpers/entities/registry';

const TabPane = Tabs.TabPane;

class ContestsFormContariner extends React.Component {
  constructor(props) {
    super(props);

    const curMode = this.props.match.params.mode || 'create';
    this.curGuid = this.props.match.params.guid || '';

    this.state = {
      curMode,
      dialogOpen: false,
      lockDocumentModalIsOpen: false,
      dialogMessage: '',
    };

    this.loaded = false;
  }

  componentWillMount() {
    const { history } = this.props;
    if (this.state.curMode === 'create' && !this.getFormType()) {
      goToRegistry({
        name: 'documents',
        history,
      });
    }
  }

  componentDidMount = () => {
    const { getContests, isViewModal, modalData, storeKey } = this.props;
    const { curMode } = this.state;

    this.props.loadClassifiersForContainer(CONTESTS_FORM_CONTAINER, {
      [WEBSITELIST]: {
        webSiteRegistryParam: {
          limit: '100',
          offset: '0',
        },
      },
      [REF_DOCUMENT_TYPE_GENERAL_DOC_CLASSNAME]: {
        generalDocClassName: 'CompetitionProtocol',
      },
    });

    if (isViewModal) {
      this.setState({ curMode: 'view' });
      getContests(modalData.guid, storeKey);
    } else if (!isViewModal && (curMode === 'view' || curMode === 'edit')) {
      getContests(this.curGuid, storeKey);
    }
  };

  componentWillReceiveProps(nextProps) {
    const {
      formParam,
      storeKey,
      isViewModal,
      match: {
        params: { mode },
      },
      resetContestsForm,
      resetContestsDoneStatus,
      form,
    } = nextProps;

    const { createdForm, status, errors } = formParam;

    if (isViewModal && isViewModal !== this.props.isViewModal) {
      this.setState({ curMode: 'view' });
    } else if (this.state.curMode !== mode) this.setState({ curMode: mode });

    if (
      (createdForm.versionId || createdForm.versionId === 0) &&
      this.props.formParam.createdForm.versionId !== createdForm.versionId
    ) {
      form.setFieldsValue(getParsedForm(createdForm));
    } else if (createdForm.guid && (mode === 'view' || mode === 'edit') && !this.loaded) {
      this.loaded = true;
      form.setFieldsValue(getParsedForm(createdForm));
    }

    if (this.state.curMode !== mode && mode === 'create') {
      form.resetFields();
      resetContestsForm(storeKey);
    }

    if (status.isDone) {
      this.loaded = true;
      this.curGuid = createdForm.guid;
      this.curVersionId = createdForm.versionId;
      this.handleToggleDialog();
      resetContestsDoneStatus(storeKey);
    }

    if (errors.length > 0) {
      const errorsText = errors.map((el) => el.message).join(', ');
      this.setState({ dialogMessage: errorsText, dialogOpen: true });
      resetContestsForm(storeKey);
    }
  }

  componentWillUnmount() {
    this.props.resetContestsForm(this.props.storeKey);
  }

  handleCreateNew = () => {
    this.changeRouteTo(`/${RouteNames.DOCUMENTS}/${RouteNames.DOCUMENT_CONTESTS}/create`);
    this.curGuid = '';
    this.loaded = false;
    this.props.form.resetFields();
    this.props.resetContestsForm(this.props.storeKey);
    this.handleToggleDialog();
  };

  clearForm = () => {
    this.props.form.resetFields();
  };

  changeRouteTo = (route) => {
    this.props.history.push(route);
  };

  handleToggleDialog = (isOpened) => {
    if (isOpened !== undefined) this.setState({ dialogOpen: isOpened });
    else this.setState((prevState) => ({ dialogOpen: !prevState.dialogOpen }));
  };

  handleDialogCancel = () => {
    this.handleToggleDialog();
    this.switchToViewMode();
  };

  switchToEditMode = () => {
    this.changeRouteTo(
      `/${RouteNames.DOCUMENTS}/${RouteNames.DOCUMENT_CONTESTS}/edit/${this.curGuid}`,
    );
  };

  switchToViewMode = () => {
    this.changeRouteTo(
      `/${RouteNames.DOCUMENTS}/${RouteNames.DOCUMENT_CONTESTS}/view/${this.curGuid}`,
    );
  };

  handleLockDocumentModal = () => {
    this.setState((prevState) => ({
      lockDocumentModalIsOpen: !prevState.lockDocumentModalIsOpen,
    }));
  };

  handleSubmit = ({ ignoreStatus, file = {}, delFileGuid = '', delDoc = {} }) => {
    const { curMode } = this.state;
    const {
      formParam: { createdForm },
      storeKey,
      putContests,
      postContests,
      classifiers,
      form,
    } = this.props;

    const fields = {
      ...generalFields,
      ...contestsFields,
    };

    const curFields = [...Object.keys(generalFields), ...Object.keys(contestsFields)];

    form.validateFields(curFields, (err, values) => {
      if (!err) {
        let classifiersPlus = classifiers;
        if (
          curMode !== 'create' &&
          (createdForm.leaseCompetition || {}).guid &&
          !classifiers.leaseUnusedCompetitions.find(
            (el) => createdForm.leaseCompetition.guid === el.guid,
          )
        ) {
          classifiersPlus = update(classifiers, {
            leaseUnusedCompetitions: {
              $set: [...classifiers.leaseUnusedCompetitions, createdForm.leaseCompetition],
            },
          });
        }
        const normilizedValues = getFormEntityData(values, classifiersPlus, fields);

        if (curMode === 'create') {
          postContests(
            {
              ...getMappedForm(normilizedValues),
              refDocumentType: this.getFormTypeData(),
              documentType: 'CompetitionProtocol',
            },
            storeKey,
          );
        }

        if (curMode === 'edit') {
          const files = file.guid ? [...createdForm.fileStorage, file] : createdForm.fileStorage;

          if (delFileGuid) {
            _remove(files, (el) => el.guid === delFileGuid);
          }

          if (delDoc.guid) {
            if (Array.isArray(createdForm[delDoc.field])) {
              _remove(createdForm[delDoc.field], (el) => el.guid === delDoc.guid);
            } else {
              createdForm[delDoc.field] = undefined;
            }
          }

          putContests(
            {
              ...createdForm,
              ...getMappedForm(normilizedValues),
              compMembersList: createdForm.compMembersList,
              linkedDocuments: getObjGuidAndVersionId(createdForm.linkedDocuments),
              parentDocument: getObjGuidAndVersionId(createdForm.parentDocument),
              childrenDocuments: getObjGuidAndVersionId(createdForm.childrenDocuments),
              fileStorage: getObjGuidAndVersionId(files),
              guid: this.curGuid,
              versionId: _get(createdForm, 'versionId', this.curVersionId),
            },
            storeKey,
            ignoreStatus,
          );
        }
      } else {
        failedValidationNotification(err, fields);
      }
    });
  };

  handleSubmitContestMemeber = ({ obj }) => {
    const {
      postContestMember,
      putContestMember,
      getContests,
      formParam: { createdForm },
      storeKey,
    } = this.props;
    const post = {
      ...mapContestMembers(obj),
      protocol: {
        guid: this.curGuid,
        versionId: _get(createdForm, 'versionId', this.curVersionId),
      },
    };

    const put = {
      ...obj.beObj,
      ...post,
    };

    if (!put.guid) {
      postContestMember(post, storeKey).then((res) => {
        if (res.statusCode === 200) {
          getContests(this.curGuid, storeKey);
        }
      });
    } else {
      putContestMember(put, storeKey).then((res) => {
        if (res.statusCode === 200) {
          getContests(this.curGuid, storeKey);
        }
      });
    }
  };

  getFormType = () => {
    const {
      formTypeData,
      classifiers,
      formParam: {
        createdForm: { refDocumentType },
      },
    } = this.props;

    const documentTypeField = classifiers.refDocumentTypeGeneralDocClassName.find(
      (el) => el.guid === (refDocumentType || {}).guid,
    );

    if (documentTypeField) {
      return documentTypeField;
    }
    return formTypeData;
  };

  getFormTypeData = () => {
    const { guid, versionId, type } = this.getFormType();
    return {
      guid,
      versionId,
      type,
    };
  };

  getFormTypeLabel = () => {
    const obj = this.getFormType();
    return obj && `${obj.scopeOfApplication}/${obj.docCategory}/${obj.name}`;
  };

  render() {
    const { curMode, dialogMessage } = this.state;

    const {
      classifiers,
      form,
      formParam,
      bindDocToContestsDocument,
      lockDocToContestsDocument,
      isViewModal,
    } = this.props;

    let classifiersPlus = classifiers;
    if (
      curMode !== 'create' &&
      (formParam.createdForm.leaseCompetition || {}).guid &&
      !classifiers.leaseUnusedCompetitions.find(
        (el) => formParam.createdForm.leaseCompetition.guid === el.guid,
      )
    ) {
      classifiersPlus = update(classifiers, {
        leaseUnusedCompetitions: {
          $set: [...classifiers.leaseUnusedCompetitions, formParam.createdForm.leaseCompetition],
        },
      });
    }

    const dialogText = curMode === 'create' ? 'створено' : 'відредаговано';
    const isViewMode = isViewModal || curMode === 'view';

    const controlButtons = (
      <GeneralControlButtons
        form={form}
        guid={this.curGuid}
        handleLockDocument={this.handleLockDocumentModal}
        documentType="DOCUMENT_CONTESTS"
      />
    );

    return (
      <Row>
        <Modal
          title="Документ"
          visible={this.state.dialogOpen}
          onOk={this.handleCreateNew}
          onCancel={this.handleDialogCancel}
          cancelText="Переглянути"
          okText="Створити новий"
        >
          {dialogMessage === '' ? (
            <p>{`Документ успішно ${dialogText}`}</p>
          ) : (
            <p>{`${dialogMessage}`}</p>
          )}
        </Modal>
        <Modal
          title="Блокування документа"
          visible={this.state.lockDocumentModalIsOpen}
          onCancel={this.handleLockDocumentModal}
          footer={null}
          width="1000px"
          maskClosable={false}
          destroyOnClose
        >
          <LockDocumentModal
            handleCloseModal={this.handleLockDocumentModal}
            childrenDocuments={formParam.createdForm.childrenDocuments}
            guid={this.curGuid}
            versionId={_get(formParam, ['createdForm', 'versionId'], this.curVersionId)}
            updateForm={lockDocToContestsDocument}
            loadDocument={() => this.props.getContests(this.curGuid, this.props.storeKey)}
          />
        </Modal>
        <h1 key="formLabel">{this.getFormTypeLabel()}</h1>
        <GeneralTabsContainer
          ownerSide={{
            guid: this.curGuid,
            versionId: _get(formParam, ['createdForm', 'versionId'], this.curVersionId),
          }}
          editAction={this.handleSubmit}
          controlButtons={controlButtons}
          bindDocAction={bindDocToContestsDocument}
          isViewModal={isViewModal}
          createdForm={formParam.createdForm}
        >
          <TabPane tab="Основна інформація" key="0">
            <Row>
              {!isViewModal && controlButtons}
              <Row>
                <Form>
                  <Row>
                    <Separator text="Основна інформація" />
                    {mapFormItems({
                      viewMode: curMode,
                      fields: generalFields,
                      classifiers,
                      isViewMode,
                      form: this.props.form,
                    })}
                  </Row>
                  <Row>
                    <Separator text="Протокол визначення переможця конкурсу" />
                    {mapFormItems({
                      viewMode: curMode,
                      fields: contestsFields,
                      classifiers: classifiersPlus,
                      isViewMode,
                      form: this.props.form,
                    })}
                  </Row>
                  {curMode !== 'create' && (
                    <Row>
                      <Separator text="Перелік учасників конкурсу з пропозиціями" />
                      <FormTable
                        classifiers={classifiers}
                        fields={contestsTableFields}
                        viewMode={curMode}
                        parserToFE={parseContestMembers}
                        rows={(formParam.createdForm || {}).compMembersList || []}
                        form={this.props.form}
                        isViewMode={isViewMode}
                        onSave={this.handleSubmitContestMemeber}
                        onDelete={() => {}}
                      />
                    </Row>
                  )}
                  <Row type="flex" justify="end">
                    <Button
                      style={{ marginRight: '1.5rem' }}
                      type="primary"
                      onClick={this.handleSubmit}
                      disabled={isViewMode}
                    >
                      Відправити
                    </Button>
                  </Row>
                </Form>
              </Row>
            </Row>
          </TabPane>
        </GeneralTabsContainer>
      </Row>
    );
  }
}

ContestsFormContariner.defaultProps = {
  isViewModal: false,
  modalData: {},
  formParam: {
    createdForm: {},
    status: {},
  },
  storeKey: 'default',
};

ContestsFormContariner.propTypes = {
  loadClassifiersForContainer: PropTypes.func.isRequired,
  history: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
  match: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,

  postContests: PropTypes.func.isRequired,
  putContests: PropTypes.func.isRequired,
  getContests: PropTypes.func.isRequired,
  resetContestsForm: PropTypes.func.isRequired,
  resetContestsDoneStatus: PropTypes.func.isRequired,

  postContestMember: PropTypes.func.isRequired,
  putContestMember: PropTypes.func.isRequired,

  classifiers: PropTypes.objectOf(PropTypes.array).isRequired,
  formTypeData: PropTypes.objectOf(PropTypes.any).isRequired,
  formParam: PropTypes.objectOf(PropTypes.any),

  form: PropTypes.objectOf(PropTypes.any).isRequired,
  isViewModal: PropTypes.bool,
  modalData: PropTypes.objectOf(PropTypes.string),
  storeKey: PropTypes.string,
  lockDocToContestsDocument: PropTypes.func.isRequired,
  bindDocToContestsDocument: PropTypes.func.isRequired,
};

const mapStateToProps = (state, props) => ({
  classifiers: state.classifiers,
  formTypeData:
    state.documentForms.documentCascader.selectedValue[props.storeKey || defStoreKey].data, // eslint-disable-line
  formParam: state.documentForms.contests.forms[props.storeKey || defStoreKey],
});

export default withRouter(
  connect(mapStateToProps, {
    ...contestsActions,
    ...documentsActions,
    ...classifiersActions,
  })(Form.create()(ContestsFormContariner)),
);
