import React from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import PropTypes from 'prop-types';

import { Form, Modal, Button, Row, Tabs } from 'antd';

import _get from 'lodash/get';
import _remove from 'lodash/remove';

import * as classifiersActions from '../../actions/classifiersActions';
import * as judicialDecisionActions from '../../actions/modules/documents/judicialDecisionActions';
import * as commonActions from '../../actions';
import * as fileActions from '../../actions/modules/documents/fileTableActions';

import { mapFormItems } from '../../helpers/formHelpers/mapFormHelper';

import { generalFields } from '../../models/formFields/documents/generalFields';

import {
  judicialDecisionFields,
  getParsedForm,
  getMappedForm,
} from '../../models/formFields/documents/judicialDecisionFields';

import { JUDICIAL_DECISION_FORM_CONTAINER } from '../../constants/ContainerNames';
import {
  WEBSITELIST,
  REF_DOCUMENT_TYPE_GENERAL_DOC_CLASSNAME,
} from '../../constants/ClassifiersNames';

import Separator from '../../components/common/form/Separator';
import * as RouteNames from '../../constants/RouteNames';

import {
  failedValidationNotification,
  getFormEntityData,
} from '../../helpers/formHelpers/formHelpers';

import GeneralControlButtons from './common/GeneralControlButtons';
import GeneralTabsContainer from './common/GeneralTabsContainer';
import LockDocumentModal from './common/modals/LockDocumentModal';
import { defStoreKey } from '../../helpers/reducers/documents/commonActionsHandlers';
import { getObjGuidAndVersionId } from '../../helpers/commonUtils';
import { goToRegistry } from '../../helpers/entities/registry';

const JUDICIAL_DECISIONS_ACTIONS = {
  ...classifiersActions,
  ...judicialDecisionActions,
  ...commonActions,
  ...fileActions,
};

const TabPane = Tabs.TabPane;

class JudicialDecisionFormContainer extends React.Component {
  constructor(props) {
    super(props);

    const curMode = this.props.match.params.mode || 'create';
    this.curGuid = this.props.match.params.guid || '';

    this.state = {
      curMode,
      dialogOpen: false,
      lockDocumentModalIsOpen: false,
      dialogMessage: '',
    };

    this.loaded = false;
  }

  componentWillMount() {
    const { history } = this.props;
    if (this.state.curMode === 'create' && !this.getFormType()) {
      goToRegistry({
        name: 'documents',
        history,
      });
    }
  }

  componentDidMount = () => {
    const { getJudicialDecision, isViewModal, modalData, storeKey } = this.props;
    const { curMode } = this.state;

    this.props.loadClassifiersForContainer(JUDICIAL_DECISION_FORM_CONTAINER, {
      [WEBSITELIST]: {
        webSiteRegistryParam: {
          offset: '0',
          limit: '100',
        },
      },
      [REF_DOCUMENT_TYPE_GENERAL_DOC_CLASSNAME]: {
        generalDocClassName: 'DocJudicialDecision',
      },
    });

    if (isViewModal) {
      this.setState({
        curMode: 'view',
      });
      getJudicialDecision(modalData.guid, storeKey);
    } else if (!isViewModal && (curMode === 'view' || curMode === 'edit')) {
      getJudicialDecision(this.curGuid, storeKey);
    }
  };

  componentWillReceiveProps(nextProps) {
    const {
      formParam: { createdForm, status, errors },
      match: {
        params: { mode },
      },
      resetJudicialDecisionForm,
      resetJudicialDecisionDoneStatus,
      form,
      isViewModal,
      storeKey,
      setFileTable,
    } = nextProps;

    if (isViewModal && isViewModal !== this.props.isViewModal) {
      this.setState({
        curMode: 'view',
      });
    } else if (this.state.curMode !== mode) {
      this.setState({
        curMode: mode,
      });
    }

    if (
      (createdForm.versionId || createdForm.versionId === 0) &&
      this.props.formParam.createdForm.versionId !== createdForm.versionId
    ) {
      form.setFieldsValue(getParsedForm(createdForm));
    } else if (createdForm.guid && (mode === 'view' || mode === 'edit') && !this.loaded) {
      this.loaded = true;
      form.setFieldsValue(getParsedForm(createdForm));
      setFileTable(createdForm.fileStorage);
    }

    if (this.state.curMode !== mode && mode === 'create') {
      form.resetFields();
      resetJudicialDecisionForm(storeKey);
    }

    if (status.isDone) {
      this.curGuid = createdForm.guid;
      this.curVersionId = createdForm.versionId;
      this.handleToggleDialog();
      resetJudicialDecisionDoneStatus();
      this.loaded = true;
    }

    if (errors.length > 0) {
      const errorsText = errors.map((el) => el.message).join(', ');
      this.setState({ dialogMessage: errorsText, dialogOpen: true });
      resetJudicialDecisionForm();
    }
  }

  componentWillUnmount() {
    this.props.resetJudicialDecisionForm();
  }

  handleCreateNew = () => {
    this.changeRouteTo(`/${RouteNames.DOCUMENTS}/${RouteNames.DOCUMENT_JUDICIAL_DECISION}/create`);
    this.curGuid = '';
    this.loaded = false;
    this.props.form.resetFields();
    this.props.resetJudicialDecisionForm();
    this.handleToggleDialog();
  };

  clearForm = () => {
    this.props.form.resetFields();
  };

  changeRouteTo = (route) => {
    this.props.history.push(route);
  };

  handleToggleDialog = (isOpened) => {
    if (isOpened !== undefined) this.setState({ dialogOpen: isOpened });
    else this.setState((prevState) => ({ dialogOpen: !prevState.dialogOpen }));
  };

  handleDialogCancel = () => {
    this.handleToggleDialog(false);
    this.switchToViewMode();
  };

  switchToEditMode = () => {
    this.changeRouteTo(
      `/${RouteNames.DOCUMENTS}/${RouteNames.DOCUMENT_JUDICIAL_DECISION}/edit/${this.curGuid}`,
    );
  };

  switchToViewMode = () => {
    this.changeRouteTo(
      `/${RouteNames.DOCUMENTS}/${RouteNames.DOCUMENT_JUDICIAL_DECISION}/view/${this.curGuid}`,
    );
  };

  handleSubmit = ({ ignoreStatus, file = {}, delFileGuid = '', delDoc = {} }) => {
    const { curMode } = this.state;
    const {
      putJudicialDecision,
      postJudicialDecision,
      classifiers,
      formParam: { createdForm },
      storeKey,
      form,
    } = this.props;

    const fields = {
      ...generalFields,
      ...judicialDecisionFields,
    };

    const curFields = [...Object.keys(generalFields), ...Object.keys(judicialDecisionFields)];

    form.validateFields(curFields, (err, values) => {
      if (!err) {
        const normilizedValues = getFormEntityData(values, classifiers, fields);

        if (curMode === 'create') {
          postJudicialDecision(
            {
              ...getMappedForm(normilizedValues),
              refDocumentType: this.getFormTypeData(),
              documentType: 'DocJudicialDecision',
            },
            storeKey,
          );
        }

        if (curMode === 'edit') {
          const files = file.guid ? [...createdForm.fileStorage, file] : createdForm.fileStorage;

          if (delFileGuid) {
            _remove(files, (el) => el.guid === delFileGuid);
          }

          if (delDoc.guid) {
            if (Array.isArray(createdForm[delDoc.field])) {
              _remove(createdForm[delDoc.field], (el) => el.guid === delDoc.guid);
            } else {
              createdForm[delDoc.field] = undefined;
            }
          }

          putJudicialDecision(
            {
              ...createdForm,
              ...getMappedForm(normilizedValues),
              guid: this.curGuid,
              fileStorage: getObjGuidAndVersionId(files),
              linkedDocuments: getObjGuidAndVersionId(createdForm.linkedDocuments),
              parentDocument: getObjGuidAndVersionId(createdForm.parentDocument),
              childrenDocuments: getObjGuidAndVersionId(createdForm.childrenDocuments),
              versionId: _get(createdForm, 'versionId', this.curVersionId),
            },
            storeKey,
            ignoreStatus,
          );
        }
      } else {
        failedValidationNotification(err, fields);
      }
    });
  };

  getFormType = () => {
    const {
      formTypeData,
      classifiers,
      formParam: {
        createdForm: { refDocumentType },
      },
    } = this.props;

    const documentTypeField = classifiers.refDocumentTypeGeneralDocClassName.find(
      (el) => el.guid === (refDocumentType || {}).guid,
    );

    if (documentTypeField) {
      return documentTypeField;
    }
    return formTypeData;
  };

  getFormTypeData = () => {
    const { guid, versionId, type } = this.getFormType();
    return {
      guid,
      versionId,
      type,
    };
  };

  getFormTypeLabel = () => {
    const obj = this.getFormType();
    return obj && `${obj.scopeOfApplication}/${obj.docCategory}/${obj.name}`;
  };

  handleLockDocumentModal = () => {
    this.setState((prevState) => ({
      lockDocumentModalIsOpen: !prevState.lockDocumentModalIsOpen,
    }));
  };

  render() {
    const { curMode, dialogMessage } = this.state;

    const {
      classifiers,
      form,
      formParam,
      bindDocToJudicialDecisionDocument,
      lockDocToJudicialDecisionDocument,
      isViewModal,
    } = this.props;

    const dialogText = curMode === 'create' ? 'створено' : 'відредаговано';
    const isViewMode = isViewModal || curMode === 'view';

    const controlButtons = (
      <GeneralControlButtons
        form={form}
        guid={this.curGuid}
        handleLockDocument={this.handleLockDocumentModal}
        documentType="DOCUMENT_JUDICIAL_DECISION"
      />
    );

    return (
      <Row>
        <Modal
          title="Форма рішення суду"
          visible={this.state.dialogOpen}
          onOk={() => {
            this.handleCreateNew();
          }}
          onCancel={() => {
            this.handleDialogCancel();
          }}
          cancelText="Переглянути картку"
          okText="Створити нову"
        >
          {dialogMessage === '' ? (
            <p>{`Картку успішно ${dialogText}`}</p>
          ) : (
            <p>{`${dialogMessage}`}</p>
          )}
        </Modal>
        <Modal
          title="Блокування документа"
          visible={this.state.lockDocumentModalIsOpen}
          onCancel={this.handleLockDocumentModal}
          footer={null}
          width="1000px"
          maskClosable={false}
          destroyOnClose
        >
          <LockDocumentModal
            handleCloseModal={this.handleLockDocumentModal}
            childrenDocuments={formParam.createdForm.childrenDocuments}
            guid={this.curGuid}
            versionId={_get(formParam, ['createdForm', 'versionId'], this.curVersionId)}
            updateForm={lockDocToJudicialDecisionDocument}
            loadDocument={() => this.props.getJudicialDecision(this.curGuid, this.props.storeKey)}
          />
        </Modal>
        <h1 key="formLabel">{this.getFormTypeLabel()}</h1>
        <GeneralTabsContainer
          ownerSide={{
            guid: this.curGuid,
            versionId: _get(formParam, ['createdForm', 'versionId'], this.curVersionId),
          }}
          editAction={this.handleSubmit}
          controlButtons={controlButtons}
          bindDocAction={bindDocToJudicialDecisionDocument}
          isViewModal={isViewModal}
          createdForm={formParam.createdForm}
        >
          <TabPane tab="Форма рішення суду" key="0">
            <Row>
              <Row type="flex" justify="center">
                {!isViewModal && controlButtons}
              </Row>
              <Row>
                <Row>
                  <Separator text="Основна інформація" />
                  {mapFormItems({
                    viewMode: curMode,
                    fields: generalFields,
                    classifiers,
                    isViewMode,
                    form: this.props.form,
                  })}
                </Row>
                <Row>
                  <Separator text="Рішення суду" />
                  {mapFormItems({
                    viewMode: curMode,
                    fields: judicialDecisionFields,
                    classifiers,
                    isViewMode,
                    form: this.props.form,
                  })}
                  <Row type="flex" justify="end">
                    <Button
                      style={{ marginRight: '1.5rem' }}
                      type="primary"
                      onClick={this.handleSubmit}
                      disabled={isViewMode}
                    >
                      Відправити
                    </Button>
                  </Row>
                </Row>
              </Row>
            </Row>
          </TabPane>
        </GeneralTabsContainer>
      </Row>
    );
  }
}

JudicialDecisionFormContainer.defaultProps = {
  isViewModal: false,
  modalData: {},
  formParam: {
    createdForm: {},
    status: {},
  },
  storeKey: defStoreKey,
};

JudicialDecisionFormContainer.propTypes = {
  loadClassifiersForContainer: PropTypes.func.isRequired,
  history: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
  match: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,

  postJudicialDecision: PropTypes.func.isRequired,
  putJudicialDecision: PropTypes.func.isRequired,
  getJudicialDecision: PropTypes.func.isRequired,

  bindDocToJudicialDecisionDocument: PropTypes.func.isRequired,
  lockDocToJudicialDecisionDocument: PropTypes.func.isRequired,

  isViewModal: PropTypes.bool,
  storeKey: PropTypes.string,
  modalData: PropTypes.objectOf(PropTypes.string),

  setFileTable: PropTypes.func.isRequired,

  classifiers: PropTypes.objectOf(PropTypes.array).isRequired,
  formTypeData: PropTypes.objectOf(PropTypes.any).isRequired,
  // fileRows: PropTypes.arrayOf(PropTypes.any).isRequired,
  resetJudicialDecisionForm: PropTypes.func.isRequired,
  resetJudicialDecisionDoneStatus: PropTypes.func.isRequired,
  formParam: PropTypes.objectOf(PropTypes.any),

  form: PropTypes.objectOf(PropTypes.any).isRequired,
};

const mapStateToProps = (state, props) => ({
  classifiers: state.classifiers,
  formTypeData:
    state.documentForms.documentCascader.selectedValue[props.storeKey || defStoreKey].data, // eslint-disable-line
  formParam: state.documentForms.judicialDecision.forms[props.storeKey || defStoreKey],
});

export default withRouter(
  connect(mapStateToProps, JUDICIAL_DECISIONS_ACTIONS)(
    Form.create()(JudicialDecisionFormContainer),
  ),
);
