import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';

import * as documentsActions from '../../actions/modules/documents/documentsActions';
import * as classifiersActions from '../../actions/classifiersActions';

import { WRITE_OFF_FORM_CONTAINER } from '../../constants/ContainerNames';
import { WEBSITELIST } from '../../constants/ClassifiersNames';

// import {
//   writeOffOOMTableFields,
//   writeOffInformationFields
// } from '../../models/formFields/documents/writeOffFields';

class WriteOffFormContainer extends React.Component {
  componentDidMount = () => {
    this.props.loadClassifiersForContainer(WRITE_OFF_FORM_CONTAINER, {
      [WEBSITELIST]: { webSiteRegistryParam: { offset: '0', limit: '100' } },
    });
  };

  render() {
    return <div />;
  }
}

WriteOffFormContainer.propTypes = {
  loadClassifiersForContainer: PropTypes.func.isRequired,
  // classifiers: PropTypes.objectOf(PropTypes.any).isRequired
};

const mapStateToProps = (state) => ({
  classifiers: state.classifiers,
});

export default connect(mapStateToProps, {
  ...documentsActions,
  ...classifiersActions,
})(WriteOffFormContainer);
