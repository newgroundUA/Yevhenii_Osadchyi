import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { Icon, Select, Modal, Button } from 'antd';
import PropTypes from 'prop-types';

import wrapRegister from '../HOCs/wrapRegister';

import * as documentActions from '../../actions/modules/documents/documentsActions';
import * as appActions from '../../actions/appActions';
import EnumToLabelsMap from '../../constants/EnumToLabelsMap';
import { documentsRegisterSelector } from '../../selectors';

import DocumentClassifier from './DocumentClassifier';
import TableToolbar from '../../components/common/toolbar/TableToolbar';

import * as routeNames from '../../constants/RouteNames';
import { documentsFilters } from '../../models/registers/filters/templates/documents';
import { DOCUMENT_TYPE } from '../../constants/ClassifiersNames';
import { documentTypesEnums } from '../../reducers/modules/documents/documentsReducer';

const ButtonGroup = Button.Group;
const Option = Select.Option;

const CONTAINER_ACTIONS = {
  ...appActions,
  ...documentActions,
};

const getNewDocForm = (typeOfNewDoc) =>
  ({
    Document: routeNames.DOCUMENT_GENERAL,
    PersonPassport: routeNames.DOCUMENT_PASSPORT,
    ApplicationToLease: routeNames.DOCUMENT_RENT_STATEMENT,
    CompetitionProtocol: routeNames.DOCUMENT_CONTESTS,
    DocJudicialDecision: routeNames.DOCUMENT_JUDICIAL_DECISION,
    DocAppeals: routeNames.DOCUMENT_APPEALS,
    AccountItemReceiptAct: routeNames.DOCUMENT_BALANCE,
    LeaseContract: routeNames.DOCUMENT_TYPICAL_CONTRACT,
    // ApplicationToPrivatization: routeNames.,
    // AccountingDocs: routeNames.,
    // AccountItemWriteOff: routeNames.,
    MarketPriceDetect: routeNames.DOCUMENT_MARKET,
    BankStatement: routeNames.DOCUMENT_BANK_STATEMENT,
  }[typeOfNewDoc] || routeNames.DOCUMENT_GENERAL);

class DocumentRegisterContainer extends Component {
  constructor(props) {
    super(props);
    this.initialState = {
      selectedFastFilter: 'Document',
      showDocumentsClassifierForm: false,
      newDocumentName: undefined,
    };

    this.state = { ...this.initialState };
  }

  componentDidMount() {
    this.props.loadDocumentsTypeEnum();
  }

  handleCreateNewDocumentCanceled = () => {
    this.setState({
      showDocumentsClassifierForm: false,
    });
  };

  handleNewDocNameChanged = (newDocumentName) => {
    this.setState({
      newDocumentName,
    });
  };

  handleCreateDocumentClick = () => {
    this.setState({
      showDocumentsClassifierForm: true,
    });
  };

  getColumnsForFilter = () => {
    const common = [
      { value: 'docRegNumber', label: 'Внутрішній реєстраційний номер' },
      { value: 'refDocumentTypeName ', label: 'refDocumentTypeName ???' },
    ];

    const getFilterFields = () => {
      switch (this.state.selectedFastFilter) {
        case 'PersonPassport':
          return [
            { value: 'unicodeEddr', label: 'unicodeEddr' },
            { value: 'passPublisherCode', label: 'passPublisherCode' },
          ];
        case 'CompetitionProtocol':
          return [
            { value: 'observersList', label: 'observersList' },
            { value: 'compResult ', label: 'compResult ' },
          ];
        case 'DocJudicialDecision':
          return [
            { value: 'descriptivePart', label: 'descriptivePart' },
            { value: 'motivatedPart ', label: 'motivatedPart ' },
            { value: 'conclusion', label: 'conclusion' },
          ];
        case 'DocAppeals':
          return [
            { value: 'appealClaims', label: 'appealClaims' },
            { value: 'conditionsOfClaims ', label: 'conditionsOfClaims ' },
            { value: 'proofsOfClaims', label: 'proofsOfClaims' },
            { value: 'additionalInfo ', label: 'additionalInfo ' },
          ];
        case 'AccountItemReceiptAct':
          return [{ value: 'writeOffTypeName', label: 'writeOffTypeName' }];
        case 'AccountItemWriteOff':
          return [{ value: 'accountItemWriteOffNotes', label: 'accountItemWriteOffNotes' }];
        case 'MarketPriceDetect':
          return [{ value: 'goOLeaseRateDirectoryName', label: 'goOLeaseRateDirectoryName' }];
        default:
          return 'Not Found';
      }
    };

    return [...common, ...getFilterFields()];
  };

  handleCloseModal = (choiseDone, typeOfNewDoc) => {
    this.setState({
      showDocumentsClassifierForm: false,
    });
    if (choiseDone) {
      this.props.history.push(
        `/${routeNames.DOCUMENTS}/${getNewDocForm(typeOfNewDoc)}/${routeNames.CREATE}`,
      );
    }
  };

  handleSubmitFilters = () => {
    const fastFilter =
      this.state.selectedFastFilter === 'Document'
        ? documentTypesEnums
        : [this.state.selectedFastFilter];
    this.props.setValueRequestBody('page', 0);
    this.props.setValuePages('currentPage', 0);
    this.props.setValueRequestBody('documentTypes', fastFilter);
  };

  handleCancelFilters = () => {
    this.state({
      selectedFastFilter: '',
    });
  };

  handleChangeFastFilters = (selected) => {
    this.setState(
      {
        selectedFastFilter: selected,
      },
      () => this.handleSubmitFilters(),
    );
  };

  render() {
    const {
      tableToolbar,
      sortedColumns,
      extraData: { documentTypeEnum },
      requestBody,
    } = this.props;

    return (
      <div>
        <Modal
          title="Створення нового документа"
          visible={this.state.showDocumentsClassifierForm}
          onCancel={this.handleCreateNewDocumentCanceled}
          onDocNameChanged={this.handleNewDocNameChanged}
          footer={false}
        >
          <DocumentClassifier handleCloseModal={this.handleCloseModal} />
        </Modal>

        <div className="content__table-menu">
          <TableToolbar
            items={tableToolbar}
            requestBody={requestBody}
            columnsForFilter={this.getColumnsForFilter()}
            setValueRequestBody={this.props.setValueRequestBody}
            handleToggleToolbarItem={this.props.handleToggleToolbarItem}
            isActive={false}
            columns={sortedColumns}
            handleChangeColumns={this.props.handleChangeColumns}
            handleClickToolbarItem={() => {}}
            registryFiltersTemplate={documentsFilters}
          >
            <ButtonGroup>
              <Button type="primary" size="large" onClick={this.handleCreateDocumentClick}>
                {'Створити документ'}
              </Button>
            </ButtonGroup>
          </TableToolbar>
        </div>

        <div className="content__fast-filters">
          <div className="fast-filters">
            <div className="fast-filters__filters">
              <div className="table-menu__icon">
                <Icon type="filter" />
              </div>
              <Select
                // mode="multiple"
                style={{ minWidth: 200 }}
                // allowClear
                value={this.state.selectedFastFilter}
                placeholder="Виберіть тип документа"
                onChange={this.handleChangeFastFilters}
              >
                {documentTypeEnum.map((item) => (
                  <Option value={item} key={item}>
                    {EnumToLabelsMap[DOCUMENT_TYPE][item]}
                  </Option>
                ))}
              </Select>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

DocumentRegisterContainer.propTypes = {
  history: PropTypes.objectOf(PropTypes.any).isRequired,

  tableToolbar: PropTypes.objectOf(PropTypes.any).isRequired,
  extraData: PropTypes.objectOf(PropTypes.any).isRequired,
  sortedColumns: PropTypes.shape({
    fixed: PropTypes.object,
    fluid: PropTypes.object,
  }).isRequired,
  requestBody: PropTypes.objectOf(PropTypes.any).isRequired,
  setValueRequestBody: PropTypes.func.isRequired,
  setValuePages: PropTypes.func.isRequired,

  loadDocumentsTypeEnum: PropTypes.func.isRequired,

  handleChangeColumns: PropTypes.func.isRequired,
  handleToggleToolbarItem: PropTypes.func.isRequired,
  // handleSubmitFilters: PropTypes.func.isRequired,
  // handleCancelFilters: PropTypes.func.isRequired
};

export default withRouter(
  connect(documentsRegisterSelector, CONTAINER_ACTIONS)(
    wrapRegister(DocumentRegisterContainer, 'documents', 'loadDocuments'),
  ),
);
