import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { Form, Modal, Button, Row, message, Upload, Icon, Tabs } from 'antd';

import _get from 'lodash/get';
import _remove from 'lodash/remove';

import GeneralControlButtons from './common/GeneralControlButtons';
import GeneralTabsContainer from './common/GeneralTabsContainer';
import LockDocumentModal from './common/modals/LockDocumentModal';

import * as bankStatementActions from '../../actions/modules/documents/bankStatementActions';
import * as classifiersActions from '../../actions/classifiersActions';

import * as RouteNames from '../../constants/RouteNames';

import { BANK_STATEMENT_FORM_CONTAINER } from '../../constants/ContainerNames';
import {
  WEBSITELIST,
  REF_DOCUMENT_TYPE_GENERAL_DOC_CLASSNAME,
} from '../../constants/ClassifiersNames';

import { mapFormItems } from '../../helpers/formHelpers/mapFormHelper';
import { generalFields } from '../../models/formFields/documents/generalFields';
import {
  parseBankStatementToFE,
  parseBankStatementToBE,
  receivedPaymentFields,
  parseReceivedPaymentToFE,
  parseReceivedPaymentToBE,
  receivedMoneyFields,
  parseReceivedMoneyToFE,
  parseReceivedMoneyToBE,
} from '../../models/formFields/documents/bankStatementFields';

import { baseURL } from '../../api/config';
import FormTable from '../../components/common/form/Table';
import CounterpartiesDropdownContainer from '../common/CounterpartiesDropdownContainer';
import Separator from '../../components/common/form/Separator';
import {
  failedValidationNotification,
  getFormEntityData,
} from '../../helpers/formHelpers/formHelpers';
import { defStoreKey } from '../../helpers/reducers/documents/commonActionsHandlers';
import { defaultStoreKey } from '../../reducers/modules/documents/generalDocumentReducer';
import { getObjGuidAndVersionId } from '../../helpers/commonUtils';
import { goToRegistry } from '../../helpers/entities/registry';

const TabPane = Tabs.TabPane;

class BankStatementFormContainer extends React.Component {
  constructor(props) {
    super(props);

    const curMode = this.props.match.params.mode || 'create';
    this.curGuid = this.props.match.params.guid || '';

    this.state = {
      curMode,
      dialogOpen: false,
      lockDocumentModalIsOpen: false,
      dialogMessage: '',
    };

    this.loaded = false;
  }

  componentWillMount() {
    const { history } = this.props;
    if (this.state.curMode === 'create' && !this.getFormType()) {
      goToRegistry({
        name: 'documents',
        history,
      });
    }
  }

  componentDidMount = () => {
    const { getBankStatement, isViewModal, storeKey, modalData } = this.props;
    const { curMode } = this.state;

    this.props.loadClassifiersForContainer(BANK_STATEMENT_FORM_CONTAINER, {
      [WEBSITELIST]: {
        webSiteRegistryParam: {
          limit: '100',
          offset: '0',
        },
      },
      [REF_DOCUMENT_TYPE_GENERAL_DOC_CLASSNAME]: { generalDocClassName: 'BankStatement' },
    });

    if (isViewModal) {
      this.setState({ curMode: 'view' });
      getBankStatement(modalData.guid, storeKey);
    } else if (curMode === 'view' || curMode === 'edit') {
      getBankStatement(this.curGuid, storeKey);
    }
  };

  componentWillReceiveProps(nextProps) {
    const {
      formParam: { createdForm, status, errors },
      match: {
        params: { mode, guid },
      },
      resetBankStatementForm,
      resetBankStatementDoneStatus,
      getBankStatement,
      isViewModal,
      storeKey,
      form,
    } = nextProps;

    if (isViewModal && isViewModal !== this.props.isViewModal) {
      this.setState({ curMode: 'view' });
    } else if (this.state.curMode !== mode) {
      this.setState({ curMode: mode });
      if (mode === 'create') {
        resetBankStatementForm();
        form.resetFields();
      }
      if (mode === 'edit' || mode === 'view') {
        this.curGuid = guid;
        this.loaded = false;
        if (!createdForm.guid) getBankStatement(this.curGuid);
      }
    }

    if (
      (createdForm.versionId || createdForm.versionId === 0) &&
      this.props.formParam.createdForm.versionId !== createdForm.versionId
    ) {
      form.setFieldsValue(parseBankStatementToFE(createdForm));
    } else if (createdForm.guid && (mode === 'view' || mode === 'edit') && !this.loaded) {
      this.loaded = true;
      form.setFieldsValue(parseBankStatementToFE(createdForm));
    }

    if (this.state.curMode !== mode && mode === 'create') {
      form.resetFields();
      resetBankStatementForm(storeKey);
    }

    if (status.isDone) {
      this.loaded = true;
      this.curGuid = createdForm.guid;
      this.curVersionId = createdForm.versionId;
      form.setFieldsValue(parseBankStatementToFE(createdForm));
      this.handleToggleDialog();
      resetBankStatementDoneStatus(storeKey);
    }

    if (errors.length > 0) {
      const errorsText = errors.map((el) => el.message).join(', ');
      this.setState({ dialogMessage: errorsText, dialogOpen: true });
      resetBankStatementForm(storeKey);
    }
  }

  componentWillUnmount() {
    this.props.resetBankStatementForm(this.props.storeKey);
  }

  handleCreateNew = () => {
    this.changeRouteTo(`/${RouteNames.DOCUMENTS}/${RouteNames.DOCUMENT_BANK_STATEMENT}/create`);
    this.curGuid = '';
    this.loaded = false;
    this.props.form.resetFields();
    this.props.resetBankStatementForm(this.props.storeKey);
    this.handleToggleDialog();
  };

  clearForm = () => {
    this.props.form.resetFields();
  };

  changeRouteTo = (route) => {
    this.props.history.push(route);
  };

  handleToggleDialog = (isOpened) => {
    if (isOpened !== undefined) this.setState({ dialogOpen: isOpened });
    else this.setState((prevState) => ({ dialogOpen: !prevState.dialogOpen }));
  };

  handleDialogCancel = () => {
    this.handleToggleDialog();
    this.switchToViewMode();
  };

  switchToEditMode = () => {
    this.changeRouteTo(
      `/${RouteNames.DOCUMENTS}/${RouteNames.DOCUMENT_BANK_STATEMENT}/edit/${this.curGuid}`,
    );
  };

  switchToViewMode = () => {
    this.changeRouteTo(
      `/${RouteNames.DOCUMENTS}/${RouteNames.DOCUMENT_BANK_STATEMENT}/view/${this.curGuid}`,
    );
  };

  handleSubmit = ({ delDoc = {}, ignoreStatus, file = {}, delFileGuid = '' }) => {
    const { curMode } = this.state;
    const {
      formParam: { createdForm },
      putBankStatement,
      postBankStatement,
      storeKey,
      classifiers,
      form,
    } = this.props;

    const curFields = Object.keys(generalFields);

    form.validateFields(curFields, (err, values) => {
      if (!err) {
        const normilizedValues = getFormEntityData(values, classifiers, generalFields);

        if (curMode === 'create') {
          postBankStatement(
            {
              ...parseBankStatementToBE(normilizedValues),
              refDocumentType: this.getFormTypeData(),
              documentType: 'BankStatement',
            },
            storeKey,
          );
        }

        if (curMode === 'edit') {
          const files = file.guid ? [...createdForm.fileStorage, file] : createdForm.fileStorage;

          if (delFileGuid) {
            _remove(files, (el) => el.guid === delFileGuid);
          }

          if (delDoc.guid) {
            if (Array.isArray(createdForm[delDoc.field])) {
              _remove(createdForm[delDoc.field], (el) => el.guid === delDoc.guid);
            } else {
              createdForm[delDoc.field] = undefined;
            }
          }

          putBankStatement(
            {
              ...createdForm,
              ...parseBankStatementToBE(normilizedValues),
              fileStorage: getObjGuidAndVersionId(files),
              linkedDocuments: getObjGuidAndVersionId(createdForm.linkedDocuments),
              parentDocument: getObjGuidAndVersionId(createdForm.parentDocument),
              childrenDocuments: getObjGuidAndVersionId(createdForm.childrenDocuments),
              documentType: 'BankStatement',
            },
            storeKey,
            ignoreStatus,
          );
        }
      } else {
        failedValidationNotification(err, generalFields);
      }
    });
  };

  getFormType = () => {
    const {
      formTypeData,
      classifiers,
      formParam: {
        createdForm: { refDocumentType },
      },
    } = this.props;

    const documentTypeField = classifiers.refDocumentTypeGeneralDocClassName.find(
      (el) => el.guid === (refDocumentType || {}).guid,
    );

    if (documentTypeField) {
      return documentTypeField;
    }
    return formTypeData;
  };

  getFormTypeData = () => {
    const { guid, versionId, type } = this.getFormType();
    return {
      guid,
      versionId,
      type,
    };
  };

  getFormTypeLabel = () => {
    const obj = this.getFormType();
    return obj && `${obj.scopeOfApplication}/${obj.docCategory}/${obj.name}`;
  };

  handleSubmitReceivedMoney = ({ obj }) => {
    const { storeKey } = this.props;

    const post = {
      ...parseReceivedMoneyToBE(obj),
      bankStatement: {
        guid: this.curGuid,
        versionId: _get(this.props.formParam.createdForm, 'versionId', this.curVersionId),
      },
    };

    const put = {
      ...obj.beObj,
      ...post,
    };

    if (!put.guid) {
      this.props.postReceivedMoney(post).then((res) => {
        if (res.statusCode === 200) {
          this.props.getBankStatement(this.curGuid, storeKey);
        }
      });
    } else {
      this.props.putReceivedMoney(put).then((res) => {
        if (res.statusCode === 200) {
          this.props.getBankStatement(this.curGuid, storeKey);
        }
      });
    }
  };

  handleSubmitReceivedPayment = (record) => ({ obj }) => {
    const {
      formParam: {
        createdForm: { receivedMoneyList },
      },
    } = this.props;

    const getPDV = () => (record.pdv === 'Так' ? record.pdvSum : 0);
    const maxSum = record.moneyAmountReceived - getPDV();
    const receivedDoc = (receivedMoneyList || []).find((el) => el.guid === record.guid);
    const receivedDocList = receivedDoc.receivedPaymentToPurposeList || [];
    const currDocsSum =
      receivedDocList.reduce((prev, curr) => prev + curr.nominatedPaymentAmount, 0) || 0;
    const currSum = currDocsSum + Number(obj.nominatedPaymentAmount);

    if (maxSum < currSum) {
      return message.error(
        `Сума рознесених документів перевищує суму платіжного доручення на ${currSum - maxSum}.`,
      );
    }

    const post = {
      ...parseReceivedPaymentToBE(obj),
      receivedMoneyList: getObjGuidAndVersionId(record),
    };

    const put = {
      ...obj.beObj,
      ...post,
    };

    if (!put.guid) {
      this.props.postReceivedPayment(post).then((res) => {
        if (res.statusCode === 200) {
          this.props.getBankStatement(this.curGuid, this.props.storeKey);
        }
      });
    } else {
      this.props.putReceivedPayment(put).then((res) => {
        if (res.statusCode === 200) {
          this.props.getBankStatement(this.curGuid, this.props.storeKey);
        }
      });
    }
  };

  handleChangeUploading = (info) => {
    const status = info.file.status;
    if (status !== 'uploading') {
      // console.log(info.file, info.fileList);
    }
    if (status === 'done') {
      message.success(`${info.file.name} файл успішно завантажено.`);
      this.props.setReceivedMoneyList(info.file.response, this.props.storeKey);
    } else if (status === 'error') {
      message.error(`${info.file.name} файл не завантаженно.`, 2000);
    }
  };

  handleLockDocumentModal = () => {
    this.setState((prevState) => ({
      lockDocumentModalIsOpen: !prevState.lockDocumentModalIsOpen,
    }));
  };

  getReceivedMoneyFields = () => {
    const { form } = this.props;

    function setPdvSum(value) {
      form.setFields({ pdvSum: { value } });
    }

    const onPdvChange = (value) => {
      if (!value) {
        return setPdvSum(0);
      }
      const moneyAmount = +form.getFieldValue('moneyAmountReceived');
      if (moneyAmount) {
        const pdv = this.calculatePdvSum(moneyAmount);
        setPdvSum(pdv);
      }
    };

    const onMoneyAmountReceivedBlur = (event) => {
      const { value } = event.target;
      const isEmpty = value.length === 0;
      const isWithPdv = form.getFieldValue('pdv');
      if (isEmpty && isWithPdv) {
        return setPdvSum(0);
      }
      const moneyAmount = +value;
      const moneyAmountIsZero = moneyAmount === 0;
      if (moneyAmountIsZero) {
        return setPdvSum(0);
      }
      if (isWithPdv && moneyAmount) {
        const pdv = this.calculatePdvSum(moneyAmount);
        setPdvSum(pdv);
      }
    };

    return {
      ...receivedMoneyFields,
      moneyAmountReceived: {
        ...receivedMoneyFields.moneyAmountReceived,
        onBlur: onMoneyAmountReceivedBlur,
      },
      pdv: {
        ...receivedMoneyFields.pdv,
        onChange: onPdvChange,
      },
    };
  };

  calculatePdvSum = (moneyAmount) => {
    const pdv = moneyAmount / 6;
    return pdv.toFixed(2);
  };

  render() {
    const { curMode, dialogMessage } = this.state;

    const {
      formParam: { createdForm },
      classifiers,
      form,
      bindDocToBankStatementDocument,
      lockDocToBankStatementDocument,
      formParam,
      isViewModal,
    } = this.props;

    const dialogText = curMode === 'create' ? 'створено' : 'відредаговано';
    const isViewMode = isViewModal || curMode === 'view';

    const controlButtons = (
      <GeneralControlButtons
        form={form}
        guid={this.curGuid}
        handleLockDocument={this.handleLockDocumentModal}
        documentType="DOCUMENT_BANK_STATEMENT"
      />
    );

    return (
      <Row>
        <Modal
          title="Документ"
          visible={this.state.dialogOpen}
          onOk={this.handleCreateNew}
          onCancel={this.handleDialogCancel}
          cancelText="Переглянути"
          okText="Створити новий"
        >
          {dialogMessage === '' ? (
            <p>{`Документ успішно ${dialogText}`}</p>
          ) : (
            <p>{`${dialogMessage}`}</p>
          )}
        </Modal>
        <Modal
          title="Блокування документа"
          visible={this.state.lockDocumentModalIsOpen}
          onCancel={this.handleLockDocumentModal}
          footer={null}
          width="1000px"
          maskClosable={false}
          destroyOnClose
        >
          <LockDocumentModal
            handleCloseModal={this.handleLockDocumentModal}
            childrenDocuments={formParam.createdForm.childrenDocuments}
            guid={this.curGuid}
            versionId={_get(formParam, ['createdForm', 'versionId'], this.curVersionId)}
            updateForm={lockDocToBankStatementDocument}
            loadDocument={() => this.props.getBankStatement(this.curGuid, this.props.storeKey)}
          />
        </Modal>
        <h1 key="formLabel">{this.getFormTypeLabel()}</h1>
        <GeneralTabsContainer
          ownerSide={{
            guid: this.curGuid,
            versionId: _get(formParam, ['createdForm', 'versionId'], this.curVersionId),
          }}
          editAction={this.handleSubmit}
          controlButtons={controlButtons}
          bindDocAction={bindDocToBankStatementDocument}
          isViewModal={isViewModal}
          createdForm={formParam.createdForm}
        >
          <TabPane tab="Форма документа" key="0">
            <Row>
              {!isViewModal && controlButtons}
              <Row>
                <Row>
                  <Separator text="Основна інформація" />
                  {mapFormItems({
                    viewMode: curMode,
                    fields: generalFields,
                    classifiers,
                    isViewMode,
                    form: this.props.form,
                  })}
                </Row>
                <Row>
                  <Row type="flex" justify="space-between">
                    <Upload
                      style={{ marginLeft: '1.5rem' }}
                      headers={{ Authorization: localStorage.getItem('token') || '' }}
                      action={`${baseURL}document/bankStatement/${this.curGuid}/upload`}
                      onChange={this.handleChangeUploading}
                      disabled={curMode === 'create'}
                    >
                      <Button disabled={curMode === 'create'}>
                        <Icon type="upload" />
                        Завантажити банківську виписку
                      </Button>
                    </Upload>
                    <Button
                      style={{ marginRight: '1.5rem' }}
                      type="primary"
                      onClick={this.handleSubmit}
                      disabled={isViewMode}
                    >
                      <Icon type="save" />
                      Відправити
                    </Button>
                  </Row>
                </Row>
                {curMode !== 'create' && (
                  <Row>
                    <Separator text="Перелік отриманих коштів" />
                    <FormTable
                      classifiers={classifiers}
                      fields={this.getReceivedMoneyFields()}
                      parserToFE={parseReceivedMoneyToFE}
                      rows={createdForm.receivedMoneyList || []}
                      form={this.props.form}
                      scroll={{ x: '100%' }}
                      isViewMode={isViewMode}
                      onSave={this.handleSubmitReceivedMoney}
                      viewMode={curMode}
                      deleteDisabled
                      minWidth={isViewModal ? '2400px' : null}
                      expandedRowRender={(record) => (
                        <Row>
                          Рознесення
                          <FormTable
                            classifiers={classifiers}
                            fields={receivedPaymentFields}
                            parserToFE={parseReceivedPaymentToFE}
                            viewMode={curMode}
                            rows={
                              (createdForm.receivedMoneyList || []).find(
                                (el) => el.guid === record.guid,
                              ).receivedPaymentToPurposeList || []
                            }
                            form={this.props.form}
                            isViewMode={isViewMode}
                            onSave={this.handleSubmitReceivedPayment(record)}
                            deleteDisabled
                          />
                        </Row>
                      )}
                      customFields={[
                        {
                          title: receivedMoneyFields.moneyReceiverGuid.name,
                          dataIndex: receivedMoneyFields.moneyReceiverGuid.field,
                          key: receivedMoneyFields.moneyReceiverGuid.field,
                          render: (text, record = {}) => (
                            <CounterpartiesDropdownContainer
                              form={this.props.form}
                              fieldSpec={receivedMoneyFields.moneyReceiverGuid}
                              displayMode={text === 'component' ? 'component' : 'text'}
                              isViewMode={isViewMode}
                              value={record[receivedMoneyFields.moneyReceiverGuid.field]}
                              asd={{}}
                            />
                          ),
                        },
                        {
                          title: receivedMoneyFields.moneySenderGuid.name,
                          dataIndex: receivedMoneyFields.moneySenderGuid.field,
                          key: receivedMoneyFields.moneySenderGuid.field,
                          render: (text, record = {}) => (
                            <CounterpartiesDropdownContainer
                              form={this.props.form}
                              fieldSpec={receivedMoneyFields.moneySenderGuid}
                              displayMode={text === 'component' ? 'component' : 'text'}
                              isViewMode={isViewMode}
                              value={record[receivedMoneyFields.moneySenderGuid.field]}
                              asd={{}}
                            />
                          ),
                        },
                      ]}
                    />
                  </Row>
                )}
              </Row>
            </Row>
          </TabPane>
        </GeneralTabsContainer>
      </Row>
    );
  }
}

BankStatementFormContainer.defaultProps = {
  isViewModal: false,
  modalData: {},
  formParam: {
    createdForm: {},
    status: {},
  },
  storeKey: defaultStoreKey,
};

BankStatementFormContainer.propTypes = {
  loadClassifiersForContainer: PropTypes.func.isRequired,
  history: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
  match: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,

  setReceivedMoneyList: PropTypes.func.isRequired,
  getBankStatement: PropTypes.func.isRequired,
  postBankStatement: PropTypes.func.isRequired,
  putBankStatement: PropTypes.func.isRequired,
  resetBankStatementForm: PropTypes.func.isRequired,
  resetBankStatementDoneStatus: PropTypes.func.isRequired,

  postReceivedMoney: PropTypes.func.isRequired,
  putReceivedMoney: PropTypes.func.isRequired,

  postReceivedPayment: PropTypes.func.isRequired,
  putReceivedPayment: PropTypes.func.isRequired,

  classifiers: PropTypes.objectOf(PropTypes.array).isRequired,
  formTypeData: PropTypes.objectOf(PropTypes.any).isRequired,
  formParam: PropTypes.objectOf(PropTypes.any),

  form: PropTypes.objectOf(PropTypes.any).isRequired,

  bindDocToBankStatementDocument: PropTypes.func.isRequired,
  lockDocToBankStatementDocument: PropTypes.func.isRequired,

  isViewModal: PropTypes.bool,
  modalData: PropTypes.objectOf(PropTypes.string),
  storeKey: PropTypes.string,
};

const mapStateToProps = (state, { storeKey }) => ({
  classifiers: state.classifiers,
  formTypeData: state.documentForms.documentCascader.selectedValue[storeKey || defStoreKey].data, // eslint-disable-line
  formParam: state.documentForms.bankStatement.forms[storeKey || defStoreKey],
});

export default withRouter(
  connect(mapStateToProps, {
    ...bankStatementActions,
    ...classifiersActions,
  })(Form.create()(BankStatementFormContainer)),
);
