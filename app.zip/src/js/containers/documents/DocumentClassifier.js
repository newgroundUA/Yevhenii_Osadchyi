import React from 'react';
import { Button, Row } from 'antd';
import { connect } from 'react-redux';
import { PropTypes } from 'prop-types';

import DocumentCascader from './common/DocumentCascader';
import { defStoreKey } from '../../helpers/reducers/documents/commonActionsHandlers';

class DocumentClassifier extends React.Component {
  handleClose = () => {
    this.props.handleCloseModal(false);
  };

  handleSend = () => {
    this.props.handleCloseModal(true, this.props.selectedValue.generalDocClassName);
  };

  render() {
    return (
      <div className="document-create-modal-section__detailed_search">
        <Row style={{ margin: '5px' }}>
          <DocumentCascader />
        </Row>
        <div className="document-create-modal-section__buttons">
          <Button onClick={this.handleClose}>Скасувати</Button>
          <Button
            type="primary"
            onClick={this.handleSend}
            disabled={!this.props.selectedValue.data}
          >
            Створити
          </Button>
        </div>
      </div>
    );
  }
}

DocumentClassifier.propTypes = {
  handleCloseModal: PropTypes.func.isRequired,
  selectedValue: PropTypes.objectOf(PropTypes.any).isRequired,
};

const mapStateToProps = (state) => ({
  selectedValue: state.documentForms.documentCascader.selectedValue[defStoreKey],
});

export default connect(mapStateToProps)(DocumentClassifier);
