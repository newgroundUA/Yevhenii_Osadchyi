import React from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import PropTypes from 'prop-types';

import { Form, Button, Row, Icon, Collapse, Table } from 'antd';

import * as classifiersActions from '../../actions/classifiersActions';
import * as fileTableActions from '../../actions/modules/documents/fileTableActions';
import * as commonActions from '../../actions';

import { mapFormItems } from '../../helpers/formHelpers/mapFormHelper';
import { getFormEntityData, mapRowsToTable } from '../../helpers/formHelpers/formHelpers';

import { fileFields, getMappedForm, getParsedForm } from '../../models/formFields/fileFields';

import { FILE_TABLE } from '../../constants/ContainerNames';
import { getTableColumns } from '../../helpers/table';
// import { generalFields } from '../../models/formFields/documents/generalFields';

const FILE_TABLE_ACTIONS = {
  ...classifiersActions,
  ...fileTableActions,
  ...commonActions,
};

const Panel = Collapse.Panel;

class FileTable extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      curMode: props.curMode,

      fileTable: {
        curIndex: -1,
        isAddingNewRow: false,
        activeKey: 0,
        collapsed: false,
      },
    };

    this.columns = getTableColumns({
      formFields: fileFields,
      actionsData: {
        deleteParams: {
          handler: this.handleDeleteRow,
        },
      },
    });

    this.loaded = false;
  }

  componentDidMount = () => {
    // const { loadFileTable } = this.props;
    const { curMode } = this.state;

    this.props.loadClassifiersForContainer(FILE_TABLE);

    if (curMode === 'view' || curMode === 'edit') {
      // loadFileTable();
    }
  };

  componentWillReceiveProps(nextProps) {
    const {
      match: {
        params: { mode },
      },
      status,
      resetFileTable,
    } = nextProps;

    if (this.state.curMode !== mode) this.setState({ curMode: mode });

    if (status.isDone) {
      this.loaded = true;
      // this.curGuid = createdForm.guid;
      this.handleToggleDialog();
      resetFileTable();
    }
  }

  componentWillUnmount() {
    this.props.resetFileTable();
  }

  handleSaveTableForm = () => {
    const { postFile, classifiers } = this.props;

    const fieldsArr = Object.keys(fileFields);
    this.props.form.validateFields(fieldsArr, (err, values) => {
      if (!err) {
        const normilizedValues = getFormEntityData(values, classifiers, fileFields);
        postFile(getMappedForm(normilizedValues));

        this.setState((prevState) => ({
          fileTable: {
            ...prevState.fileTable,
            collapsed: false,
            activeKey: 0,
            isAddingNewRow: false,
            curIndex: -1,
          },
        }));
      }
    });
  };

  handleDeleteRow = (rowIndex) => {
    const { deleteFile, rows } = this.props;

    deleteFile(rows[rowIndex].guid);
  };

  handleAddTableRow = (formName) => () => {
    this.props.form.resetFields(Object.keys(fileFields));
    this.setState((prevState) => ({
      [formName]: {
        ...prevState[formName],
        collapsed: true,
        isAddingNewRow: true,
        activeKey: 1,
      },
    }));
  };

  handleCancelTableRow = () => {
    this.props.form.resetFields(Object.keys(fileFields));
    this.setState((prevState) => ({
      fileTable: {
        ...prevState.fileTable,
        collapsed: false,
        isAddingNewRow: false,
        activeKey: 0,
      },
    }));
  };

  clearForm = () => {
    this.props.form.resetFields();
  };

  render() {
    const { curMode } = this.state;

    const { classifiers, rows } = this.props;

    const propertyPanelStyle = this.state.fileTable.collapsed
      ? { marginBottom: '1rem' }
      : { display: 'none' };
    const isViewMode = curMode === 'view';
    const tableRows = mapRowsToTable(rows.map((el) => getParsedForm(el)), fileFields, classifiers);

    return (
      <Form>
        <Row>
          <Button
            disabled={this.state.fileTable.collapsed || isViewMode}
            onClick={this.handleAddTableRow('fileTable')}
          >
            <Icon type="plus" />
            Додати
          </Button>
          <Collapse
            style={propertyPanelStyle}
            bordered={false}
            activeKey={`${this.state.fileTable.activeKey}`}
            onChange={(key) => this.setState({ activeKey: key })}
          >
            <Panel header="Форма створення" key="1" disabled={!this.state.fileTable.collapsed}>
              {mapFormItems({
                viewMode: curMode,
                fields: fileFields,
                classifiers,
                isViewMode,
                form: this.props.form,
              })}
              <Row>
                <Button
                  style={{ marginRight: '1rem' }}
                  onClick={this.handleSaveTableForm}
                  type="primary"
                >
                  <Icon type="save" />
                  Зберегти
                </Button>
                <Button onClick={this.handleCancelTableRow}>
                  <Icon type="close" />
                  Вiдмiнити
                </Button>
              </Row>
            </Panel>
          </Collapse>
          <Table
            style={{ margin: '1rem 0', background: '#fff' }}
            bordered
            pagination={false}
            columns={this.columns}
            dataSource={tableRows}
          />
        </Row>
      </Form>
    );
  }
}

FileTable.propTypes = {
  loadClassifiersForContainer: PropTypes.func.isRequired,
  match: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
  curMode: PropTypes.string.isRequired,

  // loadFileTable: PropTypes.func.isRequired,
  postFile: PropTypes.func.isRequired,
  deleteFile: PropTypes.func.isRequired,

  classifiers: PropTypes.objectOf(PropTypes.array).isRequired,
  resetFileTable: PropTypes.func.isRequired,
  rows: PropTypes.arrayOf(PropTypes.any).isRequired,
  status: PropTypes.objectOf(PropTypes.bool).isRequired,

  form: PropTypes.objectOf(PropTypes.any).isRequired,
};

const mapStateToProps = (state) => ({
  classifiers: state.classifiers,
  rows: state.documentForms.fileTable.rows,
  status: state.documentForms.fileTable.status,
});

export default withRouter(connect(mapStateToProps, FILE_TABLE_ACTIONS)(Form.create()(FileTable)));
