import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';

import { Form, Button, Row, Tabs, Modal } from 'antd';

import _get from 'lodash/get';
import _remove from 'lodash/remove';

import Separator from '../../components/common/form/Separator';
import { mapFormItems } from '../../helpers/formHelpers/mapFormHelper';

import {
  balanceFields,
  balanceTableFields,
  getMappedBalanceForm,
  getParsedBalanceForm,
  getMappedBalaceDetailForm,
  getParsedBalanceDetailForm,
} from '../../models/formFields/documents/balanceFields';

import { generalFields } from '../../models/formFields/documents/generalFields';

import FormTable from '../../components/common/form/Table';
import * as RouteNames from '../../constants/RouteNames';

import * as balanceActions from '../../actions/modules/documents/balanceDocumentActions';
import * as fileActions from '../../actions/modules/documents/fileTableActions';
import * as classifiersActions from '../../actions/classifiersActions';
import * as commonActions from '../../actions';

import { BALANCE_FORM_CONTAINER } from '../../constants/ContainerNames';
import {
  failedValidationNotification,
  getFormEntityData,
} from '../../helpers/formHelpers/formHelpers';
import {
  REF_DOCUMENT_TYPE_GENERAL_DOC_CLASSNAME,
  WEBSITELIST,
} from '../../constants/ClassifiersNames';
import { getObjGuidAndVersionId } from '../../helpers/commonUtils';
import GeneralTabsContainer from './common/GeneralTabsContainer';
import GeneralControlButtons from './common/GeneralControlButtons';
import LockDocumentModal from './common/modals/LockDocumentModal';
import { defStoreKey } from '../../helpers/reducers/documents/commonActionsHandlers';
import { goToRegistry } from '../../helpers/entities/registry';

const TabPane = Tabs.TabPane;

const CONTAINER_ACTIONS = {
  ...balanceActions,
  ...fileActions,
  ...classifiersActions,
  ...commonActions,
};

class BalanceFormContainer extends Component {
  constructor(props) {
    super(props);

    const curMode = this.props.match.params.mode || 'create';
    this.curGuid = this.props.match.params.guid || '';

    this.state = {
      curMode,
      dialogOpen: false,
      lockDocumentModalIsOpen: false,
      dialogMessage: '',
    };

    this.loaded = false;
  }

  componentWillMount() {
    const { history } = this.props;
    if (this.state.curMode === 'create' && !this.getFormType()) {
      goToRegistry({
        name: 'documents',
        history,
      });
    }
  }

  componentDidMount = () => {
    const { getBalance, isViewModal, modalData, storeKey } = this.props;
    const { curMode } = this.state;

    this.props.loadClassifiersForContainer(BALANCE_FORM_CONTAINER, {
      [WEBSITELIST]: {
        webSiteRegistryParam: {
          limit: '100',
          offset: '0',
        },
      },
      [REF_DOCUMENT_TYPE_GENERAL_DOC_CLASSNAME]: {
        generalDocClassName: 'AccountItemReceiptAct',
      },
    });

    if (isViewModal) {
      this.setState({ curMode: 'view' });
      getBalance(modalData.guid, storeKey);
    } else if (!isViewModal && (curMode === 'view' || curMode === 'edit')) {
      getBalance(this.curGuid, storeKey);
    }
  };

  componentWillReceiveProps(nextProps) {
    const {
      formParam,
      storeKey,
      isViewModal,
      match: {
        params: { mode },
      },
      resetBalanceDocumentForm,
      resetBalanceDocumentDoneStatus,
      form,
      setFileTable,
    } = nextProps;

    const { createdForm, status, errors } = formParam;

    if (isViewModal && isViewModal !== this.props.isViewModal) {
      this.setState({ curMode: 'view' });
    } else if (this.state.curMode !== mode) this.setState({ curMode: mode });

    if (
      (createdForm.versionId || createdForm.versionId === 0) &&
      this.props.formParam.createdForm.versionId !== createdForm.versionId
    ) {
      form.setFieldsValue(getParsedBalanceForm(createdForm));
    } else if (createdForm.guid && (mode === 'view' || mode === 'edit') && !this.loaded) {
      this.loaded = true;
      form.setFieldsValue(getParsedBalanceForm(createdForm));
      setFileTable(createdForm.fileStorage);
    }

    if (this.state.curMode !== mode && mode === 'create') {
      form.resetFields();
      resetBalanceDocumentForm(storeKey);
    }

    if (status.isDone) {
      this.loaded = true;
      this.curGuid = createdForm.guid;
      this.curVersionId = createdForm.versionId;
      this.handleToggleDialog();
      resetBalanceDocumentDoneStatus(storeKey);
    }

    if (errors.length > 0) {
      const errorsText = errors.map((el) => el.message).join(', ');
      this.setState({ dialogMessage: errorsText, dialogOpen: true });
      resetBalanceDocumentForm(storeKey);
    }
  }

  componentWillUnmount() {
    this.props.resetBalanceDocumentForm(this.props.storeKey);
  }

  handleCreateNew = () => {
    this.changeRouteTo(`/${RouteNames.DOCUMENTS}/${RouteNames.DOCUMENT_BALANCE}/create`);
    this.curGuid = '';
    this.loaded = false;
    this.props.form.resetFields();
    this.props.resetBalanceDocumentForm(this.props.storeKey);
    this.handleToggleDialog();
  };

  clearForm = () => {
    this.props.form.resetFields();
  };

  changeRouteTo = (route) => {
    this.props.history.push(route);
  };

  handleToggleDialog = (isOpened) => {
    if (isOpened !== undefined) this.setState({ dialogOpen: isOpened });
    else this.setState((prevState) => ({ dialogOpen: !prevState.dialogOpen }));
  };

  handleDialogCancel = () => {
    this.handleToggleDialog();
    this.switchToViewMode();
  };

  switchToEditMode = () => {
    this.changeRouteTo(
      `/${RouteNames.DOCUMENTS}/${RouteNames.DOCUMENT_BALANCE}/edit/${this.curGuid}`,
    );
  };

  switchToViewMode = () => {
    this.changeRouteTo(
      `/${RouteNames.DOCUMENTS}/${RouteNames.DOCUMENT_BALANCE}/view/${this.curGuid}`,
    );
  };

  handleSubmit = ({ delDoc = {}, ignoreStatus, file = {}, delFileGuid = '' }) => {
    const { curMode } = this.state;
    const {
      postBalance,
      putBalance,
      classifiers,
      form,
      formParam: { createdForm },
      storeKey,
    } = this.props;

    const fields = {
      ...generalFields,
      ...balanceFields,
    };

    const curFields = [...Object.keys(generalFields), ...Object.keys(balanceFields)];

    form.validateFields(curFields, (err, values) => {
      if (!err) {
        const normilizedValues = getFormEntityData(values, classifiers, fields);

        if (curMode === 'create') {
          postBalance(
            {
              ...getMappedBalanceForm({ ...normilizedValues }),
              refDocumentType: this.getFormTypeData(),
              documentType: 'AccountItemReceiptAct',
            },
            storeKey,
            ignoreStatus,
          );
        }

        if (curMode === 'edit') {
          const files = file.guid ? [...createdForm.fileStorage, file] : createdForm.fileStorage;

          if (delFileGuid) {
            _remove(files, (el) => el.guid === delFileGuid);
          }

          if (delDoc.guid) {
            if (Array.isArray(createdForm[delDoc.field])) {
              _remove(createdForm[delDoc.field], (el) => el.guid === delDoc.guid);
            } else {
              createdForm[delDoc.field] = undefined;
            }
          }

          putBalance(
            {
              ...createdForm,
              ...getMappedBalanceForm({ ...normilizedValues }),
              linkedDocuments: getObjGuidAndVersionId(createdForm.linkedDocuments),
              parentDocument: getObjGuidAndVersionId(createdForm.parentDocument),
              childrenDocuments: getObjGuidAndVersionId(createdForm.childrenDocuments),
              fileStorage: getObjGuidAndVersionId(files),
              guid: this.curGuid,
              versionId: _get(createdForm, 'versionId', this.curVersionId),
            },
            storeKey,
            ignoreStatus,
          );
        }
      } else {
        failedValidationNotification(err, fields);
      }
    });
  };

  getFormType = () => {
    const {
      formTypeData,
      classifiers,
      formParam: {
        createdForm: { refDocumentType },
      },
    } = this.props;

    const documentTypeField = classifiers.refDocumentTypeGeneralDocClassName.find(
      (el) => el.guid === (refDocumentType || {}).guid,
    );

    if (documentTypeField) {
      return documentTypeField;
    }
    return formTypeData;
  };

  getFormTypeData = () => {
    const { guid, versionId, type } = this.getFormType();
    return {
      guid,
      versionId,
      type,
    };
  };

  getFormTypeLabel = () => {
    const obj = this.getFormType();
    return obj && `${obj.scopeOfApplication}/${obj.docCategory}/${obj.name}`;
  };

  handleSaveTableRow = ({ obj }) => {
    const { formParam, putBalanceDetail, getBalance, postBalanceDetail } = this.props;
    const balanceDoc = {
      guid: this.curGuid,
      versionId: formParam.createdForm.versionId,
    };
    if (obj) {
      // TODO: fix after errors handling will be implemented
      if (obj.beObj && obj.beObj.guid) {
        putBalanceDetail({
          accountItemReceiptAct: balanceDoc,
          guid: obj.beObj.guid,
          versionId: obj.beObj.versionId,
          ...getMappedBalaceDetailForm(obj),
        }).then(() => getBalance(this.curGuid));
      } else {
        postBalanceDetail({
          accountItemReceiptAct: balanceDoc,
          ...getMappedBalaceDetailForm(obj),
        }).then(() => getBalance(this.curGuid));
      }
    }
  };

  handleLockDocumentModal = () => {
    this.setState((prevState) => ({
      lockDocumentModalIsOpen: !prevState.lockDocumentModalIsOpen,
    }));
  };

  render() {
    const { curMode, dialogMessage } = this.state;

    const {
      classifiers,
      form,
      formParam,
      bindDocToBalanceDocument,
      lockDocToBalanceDocument,
      isViewModal,
    } = this.props;
    const dialogText = curMode === 'create' ? 'створено' : 'відредаговано';
    const isViewMode = isViewModal || curMode === 'view';

    const controlButtons = (
      <GeneralControlButtons
        form={form}
        guid={this.curGuid}
        handleLockDocument={this.handleLockDocumentModal}
        documentType="DOCUMENT_BALANCE"
      />
    );

    return (
      <Row>
        <Modal
          title="Паспортний документ"
          visible={this.state.dialogOpen}
          onOk={this.handleCreateNew}
          onCancel={this.handleDialogCancel}
          cancelText="Переглянути документ"
          okText="Створити новий"
        >
          {dialogMessage === '' ? (
            <p>{`Картку успішно ${dialogText}`}</p>
          ) : (
            <p>{`${dialogMessage}`}</p>
          )}
        </Modal>
        <Modal
          title="Блокування документа"
          visible={this.state.lockDocumentModalIsOpen}
          onCancel={this.handleLockDocumentModal}
          footer={null}
          width="1000px"
          maskClosable={false}
          destroyOnClose
        >
          <LockDocumentModal
            handleCloseModal={this.handleLockDocumentModal}
            childrenDocuments={formParam.createdForm.childrenDocuments}
            guid={this.curGuid}
            versionId={_get(formParam, ['createdForm', 'versionId'], this.curVersionId)}
            updateForm={lockDocToBalanceDocument}
            loadDocument={() => this.props.getBalance(this.curGuid, this.props.storeKey)}
          />
        </Modal>
        <h1 key="formLabel">{this.getFormTypeLabel()}</h1>
        <GeneralTabsContainer
          ownerSide={{
            guid: this.curGuid,
            versionId: _get(formParam, ['createdForm', 'versionId'], this.curVersionId),
          }}
          editAction={this.handleSubmit}
          controlButtons={controlButtons}
          bindDocAction={bindDocToBalanceDocument}
          isViewModal={isViewModal}
          createdForm={formParam.createdForm}
        >
          <TabPane tab="Основна інформація" key="0">
            <Row>
              {!isViewModal && controlButtons}
              <Row>
                <Form>
                  <Row>
                    <Separator text="Основна інформація" />
                    {mapFormItems({
                      viewMode: curMode,
                      fields: generalFields,
                      classifiers,
                      isViewMode,
                      form: this.props.form,
                    })}
                  </Row>
                  <Row>
                    <Separator text="Приймання на баланс" />
                    {mapFormItems({
                      viewMode: curMode,
                      fields: balanceFields,
                      classifiers,
                      isViewMode,
                      form: this.props.form,
                    })}
                  </Row>
                  <Row type="flex" justify="end">
                    <Button
                      style={{ marginRight: '1.5rem' }}
                      type="primary"
                      onClick={this.handleSubmit}
                      disabled={isViewMode}
                    >
                      Відправити
                    </Button>
                  </Row>
                  {curMode !== 'create' && (
                    <Row>
                      <Separator text="Перелік ООМ в документі" />
                      <FormTable
                        classifiers={classifiers}
                        fields={balanceTableFields}
                        parserToFE={getParsedBalanceDetailForm}
                        rows={formParam.createdForm.accountItemList || []}
                        form={this.props.form}
                        isViewMode={isViewMode}
                        viewMode={curMode}
                        onSave={this.handleSaveTableRow}
                        onDelete={(guid) => this.props.deleteBalanceDetail(guid)}
                      />
                    </Row>
                  )}
                </Form>
              </Row>
            </Row>
          </TabPane>
        </GeneralTabsContainer>
      </Row>
    );
  }
}

BalanceFormContainer.defaultProps = {
  isViewModal: false,
  modalData: {},
  formParam: {
    createdForm: {},
    status: {},
  },
  storeKey: 'default',
};

BalanceFormContainer.propTypes = {
  history: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
  match: PropTypes.oneOfType([PropTypes.objectOf(PropTypes.object), PropTypes.any]).isRequired,
  loadClassifiersForContainer: PropTypes.func.isRequired,

  getBalance: PropTypes.func.isRequired,
  postBalance: PropTypes.func.isRequired,
  putBalance: PropTypes.func.isRequired,
  postBalanceDetail: PropTypes.func.isRequired,
  putBalanceDetail: PropTypes.func.isRequired,
  deleteBalanceDetail: PropTypes.func.isRequired,

  form: PropTypes.objectOf(PropTypes.any).isRequired,
  formParam: PropTypes.objectOf(PropTypes.any),
  resetBalanceDocumentForm: PropTypes.func.isRequired,
  resetBalanceDocumentDoneStatus: PropTypes.func.isRequired,
  setFileTable: PropTypes.func.isRequired,
  classifiers: PropTypes.objectOf(PropTypes.array).isRequired,
  formTypeData: PropTypes.objectOf(PropTypes.any).isRequired,

  isViewModal: PropTypes.bool,
  modalData: PropTypes.objectOf(PropTypes.string),
  storeKey: PropTypes.string,

  lockDocToBalanceDocument: PropTypes.func.isRequired,
  bindDocToBalanceDocument: PropTypes.func.isRequired,
};

const mapStateToProps = (state, { storeKey }) => ({
  formTypeData: state.documentForms.documentCascader.selectedValue[storeKey || defStoreKey].data, // eslint-disable-line
  formParam: state.documentForms.balanceDocument.forms[storeKey || defStoreKey],
  classifiers: state.classifiers,
});

export default withRouter(
  connect(mapStateToProps, CONTAINER_ACTIONS)(Form.create()(BalanceFormContainer)),
);
