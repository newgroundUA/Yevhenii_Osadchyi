import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import Loadable from 'react-loadable';
import { LocaleProvider, BackTop } from 'antd';
import moment from 'moment';
// import EventListener from 'react-event-listener';

import ContentContainer from './ContentContainer';
import * as userActions from '../actions/usersActions';
import * as appActions from '../actions/appActions';
import LocaleAntUa from '../models/localisation/antdLocalization';
import { isLoggedIn /*  isTokenExpired, getRefreshToken */ } from '../helpers/OAuth2Service';
import Loading from '../components/common/Loading';

moment.locale('uk');

const actions = {
  ...userActions,
  ...appActions,
};

const NotificationContainer = Loadable({
  loader: () => import(/* webpackChunkName: "NotificationContainer" */ './NotificationContainer'),
  loading: Loading,
  delay: 400,
});

const HeaderContainer = Loadable({
  loader: () => import(/* webpackChunkName: "HeaderContainer" */ './HeaderContainer'),
  loading: Loading,
  delay: 400,
});

const LoginContainer = Loadable({
  loader: () => import(/* webpackChunkName: "LoginContainer" */ './LoginContainer'),
  loading: Loading,
  delay: 400,
});

const spinner = document.querySelector('#spinner-666');

class App extends Component {
  // updateToken = () => {
  //   const { postRefreshToken } = this.props;
  //   if (getRefreshToken() && isTokenExpired()) postRefreshToken();
  // };

  componentDidMount() {
    this.props.getAppConfig();
  }

  render() {
    const { isLoad } = this.props;

    if (isLoad) {
      spinner.className = 'show-spinner';
    } else if (spinner.className !== 'hide-spinner') {
      spinner.className = 'hide-spinner';
    }

    if (!isLoggedIn()) {
      return (
        <div>
          {/* <NotificationContainer /> */}
          <LoginContainer />
        </div>
      );
    }

    return (
      <LocaleProvider locale={LocaleAntUa}>
        <div className="react-root">
          {/* <EventListener
            target="document"
            onMouseDown={this.updateToken}
            onKeyPress={this.updateToken}
          /> */}
          <NotificationContainer />
          <HeaderContainer />
          <ContentContainer />
          <BackTop />
        </div>
      </LocaleProvider>
    );
  }
}

App.propTypes = {
  isLoad: PropTypes.bool.isRequired,
  // postRefreshToken: PropTypes.func.isRequired,
  getAppConfig: PropTypes.func.isRequired,
};

const mapStateToProps = (state) => ({
  isLoad: state.app.spin.isLoad,
});

export default withRouter(connect(mapStateToProps, actions)(App));
