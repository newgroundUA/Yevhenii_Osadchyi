import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import moment from 'moment';

import {
  Row,
  Col,
  Form,
  Icon,
  Input,
  Button,
  Checkbox,
  Collapse,
  // Upload,
  // message,
  Steps,
  Select,
  Alert,
  Modal,
} from 'antd';

import * as userActions from '../actions/usersActions';
import CountDown from '../components/common/CountDown';

const FormItem = Form.Item;
const Panel = Collapse.Panel;
// const Dragger = Upload.Dragger;
const Option = Select.Option;
const Step = Steps.Step;

const formFields = {
  login: undefined,
  pwd: undefined,
  counterPartyId: undefined,
};

const clientIds = {
  default: 'dkv_default_client_id',
  defaultECP: 'dkv_default_client_id_ds',
  person: 'dkv_enter_as_person',
  selfEmployed: 'dkv_enter_as_self_employee',
  employee: 'dkv_enter_as_employee',
};

class LoginForm extends Component {
  initialState = {
    currentStep: 0,
    isTimeOut: false,
    isCheckedECP: false,
    isValidStep1: false,
    isValidStep2: false,
    counterpartyArr: [],
  };

  state = { ...this.initialState };

  expires = 0;

  componentDidMount() {
    document.addEventListener('keyup', this.handleSubmitOnEnter);
  }

  componentWillUnmount() {
    document.removeEventListener('keyup', this.handleSubmitOnEnter);
  }

  handleSubmitOnEnter = (e) => {
    if (e.code === 'Enter') {
      this.handleSubmit();
    }
  };

  componentWillReceiveProps({
    selfCounterparty: { person, selfEmployed, employee },
    tokenInfo: { access_token: nextAccessToken, token_type: nextTokenType, expires_in: expiresIn },
  }) {
    const {
      getSelfCounterparty,
      tokenInfo: { access_token: accessToken },
    } = this.props;

    this.expires = moment().add(expiresIn, 'seconds');

    // change step 2 after first login
    if (accessToken !== nextAccessToken && nextAccessToken !== '') {
      this.setState({
        currentStep: 1,
      });
      getSelfCounterparty(`${nextTokenType} ${nextAccessToken}`);
    }

    // make option for select in step 2
    if (person || selfEmployed || employee) {
      const makeOptionObj = (value, counterpartyType, label) => ({
        value,
        label,
        counterpartyType,
      });
      // make option for person
      const personOption =
        person && person.guid
          ? [
              makeOptionObj(
                person.guid,
                'person',
                `ФО ${person.personLastName} 
            ${person.personFirstName} 
            ${person.personMiddleName}
          `,
              ),
            ]
          : [];
      // make option for FOP
      const selfEmployedOption =
        selfEmployed && selfEmployed.guid
          ? [
              makeOptionObj(
                selfEmployed.guid,
                'selfEmployed',
                `ФОП ${selfEmployed.personDto.lastName} 
            ${selfEmployed.personDto.fistName} 
            ${selfEmployed.personDto.middleName}
          `,
              ),
            ]
          : [];
      // make option for for employee
      const employeeOptions = employee
        ? employee.map((el) =>
            makeOptionObj(
              el.guid,
              'employee',
              `EE ${el.personLastName} 
            ${el.personFirstName} 
            ${el.personMiddleName}
          `,
            ),
          )
        : [];

      this.setState({
        counterpartyArr: [...personOption, ...selfEmployedOption, ...employeeOptions],
      });
    }
  }

  handleSubmit = () => {
    const {
      postLogin,
      postLoginStep2,
      form: { validateFields },
      tokenInfo: { access_token: accessToken, token_type: tokenType },
    } = this.props;

    const { isCheckedECP, currentStep } = this.state;

    switch (currentStep) {
      case 0: {
        validateFields(['login', 'pwd'], (err, { login, pwd }) => {
          if (!err) {
            postLogin({
              login,
              pwd: isCheckedECP ? `encrypt ${pwd}` : pwd,
              // Belowe hardCode is contract with BE
              // Look at https://ucplatform.atlassian.net/wiki/spaces/DKV/pages/466846003
              clientId: isCheckedECP ? clientIds.defaultECP : clientIds.default,
            });
          }
        });
        break;
      }
      case 1: {
        validateFields(['counterPartyId'], (err, val) => {
          if (!err) {
            const [clientId, counterPartyId] = val.counterPartyId.key.split('.');
            postLoginStep2(
              {
                clientId: clientIds[clientId],
                counterPartyId,
              },
              `${tokenType} ${accessToken}`,
            );
          }
        });
        break;
      }
      default:
        break;
    }
  };

  onChangeECP = (e) => {
    if (Array.isArray(e)) {
      this.setState({
        isCheckedECP: e.length !== 0,
        activeKey: e.length === 0 ? '' : '1',
      });
    } else {
      this.setState({
        isCheckedECP: e.target.value,
        activeKey: e.target.value ? '1' : '',
      });
    }
  };

  // beforeUpload = () => {
  // if (this.props.onChange) {
  // this.props.onChange(file);
  // }
  // return false;
  // };

  forgetPwd = () => {
    Modal.info({
      title: 'Відновлення пароля',
      content: (
        <div>
          <p>
            {`Якщо Ви загубили пароль до свого облікового запису - 
            будь ласка, зверніться до Адміністратора.`}
          </p>
        </div>
      ),
      okText: 'Зрозуміло',
    });
  };

  isValidFormField = (obj) => !Object.keys(obj).some((field) => obj[field]);

  validateForm = () => {
    const {
      form: { getFieldsError },
    } = this.props;

    switch (this.state.currentStep) {
      case 0: {
        const isValidStep1 = this.isValidFormField(getFieldsError(['login', 'pwd']));
        this.setState(() => ({ isValidStep1 }));
        break;
      }
      case 1: {
        const isValidStep2 = this.isValidFormField(getFieldsError(['counterPartyId']));
        this.setState(() => ({ isValidStep2 }));
        break;
      }
      default:
        break;
    }
  };

  goOut = () => {
    this.props.resetUserInfo();
    this.props.form.resetFields();
    this.setState({ ...this.initialState });
  };

  goOutWithPending = () => {
    this.setState({ isTimeOut: true });
    setTimeout(this.goOut, 3000);
  };

  getAlertDesc = () => (
    <p>
      {`Ви маєте`}
      <strong>5 хвилин </strong>
      {`для здійснення входу в систему. По закінченню часу Вас буде перенаправлено на екран аутентифікації.`}
    </p>
  );

  render() {
    const {
      form: { getFieldDecorator },
    } = this.props;

    const {
      currentStep,
      isTimeOut,
      isCheckedECP,
      activeKey,
      isValidStep1,
      isValidStep2,
      counterpartyArr,
    } = this.state;

    return (
      <div className="login-container">
        <Row className="login-container__form">
          <Col span={5} className="login-container__wrapper">
            <h1>Вхід в систему</h1>

            <Steps current={currentStep}>
              <Step title="Аутентифікація" />
              <Step title="Вибір контрагента" />
            </Steps>

            <Form className="login-form" onChange={this.validateForm}>
              {currentStep === 0 && (
                <div>
                  <FormItem label="Електронна адреса">
                    {getFieldDecorator('login', {
                      rules: [{ required: true, message: "Поле обов'язкове для заповнення!" }],
                    })(
                      <Input
                        prefix={<Icon type="mail" style={{ fontSize: 13 }} />}
                        placeholder="useremail@example.com"
                      />,
                    )}
                  </FormItem>

                  <FormItem label="Пароль">
                    {getFieldDecorator('pwd', {
                      rules: [{ required: true, message: "Поле обов'язкове для заповнення!" }],
                    })(
                      <Input
                        prefix={<Icon type="lock" style={{ fontSize: 13 }} />}
                        type="password"
                        placeholder="Введіть пароль користувача"
                      />,
                    )}
                  </FormItem>

                  <div style={{ textAlign: 'right' }}>
                    <a className="login-form-forgot" onClick={this.forgetPwd}>
                      {`Загубили пароль?`}
                    </a>
                  </div>

                  <Collapse onChange={this.onChangeECP} activeKey={activeKey}>
                    <Panel
                      key="1"
                      disabled
                      header={
                        <Checkbox
                          disabled
                          value={isCheckedECP}
                          checked={isCheckedECP}
                          onChange={this.onChangeECP}
                        >
                          {`Вхід з ЕЦП`}
                        </Checkbox>
                      }
                    >
                      <FormItem>
                        <div>* Файл-ключ</div>
                        {/* <Dragger
                          beforeUpload={this.beforeUpload}
                          style={{ fontSize: 13 }}
                        >
                          <Row>
                            <Col span={9} offset={1}>Натисніть для вибору файлу</Col>
                            <Col span={4}>
                              <p style={{ marginBottom: 0 }} className="ant-upload-drag-icon">
                                <Icon style={{ marginBottom: 0 }} type="cloud-upload" />
                              </p>
                            </Col>
                            <Col span={9} offset={1}>або перетягніть його сюди</Col>
                          </Row>
                        </Dragger> */}
                        <div>* Пароль до ключа</div>
                        <div>
                          {/* getFieldDecorator('passwordKey', {
                            rules: [{ required: true, message: 'Це поле обов`язкове!' }]
                          })(
                            <Input
                              prefix={<Icon type="lock" style={{ fontSize: 13 }} />}
                              type="password"
                              placeholder="Пароль до ключа"
                            />
                          ) */}
                        </div>
                        <div>* Сертифікат</div>
                        {/* <Dragger
                              beforeUpload={this.beforeUpload}
                              style={{ fontSize: 13 }}
                            >
                              <Row>
                                <Col span={9} offset={1}>Натисніть для вибору файлу</Col>
                                <Col span={4}>
                                  <p style={{ marginBottom: 0 }} className="ant-upload-drag-icon">
                                    <Icon style={{ marginBottom: 0 }} type="cloud-upload" />
                                  </p>
                                </Col>
                                <Col span={9} offset={1}>або перетягніть його сюди</Col>
                              </Row>
                            </Dragger> */}
                      </FormItem>
                    </Panel>
                  </Collapse>

                  <Button
                    size="large"
                    type="primary"
                    disabled={!isValidStep1}
                    className="login-form-button"
                    onClick={this.handleSubmit}
                    style={{ width: '100%', marginTop: '1rem' }}
                  >
                    {`Пройти аутентифікацію`}
                  </Button>
                </div>
              )}
              {currentStep === 1 && (
                <div>
                  <FormItem label="Контрагент">
                    {getFieldDecorator('counterPartyId', {
                      rules: [{ required: true, message: 'Це поле обов`язкове!' }],
                    })(
                      <Select
                        autoFocus
                        labelInValue
                        onChange={this.validateForm}
                        placeholder="Оберіть контрагента"
                      >
                        {counterpartyArr.map((el) => (
                          <Option key={el.value} value={`${el.counterpartyType}.${el.value}`}>
                            {`${el.label}`}
                          </Option>
                        ))}
                      </Select>,
                    )}
                  </FormItem>
                  <Alert
                    style={{ marginTop: '1rem' }}
                    description={this.getAlertDesc()}
                    type="warning"
                    showIcon
                  />

                  {isTimeOut && (
                    <p style={{ color: 'red', textAlign: 'center' }}>
                      {`Час закінчився. Виконується перенаправлення...`}
                    </p>
                  )}

                  {!isTimeOut && (
                    <p style={{ textAlign: 'center' }}>
                      {`Залишилось:  `}
                      <CountDown
                        style={{ fontSize: 14 }}
                        target={this.expires}
                        onEnd={this.goOutWithPending}
                      />
                      {`хв.`}
                    </p>
                  )}

                  <FormItem>
                    <Button
                      size="large"
                      type="primary"
                      disabled={!isValidStep2}
                      className="login-form-button"
                      onClick={this.handleSubmit}
                      style={{ width: '100%', marginTop: '1rem' }}
                    >
                      {`Увійти`}
                    </Button>
                    <p style={{ textAlign: 'center' }}>
                      <a onClick={this.goOut}>Вийти</a>
                      {` з облікового запису`}
                    </p>
                  </FormItem>
                </div>
              )}
            </Form>
          </Col>
        </Row>
      </div>
    );
  }
}

const LoginFormHOC = Form.create({
  mapPropsToFields() {
    return Object.keys(formFields).reduce(
      (formState, currField) => ({
        ...formState,
        [currField]: Form.createFormField(formFields[currField]),
      }),
      {},
    );
  },
})(LoginForm);

LoginForm.propTypes = {
  tokenInfo: PropTypes.shape({
    access_token: PropTypes.string,
    expires_in: PropTypes.number,
    scope: PropTypes.string,
    token_type: PropTypes.string,
  }).isRequired,
  selfCounterparty: PropTypes.objectOf(PropTypes.any).isRequired,
  form: PropTypes.objectOf(PropTypes.any).isRequired,
  getSelfCounterparty: PropTypes.func.isRequired,
  postLoginStep2: PropTypes.func.isRequired,
  resetUserInfo: PropTypes.func.isRequired,
  postLogin: PropTypes.func.isRequired,
};

const mapStateToProps = (state) => ({
  tokenInfo: state.user.userInfo.tokenInfo,
  selfCounterparty: state.user.userInfo.selfCounterparty,
});

export default withRouter(connect(mapStateToProps, userActions)(LoginFormHOC));
