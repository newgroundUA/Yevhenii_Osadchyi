import React, { Component } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import _ from 'lodash';

import { withRouter } from 'react-router-dom';
import { Pagination, Button } from 'antd';

import { corporateRightsRegisterSelector } from '../../selectors';

import * as RouteNames from '../../constants/RouteNames';
import * as appActions from '../../actions/appActions';
import * as commonActions from '../../actions';
import * as corporateRightsActions from '../../actions/modules/corporateRights/corporateRightsActions';
import * as usersActions from '../../actions/usersActions';

import TableToolbar from '../../components/common/toolbar/TableToolbar';
import Table from '../../components/common/table/Table';

const ButtonGroup = Button.Group;
const limitOption = ['25', '50', '100'];

class CorporateRightsRegisterContainer extends Component {
  checkedItems = [];

  componentDidMount() {
    this.props.getCorporateRightsRegister(this.props.requestBody);
  }

  componentWillReceiveProps(nextProps) {
    const { requestBody, getCorporateRightsRegister } = this.props;
    const { requestBody: nextRequestBody } = nextProps;
    if (!_.isEqual(requestBody, nextRequestBody)) {
      getCorporateRightsRegister(nextRequestBody);
    }
  }

  getSortedColumns = (columns) =>
    Object.values(columns)
      .sort((a, b) => a.position - b.position)
      .reduce((sum, el) => ({ ...sum, [el.colName]: el }), {});

  handleSortColumn = () => {};

  saveTableSettings = () => {};

  handleChangeLimit = (current, pageSize) => {
    const { setValueRequestBody, setValuePages } = this.props;

    setValueRequestBody('limit', pageSize);
    setValueRequestBody('offset', '0');
    setValuePages('currentPage', 1);
  };

  handleToggleToolbarItem = (value) => {
    const toolbarItems = this.props.tableToolbar;
    const curSection = Object.keys(toolbarItems).find((key) =>
      Object.keys(toolbarItems[key]).includes(value),
    );
    const isVisible = toolbarItems[curSection][value].isVisible;
    this.props.setValueAppSettings(
      ['components', 'corporateRights', 'register', 'tableToolbar', curSection, value, 'isVisible'],
      !isVisible,
    );
  };

  handleChangeColumns = (obj) => {
    this.props.setValueAppSettings(
      ['components', 'corporateRights', 'register', 'tableBody', 'columns', 'fluid'],
      { ...this.props.tableBody.columns.fluid, ...obj },
    );
  };

  // handleSubmitFilters = () => {};

  // handleCancelFilters = () => {};

  handleChangePage = (page, pageSize) => {
    const {
      setValueRequestBody,
      setValuePages,
      pages: { currentPage },
    } = this.props;

    if (currentPage !== page) {
      const offset = (pageSize * page - pageSize).toString();
      setValueRequestBody('offset', offset);
      setValuePages('currentPage', page);
    }
  };

  syncronizeCheckedArr = (arr = [], rows) => {
    this.checkedItems = arr.map((key) => rows[key].guid);
  };

  syncronizeCheckedArr = (arr = [], rows) => {
    this.checkedItems = arr.map((key) => rows[key].guid);
  };

  render() {
    const {
      registers,
      requestBody: { limit },
      tableBody,
      history,
      tableToolbar,
      pages: { totalFinded, currentPage },
    } = this.props;

    // const filters = () => {};

    const sortedColumns = {
      fixed: this.getSortedColumns(tableBody.columns.fixed),
      fluid: this.getSortedColumns(tableBody.columns.fluid),
    };

    return (
      <div className="content__table-items">
        <div className="content__table-menu">
          <TableToolbar
            items={tableToolbar}
            limitOption={limitOption}
            changedLimit={limit}
            handleChangeLimit={this.handleChangeLimit}
            handleToggleToolbarItem={this.handleToggleToolbarItem}
            isActive={false}
            columns={sortedColumns}
            handleClickToolbarItem={() => {}}
            handleChangeColumns={this.handleChangeColumns}
            setValueRequestBody={() => {}}
            columnsForFilter={[]}
          >
            <ButtonGroup>
              <Button
                type="primary"
                size="large"
                onClick={() =>
                  this.props.history.push(
                    `/${RouteNames.CORPORATE_RIGHTS}/${RouteNames.FORM_CORPORATE_RIGHTS}/${
                      RouteNames.CREATE
                    }`,
                  )
                }
              >
                {`+ Картка на корпоративні права`}
              </Button>
            </ButtonGroup>
          </TableToolbar>
        </div>

        {/* <div className="content__fast-filters">
          <FastFiltersPanel
            useAll={this.handleSubmitFilters}
            cancelAll={this.handleCancelFilters}
            filters={filters}
            totalFinded={totalFinded}
          >
            <div className="table-menu__icon">
              <Icon type="filter" />
            </div>
            <Select
              mode="multiple"
              style={{ minWidth: 200 }}
              allowClear
              placeholder="Швидкий фільтр"
            />
          </FastFiltersPanel>
        </div> */}

        <div className="content__table">
          <Table
            history={history}
            columnsData={tableBody.columns || {}}
            syncronizeCheckedArr={this.syncronizeCheckedArr}
            rows={registers}
            saveTableWidthSettings={this.saveTableSettings}
            sortList={[]}
            handleSortColumn={this.handleSortColumn}
          />
        </div>

        <div className="content__pagination">
          <Pagination
            showSizeChanger
            pageSize={+limit}
            total={totalFinded}
            current={currentPage}
            pageSizeOptions={limitOption}
            onChange={this.handleChangePage}
            onShowSizeChange={this.handleChangeLimit}
            showTotal={(total) => `Знайдено: ${total}`}
          />
        </div>
      </div>
    );
  }
}

CorporateRightsRegisterContainer.defaultProps = {
  requestBody: {},
  tableToolbar: {},
  // fastFilters: {},
};

CorporateRightsRegisterContainer.propTypes = {
  pages: PropTypes.shape({
    currentPage: PropTypes.number,
    totalPages: PropTypes.number,
    totalFinded: PropTypes.number,
  }).isRequired,
  history: PropTypes.objectOf(PropTypes.any).isRequired,
  registers: PropTypes.arrayOf(PropTypes.object).isRequired,
  requestBody: PropTypes.shape({
    countAll: PropTypes.bool,
    limit: PropTypes.string,
    offset: PropTypes.string,
    filter: PropTypes.arrayOf(PropTypes.object),
  }),
  tableToolbar: PropTypes.objectOf(PropTypes.any),
  tableBody: PropTypes.objectOf(PropTypes.any).isRequired,

  getCorporateRightsRegister: PropTypes.func.isRequired,
  setValueRequestBody: PropTypes.func.isRequired,
  setValueAppSettings: PropTypes.func.isRequired,
  setValuePages: PropTypes.func.isRequired,
};

export default withRouter(
  connect(corporateRightsRegisterSelector, {
    ...appActions,
    ...commonActions,
    ...corporateRightsActions,
    ...usersActions,
  })(CorporateRightsRegisterContainer),
);
