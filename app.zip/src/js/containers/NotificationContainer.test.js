import React from 'react';
import reactTestRender from 'react-test-renderer';
import { NotificationContainer } from './NotificationContainer';

describe('NotificationContainer', () => {
  test('Test render snapshot', () => {
    const component = reactTestRender
      .create(
        <NotificationContainer
          isSuccessMessage={false}
          isErrorMessage={false}
          isInfoMessage={false}
          closeMessage={() => {}}
          messageData={{}}
        />,
      )
      .toJSON();

    expect(component).toMatchSnapshot();
  });
});
