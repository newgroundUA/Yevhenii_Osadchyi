import React from 'react';

import { connect } from 'react-redux';
import PropTypes from 'prop-types';

import { Route, Link, Redirect, withRouter, Switch } from 'react-router-dom';

import { Breadcrumb, Icon } from 'antd';
import Routes from '../constants/Routes';
import { CREATE, VIEW, EDIT, NOT_FOUND, COUNTERPARTIES, REGISTER } from '../constants/RouteNames';
import Sidebar from '../components/navigation/Sidebar';
import { isGuidFormat } from '../services/validator/valiators';

const RouteWithSubRoutes = (route) => (
  <Route
    path={route.path}
    // exact={route.isExact}
    render={(props) => <route.component {...props} routes={route.routes} />}
  />
);

class ContentContainer extends React.Component {
  breadcrumbNameMap = {};

  componentWillMount() {
    this.generateBreadcrumbs(this.props);
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.location.pathname !== this.props.location.pathname) {
      this.generateBreadcrumbs(nextProps);
    }
  }

  generateBreadcrumbs = (props) => {
    const { menuItems, location } = props;

    const pagesArr = Object.keys(menuItems);
    const pathname = location.pathname;
    const pathnameArr = pathname.split('/');
    const strGuid = pathnameArr[pathnameArr.length - 1];
    const isGuid = isGuidFormat(strGuid);

    // eslint-disable-next-line
    pagesArr.map((page) => {
      const containersArr = Object.keys(menuItems[page].children);

      this.breadcrumbNameMap = {
        ...this.breadcrumbNameMap,
        [`/${page}`]: menuItems[page].text,
      };
      // eslint-disable-next-line
      containersArr.map((container) => {
        // eslint-disable-next-line
        if (menuItems[page].children[container].hasOwnProperty('route')) {
          let subRoute = {};
          if (pathname.includes(CREATE)) {
            subRoute = {
              [`/${page}/${container}/${CREATE}`]: 'Створення',
            };
          } else if (pathname.includes(VIEW) && isGuid) {
            subRoute = {
              [`/${page}/${container}/${VIEW}`]: 'Перегляд',
              [`/${page}/${container}/${VIEW}/${strGuid}`]: 'Форми',
            };
          } else if (pathname.includes(EDIT) && isGuid) {
            subRoute = {
              [`/${page}/${container}/${EDIT}`]: 'Редагування',
              [`/${page}/${container}/${EDIT}/${strGuid}`]: 'Форми',
            };
          }

          this.breadcrumbNameMap = {
            ...this.breadcrumbNameMap,
            [`/${page}/${container}`]: menuItems[page].children[container].text,
            ...subRoute,
          };
        }
      });
    });
  };

  render() {
    if (!this.props.menuItems.administration) return <div />;

    const { location } = this.props;
    const pathSnippets = location.pathname.split('/').filter((i) => i);
    const extraBreadcrumbItems = pathSnippets.map((_, index) => {
      const url = `/${pathSnippets.slice(0, index + 1).join('/')}`;
      return (
        <Breadcrumb.Item key={url}>
          {
            // <Link to={url}>
            //   {this.breadcrumbNameMap[objKey]}
            // </Link>
          }
          {this.breadcrumbNameMap[url]}
        </Breadcrumb.Item>
      );
    });

    const breadcrumbItems = [
      <Breadcrumb.Item key="home">
        <Link to="/">
          <Icon type="home" />
        </Link>
      </Breadcrumb.Item>,
    ].concat(extraBreadcrumbItems);

    return (
      <div className="content">
        <div className="content__menu">
          <Route
            path="/:page?/:component?"
            render={(props) => {
              const page = props.match.params.page || '';
              const component = props.match.params.component || '';
              return (
                <Sidebar
                  items={this.props.menuItems[page] ? this.props.menuItems[page].children : {}}
                  routePage={page}
                  routeComponent={component}
                />
              );
            }}
          />
        </div>
        <div className="content__main">
          <Breadcrumb>{breadcrumbItems}</Breadcrumb>
          <Switch>
            {Routes.map((route, i) => <RouteWithSubRoutes key={i} {...route} />)}
            <Redirect exact from="/" to={`/${COUNTERPARTIES}/${REGISTER}`} />
            <Redirect to={`/${NOT_FOUND}`} />
          </Switch>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  menuItems: state.menuItems.leftMenuItems,
});

const mapDispatchToProps = () => ({});

ContentContainer.propTypes = {
  menuItems: PropTypes.objectOf(PropTypes.object).isRequired,
  location: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(ContentContainer));
