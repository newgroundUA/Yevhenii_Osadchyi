import React from 'react';
import { render } from 'react-dom';
import axios from 'axios';
import { createBrowserHistory } from 'history';

import 'froala-editor/js/froala_editor.pkgd.min';
import 'froala-editor/css/froala_style.min.css';
import 'froala-editor/css/froala_editor.pkgd.min.css';

import 'font-awesome/css/font-awesome.css';
import './assets/favicon.ico';
import './main.scss';

import { baseURL } from './js/api/config';

import configureStore from './js/store/configureStore';
import { runHandlerOfErrors } from './js/helpers/productionHandlerOfErrors';

const axiosV2 = axios.create({ baseURL });

const history = createBrowserHistory();
const store = configureStore(axiosV2, axios, history);

if (process.env.NODE_ENV === 'production') {
  runHandlerOfErrors();
}

const renderApp = () => {
  const RootComp = require('./js/containers/root/Root').default;
  render(<RootComp store={store} history={history} />, document.getElementById('root'));
};

if (module.hot) {
  module.hot.accept('./js/containers/root/Root', () => renderApp());
}

renderApp();
